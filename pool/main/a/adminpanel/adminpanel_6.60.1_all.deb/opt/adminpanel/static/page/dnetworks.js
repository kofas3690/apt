const $ = (id) => document.getElementById(id);

async function api(path, opts) {
  const r = await fetch(path, opts);
  if (r.status === 401) { location.href = "/login.html"; throw new Error("not logged in"); }
  return r;
}
async function errText(r) {
  try { const j = await r.json(); if (typeof j.detail === "string") return j.detail; } catch (e) {}
  return "Request failed (" + r.status + ")";
}
function el(tag, text, cls) { const e = document.createElement(tag); if (text !== undefined) e.textContent = text; if (cls) e.className = cls; return e; }

async function remove(n, btn) {
  if (!confirm("Remove the network \"" + n.name + "\"?\n\nNo container uses it. Compose recreates its own networks when you start the project again.")) return;
  $("err").textContent = ""; btn.disabled = true; btn.textContent = "Removing…";
  const r = await api("/api/dnetworks/remove", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name: n.name }) });
  if (!r.ok) $("err").textContent = n.name + ": " + await errText(r);
  load();
}

function draw(d) {
  const tb = $("rows"); tb.replaceChildren();
  if (!d.installed) { $("banner").textContent = "Docker is not installed on this machine. Install the package docker.io on the Packages page."; return; }
  if (!d.running) { $("banner").textContent = "Docker is installed but its service is not running" + (d.error ? " (" + d.error + ")" : "") + ". Start the docker service on the Services page."; return; }
  $("banner").textContent = d.networks.length + " network" + (d.networks.length === 1 ? "" : "s") + ".";
  if (!d.networks.length) { const tr = el("tr"), td = el("td", "No networks.", "muted"); td.colSpan = 5; tr.append(td); tb.append(tr); }
  for (const n of d.networks) {
    const tr = el("tr"), first = el("td", undefined, "m");
    first.append(el("b", n.name));
    first.append(document.createElement("br"));
    first.append(el("span", n.id + " · " + n.scope + (n.internal ? " · internal" : "") + (n.project ? " · Compose: " + n.project : "") + (n.builtin ? " · built in" : ""), "muted"));
    tr.append(first, el("td", n.driver), el("td", n.subnets.length ? n.subnets.join("\n") : "–", "m"));
    const used = n.container_count;
    const c = el("td", used ? n.containers.join("\n") + (used > n.containers.length ? "\n+" + (used - n.containers.length) + " more" : "") : (used === 0 ? "None" : "Unknown"), used ? "ok m" : "muted");
    tr.append(c);
    const ac = el("td");
    if (!n.builtin && used === 0) { const b = el("button", "Remove…"); b.onclick = () => remove(n, b); ac.append(b); }
    tr.append(ac); tb.append(tr);
  }
}

async function load() {
  const r = await api("/api/dnetworks");
  if (!r.ok) { $("err").textContent = await errText(r); return; }
  draw(await r.json());
}
load();
