"use strict";
/* A small code editor for the panel: line numbers, colours, indenting, find and replace.
 *
 * No libraries and nothing is fetched from the internet. The person types into a see-through
 * <textarea>; a coloured copy of the same text sits exactly behind it, so the browser keeps the
 * caret, the selection, undo, spell-check settings and IME input, and we only paint colours.
 *
 *   const ed = CodeEditor.attach(hostDiv, { text: "...", name: "nginx.conf", onSave: fn });
 *   ed.getText()  ed.setText(s)  ed.dirty  ed.markSaved()  ed.focus()  ed.destroy()
 *
 * CodeEditor.languageFor(name, firstLine) picks the language and CodeEditor.highlight(text, id)
 * returns the coloured HTML. Both are plain functions of their input, so they can be tested
 * without a browser (tests/test_editor.py runs them under node).
 */
const CodeEditor = (() => {

/* ---------------- pieces every language is built from ---------------- */
const ID = "[A-Za-z_$][A-Za-z0-9_$]*";
const STR2 = '"(?:\\\\[\\s\\S]|[^"\\\\\\n])*"?';          // "double quoted", one line
const STR1 = "'(?:\\\\[\\s\\S]|[^'\\\\\\n])*'?";          // 'single quoted', one line
const STR2M = '"(?:\\\\[\\s\\S]|[^"\\\\])*"?';            // "double quoted" that may run over lines
const STR1M = "'(?:\\\\[\\s\\S]|[^'\\\\])*'?";
const BACKTICK = "`(?:\\\\[\\s\\S]|[^`\\\\])*`?";
const CBLOCK = "/\\*[\\s\\S]*?(?:\\*/|$)";
const NUM = "\\b(?:0[xX][0-9a-fA-F_]+|0[bB][01_]+|0[oO][0-7_]+|\\d[\\d_]*(?:\\.\\d[\\d_]*)?(?:[eE][+-]?\\d+)?)\\b";
const OPS = "[+\\-*/%=!<>&|^~?]+";
const line = (start) => start + "[^\\n]*";                 // a comment to the end of the line
const words = (s) => "\\b(?:" + s.trim().split(/\s+/).join("|") + ")\\b";
const call = "\\b" + ID + "(?=\\s*\\()";                   // a name with a ( after it: a call

/* A language is a list of [class, regex source] rules, tried in the order given. Classes:
   c comment, s string, n number, k keyword, y type or built-in name, f function name,
   t tag, a attribute or key, v variable, m meta (decorator, annotation, preprocessor),
   o operator, g added line (diffs), d removed line (diffs). */
const L = {};
function def(id, name, ext, rules, flags) {
  L[id] = { id, name, ext: ext ? ext.split(" ") : [], rules, flags: flags || "gm" };
}

const C_LIKE = (kw, ty) => [
  ["c", CBLOCK], ["c", line("//")],
  ["s", STR2], ["s", STR1], ["n", NUM],
  ["k", words(kw)], ["y", words(ty)], ["f", call], ["o", OPS],
];

def("plain", "Plain text", "txt text log list", []);

def("python", "Python", "py pyw pyi", [
  ["s", "(?:[rRbBuUfF]{0,2})\"\"\"[\\s\\S]*?(?:\"\"\"|$)"],
  ["s", "(?:[rRbBuUfF]{0,2})'''[\\s\\S]*?(?:'''|$)"],
  ["c", line("#")],
  ["s", "(?:[rRbBuUfF]{0,2})" + STR2], ["s", "(?:[rRbBuUfF]{0,2})" + STR1],
  ["m", "@[A-Za-z_][\\w.]*"],
  ["n", NUM],
  ["k", words("and as assert async await break class continue def del elif else except finally for from global if import in is lambda match case nonlocal not or pass raise return try while with yield")],
  ["y", words("True False None self cls bool bytes dict float int list object set str tuple len range print open enumerate zip sorted sum min max abs any all isinstance getattr setattr hasattr super Exception ValueError TypeError KeyError IndexError OSError RuntimeError __init__ __main__ __name__")],
  ["f", call], ["o", OPS],
]);

def("javascript", "JavaScript", "js mjs cjs jsx", [
  ["c", CBLOCK], ["c", line("//")],
  ["s", BACKTICK], ["s", STR2], ["s", STR1], ["n", NUM],
  ["k", words("async await break case catch class const continue debugger default delete do else export extends finally for from function get if import in instanceof let new of return set static super switch this throw try typeof var void while with yield")],
  ["y", words("true false null undefined NaN Infinity Array Boolean Date Error JSON Map Math Number Object Promise RegExp Set String Symbol console document window globalThis fetch localStorage require module exports")],
  ["f", call], ["o", OPS],
]);

def("typescript", "TypeScript", "ts tsx mts", [
  ["c", CBLOCK], ["c", line("//")],
  ["s", BACKTICK], ["s", STR2], ["s", STR1], ["n", NUM],
  ["k", words("abstract as async await break case catch class const continue declare default delete do else enum export extends finally for from function get if implements import in infer instanceof interface keyof let namespace new of private protected public readonly return satisfies set static super switch this throw try type typeof var void while yield")],
  ["y", words("any boolean never number object string symbol unknown void true false null undefined Array Promise Record Partial Map Set console document window")],
  ["f", call], ["o", OPS],
]);

def("json", "JSON", "json jsonc map lock", [
  ["c", CBLOCK], ["c", line("//")],
  ["a", '"(?:\\\\[\\s\\S]|[^"\\\\])*"(?=\\s*:)'],
  ["s", STR2], ["n", NUM],
  ["y", words("true false null")], ["o", "[:,]"],
]);

def("html", "HTML", "html htm xhtml shtml", [
  ["c", "<!--[\\s\\S]*?(?:-->|$)"],
  ["m", "<![^>]*>"],
  ["t", "</?[A-Za-z][\\w:.-]*"], ["t", "/?>"],
  ["a", "[A-Za-z_:][\\w:.-]*(?=\\s*=)"],
  ["s", STR2M], ["s", STR1M],
  ["n", "&(?:#\\d+|#[xX][0-9a-fA-F]+|[A-Za-z][\\w]*);"],
]);
L.html.parts = true;                                        // <script> and <style> get their own colours

def("xml", "XML", "xml svg xsl xsd rss plist pom", L.html.rules);

def("css", "CSS", "css", [
  ["c", CBLOCK],
  ["k", "@[-\\w]+"], ["k", "!important"],
  ["s", STR2M], ["s", STR1M],
  ["a", "[-A-Za-z][-\\w]*(?=\\s*:)"],
  ["n", "#[0-9a-fA-F]{3,8}\\b"],
  ["n", "\\b\\d*\\.?\\d+(?:px|r?em|%|vh|vw|vmin|vmax|fr|ch|ex|deg|m?s|pt|cm|mm|in|dpi)?\\b"],
  ["f", "[-\\w]+(?=\\()"],
  ["y", "::?[a-z][-\\w]*(?:\\([^)]*\\))?"],
  ["t", "\\.[-\\w]+|#[-A-Za-z][-\\w]*"],
]);
def("scss", "Sass or Less", "scss sass less", [
  ["c", CBLOCK], ["c", line("//")],
  ["v", "[$@][-\\w]+"],
].concat(L.css.rules.slice(1)));

def("bash", "Shell", "sh bash zsh ksh bashrc profile bash_profile zshrc", [
  ["c", line("#")],
  ["s", STR2M], ["s", "\\$?" + STR1M],
  ["v", "\\$(?:\\{[^}\\n]*\\}|[A-Za-z_]\\w*|[0-9@*#?$!_-])"],
  ["n", NUM],
  ["k", words("if then else elif fi for while until do done case esac in function select time coproc return break continue exit local export readonly declare typeset source eval exec trap shift set unset shopt let")],
  ["y", words("echo printf read cd pwd ls cp mv rm mkdir rmdir ln touch chmod chown chgrp cat head tail grep sed awk cut sort uniq wc find xargs tar gzip curl wget ssh scp rsync sudo su systemctl service journalctl apt apt-get dpkg test true false kill ps df du date sleep mktemp basename dirname realpath")],
  ["m", "^#!.*"],
  ["f", call], ["o", OPS],
]);

def("java", "Java", "java", [
  ["c", CBLOCK], ["c", line("//")],
  ["s", STR2], ["s", STR1], ["m", "@[A-Za-z_]\\w*"], ["n", NUM + "[lLfFdD]?"],
  ["k", words("abstract assert break case catch class const continue default do else enum extends final finally for goto if implements import instanceof interface native new package permits private protected public record return sealed static strictfp super switch synchronized this throw throws transient try var void volatile while yield")],
  ["y", words("boolean byte char double float int long short true false null String Integer Long Double Float Boolean Object System List Map Set ArrayList HashMap Exception Override")],
  ["y", "\\b[A-Z][A-Za-z0-9_]*\\b"],
  ["f", call], ["o", OPS],
]);

def("c", "C or C++", "c h cpp cc cxx hpp hh ino", [
  ["c", CBLOCK], ["c", line("//")],
  ["m", "^[ \\t]*#[ \\t]*\\w+"],
  ["s", STR2], ["s", STR1], ["n", NUM + "[uUlLfF]*"],
  ["k", words("alignas auto break case catch class const constexpr continue default delete do else enum explicit export extern for friend goto if inline namespace new noexcept nullptr operator private protected public register return sizeof static static_cast struct switch template this throw try typedef typename union using virtual volatile while")],
  ["y", words("bool char double float int long short signed unsigned void size_t ssize_t uint8_t uint16_t uint32_t uint64_t int8_t int16_t int32_t int64_t FILE NULL true false std string vector map")],
  ["f", call], ["o", OPS],
]);

def("go", "Go", "go", [
  ["c", CBLOCK], ["c", line("//")],
  ["s", BACKTICK], ["s", STR2], ["s", STR1], ["n", NUM],
  ["k", words("break case chan const continue default defer else fallthrough for func go goto if import interface map package range return select struct switch type var")],
  ["y", words("bool byte complex64 complex128 error float32 float64 int int8 int16 int32 int64 rune string uint uint8 uint16 uint32 uint64 uintptr nil true false iota make new len cap append copy delete panic recover print println")],
  ["f", call], ["o", OPS],
]);

def("rust", "Rust", "rs", [
  ["c", CBLOCK], ["c", line("//")],
  ["m", "#!?\\[[^\\]]*\\]"],
  ["s", "r?#*" + STR2], ["s", "'(?:\\\\.|[^'\\\\])'"], ["v", "'[a-z_]\\w*"],
  ["n", NUM + "(?:[iuf](?:8|16|32|64|128|size))?"],
  ["k", words("as async await break const continue crate dyn else enum extern fn for if impl in let loop match mod move mut pub ref return self Self static struct super trait type unsafe use where while")],
  ["y", words("bool char f32 f64 i8 i16 i32 i64 i128 isize str u8 u16 u32 u64 u128 usize String Vec Option Result Box Some None Ok Err true false")],
  ["f", "\\b" + ID + "!?(?=\\s*[(!\\[])"], ["o", OPS],
]);

def("php", "PHP", "php phtml", [
  ["m", "<\\?php|<\\?=|\\?>"],
  ["c", CBLOCK], ["c", line("//")], ["c", line("#")],
  ["s", STR2M], ["s", STR1M], ["v", "\\$\\w+"], ["n", NUM],
  ["k", words("abstract and array as break callable case catch class clone const continue declare default do echo else elseif empty enddeclare endfor endforeach endif endswitch endwhile enum extends final finally fn for foreach function global goto if implements include include_once instanceof insteadof interface isset list match namespace new or print private protected public readonly require require_once return static switch throw trait try unset use var while xor yield")],
  ["y", words("true false null int float string bool void array object self parent")],
  ["f", call], ["o", OPS],
]);

def("ruby", "Ruby", "rb gemspec rake", [
  ["c", "^=begin[\\s\\S]*?^=end"], ["c", line("#")],
  ["s", STR2M], ["s", STR1M], ["v", "[@$]{1,2}\\w+"], ["y", ":[A-Za-z_]\\w*[?!]?"], ["n", NUM],
  ["k", words("alias and begin break case class def defined do else elsif end ensure false for if in module next nil not or redo require require_relative rescue retry return self super then true undef unless until when while yield attr_accessor attr_reader attr_writer")],
  ["f", call], ["o", OPS],
]);

def("perl", "Perl", "pl pm t", [
  ["c", line("#")], ["s", STR2M], ["s", STR1M],
  ["v", "[$@%]\\{?[A-Za-z_]\\w*\\}?"], ["n", NUM],
  ["k", words("and cmp continue do else elsif eq eval exit for foreach ge gt if last le local lt my ne next no not or our package print printf push pop redo ref require return shift sub trreturn unless unshift until use wantarray while")],
  ["f", call], ["o", OPS],
]);

def("lua", "Lua", "lua", [
  ["c", "--\\[\\[[\\s\\S]*?(?:\\]\\]|$)"], ["c", line("--")],
  ["s", "\\[\\[[\\s\\S]*?(?:\\]\\]|$)"], ["s", STR2], ["s", STR1], ["n", NUM],
  ["k", words("and break do else elseif end for function goto if in local nil not or repeat return then until while")],
  ["y", words("true false self print pairs ipairs type tostring tonumber require table string math os io")],
  ["f", call], ["o", OPS],
]);

def("sql", "SQL", "sql", [
  ["c", CBLOCK], ["c", line("--")],
  ["s", STR1M], ["s", '"[^"\\n]*"'], ["s", "`[^`\\n]*`"], ["n", NUM],
  ["k", words("add all alter and as asc begin between by case cascade check column commit constraint create cross current_timestamp database default delete desc distinct drop else end exists foreign from full group having if in index inner insert into is join key left like limit not null offset on or order outer primary references rename replace return right rollback select set table then to transaction union unique update values view when where with")],
  ["y", words("bigint blob boolean char date datetime decimal double float int integer json numeric real serial smallint text time timestamp uuid varchar true false")],
  ["f", call],
], "gmi");

def("yaml", "YAML", "yml yaml", [
  ["c", line("#")],
  ["m", "^(?:---|\\.\\.\\.)[ \\t]*$"],
  ["a", "^[ \\t]*(?:-[ \\t]+)?[\\w.$/-]+(?=[ \\t]*:(?:[ \\t]|$))"],
  ["s", STR2M], ["s", STR1M],
  ["v", "[&*][\\w-]+"],
  ["y", "\\b(?:true|false|null|yes|no|on|off|~)\\b"], ["n", NUM],
]);

def("ini", "Config file", "ini cfg conf config properties env rc toml desktop service timer socket mount target path network netdev link sources repo", [
  ["c", line("#")], ["c", line(";")],
  ["k", "^[ \\t]*\\[[^\\]\\n]*\\]"],
  ["a", "^[ \\t]*[\\w.$@\\\\/-]+(?=[ \\t]*[=:])"],
  ["s", STR2M], ["s", STR1M],
  ["v", "\\$(?:\\{[^}\\n]*\\}|\\w+)"],
  ["y", "\\b(?:true|false|yes|no|on|off|none)\\b"], ["n", NUM],
]);

def("nginx", "nginx", "", [
  ["c", line("#")],
  ["s", STR2M], ["s", STR1M],
  ["v", "\\$\\w+"],
  ["k", words("server location upstream http events listen server_name root index try_files proxy_pass proxy_set_header include return rewrite ssl_certificate ssl_certificate_key access_log error_log client_max_body_size add_header gzip map if set limit_req worker_processes worker_connections")],
  ["n", NUM], ["o", "[{};]"],
]);

def("dockerfile", "Dockerfile", "dockerfile containerfile", [
  ["c", line("#")],
  ["k", "^[ \\t]*(?:FROM|RUN|CMD|LABEL|MAINTAINER|EXPOSE|ENV|ADD|COPY|ENTRYPOINT|VOLUME|USER|WORKDIR|ARG|ONBUILD|STOPSIGNAL|HEALTHCHECK|SHELL)\\b"],
  ["s", STR2M], ["s", STR1M], ["v", "\\$(?:\\{[^}\\n]*\\}|\\w+)"], ["n", NUM],
  ["y", "\\bAS\\b"],
], "gmi");

def("makefile", "Makefile", "mk make mak", [
  ["c", line("#")],
  ["f", "^[A-Za-z0-9_./%$()-]+(?=[ \\t]*:(?!=))"],
  ["v", "\\$[({]?\\w+[)}]?"],
  ["k", words("ifeq ifneq ifdef ifndef else endif include export unexport define endef override")],
  ["s", STR2M], ["s", STR1M],
]);

def("markdown", "Markdown", "md markdown mdown", [
  ["s", "```[\\s\\S]*?(?:```|$)"], ["s", "`[^`\\n]*`"],
  ["k", "^#{1,6}[ \\t].*"],
  ["c", "^>.*"],
  ["y", "\\*\\*[^*\\n]+\\*\\*|__[^_\\n]+__"],
  ["m", "\\*[^*\\n]+\\*|_[^_\\n]+_"],
  ["f", "\\[[^\\]\\n]*\\]\\([^)\\n]*\\)"],
  ["o", "^[ \\t]*(?:[-*+]|\\d+\\.)[ \\t]"],
  ["t", "^(?:---+|===+)[ \\t]*$"],
]);

def("diff", "Diff or patch", "diff patch", [
  ["c", "^(?:diff |index |--- |\\+\\+\\+ |old mode|new mode|similarity|rename ).*"],
  ["k", "^@@.*"],
  ["g", "^\\+.*"], ["d", "^-.*"],
]);

/* Files with no extension, or a name that says more than the extension does. */
const BY_NAME = {
  dockerfile: "dockerfile", containerfile: "dockerfile", makefile: "makefile", gnumakefile: "makefile",
  "nginx.conf": "nginx", "default": "nginx", "docker-compose.yml": "yaml", "docker-compose.yaml": "yaml",
  "cmakelists.txt": "c", "fstab": "ini", "hosts": "ini", "crontab": "bash", "authorized_keys": "plain",
  "sshd_config": "ini", "ssh_config": "ini", "sudoers": "ini", "passwd": "ini", "group": "ini",
  ".bashrc": "bash", ".profile": "bash", ".bash_profile": "bash", ".zshrc": "bash", ".gitignore": "ini",
  ".env": "ini", "package.json": "json", "requirements.txt": "ini", "robots.txt": "ini",
};
const BY_SHEBANG = [
  [/\bpython[\d.]*\b/, "python"], [/\b(?:ba|z|k|da)?sh\b/, "bash"], [/\bnode\b/, "javascript"],
  [/\bperl\b/, "perl"], [/\bruby\b/, "ruby"], [/\bphp\b/, "php"], [/\blua\b/, "lua"],
];

const EXT_MAP = (() => {
  const m = {};
  for (const id in L) for (const e of L[id].ext) if (!(e in m)) m[e] = id;
  return m;
})();

/* Which language a file is written in: its name (a whole path is welcome) first, then the #! line. */
function languageFor(name, firstLine) {
  const full = String(name || "").toLowerCase();
  const low = full.split("/").pop();
  if (BY_NAME[low]) return BY_NAME[low];
  const dot = low.lastIndexOf(".");
  const ext = dot > 0 ? low.slice(dot + 1) : "";
  if ((!ext || ext === "conf") && /nginx|sites-available|sites-enabled/.test(full)) return "nginx";
  if (ext && EXT_MAP[ext]) return EXT_MAP[ext];
  if (low.startsWith("dockerfile")) return "dockerfile";
  const sb = String(firstLine || "");
  if (sb.startsWith("#!")) for (const [re, id] of BY_SHEBANG) if (re.test(sb)) return id;
  if (!ext && /^<\?xml|^<!doctype html/i.test(sb)) return "html";
  return "plain";
}
const languages = () => Object.keys(L).map((id) => ({ id, name: L[id].name }));

/* ---------------- colouring ---------------- */
const esc = (s) => s.replace(/[&<>]/g, (c) => (c === "&" ? "&amp;" : c === "<" ? "&lt;" : "&gt;"));

/* One regex per language: every rule becomes a named group, so the first rule that matches at the
   earliest position wins. Comments and strings come first, which is what keeps a keyword inside a
   string plain. Built once, then kept on the language. */
function compiled(lang) {
  if (lang._re !== undefined) return lang._re;
  lang._re = null;
  if (lang.rules && lang.rules.length) {
    const src = lang.rules.map(([cls, re], i) => "(?<g" + i + ">" + re + ")").join("|");
    try {
      lang._re = new RegExp(src, lang.flags);
      lang._cls = lang.rules.map(([cls]) => cls);
    } catch (e) {
      lang._re = null;                                      // a bad rule must never stop the editor
    }
  }
  return lang._re;
}

function tokenize(text, lang) {
  if (!text) return "";
  const re = compiled(lang);
  if (!re) return esc(text);
  re.lastIndex = 0;
  let out = "", last = 0, m, guard = 0;
  while ((m = re.exec(text)) !== null) {
    if (!m[0]) { re.lastIndex++; continue; }
    if (++guard > 200000) break;                            // never spin on a strange file
    if (m.index > last) out += esc(text.slice(last, m.index));
    let cls = "o";
    for (const k in m.groups) if (m.groups[k] !== undefined) { cls = lang._cls[+k.slice(1)]; break; }
    out += '<span class="t-' + cls + '">' + esc(m[0]) + "</span>";
    last = re.lastIndex;
  }
  return out + esc(text.slice(last));
}

/* Coloured HTML for the whole text. In an HTML file the <script> and <style> bodies are coloured
   as JavaScript and CSS, the way an editor would. */
function highlight(text, id) {
  const lang = L[id] || L.plain;
  if (!lang.parts) return tokenize(text, lang);
  const re = /(<(script|style)\b[^>]*>)([\s\S]*?)(<\/\2\s*>)/gi;
  let out = "", last = 0, m;
  while ((m = re.exec(text)) !== null) {
    out += tokenize(text.slice(last, m.index), lang) + tokenize(m[1], lang);
    out += tokenize(m[3], m[2].toLowerCase() === "script" ? L.javascript : L.css);
    out += tokenize(m[4], lang);
    last = re.lastIndex;
  }
  return out + tokenize(text.slice(last), lang);
}

/* ---------------- the editor itself ---------------- */
const BIG = 160000;                                          // above this many characters, colours go off
const PAIRS = { "(": ")", "[": "]", "{": "}", '"': '"', "'": "'", "`": "`" };
const CLOSERS = ")]}\"'`";
const COMMENT = {
  python: "#", bash: "#", yaml: "#", ini: "#", nginx: "#", dockerfile: "#", makefile: "#",
  ruby: "#", perl: "#", plain: "#", diff: "#",
  javascript: "//", typescript: "//", json: "//", java: "//", c: "//", go: "//", rust: "//",
  php: "//", scss: "//", css: "/*", sql: "--", lua: "--",
  html: "<!--", xml: "<!--", markdown: "<!--",
};
const rx = (s) => s.replace(/[-/\\^$*+?.()|[\]{}]/g, "\\$&");

function attach(host, opts) {
  const o = opts || {};
  const d = host.ownerDocument;
  const mk = (tag, cls, parent) => {
    const x = d.createElement(tag);
    if (cls) x.className = cls;
    if (parent) parent.appendChild(x);
    return x;
  };

  /* --- the parts on screen --- */
  host.classList.add("ced");
  host.replaceChildren();
  const bar = mk("div", "ced-find", host); bar.hidden = true;
  const fIn = mk("input", "ced-q", bar); fIn.type = "text"; fIn.placeholder = "Find"; fIn.spellcheck = false;
  const fCount = mk("span", "ced-count", bar);
  const bPrev = mk("button", "", bar); bPrev.type = "button"; bPrev.textContent = "↑"; bPrev.title = "Previous (Shift+Enter)";
  const bNext = mk("button", "", bar); bNext.type = "button"; bNext.textContent = "↓"; bNext.title = "Next (Enter)";
  const fCase = mk("label", "ced-case", bar);
  const fCaseIn = mk("input", "", fCase); fCaseIn.type = "checkbox";
  fCase.appendChild(d.createTextNode("Aa"));
  fCase.title = "Match upper and lower case";
  const rIn = mk("input", "ced-r", bar); rIn.type = "text"; rIn.placeholder = "Replace with"; rIn.spellcheck = false;
  const bRep = mk("button", "ced-rb", bar); bRep.type = "button"; bRep.textContent = "Replace";
  const bAll = mk("button", "ced-rb", bar); bAll.type = "button"; bAll.textContent = "All";
  const bX = mk("button", "ced-x", bar); bX.type = "button"; bX.textContent = "✕"; bX.title = "Close (Esc)";

  const body = mk("div", "ced-body", host);
  const cur = mk("div", "ced-cur", body);
  const gut = mk("div", "ced-gutter", body);
  const nums = mk("div", "ced-nums", gut);
  const codeBox = mk("div", "ced-code", body);
  const shift = mk("div", "ced-shift", codeBox);
  const pre = mk("pre", "ced-pre", shift);
  const code = mk("code", "", pre);
  const ta = mk("textarea", "ced-ta", body);
  ta.spellcheck = false; ta.wrap = "off";
  ta.setAttribute("autocomplete", "off"); ta.setAttribute("autocapitalize", "off");
  ta.setAttribute("autocorrect", "off"); ta.setAttribute("aria-label", o.name || "File contents");

  const sb = mk("div", "ced-status", host);
  const posL = mk("span", "ced-pos", sb);
  const selL = mk("span", "ced-sel", sb);
  mk("span", "ced-gap", sb);
  const hint = mk("span", "ced-hint", sb);
  hint.textContent = "Ctrl+S save · Ctrl+F find · Ctrl+/ comment · Tab indent";
  const langSel = mk("select", "ced-lang", sb);
  for (const l of languages().sort((a, b) => a.name.localeCompare(b.name))) {
    const op = mk("option", "", langSel); op.value = l.id; op.textContent = l.name;
  }
  const tabSel = mk("select", "ced-tab", sb);
  for (const t of ["2", "4", "8", "Tabs"]) {
    const op = mk("option", "", tabSel); op.value = t; op.textContent = t === "Tabs" ? "Tabs" : "Spaces: " + t;
  }
  const wrapL = mk("label", "ced-wrapbox", sb);
  const wrapIn = mk("input", "", wrapL); wrapIn.type = "checkbox";
  wrapL.appendChild(d.createTextNode("Wrap"));
  wrapL.title = "Wrap long lines (line numbers are hidden while wrapping)";

  /* --- state --- */
  let ready = false;                                         // true once the page can be told about changes
  let langId = o.language || languageFor(o.name, String(o.text || "").slice(0, 200).split("\n")[0]);
  let tabW = 4, useTabs = false, saved = o.text || "", lines = -1, lh = 20, timer = 0, rafId = 0;
  let matches = [], at = -1;

  const text = () => ta.value;
  /* Never let focus scroll the page: the editor is in a dialog, and the page behind it must stay where it was. */
  const focusText = () => { try { ta.focus({ preventScroll: true }); } catch (e) { ta.focus(); } };
  const lineStart = (s, i) => s.lastIndexOf("\n", i - 1) + 1;
  const lineEnd = (s, i) => { const j = s.indexOf("\n", i); return j < 0 ? s.length : j; };
  const unit = () => (useTabs ? "\t" : " ".repeat(tabW));

  /* Guess the indent the file already uses, so we keep its style instead of forcing ours. */
  function guessIndent(s) {
    const head = s.slice(0, 60000);
    if (/^\t/m.test(head) && !/^ {2,}\S/m.test(head)) { useTabs = true; tabW = 4; return; }
    const counts = {};
    for (const m of head.matchAll(/^( +)\S/gm)) counts[m[1].length] = (counts[m[1].length] || 0) + 1;
    let best = 0, n = 0;
    for (const k in counts) if (counts[k] > n) { n = counts[k]; best = +k; }
    useTabs = false;
    tabW = best === 2 || best === 8 ? best : 4;
  }

  function applyIndent() {
    tabSel.value = useTabs ? "Tabs" : String(tabW);
    host.style.setProperty("--ced-tab", String(tabW));
  }

  /* --- drawing --- */
  function paint() {
    const t = text();
    if (t.length > BIG || langId === "plain") {
      host.classList.toggle("ced-plain", t.length > BIG);
      code.textContent = t + "\n";
    } else {
      host.classList.remove("ced-plain");
      code.innerHTML = highlight(t, langId) + "\n";
    }
  }
  function schedule() {
    const t = text();
    if (t.length > 40000) {
      if (timer) clearTimeout(timer);
      timer = setTimeout(() => { timer = 0; paint(); }, 150);
      return;
    }
    if (rafId) return;
    rafId = (d.defaultView || window).requestAnimationFrame(() => { rafId = 0; paint(); });
  }
  function gutter(t) {
    let n = 1;
    for (let i = t.indexOf("\n"); i >= 0; i = t.indexOf("\n", i + 1)) n++;
    if (n === lines) return;
    lines = n;
    const a = new Array(n);
    for (let i = 0; i < n; i++) a[i] = i + 1;
    nums.textContent = a.join("\n");
    host.style.setProperty("--ced-digits", String(String(n).length));
  }
  function scrolled() {
    shift.style.transform = "translate(" + -ta.scrollLeft + "px," + -ta.scrollTop + "px)";
    nums.style.transform = "translateY(" + -ta.scrollTop + "px)";
    cur.style.transform = "translateY(" + -ta.scrollTop + "px)";
  }
  function caret() {
    const t = text(), a = ta.selectionStart, b = ta.selectionEnd;
    const before = t.slice(0, a);
    const ln = before.split("\n").length;
    const col = a - lineStart(t, a) + 1;
    posL.textContent = "Ln " + ln + ", Col " + col;
    selL.textContent = b > a ? (b - a) + " selected" : "";
    cur.style.top = ((ln - 1) * lh) + "px";
    cur.hidden = b > a;
  }
  function sync() {
    const t = text();
    gutter(t);
    schedule();
    caret();
    scrolled();
    if (!bar.hidden) runFind(false);
    if (ready && o.onChange) o.onChange(api);
  }

  /* --- editing that keeps the browser's own undo --- */
  function put(a, b, s, selA, selB) {
    focusText();
    ta.setSelectionRange(a, b);
    let done = false;
    try { done = s === "" ? d.execCommand("delete") : d.execCommand("insertText", false, s); } catch (e) { done = false; }
    if (!done) ta.setRangeText(s, a, b, "end");
    if (selA != null) ta.setSelectionRange(selA, selB == null ? selA : selB);
    sync();
  }

  /* Indent or outdent every line the selection touches. */
  function blockIndent(dir) {
    const t = text(), a = ta.selectionStart, b = ta.selectionEnd;
    const from = lineStart(t, a), to = lineEnd(t, b);
    const u = unit();
    const rows = t.slice(from, to).split("\n");
    let first = 0;
    const out = rows.map((ln, i) => {
      if (dir > 0) {
        if (!ln && rows.length > 1) return ln;               // leave blank lines alone
        if (i === 0) first = u.length;
        return u + ln;
      }
      let cut = 0;
      if (ln.startsWith("\t")) cut = 1;
      else { const m = ln.match(/^ +/); cut = m ? Math.min(m[0].length, tabW) : 0; }
      if (i === 0) first = -cut;
      return ln.slice(cut);
    }).join("\n");
    const grew = out.length - (to - from);
    const na = Math.min(Math.max(from, a + first), from + out.length);
    put(from, to, out, na, Math.max(na, b + grew));
  }

  function tabKey(back) {
    const t = text(), a = ta.selectionStart, b = ta.selectionEnd;
    if (back || t.slice(a, b).includes("\n")) { blockIndent(back ? -1 : 1); return; }
    if (useTabs) { put(a, b, "\t"); return; }
    const n = tabW - ((a - lineStart(t, a)) % tabW);
    put(a, b, " ".repeat(n));
  }

  function enterKey(e) {
    const t = text(), a = ta.selectionStart, b = ta.selectionEnd;
    const ls = lineStart(t, a);
    const head = t.slice(ls, a);
    const ind = (head.match(/^[ \t]*/) || [""])[0];
    const prev = head.replace(/\s+$/, "").slice(-1);
    const next = t.slice(b, b + 1);
    const opens = "([{".includes(prev) || /:\s*$/.test(head) && (langId === "python" || langId === "yaml");
    if (!opens && !ind) return;                              // nothing clever to do: let the browser type it
    e.preventDefault();
    const add = opens ? unit() : "";
    let s = "\n" + ind + add;
    const caretAt = a + s.length;
    if (opens && PAIRS[prev] === next) s += "\n" + ind;
    put(a, b, s, caretAt);
  }

  function backKey(e) {
    const t = text(), a = ta.selectionStart, b = ta.selectionEnd;
    if (a !== b) return;
    const before = t.slice(a - 1, a), after = t.slice(a, a + 1);
    if (PAIRS[before] && PAIRS[before] === after) { e.preventDefault(); put(a - 1, a + 1, ""); return; }
    if (useTabs) return;
    const ls = lineStart(t, a), head = t.slice(ls, a);
    if (!head || !/^ +$/.test(head)) return;
    const n = head.length % tabW || tabW;
    e.preventDefault();
    put(a - n, a, "");
  }

  /* Ctrl+/ : comment or uncomment the lines the selection touches, the way this language does it. */
  function toggleComment() {
    const mark = COMMENT[langId] || "#";
    const tail = mark === "/*" ? " */" : mark === "<!--" ? " -->" : "";
    const t = text(), a = ta.selectionStart, b = ta.selectionEnd;
    const from = lineStart(t, a), to = lineEnd(t, b);
    const rows = t.slice(from, to).split("\n");
    const live = rows.filter((r) => r.trim());
    if (!live.length) return;
    const off = live.every((r) => r.trim().startsWith(mark));
    const pad = Math.min.apply(null, live.map((r) => r.match(/^[ \t]*/)[0].length));
    const head = new RegExp("^([ \\t]*)" + rx(mark) + " ?");
    const foot = tail ? new RegExp("[ \\t]*" + rx(tail.trim()) + "[ \\t]*$") : null;
    const out = rows.map((r) => {
      if (!r.trim()) return r;
      if (off) { const s2 = r.replace(head, "$1"); return foot ? s2.replace(foot, "") : s2; }
      return r.slice(0, pad) + mark + " " + r.slice(pad) + tail;
    }).join("\n");
    put(from, to, out, from, from + out.length);
  }

  function moveLines(dir) {
    const t = text(), a = ta.selectionStart, b = ta.selectionEnd;
    const from = lineStart(t, a), to = lineEnd(t, b);
    if (dir < 0 && from === 0) return;
    if (dir > 0 && to >= t.length) return;
    const block = t.slice(from, to);
    if (dir < 0) {
      const pFrom = lineStart(t, from - 1);
      const prev = t.slice(pFrom, from - 1);
      put(pFrom, to, block + "\n" + prev, pFrom + (a - from), pFrom + (b - from));
    } else {
      const nEnd = lineEnd(t, to + 1);
      const next = t.slice(to + 1, nEnd);
      put(from, nEnd, next + "\n" + block, from + next.length + 1 + (a - from), from + next.length + 1 + (b - from));
    }
  }

  function duplicate() {
    const t = text(), a = ta.selectionStart, b = ta.selectionEnd;
    if (a !== b) { put(b, b, t.slice(a, b), b, b + (b - a)); return; }
    const from = lineStart(t, a), to = lineEnd(t, a);
    const ln = t.slice(from, to);
    put(to, to, "\n" + ln, a + ln.length + 1);
  }

  function gotoLine() {
    const n = (d.defaultView || window).prompt("Go to line (1 to " + lines + ")", "");
    const v = parseInt(n, 10);
    if (!v || v < 1) return;
    const t = text();
    let i = 0;
    for (let k = 1; k < v; k++) { const j = t.indexOf("\n", i); if (j < 0) break; i = j + 1; }
    focusText();
    ta.setSelectionRange(i, lineEnd(t, i));
    reveal(i);
    caret();
  }

  function reveal(pos) {
    const t = text();
    const ln = t.slice(0, pos).split("\n").length - 1;
    const top = ta.scrollTop / lh, rows = ta.clientHeight / lh;
    if (ln < top + 1 || ln > top + rows - 2) ta.scrollTop = Math.max(0, (ln - Math.floor(rows / 2)) * lh);
    scrolled();
  }

  /* --- find and replace --- */
  function runFind(move) {
    const q = fIn.value;
    const t = text();
    matches = [];
    if (q) {
      const hay = fCaseIn.checked ? t : t.toLowerCase();
      const needle = fCaseIn.checked ? q : q.toLowerCase();
      let i = hay.indexOf(needle);
      while (i >= 0 && matches.length < 20000) { matches.push(i); i = hay.indexOf(needle, i + needle.length); }
    }
    if (matches.length === 0) { at = -1; fCount.textContent = q ? "no matches" : ""; return; }
    if (move || at < 0 || at >= matches.length) {
      const from = ta.selectionStart;
      at = matches.findIndex((p) => p >= from);
      if (at < 0) at = 0;
    }
    fCount.textContent = (at + 1) + " of " + matches.length;
    if (move) select(at);
  }
  function select(i) {
    const p = matches[i];
    if (p == null) return;
    ta.setSelectionRange(p, p + fIn.value.length);
    reveal(p);
    caret();
  }
  function go(dir) {
    if (!matches.length) { runFind(true); return; }
    at = (at + dir + matches.length) % matches.length;
    fCount.textContent = (at + 1) + " of " + matches.length;
    focusText();
    select(at);
  }
  function openFind(withReplace) {
    bar.hidden = false;
    host.classList.toggle("ced-rep", !!withReplace);
    const sel = text().slice(ta.selectionStart, ta.selectionEnd);
    if (sel && !sel.includes("\n")) fIn.value = sel;
    fIn.focus();
    fIn.select();
    runFind(false);
  }
  function closeFind() {
    bar.hidden = true;
    host.classList.remove("ced-rep");
    fCount.textContent = "";
    matches = []; at = -1;
    focusText();
  }
  function replaceOne() {
    if (at < 0 || !matches.length) { go(1); return; }
    const p = matches[at], q = fIn.value;
    const cur2 = text().slice(p, p + q.length);
    const same = fCaseIn.checked ? cur2 === q : cur2.toLowerCase() === q.toLowerCase();
    if (!same) { runFind(true); return; }
    put(p, p + q.length, rIn.value, p + rIn.value.length);
    runFind(true);
  }
  function replaceAll() {
    const q = fIn.value;
    if (!q || !matches.length) return;
    const t = text();
    let out = "", last = 0;
    for (const p of matches) { out += t.slice(last, p) + rIn.value; last = p + q.length; }
    out += t.slice(last);
    const n = matches.length;
    put(0, t.length, out, Math.min(ta.selectionStart, out.length));
    fCount.textContent = n + " replaced";
  }

  /* --- keys --- */
  function onKey(e) {
    const mod = e.ctrlKey || e.metaKey;
    const k = e.key;
    if (k === "Escape" && !bar.hidden) { e.preventDefault(); e.stopPropagation(); closeFind(); return; }
    if (mod && !e.altKey) {
      const low = k.toLowerCase();
      if (low === "s") { e.preventDefault(); if (o.onSave) o.onSave(api); return; }
      if (low === "f") { e.preventDefault(); openFind(false); return; }
      if (low === "h") { e.preventDefault(); openFind(true); return; }
      if (low === "g") { e.preventDefault(); gotoLine(); return; }
      if (low === "d") { e.preventDefault(); duplicate(); return; }
      if (k === "/") { e.preventDefault(); toggleComment(); return; }
      if (k === "]") { e.preventDefault(); blockIndent(1); return; }
      if (k === "[") { e.preventDefault(); blockIndent(-1); return; }
      return;
    }
    if (e.altKey && (k === "ArrowUp" || k === "ArrowDown")) { e.preventDefault(); moveLines(k === "ArrowUp" ? -1 : 1); return; }
    if (mod || e.altKey) return;
    if (k === "Tab") { e.preventDefault(); tabKey(e.shiftKey); return; }
    if (k === "Enter") { enterKey(e); return; }
    if (k === "Backspace") { backKey(e); return; }
    if (k === "Home" && !e.shiftKey) {
      const t = text(), a = ta.selectionStart, ls = lineStart(t, a);
      const first = ls + (t.slice(ls, lineEnd(t, ls)).match(/^[ \t]*/) || [""])[0].length;
      if (a !== first) { e.preventDefault(); ta.setSelectionRange(first, first); caret(); }
      return;
    }
    if (k.length !== 1) return;
    const t = text(), a = ta.selectionStart, b = ta.selectionEnd;
    if (PAIRS[k]) {
      const close = PAIRS[k];
      if (a !== b) { e.preventDefault(); put(a, b, k + t.slice(a, b) + close, a + 1, b + 1); return; }
      const after = t.slice(a, a + 1), before = t.slice(a - 1, a);
      const quote = k === '"' || k === "'" || k === "`";
      if (quote && (/[\w"'`\\]/.test(before) || /[\w]/.test(after))) return;
      if (after && !/[\s)\]}>,;.]/.test(after)) return;
      e.preventDefault();
      put(a, b, k + close, a + 1);
      return;
    }
    if (CLOSERS.includes(k) && a === b && t.slice(a, a + 1) === k) {
      e.preventDefault();
      ta.setSelectionRange(a + 1, a + 1);
      caret();
    }
  }

  /* --- wiring --- */
  ta.addEventListener("keydown", onKey);
  ta.addEventListener("input", sync);
  ta.addEventListener("scroll", scrolled);
  for (const ev of ["keyup", "mouseup", "select", "focus", "click"]) ta.addEventListener(ev, caret);
  bX.onclick = closeFind;
  bNext.onclick = () => go(1);
  bPrev.onclick = () => go(-1);
  bRep.onclick = replaceOne;
  bAll.onclick = replaceAll;
  fCaseIn.onchange = () => { at = -1; runFind(true); };
  fIn.addEventListener("input", () => { at = -1; runFind(false); });
  const barKey = (e, isRep) => {
    const mod = e.ctrlKey || e.metaKey;
    if (mod && !e.altKey) {
      const low = e.key.toLowerCase();
      if (low === "h") { e.preventDefault(); host.classList.add("ced-rep"); rIn.focus(); return; }
      if (low === "f") { e.preventDefault(); fIn.focus(); fIn.select(); return; }
      if (low === "s") { e.preventDefault(); if (o.onSave) o.onSave(api); return; }
      return;
    }
    if (e.key === "Enter") { e.preventDefault(); if (isRep) replaceOne(); else go(e.shiftKey ? -1 : 1); }
    else if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); closeFind(); }
  };
  fIn.addEventListener("keydown", (e) => barKey(e, false));
  rIn.addEventListener("keydown", (e) => barKey(e, true));
  langSel.onchange = () => { langId = langSel.value; paint(); };
  tabSel.onchange = () => {
    useTabs = tabSel.value === "Tabs";
    if (!useTabs) tabW = parseInt(tabSel.value, 10) || 4;
    applyIndent();
    focusText();
  };
  wrapIn.onchange = () => {
    host.classList.toggle("ced-wrap", wrapIn.checked);
    ta.wrap = wrapIn.checked ? "soft" : "off";
    const t = ta.value, a = ta.selectionStart, b = ta.selectionEnd;
    ta.value = t;                                            // Firefox needs this to re-wrap
    ta.setSelectionRange(a, b);
    shift.style.transform = "";
    sync();
  };

  /* --- the object the page talks to --- */
  const api = {
    get dirty() { return ta.value !== saved; },
    get language() { return langId; },
    get lines() { return lines; },
    getText: () => ta.value,
    setText(s, name) {
      saved = s;
      ta.value = s;
      if (name !== undefined) {
        langId = o.language || languageFor(name, String(s).slice(0, 200).split("\n")[0]);
        langSel.value = langId;
      }
      guessIndent(s);
      applyIndent();
      lines = -1;
      ta.scrollTop = 0; ta.scrollLeft = 0;
      ta.setSelectionRange(0, 0);
      paint();
      sync();
    },
    markSaved() { saved = ta.value; if (ready && o.onChange) o.onChange(api); },
    focus() { focusText(); },
    find: openFind,
    setLanguage(id) { if (L[id]) { langId = id; langSel.value = id; paint(); } },
    textarea: ta,
    destroy() {
      if (timer) clearTimeout(timer);
      ta.removeEventListener("keydown", onKey);
      host.replaceChildren();
      host.classList.remove("ced", "ced-wrap", "ced-rep", "ced-plain");
    },
  };

  guessIndent(saved);
  applyIndent();
  langSel.value = langId;
  ta.value = saved;
  paint();
  sync();
  lh = parseFloat((d.defaultView || window).getComputedStyle(ta).lineHeight) || 20;
  ready = true;
  return api;
}

return { attach, highlight, languageFor, languages, tokenize, _langs: L };
})();
if (typeof globalThis !== "undefined") globalThis.CodeEditor = CodeEditor;
