const $ = (id) => document.getElementById(id);
function el(tag, text, cls) { const e = document.createElement(tag); if (text !== undefined) e.textContent = text; if (cls) e.className = cls; return e; }
const BAD = /failed|refused|denied|revoked|removed/;
let timer = 0, first = true;

function qs() {
  const p = new URLSearchParams({ range: $("range").value, scope: $("older").checked ? "all" : "current" });
  for (const k of ["user", "event", "q"]) if ($(k).value.trim()) p.set(k, $(k).value.trim());
  return p;
}
function fill(sel, values, keep) {
  const cur = sel.value;
  while (sel.options.length > 1) sel.remove(1);
  for (const [v, t] of values) { const o = el("option", t); o.value = v; sel.append(o); }
  sel.value = values.some(([v]) => v === cur) ? cur : "";
}
async function load() {
  const r = await fetch("/api/auditlog?" + qs());
  if (r.status === 401) { location.href = "/login.html"; return; }
  if (!r.ok) {
    let m = "Request failed (" + r.status + ")"; try { m = (await r.json()).detail || m; } catch (e) {}
    $("err").textContent = m; $("rows").replaceChildren(); return;
  }
  $("err").textContent = "";
  const d = await r.json();
  fill($("user"), d.users.map((u) => [u, u]));
  fill($("event"), d.events.map((e) => [e.name, e.label ? e.label + " (" + e.name + ")" : e.name]));
  const tb = $("rows"); tb.replaceChildren();
  if (!d.rows.length) { const tr = el("tr"), td = el("td", "Nothing matches.", "muted"); td.colSpan = 5; tr.append(td); tb.append(tr); }
  for (const x of d.rows) {
    const tr = el("tr", "", BAD.test(x.event) ? "bad" : "");
    const ev = el("td", x.label || x.event, "ev"); if (x.label) ev.title = x.event;
    const det = Object.entries(x.detail).map(([k, v]) => k + "=" + (typeof v === "object" ? JSON.stringify(v) : v)).join("  ");
    tr.append(el("td", x.ts.replace("T", " ").replace("Z", ""), "when"), el("td", x.user), el("td", x.ip), ev, el("td", det, "det"));
    tb.append(tr);
  }
  $("count").textContent = d.total + " event(s)";
  $("more").textContent = (d.total > d.rows.length ? "Showing the newest " + d.rows.length + ". Narrow the search or download the CSV for all of them. " : "")
    + (d.capped ? "Very large log: only the newest part was searched. " : "")
    + (!$("older").checked && d.files > 1 ? "Older weeks are kept in " + (d.files - 1) + " more file(s): tick Include older weeks." : "");
}
for (const id of ["range", "user", "event", "older"]) $(id).onchange = load;
$("q").oninput = () => { clearTimeout(timer); timer = setTimeout(load, 300); };
$("export").onclick = () => { location.href = "/api/auditlog/export?" + qs(); };
load();
