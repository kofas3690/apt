const $ = (id) => document.getElementById(id);

async function api(path, opts) {
  const r = await fetch(path, opts);
  if (r.status === 401) { location.href = "/login.html"; throw new Error("not logged in"); }
  return r;
}
async function errText(r) {
  try { const j = await r.json(); if (typeof j.detail === "string") return j.detail; } catch (e) {}
  if (r.status === 422) return "That host, record or port is not valid.";
  return "Request failed (" + r.status + ")";
}

function sync() {
  const t = $("tool").value;
  $("recl").hidden = t !== "dns"; $("portl").hidden = t !== "port";
}
$("tool").onchange = sync; sync();

$("form").onsubmit = async (e) => {
  e.preventDefault();
  $("err").textContent = "";
  const t = $("tool").value, body = { tool: t, host: $("host").value.trim() };
  if (t === "dns") body.record = $("record").value;
  if (t === "port") body.port = parseInt($("port").value, 10);
  $("go").disabled = true; $("go").textContent = "Running…";
  $("out").textContent = t === "trace" ? "Tracing… this can take up to a minute." : "Running…";
  const r = await api("/api/nettools", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  if (!r.ok) { $("err").textContent = await errText(r); $("out").textContent = ""; }
  else $("out").textContent = (await r.json()).output;
  $("go").disabled = false; $("go").textContent = "Run";
};
