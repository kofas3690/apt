document.getElementById("f").addEventListener("submit", async (e) => {
  e.preventDefault();
  const go = document.getElementById("go"), err = document.getElementById("err");
  go.disabled = true;
  err.textContent = "";
  try {
    const r = await fetch("/api/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        username: document.getElementById("u").value,
        password: document.getElementById("p").value,
        code: document.getElementById("c").value,
      }),
    });
    if (r.ok) { location.href = "/"; return; }
    let msg = "Sign-in failed";
    try { const j = await r.json(); if (typeof j.detail === "string") msg = j.detail; } catch (x) {}
    err.textContent = msg;
  } catch (x) {
    err.textContent = "Could not reach the server";
  }
  go.disabled = false;
});

/* The distribution's own logo and short name, when the system has them (nothing else is shown before sign-in). */
(async function () {
  try {
    const r = await fetch("/api/distro", { cache: "no-store" });
    if (!r.ok) return;
    const d = await r.json();
    if (typeof d.name === "string" && d.name && d.name.length < 40) document.getElementById("sub").textContent = "Sign in to manage this " + d.name + " server";
    if (d.logo) {
      const img = document.getElementById("distro");
      img.onerror = () => { img.hidden = true; };
      img.onload = () => { img.hidden = false; };
      img.src = "/api/distro-logo";
    }
  } catch (e) { /* the page works without it */ }
})();
