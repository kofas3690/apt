const $ = (id) => document.getElementById(id);
let poll = null;

async function api(path, opts) {
  const r = await fetch(path, opts);
  if (r.status === 401) { location.href = "/login.html"; throw new Error("not logged in"); }
  return r;
}
async function errText(r) {
  try { const j = await r.json(); if (typeof j.detail === "string") return j.detail; } catch (e) {}
  return "Request failed (" + r.status + ")";
}
const send = (method, path, body) => api(path, { method, headers: { "Content-Type": "application/json" }, body: body === undefined ? undefined : JSON.stringify(body) });
function fmtBytes(n) {
  const u = ["B", "kB", "MB", "GB", "TB"]; let i = 0;
  while (n >= 1000 && i < u.length - 1) { n /= 1000; i++; }
  return (i === 0 || n >= 100 ? n.toFixed(0) : n.toFixed(1)) + " " + u[i];
}
const when = (s) => new Date(s * 1000).toLocaleString([], { dateStyle: "medium", timeStyle: "short" });
function el(tag, text, cls) { const e = document.createElement(tag); if (text !== undefined) e.textContent = text; if (cls) e.className = cls; return e; }
function kv(tb, k, v, cls) { const tr = el("tr"); tr.append(el("th", k)); tr.append(el("td", v, cls)); tb.append(tr); }
const hh = (h) => String(h).padStart(2, "0") + ":00";

for (let h = 0; h < 24; h++) $("hour").append(new Option(hh(h), String(h)));

function drawState(d) {
  const tb = $("state"); tb.replaceChildren();
  const c = d.config;
  const sched = c.schedule === "off" ? "Off: only when you press the button"
    : (c.schedule === "daily" ? "Every day" : "Every week") + ", from " + hh(c.hour) + ". Keeps " + c.keep + " copies.";
  kv(tb, "Schedule", sched);
  if (d.running) kv(tb, "Last backup", "Running now…");
  else if (!d.last) kv(tb, "Last backup", "No backup has run yet");
  else if (d.last.ok) kv(tb, "Last backup", when(d.last.t) + ", " + fmtBytes(d.last.size) + (d.last.warning ? " (a file changed while it was read)" : ""), "ok");
  else kv(tb, "Last backup", "Failed on " + when(d.last.t) + ": " + (d.last.error || "unknown error"), "bad");
  const disk = c.dest.startsWith("mnt:");
  const label = c.dest === "local" ? "This machine" : disk ? "Disk /mnt/" + c.dest.slice(4) : "Network share \"" + c.dest + "\"";
  if (c.dest !== "local" && !d.dest_ready) kv(tb, "Stored on", label + ": " + (disk ? "not mounted right now. Mount it on the Storage page." : "not connected right now. It is connected automatically when a backup starts."), "bad");
  else kv(tb, "Stored on", label);
  if (d.dest_ready) kv(tb, "Free space", fmtBytes(d.free) + " of " + fmtBytes(d.total) + " on the backup " + (c.dest === "local" || disk ? "disk" : "share"));
  $("now").disabled = d.running;
  $("nowmsg").textContent = d.running ? "A backup is running." : "";
}

function drawCopies(d) {
  const tb = $("copies"); tb.replaceChildren();
  const list = d.archives.slice().reverse();
  if (!list.length) { const tr = el("tr"), td = el("td", "No copies yet.", "muted"); td.colSpan = 4; tr.append(td); tb.append(tr); }
  for (const a of list) {
    const tr = el("tr");
    const nm = el("td", a.name);
    if (a.checked_t) nm.append(el("div", (a.checked_ok ? "Checked fine " : "DAMAGED when checked ") + when(a.checked_t), a.checked_ok ? "muted" : "pill bad"));
    tr.append(el("td", when(a.t)), el("td", fmtBytes(a.size)), nm);
    const td = el("td"), v = el("button", "Check"), x = el("button", "Delete");
    v.onclick = async () => {
      v.disabled = true; v.textContent = "Checking…"; $("err").textContent = "";
      const r = await send("POST", "/api/backup/verify", { name: a.name });
      if (r.ok) { const j = await r.json(); v.textContent = "OK, " + j.entries + " items"; }
      else { $("err").textContent = await errText(r); v.textContent = "Check"; v.disabled = false; }
    };
    x.onclick = async () => {
      if (!confirm("Delete the copy from " + when(a.t) + "?")) return;
      const r = await send("POST", "/api/backup/delete", { name: a.name });
      if (!r.ok) $("err").textContent = await errText(r);
      load(false);
    };
    const br = el("button", "Browse and restore"); br.onclick = () => openBrowse(a);
    td.append(v, " ", br, " ", x); tr.append(td); tb.append(tr);
  }
  const r = $("restore"); r.replaceChildren();
  r.append("Use Browse and restore to look inside a copy and restore all of it or chosen files into a protected folder (see Restored folders below).");
}

async function fillDest(current, targets) {
  const sel = $("dest");
  while (sel.options.length > 1) sel.remove(1);
  try {
    const r = await api("/api/shares");
    if (r.ok) for (const s of (await r.json()).shares) if (s.access === "backup") sel.append(new Option("Network share: " + s.name + " (" + s.server + ")", s.name));
  } catch (e) {}
  for (const t of targets || []) sel.append(new Option("Disk " + t.path + " (" + t.fstype + ", " + fmtBytes(t.free) + " free)", t.name));
  if (current !== "local" && ![...sel.options].some((o) => o.value === current)) sel.append(new Option((current.startsWith("mnt:") ? "Disk /mnt/" + current.slice(4) : "Network share: " + current) + " (not available)", current));
  sel.value = current;
}

async function load(fillForm) {
  const r = await api("/api/backup");
  if (!r.ok) { $("err").textContent = await errText(r); return; }
  const d = await r.json();
  drawState(d); drawCopies(d); loadRestores();
  if (fillForm) {
    $("sources").value = d.config.sources.join("\n");
    $("exclude").value = (d.config.exclude || []).join("\n");
    await fillDest(d.config.dest, d.targets);
    $("schedule").value = d.config.schedule; $("hour").value = String(d.config.hour); $("keep").value = d.config.keep;
  }
  clearTimeout(poll);
  if (d.running) poll = setTimeout(() => load(false), 3000);
}

$("now").onclick = async () => {
  $("err").textContent = "";
  const r = await send("POST", "/api/backup/start");
  if (!r.ok) $("err").textContent = await errText(r);
  setTimeout(() => load(false), 1200);
};
$("form").addEventListener("submit", async (e) => {
  e.preventDefault(); $("err").textContent = ""; $("savemsg").textContent = "";
  const sources = $("sources").value.split("\n").map((s) => s.trim()).filter(Boolean);
  const exclude = $("exclude").value.split("\n").map((s) => s.trim()).filter(Boolean);
  const r = await send("PUT", "/api/backup/settings", { schedule: $("schedule").value, hour: Number($("hour").value), keep: Number($("keep").value), sources, exclude, dest: $("dest").value });
  if (!r.ok) { $("err").textContent = await errText(r); return; }
  $("savemsg").textContent = "Saved.";
  load(false);
});
load(true);

// What makes a backup big: measure, then add a folder to the "leave out" box (it is saved with Save settings)
function drawSizes(d) {
  const tb = $("sizes"); tb.replaceChildren();
  for (const f of d.folders) {
    const tr = el("tr");
    tr.append(el("td", f.path, f.skipped ? "muted" : undefined));
    tr.append(el("td", fmtBytes(f.bytes)));
    const td = el("td");
    if (f.skipped) td.append(el("span", "left out", "muted"));
    else {
      const b = el("button", "Leave out"); b.type = "button";
      b.onclick = () => {
        const have = $("exclude").value.split("\n").map((s) => s.trim()).filter(Boolean);
        if (!have.includes(f.path)) have.push(f.path);
        $("exclude").value = have.join("\n");
        $("measuremsg").textContent = "Added. Press Save settings to keep the change.";
        $("exclude").scrollIntoView({ block: "center" });
      };
      td.append(b);
    }
    tr.append(td); tb.append(tr);
  }
  $("measuremsg").textContent = "Total " + fmtBytes(d.total) + (d.left_out_bytes ? ", of which " + fmtBytes(d.left_out_bytes) + " is left out." : ".");
}
$("measure").onclick = async () => {
  $("err").textContent = ""; $("measure").disabled = true; $("measuremsg").textContent = "Measuring…";
  try {
    const r = await api("/api/backup/sizes");
    if (!r.ok) { $("err").textContent = await errText(r); $("measuremsg").textContent = ""; return; }
    drawSizes(await r.json());
  } finally { $("measure").disabled = false; }
};

// Browse a copy and restore into a protected folder
let current = null;
const picked = new Set();

function openBrowse(a) {
  current = a; picked.clear();
  $("browse").hidden = false; $("browsehead").textContent = "Copy from " + when(a.t);
  $("bfilter").value = ""; $("rmsg").textContent = "";
  search(); $("browse").scrollIntoView();
}
function updatePicked() {
  $("rsel").disabled = picked.size === 0 || picked.size > 50;
  $("rsel").textContent = "Restore selected" + (picked.size ? " (" + picked.size + ")" : "");
}
async function search() {
  $("err").textContent = ""; $("bnote").textContent = "Reading the copy… large copies can take a minute."; $("blist").replaceChildren();
  const r = await send("POST", "/api/backup/contents", { name: current.name, filter: $("bfilter").value });
  if (!r.ok) { $("bnote").textContent = ""; $("err").textContent = await errText(r); return; }
  const d = await r.json(), box = $("blist");
  $("bnote").textContent = d.total + " items in the copy" + ($("bfilter").value ? ", " + d.matched + " match" : "") + (d.truncated ? "; showing the first " + d.shown.length + ", narrow the search to see others" : "") + ". Tick up to 50.";
  for (const m of d.shown) {
    const row = el("label"); row.style.display = "block";
    const cb = document.createElement("input"); cb.type = "checkbox"; cb.checked = picked.has(m.name);
    cb.onchange = () => { cb.checked ? picked.add(m.name) : picked.delete(m.name); updatePicked(); };
    row.append(cb, " " + m.name + (m.kind === "d" ? "/" : m.kind === "f" ? "  (" + fmtBytes(m.size) + ")" : m.kind === "l" ? "  (link)" : ""));
    box.append(row);
  }
  if (!d.shown.length) box.append(el("span", "Nothing matches.", "muted"));
  updatePicked();
}
async function doRestore(paths, btn) {
  const what = paths.length ? paths.length + " chosen item" + (paths.length === 1 ? "" : "s") : "everything in this copy";
  if (!confirm("Restore " + what + " into a protected folder on this machine? Your live files are not touched.")) return;
  $("err").textContent = ""; $("rmsg").textContent = "Restoring… this can take a while."; btn.disabled = true;
  const r = await send("POST", "/api/backup/restore", { name: current.name, paths });
  if (!r.ok) $("rmsg").textContent = ""; 
  if (!r.ok) $("err").textContent = await errText(r);
  else { const j = await r.json(); $("rmsg").textContent = "Restored " + j.restored + " item" + (j.restored === 1 ? "" : "s") + " to " + j.folder + (j.skipped ? ". Skipped " + j.skipped + " unsafe or unreadable item(s) (for example links pointing outside the folder)." : "."); }
  updatePicked(); $("rall").disabled = false; loadRestores();
}
$("bform").onsubmit = (e) => { e.preventDefault(); search(); };
$("bclose").onclick = () => { $("browse").hidden = true; current = null; };
$("rsel").onclick = () => doRestore([...picked], $("rsel"));
$("rall").onclick = () => doRestore([], $("rall"));

async function loadRestores() {
  const r = await api("/api/backup/restores");
  const tb = $("restores"); tb.replaceChildren();
  if (!r.ok) return;
  const d = await r.json();
  if (!d.restores.length) { const tr = el("tr"), td = el("td", "Nothing restored.", "muted"); td.colSpan = 5; tr.append(td); tb.append(tr); }
  for (const x of d.restores) {
    const tr = el("tr");
    tr.append(el("td", x.name.replace("adminpanel-backup-", "")), el("td", String(x.files)), el("td", fmtBytes(x.size)));
    const f = el("td"); f.append(el("code", x.path)); tr.append(f);
    const ac = el("td"), b = el("button", "Delete");
    b.onclick = async () => {
      if (!confirm("Delete the restored folder " + x.name + " and everything in it?")) return;
      const rr = await send("POST", "/api/backup/restore/delete", { name: x.name });
      if (!rr.ok) $("err").textContent = await errText(rr);
      loadRestores();
    };
    ac.append(b); tr.append(ac); tb.append(tr);
  }
}

async function loadPhoneSwitch() {
  try {
    const r = await api("/api/backup/phone");
    if (r.ok) $("phonerestore").checked = !!(await r.json()).enabled;
  } catch (e) { /* the box stays unticked */ }
}
$("phonerestore").onchange = async () => {
  const box = $("phonerestore"), want = box.checked;
  box.disabled = true;
  try {
    const r = await send("PUT", "/api/backup/phone", { enabled: want });
    if (!r.ok) { box.checked = !want; $("err").textContent = await errText(r); }
  } catch (e) { box.checked = !want; $("err").textContent = "Could not reach the panel."; }
  box.disabled = false;
};
async function loadDeleteSwitch() {
  try {
    const r = await api("/api/backup/phone/delete");
    if (r.ok) $("phonedelete").checked = !!(await r.json()).enabled;
  } catch (e) { /* the box stays unticked */ }
}
$("phonedelete").onchange = async () => {
  const box = $("phonedelete"), want = box.checked;
  box.disabled = true;
  try {
    const r = await send("PUT", "/api/backup/phone/delete", { enabled: want });
    if (!r.ok) { box.checked = !want; $("err").textContent = await errText(r); }
  } catch (e) { box.checked = !want; $("err").textContent = "Could not reach the panel."; }
  box.disabled = false;
};
loadPhoneSwitch();
loadDeleteSwitch();
