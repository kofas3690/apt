async function api(path, opts) {
  const r = await fetch(path, opts);
  if (r.status === 401) { location.href = "/login.html"; throw new Error("not logged in"); }
  return r;
}

async function errText(r) {
  try {
    const j = await r.json();
    return typeof j.detail === "string" ? j.detail : "Invalid input";
  } catch (e) { return "Request failed (" + r.status + ")"; }
}

function post(path, body) {
  const opts = { method: "POST" };
  if (body) {
    opts.headers = { "Content-Type": "application/json" };
    opts.body = JSON.stringify(body);
  }
  return api(path, opts);
}

async function load() {
  const r = await api("/api/firewall");
  const info = document.getElementById("info");
  if (!r.ok) { info.textContent = "Error: " + await errText(r); return; }
  const d = await r.json();
  info.textContent = d.active
    ? "Firewall is ACTIVE."
    : "Firewall is INACTIVE: the rules below are saved but not enforced yet.";
  info.className = d.active ? "" : "warn";
  document.getElementById("enable").hidden = d.active;
  document.getElementById("raw").textContent = d.status_text;

  const body = document.getElementById("rules");
  body.replaceChildren();
  for (const x of d.rules) {
    const tr = document.createElement("tr");
    [x.raw, x.port ?? "", x.proto ?? "", x.source ?? "Anywhere"].forEach((t) => {
      const td = document.createElement("td");
      td.textContent = t;
      tr.appendChild(td);
    });
    const td = document.createElement("td");
    if (x.protected) {
      td.textContent = "protected";
      td.className = "muted";
    } else if (!x.manageable) {
      td.textContent = "manage from console";
      td.className = "muted";
    } else {
      const b = document.createElement("button");
      b.textContent = "Remove";
      b.onclick = () => removeRule(x);
      td.appendChild(b);
    }
    tr.appendChild(td);
    body.appendChild(tr);
  }
}

async function removeRule(x) {
  if (!confirm(`Remove rule: ${x.raw}?`)) return;
  const r = await post("/api/firewall/delete", { port: x.port, proto: x.proto, source: x.source });
  if (!r.ok) alert(await errText(r));
  load();
  loadStale();
}

// Connections the rules no longer allow (6.43.0): a firewall only stops new connections, so ones opened before a rule
// was removed (or an address blocked) keep working until they close. Show them, and offer to end them.
function el(tag, text, cls) {
  const e = document.createElement(tag);
  if (text != null) e.textContent = text;
  if (cls) e.className = cls;
  return e;
}

async function blockAndEnd(s, btn) {
  if (!confirm("Block all traffic from " + s.remote + "?\n\nIts " + s.count + " open connection" + (s.count === 1 ? " is" : "s are") +
    " ended too, and it cannot connect to this server again until you unblock it on the Blocked addresses page.")) return;
  btn.disabled = true;
  const r = await post("/api/blocked/block", { address: s.remote });
  if (!r.ok) { alert(await errText(r)); btn.disabled = false; return; }
  const e = await post("/api/firewall/stale/end", { address: s.remote });
  if (!e.ok) alert("Blocked, but its connections could not be ended: " + await errText(e));
  load();
  loadStale();
}

async function loadStale() {
  const box = document.getElementById("stale");
  let d;
  try {
    const r = await api("/api/firewall/stale");
    if (!r.ok) { box.replaceChildren(); return; }
    d = await r.json();
  } catch (e) { return; }
  const list = d.stale || [];
  if (!d.active || !list.length) { box.replaceChildren(); return; }
  const n = list.reduce((a, s) => a + s.count, 0);
  const t = el("table");
  const head = el("tr");
  ["From", "To port", "Connections", "", ""].forEach((h) => head.appendChild(el("th", h)));
  t.appendChild(el("thead")).appendChild(head);
  const tb = t.appendChild(el("tbody"));
  for (const s of list) {
    const tr = el("tr");
    tr.append(el("td", s.remote), el("td", String(s.port)), el("td", String(s.count)), el("td", s.you ? "this browser (kept open)" : "", "muted"));
    const act = el("td");
    if (!s.you) {
      // 6.45.0: an address you do not know can be blocked from here, and its connections ended in the same step
      const bb = el("button", "Block");
      bb.title = "Block all traffic from " + s.remote + " and end its connections";
      bb.onclick = () => blockAndEnd(s, bb);
      act.appendChild(bb);
    }
    tr.appendChild(act);
    tb.appendChild(tr);
  }
  const others = list.filter((s) => !s.you).reduce((a, s) => a + s.count, 0);
  const b = el("button", "End " + (others === 1 ? "it" : "them"));
  b.disabled = others === 0;
  b.onclick = async () => {
    if (!confirm("End " + others + " connection" + (others === 1 ? "" : "s") + " that the firewall no longer lets in?\n\nWhoever is on the other end is disconnected, and cannot connect again while the rules stay as they are.")) return;
    b.disabled = true;
    const r = await post("/api/firewall/stale/end");
    if (!r.ok) { alert(await errText(r)); b.disabled = false; return; }
    const j = await r.json();
    alert(j.ended + " connection" + (j.ended === 1 ? " was" : "s were") + " ended.");
    loadStale();
  };
  const parts = [
    el("h2", "Still open, though no longer allowed"),
    el("p", n + " connection" + (n === 1 ? " is" : "s are") + " still open from addresses the firewall no longer lets in. " +
      "A firewall only stops new connections: these keep working until they close, for example a browser tab that stays open.", "warn"),
    t,
  ];
  if (list.some((s) => s.you)) parts.push(el("p", "Your own connection is kept open, but this address cannot connect again while the rules stay as they are.", "warn"));
  if (!d.certain) parts.push(el("p", "Some rules (for a network card or an unknown application) cannot be read with certainty; connections they might allow are not listed.", "muted"));
  parts.push(el("p", null, "row")); parts[parts.length - 1].appendChild(b);
  parts.push(el("p", "SSH connections (port 22) are never listed or ended here.", "muted"));
  box.replaceChildren(...parts);
}

async function enableFw() {
  if (!confirm("Enable the firewall now? Incoming connections without an allow rule will be blocked. SSH (22/tcp) must already be allowed."))
    return;
  const r = await post("/api/firewall/enable");
  if (!r.ok) alert(await errText(r));
  load();
}

document.getElementById("add").addEventListener("submit", async (e) => {
  e.preventDefault();
  const src = document.getElementById("src").value.trim();
  const r = await post("/api/firewall/allow", {
    port: Number(document.getElementById("port").value),
    proto: document.getElementById("proto").value,
    source: src === "" ? null : src,
  });
  if (!r.ok) { alert(await errText(r)); return; }
  e.target.reset();
  load();
});

load();
loadStale();

document.getElementById("enable").addEventListener("click", () => enableFw());
