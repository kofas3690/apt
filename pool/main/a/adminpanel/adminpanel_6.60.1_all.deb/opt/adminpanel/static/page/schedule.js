const $ = (id) => document.getElementById(id);
let cur = null;

async function api(path, opts) {
  const r = await fetch(path, opts);
  if (r.status === 401) { location.href = "/login.html"; throw new Error("not logged in"); }
  return r;
}
async function errText(r) {
  try { const j = await r.json(); if (typeof j.detail === "string") return j.detail; } catch (e) {}
  return "Request failed (" + r.status + ")";
}
const pad = (n) => String(n).padStart(2, "0");
function local(d) { return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()) + "T" + pad(d.getHours()) + ":" + pad(d.getMinutes()); }
function when(epoch) { return new Date(epoch * 1000).toLocaleString([], { weekday: "short", year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }); }
function left(sec) {
  if (sec < 90) return "in about a minute";
  const m = Math.round(sec / 60);
  if (m < 90) return "in " + m + " minutes";
  const h = Math.round(m / 60);
  if (h < 48) return "in about " + h + " hours";
  return "in " + Math.round(h / 24) + " days";
}

function draw(d) {
  cur = d;
  const box = $("state"); box.replaceChildren();
  const t = document.createElement("div");
  if (d.scheduled && d.mode === "reboot") {
    const b = document.createElement("b"); b.textContent = "A reboot is booked for " + when(d.epoch);
    const s = document.createElement("div"); s.className = "muted"; s.textContent = left(d.epoch - d.now) + ".";
    const c = document.createElement("button"); c.textContent = "Cancel the reboot"; c.onclick = cancel;
    t.append(b, s, document.createElement("br"), c);
  } else if (d.scheduled) {
    const b = document.createElement("b"); b.textContent = "A " + d.mode + " is booked for " + when(d.epoch) + " (not made here)";
    const s = document.createElement("div"); s.className = "muted"; s.textContent = "This page only handles reboots, so it will not change that booking.";
    t.append(b, s);
  } else {
    const b = document.createElement("b"); b.textContent = "No reboot is booked.";
    t.append(b);
    if (d.reboot_required) { const s = document.createElement("div"); s.className = "crit"; s.textContent = "A reboot is waiting for installed updates."; t.append(s); }
  }
  box.append(t);
  $("form").hidden = d.scheduled && d.mode !== "reboot";
  $("set").textContent = d.scheduled && d.mode === "reboot" ? "Change the time" : "Schedule reboot";
  if (!$("when").value) { const x = new Date(Date.now() + 3600e3); $("when").value = local(x); }
}

async function load() {
  const r = await api("/api/schedule");
  if (!r.ok) { $("err").textContent = await errText(r); return; }
  draw(await r.json());
}
async function post(path, body) {
  $("err").textContent = ""; $("msg").textContent = "";
  const r = await api(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) });
  if (!r.ok) { $("err").textContent = await errText(r); return false; }
  draw(await r.json());
  return true;
}
$("set").onclick = async () => {
  const v = $("when").value;
  const ms = v ? new Date(v).getTime() : NaN;
  if (!isFinite(ms)) { $("err").textContent = "Choose a date and time."; return; }
  if (!confirm("Reboot this machine on " + when(Math.floor(ms / 1000)) + "?\n\nEveryone using it, and every service on it, is interrupted for a few minutes.")) return;
  if (await post("/api/schedule/set", { at: Math.floor(ms / 1000) })) $("msg").textContent = "Reboot booked.";
};
async function cancel() {
  if (await post("/api/schedule/cancel")) $("msg").textContent = "Reboot cancelled.";
}
$("q1").onclick = () => { $("when").value = local(new Date(Date.now() + 3600e3)); };
$("q3").onclick = () => { const x = new Date(); x.setHours(3, 0, 0, 0); if (x.getTime() < Date.now() + 600e3) x.setDate(x.getDate() + 1); $("when").value = local(x); };
setInterval(() => { if (!document.hidden) load(); }, 30000);
load();
