let jobId = "", since = 0, timer = null, wasRunning = false;

async function api(path, opts) {
  const r = await fetch(path, opts);
  if (r.status === 401) { location.href = "/login.html"; throw new Error("not logged in"); }
  return r;
}

function fmtAge(s) {
  if (s === null) return "unknown";
  if (s < 3600) return Math.round(s / 60) + " min ago";
  if (s < 86400) return Math.round(s / 3600) + " h ago";
  return Math.round(s / 86400) + " days ago";
}

async function loadOverview() {
  const d = await (await api("/api/updates")).json();
  const info = document.getElementById("info");
  info.textContent = `Package lists refreshed: ${fmtAge(d.cache_age)}. ` +
    `${d.packages.length} package(s) can be upgraded.` +
    (d.reboot_required ? " A reboot is required." : "");
  info.className = d.reboot_required ? "warn" : "";
  const upg = document.getElementById("upg");
  upg.textContent = `Upgrade all (${d.packages.length})`;
  upg.dataset.count = d.packages.length;
  const body = document.getElementById("pk");
  body.replaceChildren();
  for (const p of d.packages) {
    const tr = document.createElement("tr");
    const cells = [p.name, p.old, p.new, p.security ? "security" : p.suite];
    cells.forEach((text, i) => {
      const td = document.createElement("td");
      td.textContent = text;
      if (i === 3 && p.security) td.className = "sec";
      tr.appendChild(td);
    });
    body.appendChild(tr);
  }
  setButtons(wasRunning);
}

function setButtons(running) {
  document.getElementById("upd").disabled = running;
  const upg = document.getElementById("upg");
  upg.disabled = running || Number(upg.dataset.count || 0) === 0;
}

async function startJob(kind) {
  if (kind === "upgrade" &&
      !confirm("Upgrade all packages now? Do not stop the panel while it runs.")) return;
  const r = await api(`/api/updates/run/${kind}`, { method: "POST" });
  if (!r.ok) { alert((await r.json()).detail); return; }
  poll();
}

async function poll() {
  clearTimeout(timer);
  let d;
  try {
    d = await (await api(`/api/updates/job?since=${since}&id=${jobId}`)).json();
  } catch (e) { return; }
  if (d.status === "none") return;

  const box = document.getElementById("box");
  if (d.id !== jobId) { jobId = d.id; box.textContent = ""; }
  box.textContent += d.lines.map(l => l + "\n").join("");
  since = d.next;
  box.scrollTop = box.scrollHeight;

  const running = d.status === "running";
  document.getElementById("status").textContent = running
    ? `Running ${d.kind}…`
    : `${d.kind} ${d.status} (exit code ${d.returncode})`;
  setButtons(running);

  if (running) {
    wasRunning = true;
    timer = setTimeout(poll, 1000);
  } else if (wasRunning) {
    wasRunning = false;
    loadOverview();
    if (d.status === "failed" && d.lines.concat(box.textContent.split("\n").slice(-40)).some(l => LOCK_RE.test(l))) loadBusy();
  }
}

// 6.56.0: when another program holds apt's lock, say which one, where, and what to do
const LOCK_RE = /Could not get lock|Unable to acquire the dpkg|Unable to lock|is another process using it/i;
let busyTimer = null;

function busyAge(s) {
  if (s === null || s === undefined) return "";
  if (s < 120) return ` for ${s} s`;
  if (s < 7200) return ` for ${Math.floor(s / 60)} min`;
  return ` for ${Math.floor(s / 3600)} h ${Math.floor((s % 3600) / 60)} min`;
}

async function loadBusy() {
  clearTimeout(busyTimer);
  let d;
  try { d = await (await api("/api/updates/busy")).json(); } catch (e) { return; }
  const list = (d.busy || []).filter(x => x.kind !== "panel");
  const el = document.getElementById("busy");
  el.replaceChildren();
  el.hidden = list.length === 0;
  if (!list.length) return;
  const h = document.createElement("p");
  h.textContent = list.length === 1 ? "Another program is using apt, so updates here have to wait for it:"
                                    : "Other programs are using apt, so updates here have to wait for them:";
  el.appendChild(h);
  const ul = document.createElement("ul");
  for (const x of list) {
    const li = document.createElement("li");
    const b = document.createElement("b");
    b.textContent = x.program + (x.tty ? ` in terminal ${x.tty}` : "");
    const by = x.started_by && x.started_by !== x.user ? `, started by ${x.started_by}` : "";
    const L = x.locks || [];
    const lock = L.length === 1 ? `, holds the ${L[0]} lock`
               : L.length > 1 ? `, holds the ${L.slice(0, -1).join(", ")} and ${L[L.length - 1]} locks` : "";
    const info = document.createElement("span");
    info.textContent = ` (process ${x.pid}, as ${x.user}${by}${busyAge(x.seconds)}${lock})`;
    const cmd = document.createElement("code");
    cmd.textContent = x.command;
    const hint = document.createElement("div");
    hint.textContent = x.hint;
    li.append(b, info, document.createElement("br"), cmd, hint);
    ul.appendChild(li);
  }
  el.appendChild(ul);
  const foot = document.createElement("p");
  foot.className = "muted";
  foot.textContent = "Never delete the lock files to get past this: that can break the package database. This list refreshes by itself.";
  el.appendChild(foot);
  busyTimer = setTimeout(loadBusy, 5000);
}

loadOverview();
poll();
loadBusy();

document.getElementById("upd").addEventListener("click", () => startJob("update"));
document.getElementById("upg").addEventListener("click", () => startJob("upgrade"));
