const $ = (id) => document.getElementById(id);

async function api(path, opts) {
  const r = await fetch(path, opts);
  if (r.status === 401) { location.href = "/login.html"; throw new Error("not logged in"); }
  return r;
}
async function errText(r) {
  try { const j = await r.json(); if (typeof j.detail === "string") return j.detail; } catch (e) {}
  if (r.status === 422) return "That value is not valid.";
  return "Request failed (" + r.status + ")";
}
function el(tag, text, cls) { const e = document.createElement(tag); if (text !== undefined) e.textContent = text; if (cls) e.className = cls; return e; }

async function post(path, body, done) {
  $("err").textContent = ""; $("msg").textContent = "";
  const r = await api(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  if (!r.ok) { $("err").textContent = await errText(r); return; }
  $("msg").textContent = done; load();
}

function control(s) {
  const wrap = el("td");
  if (s.current === null) { wrap.append(el("span", "not in this kernel", "muted")); return wrap; }
  let inp;
  if (s.choices) {
    inp = el("select");
    for (const c of s.choices) { const o = el("option", String(c)); o.value = String(c); inp.append(o); }
    if (s.choices.map(String).includes(s.current)) inp.value = s.current;
  } else {
    inp = el("input"); inp.type = "number"; inp.min = s.min; inp.max = s.max; inp.value = s.current;
  }
  const set = el("button", "Set");
  set.onclick = () => {
    const v = parseInt(inp.value, 10);
    if (Number.isNaN(v)) { $("err").textContent = "Enter a number."; return; }
    post("/api/sysctl/set", { key: s.key, value: v }, "Set " + s.key + " to " + v + " and saved it for the next boot.");
  };
  wrap.append(inp, " ", set);
  if (s.saved !== null) {
    const f = el("button", "Forget"); f.onclick = () => post("/api/sysctl/forget", { key: s.key }, "Removed the saved value of " + s.key + ".");
    wrap.append(" ", f);
  }
  return wrap;
}

function draw(d) {
  $("file").textContent = d.file;
  const tb = $("rows"); tb.replaceChildren();
  for (const s of d.settings) {
    const tr = el("tr"), k = el("td"); k.append(el("code", s.key));
    const cur = el("td", s.current === null ? "–" : s.current);
    if (s.recommended !== null && s.current !== null) cur.className = String(s.recommended) === s.current ? "ok" : "warn";
    tr.append(k, el("td", s.description, "desc"), cur, el("td", s.saved === null ? "–" : s.saved),
              el("td", s.recommended === null ? "–" : String(s.recommended)), control(s));
    tb.append(tr);
  }
}

async function load() {
  const r = await api("/api/sysctl");
  if (!r.ok) { $("err").textContent = await errText(r); return; }
  draw(await r.json());
}
load();
