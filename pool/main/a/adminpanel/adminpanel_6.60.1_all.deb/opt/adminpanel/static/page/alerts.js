const $ = (id) => document.getElementById(id);
let CFG = null;

async function api(path, opts) {
  const r = await fetch(path, opts);
  if (r.status === 401) { location.href = "/login.html"; throw new Error("not logged in"); }
  return r;
}
async function errText(r) {
  try { const j = await r.json(); if (typeof j.detail === "string") return j.detail; } catch (e) {}
  return "Request failed (" + r.status + ")";
}
const say = (t, bad) => { const m = $("amsg"); m.textContent = t; m.className = bad ? "crit" : "muted"; };

function drawMuted() {
  const box = $("muted");
  box.replaceChildren();
  if (!CFG.muted.length) { const n = document.createElement("span"); n.style.border = "0"; n.className = "muted"; n.textContent = "None."; box.appendChild(n); return; }
  for (const u of CFG.muted) {
    const s = document.createElement("span"); s.append(u + " ");
    const x = document.createElement("button"); x.textContent = "×"; x.title = "Unmute " + u;
    x.onclick = () => { CFG.muted = CFG.muted.filter((n) => n !== u); persist("Unmuted " + u + "."); };
    s.appendChild(x); box.appendChild(s);
  }
}

function card(a) {
  const d = document.createElement("div"); d.className = "al " + a.severity;
  const ic = document.createElement("span"); ic.className = "ic"; ic.textContent = a.severity === "critical" ? "⛔" : "⚠";
  const mid = document.createElement("div");
  const ti = document.createElement("div"); ti.className = "ti"; ti.textContent = a.title;
  const de = document.createElement("div"); de.className = "de"; de.textContent = a.detail;
  mid.append(ti, de);
  const ac = document.createElement("div"); ac.className = "ac";
  const go = document.createElement("a"); go.href = a.link; go.textContent = "Open"; ac.appendChild(go);
  if (a.kind === "unit") {
    const mu = document.createElement("button"); mu.textContent = "Mute";
    mu.onclick = () => { if (!CFG.muted.includes(a.unit)) CFG.muted.push(a.unit); persist("Muted " + a.unit + "."); };
    ac.appendChild(mu);
  }
  d.append(ic, mid, ac);
  return d;
}

async function refresh() {
  let r;
  try { r = await api("/api/alerts"); } catch (e) { return; }
  if (!r.ok) { say(await errText(r), true); return; }
  const d = await r.json();
  CFG = d.settings;
  const list = $("list"); list.replaceChildren();
  if (!d.alerts.length) {
    const ok = document.createElement("div"); ok.className = "okbox"; ok.textContent = "✓ No problems found.";
    list.appendChild(ok);
  } else for (const a of d.alerts) list.appendChild(card(a));
  if (document.activeElement && ["dw", "dc", "mw"].includes(document.activeElement.id)) { drawMuted(); return; }
  $("dw").value = CFG.disk_warn; $("dc").value = CFG.disk_crit; $("mw").value = CFG.mem_warn;
  drawMuted();
}

async function persist(okText) {
  const body = { disk_warn: +$("dw").value, disk_crit: +$("dc").value, mem_warn: +$("mw").value, muted: CFG.muted };
  const r = await api("/api/alerts/settings", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  if (!r.ok) { say(await errText(r), true); return; }
  say(okText || "Saved.");
  refresh();
}

$("save").onclick = () => persist("Settings saved.");
setInterval(() => { if (!document.hidden) refresh(); }, 30000);
refresh();

// ---- email ----
const msay = (t, bad) => { const m = $("mmsg"); m.textContent = t; m.className = bad ? "crit" : "muted"; };
function mailBody() {
  return { enabled: $("men").checked, host: $("mh").value, port: +$("mp").value || 0, security: $("ms").value,
           username: $("mu").value, sender: $("mf").value, password: $("mw2").value || null,
           to: $("mt").value.split(/[,;\s]+/).filter(Boolean) };
}
function fillMail(c) {
  $("men").checked = c.enabled; $("mh").value = c.host; $("mp").value = c.port; $("ms").value = c.security;
  $("mu").value = c.username; $("mf").value = c.sender; $("mt").value = c.to.join(", ");
  $("mw2").value = ""; $("mw2").placeholder = c.has_password ? "(saved; leave empty to keep it)" : "";
}
async function loadMail() {
  const r = await api("/api/alerts/email");
  if (r.ok) fillMail(await r.json());
}
$("ms").onchange = () => { const p = $("mp"); if (p.value === "587" && $("ms").value === "ssl") p.value = 465; else if (p.value === "465" && $("ms").value === "starttls") p.value = 587; };
$("msave").onclick = async () => {
  const r = await api("/api/alerts/email", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(mailBody()) });
  if (!r.ok) { msay(await errText(r), true); return; }
  fillMail(await r.json()); msay("Email settings saved.");
};
$("mtest").onclick = async () => {
  msay("Sending\u2026");
  const r = await api("/api/alerts/email/test", { method: "POST" });
  msay(r.ok ? "Test email sent. Check the inbox (and the spam folder)." : await errText(r), !r.ok);
};
loadMail();

// ---- Telegram and WhatsApp ----
const csay = (id, t, bad) => { const m = $(id); m.textContent = t; m.className = bad ? "crit" : "muted"; };
function chatBody() {
  return {
    telegram: { enabled: $("ten").checked, chat_id: $("tc").value, token: $("tt").value || null },
    ntfy: { enabled: $("nen").checked, server: $("ns").value, topic: $("nt").value, token: $("nk").value || null },
    whatsapp: { enabled: $("wen").checked, phone_number_id: $("wp").value, to: $("wto").value, template: $("wtp").value,
                language: $("wl").value || "en_US", token: $("wt").value || null },
  };
}
function fillChat(c) {
  $("ten").checked = c.telegram.enabled; $("tc").value = c.telegram.chat_id;
  $("tt").value = ""; $("tt").placeholder = c.telegram.has_token ? "(saved; leave empty to keep it)" : "123456789:ABC...";
  $("wen").checked = c.whatsapp.enabled; $("wp").value = c.whatsapp.phone_number_id; $("wto").value = c.whatsapp.to;
  $("wtp").value = c.whatsapp.template; $("wl").value = c.whatsapp.language;
  $("wt").value = ""; $("wt").placeholder = c.whatsapp.has_token ? "(saved; leave empty to keep it)" : "";
  $("nen").checked = c.ntfy.enabled; $("ns").value = c.ntfy.server; $("nt").value = c.ntfy.topic;
  $("nk").value = ""; $("nk").placeholder = c.ntfy.has_token ? "(saved; leave empty to keep it)" : "";
}
async function saveChat(msgId, okText) {
  const r = await api("/api/chatalerts", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(chatBody()) });
  if (!r.ok) { csay(msgId, await errText(r), true); return false; }
  fillChat(await r.json()); csay(msgId, okText);
  return true;
}
async function testChat(channel, msgId, okText) {
  csay(msgId, "Sending\u2026");
  const r = await api("/api/chatalerts/test", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ channel }) });
  csay(msgId, r.ok ? okText : await errText(r), !r.ok);
}
$("tsave").onclick = () => saveChat("tmsg", "Telegram settings saved.");
$("wsave").onclick = () => saveChat("wmsg", "WhatsApp settings saved.");
$("nsave").onclick = () => saveChat("nmsg", "Push settings saved. Subscribe to this topic in the ntfy app.");
$("ntest").onclick = () => testChat("ntfy", "nmsg", "Test message sent. It should appear in the ntfy app.");
$("ntopic").onclick = async () => {
  const r = await api("/api/chatalerts/ntfy/topic", { method: "POST" });
  if (!r.ok) { csay("nmsg", await errText(r), true); return; }
  $("nt").value = (await r.json()).topic; csay("nmsg", "New topic made. Press Save push settings, then subscribe to it in the ntfy app.");
};
$("ttest").onclick = () => testChat("telegram", "tmsg", "Test message sent. Check the Telegram chat.");
$("wtest").onclick = () => testChat("whatsapp", "wmsg", "Test message sent. Check WhatsApp.");
$("tfind").onclick = async () => {
  const box = $("tfound"); box.replaceChildren(); csay("tmsg", "Looking\u2026");
  const r = await api("/api/chatalerts/telegram/chats", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ token: $("tt").value || null }) });
  if (!r.ok) { csay("tmsg", await errText(r), true); return; }
  const d = await r.json();
  if (!d.chats.length) { csay("tmsg", "No chats found yet. Send your bot a message in Telegram, then try again."); return; }
  csay("tmsg", "Pick the chat to send alerts to:");
  for (const c of d.chats) {
    const b = document.createElement("button");
    b.textContent = (c.name || "(no name)") + " \u00b7 " + c.kind + " \u00b7 " + c.id;
    b.onclick = () => { $("tc").value = c.id; box.replaceChildren(); csay("tmsg", "Chat chosen. Press Save Telegram settings."); };
    box.appendChild(b);
  }
};
(async () => { const r = await api("/api/chatalerts"); if (r.ok) fillChat(await r.json()); })();

// ---- sign-in notices ----
function fillSignin(c) {
  $("sen").checked = c.enabled; $("smode").value = c.mode; $("slock").checked = c.lockout;
  $("sinfo").textContent = (c.channels.length ? "Channels that will be used: " + c.channels.join(", ") + "." : "No channel is switched on yet, so no message can be sent.") +
    " This account has " + c.known_addresses + " known address" + (c.known_addresses === 1 ? "" : "es") + ".";
}
async function signinCall(path, method, body, okText) {
  csay("smsg", method === "POST" && path.endsWith("/test") ? "Sending\u2026" : "");
  const r = await api("/api/signinnotice" + path, { method, headers: { "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
  if (!r.ok) { csay("smsg", await errText(r), true); return; }
  const d = await r.json();
  if (d.channels) fillSignin(d); else loadSignin();
  csay("smsg", okText(d));
}
async function loadSignin() { const r = await api("/api/signinnotice"); if (r.ok) fillSignin(await r.json()); }
$("ssave").onclick = () => signinCall("", "PUT", { enabled: $("sen").checked, mode: $("smode").value, lockout: $("slock").checked }, () => "Saved.");
$("stest").onclick = () => signinCall("/test", "POST", null, (d) => "Test message sent to " + d.sent_to.join(", ") + ".");
$("sforget").onclick = () => { if (confirm("Forget the addresses this account has signed in from? The next sign-in is learned again without a message.")) signinCall("/forget", "POST", null, () => "Known addresses forgotten."); };
loadSignin();
