(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);
  let data = null, busy = false;

  function bytes(n) {
    const u = ["B", "KB", "MB", "GB", "TB"]; let i = 0; n = Number(n) || 0;
    while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
    return (i ? n.toFixed(1) : n) + " " + u[i];
  }
  function say(text, cls) { const m = $("msg"); m.textContent = text || ""; m.className = cls || ""; }
  async function api(path, opts) {
    const r = await fetch(path, opts);
    if (r.status === 401) { location.href = "/login.html"; throw new Error("not signed in"); }
    return r;
  }
  async function detail(r, fallback) { try { const j = await r.json(); return typeof j.detail === "string" ? j.detail : fallback; } catch (e) { return fallback; } }
  function card(label, value, cls) { const c = document.createElement("div"); c.className = "card"; const b = document.createElement("b"); b.textContent = value; if (cls) b.className = cls; const s = document.createElement("span"); s.className = "muted"; s.textContent = label; c.append(b, s); return c; }

  function draw(d) {
    data = d;
    const pct = d.total ? Math.round(100 * (d.total - d.free) / d.total) : 0;
    const rem = (d.removable || []);
    const remBytes = rem.reduce((a, p) => a + p.bytes, 0);
    const cards = $("cards"); cards.replaceChildren(
      card("Disk free (" + pct + "% used)", bytes(d.free), pct >= 95 ? "crit" : pct >= 85 ? "warn" : ""),
      card("Package cache", bytes(d.apt_cache_bytes)),
      card("System journal", bytes(d.journal_bytes)),
      card("Removable packages", rem.length ? rem.length + " (" + bytes(remBytes) + ")" : "none"));
    $("do_cache").disabled = busy || d.apt_cache_bytes < 1024 * 1024;
    $("do_cache").textContent = "Clean the package cache (" + bytes(d.apt_cache_bytes) + ")";

    const rows = $("rows"); rows.replaceChildren();
    $("pkgerr").textContent = d.removable_error ? "Could not list the packages: " + d.removable_error : "";
    if (!rem.length && !d.removable_error) { const tr = document.createElement("tr"), td = document.createElement("td"); td.colSpan = 3; td.className = "muted"; td.textContent = "Nothing to remove."; tr.append(td); rows.append(tr); }
    for (const p of rem) {
      const tr = document.createElement("tr");
      const a = document.createElement("td"); a.className = "p"; a.textContent = p.name;
      const b = document.createElement("td"); b.textContent = bytes(p.bytes);
      const c = document.createElement("td"); c.textContent = p.protected ? "protected: the action will be refused" : "";
      if (p.protected) c.className = "crit";
      tr.append(a, b, c); rows.append(tr);
    }
    $("do_pkgs").disabled = busy || !rem.length || rem.some((p) => p.protected);

    $("jtext").textContent = "The journal uses " + bytes(d.journal_bytes) + ". It can be trimmed safely on the Log cleanup page.";

    const l = d.lvm;
    $("b_lvm").hidden = !l;
    if (l) {
      if (l.can_grow) {
        $("lvmtext").textContent = "The disk volume group \"" + l.vg + "\" has " + bytes(l.vg_free_bytes) + " that no volume uses. The root volume (" + bytes(l.lv_bytes) + ", " + l.fstype + ") can grow into it while running, with no data loss and no deleting.";
        $("do_grow").disabled = busy; $("do_grow").hidden = false;
      } else {
        $("lvmtext").textContent = "The root volume is " + bytes(l.lv_bytes) + " and the volume group \"" + l.vg + "\" has no usable unused space (" + bytes(l.vg_free_bytes) + "). To get more room the virtual disk has to be enlarged first, in your VM or cloud console, outside the panel.";
        $("do_grow").hidden = true;
      }
    }
  }

  async function load() {
    try {
      const r = await api("/api/freespace");
      if (!r.ok) { say(await detail(r, "Could not read the disk information."), "bad"); return; }
      draw(await r.json());
    } catch (e) { say("Could not reach the panel.", "bad"); }
  }

  async function act(path, ask, button) {
    if (busy || !confirm(ask)) return;
    busy = true; button.disabled = true; say("Working... this can take a minute.", "");
    try {
      const r = await api("/api/freespace/" + path, { method: "POST" });
      if (!r.ok) say(await detail(r, "That did not work."), "bad");
      else { const j = await r.json(); say(j.result + (j.freed_bytes ? " Freed " + bytes(j.freed_bytes) + "." : ""), "good"); }
    } catch (e) { say("Could not reach the panel.", "bad"); }
    busy = false;
    await load();
  }

  $("do_cache").onclick = () => act("apt-clean", "Delete the downloaded package files? They are only a cache.", $("do_cache"));
  $("do_pkgs").onclick = () => act("autoremove", "Remove " + ((data && data.removable) ? data.removable.length : 0) + " unused package(s) for good (purge, including their settings)?", $("do_pkgs"));
  $("do_grow").onclick = () => act("grow-root", "Grow the root volume into the unused space? This is safe while the system runs, but cannot be undone.", $("do_grow"));
  load();
})();
