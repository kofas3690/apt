const $ = (id) => document.getElementById(id);

async function api(path, opts) {
  const r = await fetch(path, opts);
  if (r.status === 401) { location.href = "/login.html"; throw new Error("not logged in"); }
  return r;
}
async function errText(r) {
  try { const j = await r.json(); if (typeof j.detail === "string") return j.detail; } catch (e) {}
  return "Request failed (" + r.status + ")";
}
function el(tag, text, cls) { const e = document.createElement(tag); if (text !== undefined) e.textContent = text; if (cls) e.className = cls; return e; }
const post = (path, body) => api(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) });

async function remove(im, btn) {
  const name = im.dangling ? im.id.slice(0, 12) : im.repository + ":" + im.tag;
  if (!confirm("Remove the image " + name + "? It will have to be downloaded again if you need it.")) return;
  $("err").textContent = ""; btn.disabled = true; btn.textContent = "Removing…";
  const r = await post("/api/images/remove", { id: im.id });
  if (!r.ok) $("err").textContent = name + ": " + await errText(r);
  load();
}

$("prune").onclick = async () => {
  if (!confirm("Remove all dangling images (untagged leftovers)?")) return;
  $("err").textContent = ""; $("prune").disabled = true; $("prune").textContent = "Pruning…";
  const r = await post("/api/images/prune");
  if (!r.ok) $("err").textContent = await errText(r);
  else { $("out").hidden = false; $("out").textContent = (await r.json()).output; }
  $("prune").disabled = false; $("prune").textContent = "Prune dangling images";
  load();
};

function draw(d) {
  const tb = $("rows"); tb.replaceChildren();
  $("prune").hidden = true;
  if (!d.installed) { $("banner").textContent = "Docker is not installed on this machine. Install the package docker.io on the Packages page."; return; }
  if (!d.running) { $("banner").textContent = "Docker is installed but its service is not running" + (d.error ? " (" + d.error + ")" : "") + ". Start the docker service on the Services page."; return; }
  const dang = d.images.filter((i) => i.dangling).length;
  $("banner").textContent = d.images.length + " image" + (d.images.length === 1 ? "" : "s") + (dang ? ", " + dang + " dangling" : "") + ".";
  $("prune").hidden = !dang;
  if (!d.images.length) { const tr = el("tr"), td = el("td", "No images.", "muted"); td.colSpan = 5; tr.append(td); tb.append(tr); }
  for (const im of d.images) {
    const tr = el("tr"), n = el("td");
    n.append(el("div", im.dangling ? "(no name)" : im.repository + ":" + im.tag), el("div", im.id.slice(0, 12), "muted m"));
    tr.append(n, el("td", im.size), el("td", im.created));
    tr.append(el("td", im.used ? "Yes" : "No", im.used ? "ok" : "muted"));
    const ac = el("td");
    if (!im.used) { const b = el("button", "Remove"); b.onclick = () => remove(im, b); ac.append(b); }
    tr.append(ac); tb.append(tr);
  }
}

async function load() {
  const r = await api("/api/images");
  if (!r.ok) { $("err").textContent = await errText(r); return; }
  draw(await r.json());
}
load();
