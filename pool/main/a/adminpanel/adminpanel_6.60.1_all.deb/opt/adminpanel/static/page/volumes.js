const $ = (id) => document.getElementById(id);

async function api(path, opts) {
  const r = await fetch(path, opts);
  if (r.status === 401) { location.href = "/login.html"; throw new Error("not logged in"); }
  return r;
}
async function errText(r) {
  try { const j = await r.json(); if (typeof j.detail === "string") return j.detail; } catch (e) {}
  return "Request failed (" + r.status + ")";
}
function el(tag, text, cls) { const e = document.createElement(tag); if (text !== undefined) e.textContent = text; if (cls) e.className = cls; return e; }

async function remove(v, btn) {
  const typed = prompt("Removing the volume deletes its data for good.\n\nType the volume name to confirm:\n" + v.name);
  if (typed === null) return;
  $("err").textContent = ""; btn.disabled = true; btn.textContent = "Removing…";
  const r = await api("/api/volumes/remove", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name: v.name, confirm: typed }) });
  if (!r.ok) $("err").textContent = v.name + ": " + await errText(r);
  load();
}

function draw(d) {
  const tb = $("rows"); tb.replaceChildren();
  if (!d.installed) { $("banner").textContent = "Docker is not installed on this machine. Install the package docker.io on the Packages page."; return; }
  if (!d.running) { $("banner").textContent = "Docker is installed but its service is not running" + (d.error ? " (" + d.error + ")" : "") + ". Start the docker service on the Services page."; return; }
  $("banner").textContent = d.volumes.length + " volume" + (d.volumes.length === 1 ? "" : "s") + ".";
  if (!d.volumes.length) { const tr = el("tr"), td = el("td", "No volumes.", "muted"); td.colSpan = 4; tr.append(td); tb.append(tr); }
  for (const v of d.volumes) {
    const tr = el("tr"), used = v.links == null ? null : v.links > 0;
    tr.append(el("td", v.name, "m"), el("td", v.size || "–"));
    tr.append(el("td", used === null ? "Unknown" : used ? "Yes (" + v.links + ")" : "No", used ? "ok" : "muted"));
    const ac = el("td");
    if (used === false) { const b = el("button", "Remove…"); b.onclick = () => remove(v, b); ac.append(b); }
    tr.append(ac); tb.append(tr);
  }
}

async function load() {
  const r = await api("/api/volumes");
  if (!r.ok) { $("err").textContent = await errText(r); return; }
  draw(await r.json());
}
load();
