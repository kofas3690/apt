const $ = (id) => document.getElementById(id);

async function api(path, opts) {
  const r = await fetch(path, opts);
  if (r.status === 401) { location.href = "/login.html"; throw new Error("not logged in"); }
  return r;
}
async function errText(r) {
  try { const j = await r.json(); if (typeof j.detail === "string") return j.detail; } catch (e) {}
  return "Request failed (" + r.status + ")";
}
function el(tag, text, cls) { const e = document.createElement(tag); if (text !== undefined) e.textContent = text; if (cls) e.className = cls; return e; }
function bytes(n) { if (n == null) return "–"; const u = ["B", "KB", "MB", "GB", "TB"]; let i = 0; while (n >= 1024 && i < 4) { n /= 1024; i++; } return (i ? n.toFixed(1) : n) + " " + u[i]; }
function span(s) {
  if (s == null) return "–";
  const d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60);
  return d ? d + " d " + h + " h" : h ? h + " h " + m + " min" : m + " min";
}

function card(title, e, hint) {
  const c = el("div", undefined, "eng");
  c.append(el("h2", title));
  if (!e.installed) { c.append(el("p", "Not installed." + (hint ? " " + hint : ""), "muted")); return c; }
  if (!e.running) { c.append(el("p", "Installed, but the server is not answering" + (e.error ? " (" + e.error + ")" : "") + ". Start it on the Services page.", "bad")); return c; }
  const f = el("p", undefined, "facts");
  f.append(el("span", "Running", "ok"), el("span", "Version " + e.version), el("span", "Up " + span(e.uptime)), el("span", (e.connections ?? "–") + " connection" + (e.connections === 1 ? "" : "s")));
  c.append(f);
  const t = el("table"), th = el("thead"), hr = el("tr");
  for (const x of ["Database", "Size", "Tables"]) hr.append(el("th", x));
  th.append(hr); t.append(th);
  const tb = el("tbody");
  for (const d of e.databases) {
    const tr = el("tr");
    tr.append(el("td", d.name + (d.system ? "  (system)" : "")), el("td", bytes(d.size)), el("td", d.tables == null ? "–" : String(d.tables)));
    tb.append(tr);
  }
  if (!e.databases.length) { const tr = el("tr"), td = el("td", "No databases.", "muted"); td.colSpan = 3; tr.append(td); tb.append(tr); }
  t.append(tb); const w = el("div", undefined, "tbl-wrap"); w.append(t); c.append(w);
  return c;
}

(async () => {
  const r = await api("/api/databases");
  if (!r.ok) { $("err").textContent = await errText(r); return; }
  const d = await r.json(), box = $("engines");
  box.append(card("MariaDB / MySQL", d.mysql, "Install the package mariadb-server on the Packages page."));
  box.append(card("PostgreSQL", d.postgres, "Install the package postgresql on the Packages page."));
})();
