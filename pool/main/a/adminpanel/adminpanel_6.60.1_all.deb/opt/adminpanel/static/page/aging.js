const $ = (id) => document.getElementById(id);
let editing = null;

async function api(path, opts) {
  const r = await fetch(path, opts);
  if (r.status === 401) { location.href = "/login.html"; throw new Error("not logged in"); }
  return r;
}
async function errText(r) {
  try { const j = await r.json(); if (typeof j.detail === "string") return j.detail; } catch (e) {}
  if (r.status === 422) return "Those values are not valid.";
  return "Request failed (" + r.status + ")";
}
function el(tag, text, cls) { const e = document.createElement(tag); if (text !== undefined) e.textContent = text; if (cls) e.className = cls; return e; }

function startEdit(a) {
  editing = a; $("edit").hidden = false; $("ehead").textContent = "Rules for " + a.name; $("msg").textContent = "";
  $("maxon").checked = a.max_days != null; $("maxd").value = a.max_days != null ? a.max_days : 90;
  $("warn").value = a.warn_days != null ? a.warn_days : 7;
  $("expon").checked = !!a.expires; $("exp").value = a.expires || "";
  $("edit").scrollIntoView();
}

$("cancel").onclick = () => { $("edit").hidden = true; editing = null; };
$("edit").onsubmit = async (e) => {
  e.preventDefault(); $("err").textContent = "";
  const body = { name: editing.name, max_days: $("maxon").checked ? parseInt($("maxd").value, 10) : null,
                 warn_days: parseInt($("warn").value, 10), expires: $("expon").checked ? $("exp").value : null };
  if ($("expon").checked && !$("exp").value) { $("err").textContent = "Choose the expiry date."; return; }
  const r = await api("/api/aging/set", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  if (!r.ok) { $("err").textContent = await errText(r); return; }
  $("msg").textContent = "Saved the rules for " + editing.name + "."; $("edit").hidden = true; editing = null; load();
};

function draw(d) {
  const tb = $("rows"); tb.replaceChildren();
  if (!d.accounts.length) { const tr = el("tr"), td = el("td", "No ordinary login accounts.", "muted"); td.colSpan = 6; tr.append(td); tb.append(tr); }
  for (const a of d.accounts) {
    const tr = el("tr"), n = el("td", a.name);
    if (a.locked) n.append(" ", el("span", "(locked)", "muted"));
    tr.append(n, el("td", a.must_change ? "must change at next sign-in" : a.changed || "–"));
    const by = el("td");
    if (a.password_expires) {
      by.append(a.password_expires + " ");
      by.append(el("span", a.days_left < 0 ? "(overdue)" : "(" + a.days_left + " days)", a.days_left < 0 ? "bad" : a.days_left <= 7 ? "warn" : "muted"));
    } else by.append(el("span", "never", "muted"));
    tr.append(by, el("td", a.warn_days != null ? a.warn_days + " days" : "–"), el("td", a.expires || "never"));
    const ac = el("td"), b = el("button", "Change rules"); b.onclick = () => startEdit(a); ac.append(b); tr.append(ac); tb.append(tr);
  }
}

async function load() {
  const r = await api("/api/aging");
  if (!r.ok) { $("err").textContent = await errText(r); return; }
  draw(await r.json());
}
load();
