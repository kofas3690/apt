/* Quick VPN: turn WireGuard on with one button, add devices by scanning a code.
   Everything here goes through /api/network/vpn/easy/*; the advanced editor on the same page is separate. */
(() => {
  const $ = (id) => document.getElementById(id);
  const JSON_H = { "Content-Type": "application/json" };
  const PANEL_PORT = location.port ? Number(location.port) : (location.protocol === "https:" ? 443 : 80);
  const box = $("qv");
  let data = null, busy = false, conf = "", confName = "device";

  async function api(path, opts) {
    const r = await fetch(path, opts);
    // A 401 on a change is a wrong password or code (step-up), not a lost session: show it (as panel.js does)
    if (r.status === 401 && !(opts && opts.method && opts.method !== "GET")) { location.href = "/login.html"; throw new Error("not logged in"); }
    return r;
  }
  async function errText(r) {
    try { const j = await r.json(); if (typeof j.detail === "string") return j.detail; } catch (e) {}
    return "Request failed (" + r.status + ")";
  }
  function h(tag, props, ...kids) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(props || {})) {
      if (k === "text") e.textContent = v;
      else if (k === "class") e.className = v;
      else if (k.startsWith("on")) e[k] = v;
      else e.setAttribute(k, v);
    }
    for (const c of kids) if (c != null) e.append(c);
    return e;
  }
  // The address a device connects to: never one inside the VPN (the page may itself be open through the VPN)
  function inVpn(h) {
    const m = /^(\d+)\.(\d+)\.(\d+)\.(\d+)$/.exec(h || ""), s = data && /^(\d+)\.(\d+)\.(\d+)\./.exec(data.subnet || "");
    return !!(m && s && m[1] === s[1] && m[2] === s[2] && m[3] === s[3]);
  }
  function publicHost(saved) {
    for (const h of [saved, data && data.host]) if (h && !inVpn(h)) return h;
    return "";
  }
  const btn = (text, fn, cls) => h("button", { type: "button", text, onclick: fn, class: cls || "" });
  const muted = (text) => h("p", { class: "muted", text });
  const warn = (text) => h("p", { class: "warn", text });
  async function copy(t) { try { await navigator.clipboard.writeText(t); } catch (e) { prompt("Copy this:", t); } }
  function ago(s) {
    if (s == null) return "never";
    if (s < 90) return s + " s ago";
    if (s < 5400) return Math.round(s / 60) + " min ago";
    if (s < 172800) return Math.round(s / 3600) + " h ago";
    return Math.round(s / 86400) + " days ago";
  }
  function fmtBytes(n) {
    const u = ["B", "KB", "MB", "GB", "TB"]; let i = 0;
    while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
    return (i ? n.toFixed(1) : Math.round(n)) + " " + u[i];
  }
  const cloudNote = (port) => muted(
    "Cloud servers (AWS, Lightsail, Azure, DigitalOcean and so on) have a second firewall in the provider's own website. " +
    "Open UDP port " + port + " there too, or devices cannot connect.");

  async function keep() {
    for (let i = 0; i < 8; i++) {
      try {
        const r = await api("/api/network/confirm", { method: "POST" });
        if (r.ok) return "";
        if (r.status === 400) return await errText(r);          // nothing is waiting: it was already undone
      } catch (e) { /* the connection is coming back (adding or removing a device restarts the tunnel) */ }
      await new Promise((res) => setTimeout(res, 3000));
    }
    return "The panel could not be reached to keep the change, so it will undo itself.";
  }
  const refreshAdvanced = () => { try { if (typeof loadConfig === "function") loadConfig(false); } catch (e) {} };
  // Before a change: is the panel reachable from this page right now? A window left open for a long time (the card does not
  // refresh meanwhile) can leave the browser holding a dead connection; this quick look also opens a fresh one.
  const UNREACHABLE = "The panel can't be reached from this page right now (is your VPN connected?). Nothing was changed. Reload the page and try again.";
  async function reachable() {
    const ctl = new AbortController(), t = setTimeout(() => ctl.abort(), 8000);
    try {
      const r = await fetch("/api/network/vpn/easy?panel_port=" + PANEL_PORT, { cache: "no-store", signal: ctl.signal });
      if (r.status === 401) { location.href = "/login.html"; return false; }     // signed out meanwhile
      return true;
    } catch (e) {
      return false;
    } finally {
      clearTimeout(t);
    }
  }
  async function change(path, body) {
    /* POST a change, then keep it. Returns [response JSON or null, error text or ""]. */
    let r;
    if (!(await reachable())) return [null, UNREACHABLE];
    try { r = await api(path, { method: "POST", headers: JSON_H, body: JSON.stringify(body || {}) }); }
    catch (e) { return [null, "The connection dropped. If the change went through, it undoes itself in two minutes unless you press Keep changes in the box above."]; }
    if (!r.ok) return [null, await errText(r)];
    const j = await r.json();
    const msg = j.pending ? await keep() : "";
    refreshAdvanced();
    return [j, msg];
  }
  const stepUp = (pw, code) => ({ password: pw.value, code: code.value.replace(/\s+/g, "") });
  function stepFields() {
    const pw = h("input", { type: "password", autocomplete: "current-password", placeholder: "Your panel password", "aria-label": "Your panel password" });
    const code = h("input", { type: "text", inputmode: "numeric", autocomplete: "one-time-code", maxlength: "8", placeholder: "2FA code",
      "aria-label": "Code from your authenticator app", style: "width:110px" });
    return [pw, code];
  }

  async function load() {
    let r;
    try { r = await api("/api/network/vpn/easy?panel_port=" + PANEL_PORT); }
    catch (e) { return; }               // a redirect to the sign-in page, or the network dropped: the next refresh tries again
    if (!r.ok) { box.replaceChildren(h("p", { class: "crit", text: await errText(r) })); return; }
    data = await r.json();
    if (!busy && !typing()) render();   // a mistake in drawing the card shows up as an error, it is not swallowed
  }

  // Redrawing the card replaces its inputs, so never redraw while someone is filling one in
  function typing() {
    const a = document.activeElement;
    if (a && box.contains(a) && /^(INPUT|TEXTAREA)$/.test(a.tagName)) return true;
    return [...box.querySelectorAll('input[type="password"], input[inputmode="numeric"], textarea')].some((e) => e.value);
  }

  function render() {
    const d = data;
    if (!d) return;
    const kids = [];
    if (!d.available) {
      kids.push(h("p", { class: "big", text: "WireGuard isn't installed" }),
        h("p", {}, "Run ", h("code", { text: "sudo apt install -y wireguard-tools" }), " on the server, then reload this page."));
      box.replaceChildren(...kids);
      return;
    }
    if (d.pending) kids.push(warn("A network change is waiting for you to keep or revert it (see the box above). Quick VPN is paused until then."));
    kids.push(!d.enabled ? renderOff(d) : d.role === "member" ? renderMember(d) : renderOn(d));
    box.replaceChildren(...kids.flat());
  }

  function renderOff(d) {
    const port = h("input", { type: "number", min: "1024", max: "65535", value: "51820", style: "width:100px" });
    const [pw, code] = stepFields();
    const go = btn("Turn on the VPN", async () => {
      const p = Number(port.value);
      if (!Number.isInteger(p) || p < 1024 || p > 65535) { alert("The port must be a number from 1024 to 65535."); return; }
      if (!pw.value || code.value.trim().length < 6) { alert("Enter your panel password and the code from your authenticator app."); return; }
      busy = true; go.disabled = true; go.textContent = "Turning on…";
      const [j, msg] = await change("/api/network/vpn/easy/enable", { port: p, panel_port: PANEL_PORT, ...stepUp(pw, code) });
      pw.value = ""; code.value = "";
      busy = false;
      if (!j) { go.disabled = false; go.textContent = "Turn on the VPN"; alert(msg); return; }
      await load();
      if (msg) { alert("The VPN was not kept: " + msg); return; }
      const bad = Object.entries(j.firewall || {}).filter(([, v]) => v !== "ok");
      if (bad.length) alert("The VPN is on, but the firewall rule could not be added automatically (" + bad.map(([k, v]) => k + ": " + v).join("; ") + "). Add it on the Firewall page.");
    }, "primary");
    const out = [
      h("p", { class: "big", text: "The VPN is off" }),
      h("h3", { text: "Start a VPN on this server" }),
      h("p", {}, "Creates a private network that only your own devices and servers can join, opens its port in this server's firewall, and starts the tunnel. Do this on the one server that your devices can reach from the internet. You can turn it off again at any time."),
      h("div", { class: "row" }, h("label", {}, "UDP port ", port)),
      h("div", { class: "row" }, pw, code, go),
      muted("Your password and 2FA code are asked again because this opens a new way into the server."),
      cloudNote("51820 (or the port you chose)"),
    ];
    const join = h("textarea", { placeholder: "apvpn1.…  or the WireGuard config ([Interface] …)", spellcheck: "false", "aria-label": "Join code or WireGuard config",
      style: "width:100%; height:110px; font: 12px var(--mono)" });
    // The config file that "Add a server" offers to download works too: read here, it only leaves this page in the join call
    const file = h("input", { type: "file", accept: ".conf,text/plain", "aria-label": "WireGuard config file", style: "display:none" });
    file.onchange = () => {
      const f = file.files && file.files[0];
      file.value = "";
      if (!f) return;
      if (f.size > 4000) { alert("That file is too big for a WireGuard config. Choose the .conf that Add a server downloaded."); return; }
      const rd = new FileReader();
      rd.onload = () => {
        const t = String(rd.result || "");
        if (!/\[interface\]/i.test(t)) { alert("That file is not a WireGuard config (it has no [Interface] section)."); return; }
        join.value = t;
      };
      rd.readAsText(f);
    };
    const pick = btn("Choose a .conf file…", () => file.click());
    const [jpw, jcode] = stepFields();
    const jgo = btn("Join", async () => {
      if (!join.value.trim()) { alert("Paste the join code, or choose the server's WireGuard config file, first."); return; }
      if (!jpw.value || jcode.value.trim().length < 6) { alert("Enter your panel password and the code from your authenticator app."); return; }
      busy = true; jgo.disabled = true; jgo.textContent = "Joining…";
      const [r, msg] = await change("/api/network/vpn/easy/join", { join: join.value, panel_port: PANEL_PORT, ...stepUp(jpw, jcode) });
      jpw.value = ""; jcode.value = "";
      busy = false;
      if (!r) { jgo.disabled = false; jgo.textContent = "Join"; alert(msg); return; }
      join.value = "";
      await load();
      if (msg) alert("Joining was not kept: " + msg);
    }, "primary");
    out.push(h("h3", { text: "Or join another server's VPN" }),
      h("p", {}, "On the server that runs the VPN, choose ", h("strong", { text: "Add a server" }), " and paste the join code it gives you here, or the WireGuard config it lets you download (paste its text, or choose the file). This server then becomes reachable from your devices, without opening any port on it."),
      join, h("div", { class: "row" }, pick, file), h("div", { class: "row" }, jpw, jcode, jgo));
    if (d.kernel === false) out.push(warn("This server's kernel may not support WireGuard. If turning it on fails, that is why."));
    return out;
  }

  function linkText(x) {
    return x.online ? "connected" : (x.handshake_ago == null ? "never connected" : "last seen " + ago(x.handshake_ago));
  }

  function renderMember(d) {
    const out = [];
    const hub = d.hub || { endpoint: "", online: false, handshake_ago: null };
    out.push(h("p", { class: "big" }, h("span", { class: "dot " + (hub.online ? "on" : "") }), hub.online ? "Joined a VPN" : "Joined a VPN, not connected"));
    out.push(muted("This server is " + d.address + " in the private network " + d.subnet + ", which is run by the server at " + hub.endpoint + ". Link to that server: " + linkText(hub) + "."));
    const url = location.protocol + "//" + d.address + (location.port ? ":" + location.port : "") + "/";
    out.push(h("p", {}, "From your devices on the VPN, open this panel at ", h("code", { text: url }), " ", btn("Copy", () => copy(url))));
    if (!hub.online && hub.handshake_ago == null) {
      out.push(warn("Not connected yet. Check that the address in the join code is right, and that the other server's UDP port is open, in its firewall and in its cloud provider's firewall."));
    }
    const f = d.firewall;
    if (f && f.active && !f.panel_open) {
      out.push(h("p", { class: "muted" }, "The firewall has no rule letting VPN devices reach this panel (port " + PANEL_PORT + "). ",
        btn("Add the rule", () => allow(PANEL_PORT, "tcp", d.subnet))));
    }
    if (d.signin && d.signin.enabled && !d.signin.covered) {
      out.push(warn("\"Where people may sign in from\" (Accounts, Panel access) is on and does not include " + d.subnet +
        ", so this panel will refuse devices that come through the VPN. Add " + d.subnet + " to that list."));
    }
    out.push(...panelAccess(d));
    const leave = btn("Leave the VPN", turnOff, "danger");
    if (d.via_vpn) { leave.disabled = true; leave.title = "You are connected through the VPN right now"; }
    out.push(muted("Devices and other servers are added on the server that runs the VPN."), h("div", { class: "row" }, leave));
    return out;
  }

  function renderOn(d) {
    const out = [];
    d.devices = d.devices || []; d.servers = d.servers || [];
    out.push(h("p", { class: "big" }, h("span", { class: "dot " + (d.up ? "on" : "") }), d.up ? "The VPN is on" : "The VPN is set up but the tunnel is not running"));
    out.push(h("p", { class: "muted", text: "Private network " + d.subnet + ". This server is " + d.address + " inside it, listening on UDP port " + d.port + "." }));
    const url = location.protocol + "//" + d.address + (location.port ? ":" + location.port : "") + "/";
    out.push(h("p", {}, "From a connected device, open this panel at ", h("code", { text: url }), " ", btn("Copy", () => copy(url))));

    const f = d.firewall;
    if (f && f.active && !f.udp_open) {
      out.push(h("p", { class: "warn" }, "The firewall is not allowing UDP port " + d.port + ", so devices cannot connect. ",
        btn("Open it", () => allow(d.port, "udp", null))));
    }
    if (f && f.active && !f.panel_open) {
      out.push(h("p", { class: "muted" }, "The firewall has no rule letting VPN devices reach this panel (port " + PANEL_PORT + "). Not needed while the panel is open to everyone, but needed once you close it to the public. ",
        btn("Add the rule", () => allow(PANEL_PORT, "tcp", d.subnet))));
    }
    if (d.signin && d.signin.enabled && !d.signin.covered) {
      out.push(warn("\"Where people may sign in from\" (Accounts, Panel access) is on and does not include " + d.subnet +
        ", so the panel will refuse devices that connect through the VPN. Add " + d.subnet + " to that list."));
    }
    if (!d.isolated) {
      out.push(h("p", { class: "warn" }, "This VPN was made before the rule that keeps its devices from reaching anything but this server. ",
        btn("Add the protection", protect)));
    }
    if (d.isolated && d.rules_ok === false) {
      out.push(h("p", { class: "warn" }, "The VPN's protection rules are not active on this server (for example right after upgrading from 6.37). ",
        btn("Repair", protect)));
    }
    if (d.relay && d.forwarding === false) {
      out.push(h("p", { class: "warn" }, "Forwarding for the VPN is off (other software may have switched it off for the whole server), so your devices cannot reach your servers. ",
        btn("Repair", protect)));
    }
    if (d.relay && f && f.active && !f.relay_rule) {
      out.push(h("p", { class: "warn" }, "The firewall is missing the rule that lets VPN traffic pass between your devices and your servers. ",
        btn("Repair", protect)));
    }
    out.push(cloudNote(d.port));
    out.push(...panelAccess(d));

    const table = (list, kind) => {
      const head = h("tr", {}, ...[kind === "server" ? "Server" : "Device", "Status", ""].map((t) => h("th", { text: t })));
      const rows = list.map((x) => {
        const status = h("td", {}, h("span", { class: "dot " + (x.online ? "on" : "") }), linkText(x),
          h("br"), h("span", { class: "muted", text: "\u2193 " + fmtBytes(x.tx) + "  \u2191 " + fmtBytes(x.rx) }));
        const rm = btn("Remove", () => removeDevice(x, kind), "danger");
        if (x.you) { rm.disabled = true; rm.title = "This is the device you are using right now"; }
        const name = h("td", {}, h("strong", { text: x.label + (x.you ? " (this device)" : "") }), h("br"), h("span", { class: "muted", text: x.address }));
        if (kind === "server") {
          const href = location.protocol + "//" + x.address + (location.port ? ":" + location.port : "") + "/";
          name.append(" ", h("a", { href, target: "_blank", rel: "noopener noreferrer", text: "open its panel" }));
        }
        return h("tr", {}, name, status, h("td", {}, rm));
      });
      return h("table", {}, h("thead", {}, head), h("tbody", {}, ...rows));
    };
    out.push(h("h3", { text: "Devices" }));
    out.push(d.devices.length ? table(d.devices, "device") : muted("No devices yet. Add your phone or laptop below."));
    const add = btn("Add a device", openDevice, "primary");
    if (d.devices.length >= d.max_devices || d.pending) add.disabled = true;
    out.push(h("div", { class: "row" }, add));
    out.push(h("h3", { text: "Servers" }));
    out.push(d.servers.length ? table(d.servers, "server")
      : muted("No servers have joined yet. Add one to reach its panel from your devices, even when it sits behind a router with no open ports."));
    const addSrv = btn("Add a server", openServer);
    if (d.servers.length >= d.max_servers || d.pending) addSrv.disabled = true;
    out.push(h("div", { class: "row" }, addSrv));
    out.push(muted("Devices reach this server and the servers above. Servers reach the whole VPN. Devices never reach each other, and nothing in the VPN reaches anything beyond it."));
    const off = btn("Turn off the VPN", turnOff, "danger");
    if (d.via_vpn) { off.disabled = true; off.title = "You are connected through the VPN right now"; }
    out.push(h("div", { class: "row" }, off));
    return out;
  }

  // "Only through the VPN" (6.42.0): who can reach this panel's port at all
  async function keepVpnOnly() {
    for (let i = 0; i < 8; i++) {
      try {
        const r = await api("/api/network/vpn/easy/vpnonly/keep", { method: "POST" });
        if (r.ok) return ["", await r.json()];
        if (r.status === 400) return [await errText(r), null];
      } catch (e) { /* try again: the change itself never touches the VPN's own rule */ }
      await new Promise((res) => setTimeout(res, 3000));
    }
    return ["The panel could not be reached to keep the change, so the port reopens by itself within two minutes.", null];
  }
  function panelAccess(d) {
    const v = d.vpn_only;
    const out = [h("h3", { text: "Panel access" })];
    if (!v) { out.push(muted("The firewall could not be read, so who can reach this panel is not known.")); return out; }
    const port = v.port || PANEL_PORT;
    const [pw, code] = stepFields();
    if (v.pending) {
      out.push(warn("A change to who can reach this panel is waiting to be kept. If nobody keeps it from a device on the VPN, port " + port + " reopens by itself within two minutes."));
      return out;
    }
    if (v.on) {
      out.push(h("p", {}, h("span", { class: "dot on" }), "Only through the VPN. Port " + port + " is closed to everyone outside " + d.subnet + "."));
      out.push(muted("If you ever lose the VPN, sign in to the server's console (for Lightsail: Connect using SSH in the browser) and run: sudo adminpanel-setup vpnonly off"));
      const go = btn("Open to everyone again", async () => {
        if (!pw.value || code.value.trim().length < 6) { alert("Enter your panel password and the code from your authenticator app."); return; }
        if (!confirm("Open port " + port + " to everyone again?\n\nAnyone on the internet can then reach this panel's sign-in page.")) return;
        busy = true; go.disabled = true;
        const [r, msg] = await change("/api/network/vpn/easy/vpnonly", { on: false, ...stepUp(pw, code) });
        busy = false; pw.value = ""; code.value = "";
        if (!r) { go.disabled = false; alert(msg); return; }
        load();
      });
      out.push(h("div", { class: "row" }, pw, code, go));
      return out;
    }
    out.push(h("p", {}, h("span", { class: "dot" }), "Open to everyone: anyone who can reach port " + port + " sees the sign-in page."));
    if (v.wanted) out.push(warn("This panel was set to be reachable only through the VPN, but its port is open outside it again (for example after sudo adminpanel-setup vpnonly off, or a rule added by hand). Close it again below, or press Open to everyone to make it official."));
    if (v.outside.length) out.push(muted("Rules that open it now: " + v.outside.join("; ")));
    const go = btn("Allow only the VPN", async () => {
      if (!pw.value || code.value.trim().length < 6) { alert("Enter your panel password and the code from your authenticator app."); return; }
      if (!confirm("Close port " + port + " to everyone outside the VPN?\n\nThis page then has two minutes to confirm, through the VPN, that it can still reach the panel. If it cannot, the port reopens by itself.")) return;
      busy = true; go.disabled = true; go.textContent = "Closing…";
      const [r, msg] = await change("/api/network/vpn/easy/vpnonly", { on: true, ...stepUp(pw, code) });
      pw.value = ""; code.value = "";
      if (!r) { busy = false; go.disabled = false; go.textContent = "Allow only the VPN"; alert(msg); return; }
      if (r.waiting) {
        const [err, kept] = await keepVpnOnly();
        if (err) alert("The change was not kept: " + err);
        else if (kept && kept.closed) alert("Done. " + kept.closed + (kept.closed === 1 ? " connection from outside the VPN was ended." : " connections from outside the VPN were ended."));
      }
      busy = false;
      load();
    }, "primary");
    if (v.wanted) {
      const ok = btn("Open to everyone", async () => {
        if (!pw.value || code.value.trim().length < 6) { alert("Enter your panel password and the code from your authenticator app."); return; }
        busy = true;
        const [r, msg] = await change("/api/network/vpn/easy/vpnonly", { on: false, ...stepUp(pw, code) });
        busy = false; pw.value = ""; code.value = "";
        if (!r) { alert(msg); return; }
        load();
      });
      ok.title = "Keep it open to everyone, and stop the alert about it";
      out.push(h("div", { class: "row" }, ok));
    }
    if (!d.via_vpn) { go.disabled = true; go.title = "Open this page through the VPN first, so you know you can still reach it"; }
    else if (!v.closed_by_default) { go.disabled = true; go.title = "The firewall lets everything in by default, so closing one port changes nothing"; }
    out.push(h("div", { class: "row" }, pw, code, go));
    if (!d.via_vpn) out.push(muted("To switch this on, open the panel through the VPN, at " + location.protocol + "//" + d.address + ":" + port + "/ from a device on the VPN."));
    else if (!v.closed_by_default) out.push(warn("The firewall lets everything in by default (ufw default incoming is allow). Run sudo ufw default deny incoming first."));
    out.push(muted("This changes this server's own firewall (ufw). If your cloud provider has its own firewall (Lightsail: Networking, IPv4 firewall), remove port " + port + " there too."));
    return out;
  }

  async function allow(port, proto, source) {
    const body = { port, proto }; if (source) body.source = source;
    const r = await api("/api/firewall/allow", { method: "POST", headers: JSON_H, body: JSON.stringify(body) });
    if (!r.ok) alert(await errText(r));
    load();
  }

  async function removeDevice(x, kind) {
    const what = kind === "server" ? "It leaves the VPN at once. To join again it needs a new join code." : "It is disconnected at once and can't connect again unless you add it as a new device.";
    if (!confirm("Remove \"" + x.label + "\"?\n\n" + what)) return;
    busy = true;
    const [, msg] = await change("/api/network/vpn/easy/revoke", { public_key: x.public_key });
    busy = false;
    if (msg) alert(msg);
    load();
  }

  async function protect() {
    busy = true;
    const [, msg] = await change("/api/network/vpn/easy/protect", {});
    busy = false;
    if (msg) alert(msg);
    load();
  }

  async function turnOff() {
    const member = data && data.role === "member";
    if (!confirm(member ? "Leave the VPN?\n\nThis server is disconnected from it. To join again you need a new join code from the server that runs the VPN."
      : "Turn the VPN off?\n\nEvery device and server is disconnected and the VPN's firewall rules are removed. Your lists are deleted; to use the VPN again you add each device and server again.")) return;
    busy = true;
    const [, msg] = await change("/api/network/vpn/easy/disable", { panel_port: PANEL_PORT });
    busy = false;
    if (msg) alert(msg);
    load();
  }

  /* ---- adding a device ---- */
  const dlg = $("devdlg");
  function openDevice() {
    $("devName").value = "";
    let host = ""; try { host = localStorage.getItem("vpnHost") || ""; } catch (e) {}
    $("devHost").value = publicHost(host);
    $("devPw").value = ""; $("devCode").value = "";
    $("devErr").textContent = ""; $("dres").hidden = true; $("dform").hidden = false;
    dlg.showModal();
    $("devName").focus();
  }
  function drawQr(rows) {
    const cv = $("devqr");
    if (!rows) { cv.hidden = true; return; }
    cv.hidden = false;
    const scale = 5, border = 4, n = rows.length;
    cv.width = cv.height = (n + border * 2) * scale;
    const ctx = cv.getContext("2d");
    ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, cv.width, cv.height);
    ctx.fillStyle = "#000";
    rows.forEach((row, y) => { for (let x = 0; x < n; x++) if (row[x] === "1") ctx.fillRect((x + border) * scale, (y + border) * scale, scale, scale); });
  }
  function wipe() {
    conf = ""; $("devconf").textContent = ""; $("devPw").value = ""; $("devCode").value = "";
    const cv = $("devqr"); cv.getContext("2d").clearRect(0, 0, cv.width, cv.height); cv.width = cv.height = 1;
    $("dres").hidden = true; $("dform").hidden = false;
  }
  dlg.addEventListener("close", () => { wipe(); load(); });
  $("devCancel").onclick = () => dlg.close();
  $("devDone").onclick = () => dlg.close();
  $("devCopy").onclick = () => copy(conf);
  $("devDl").onclick = () => {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([conf], { type: "text/plain" }));
    a.download = (confName.replace(/[^A-Za-z0-9._-]+/g, "-") || "device") + ".conf";
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);           // the file holds the device's private key
  };
  $("devGo").onclick = async () => {
    const label = $("devName").value.trim(), endpoint = $("devHost").value.trim();
    $("devErr").textContent = "";
    if (!label) { $("devErr").textContent = "Give the device a name."; return; }
    if (!endpoint) { $("devErr").textContent = "Enter this server's address."; return; }
    if (!$("devPw").value || $("devCode").value.trim().length < 6) { $("devErr").textContent = "Enter your panel password and 2FA code."; return; }
    $("devGo").disabled = true; busy = true; $("devErr").textContent = "Adding…";
    let d, msg;
    try { [d, msg] = await change("/api/network/vpn/easy/device", { label, endpoint, ...stepUp($("devPw"), $("devCode")) }); }
    finally { $("devGo").disabled = false; busy = false; $("devPw").value = ""; $("devCode").value = ""; }
    if (!d) { $("devErr").textContent = msg; return; }
    if (msg) { $("devErr").textContent = "The device was not added: " + msg; return; }   // never show a config that was undone
    $("devErr").textContent = "";
    try { localStorage.setItem("vpnHost", endpoint.replace(/:\d+$/, "")); } catch (e) {}
    conf = d.conf; confName = d.label;
    $("devTitle").textContent = d.label;
    $("devconf").textContent = d.conf;
    drawQr(d.qr);
    $("dform").hidden = true; $("dres").hidden = false;
  };

  /* ---- adding a server ---- */
  const sdlg = $("srvdlg");
  let joinText = "", srvConf = "", srvName = "server";
  function openServer() {
    $("srvName").value = ""; $("srvPw").value = ""; $("srvCode").value = "";
    let host = ""; try { host = localStorage.getItem("vpnHost") || ""; } catch (e) {}
    $("srvHost").value = publicHost(host);
    $("srvErr").textContent = ""; $("sres").hidden = true; $("sform").hidden = false;
    sdlg.showModal();
    $("srvName").focus();
  }
  function wipeServer() {
    joinText = ""; srvConf = ""; $("srvJoin").value = ""; $("srvPw").value = ""; $("srvCode").value = "";
    $("sres").hidden = true; $("sform").hidden = false;
  }
  sdlg.addEventListener("close", () => { wipeServer(); load(); });
  $("srvCancel").onclick = () => sdlg.close();
  $("srvDone").onclick = () => sdlg.close();
  $("srvCopy").onclick = () => copy(joinText);
  $("srvDl").onclick = () => {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([srvConf], { type: "text/plain" }));
    a.download = (srvName.replace(/[^A-Za-z0-9._-]+/g, "-") || "server") + ".conf";
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);           // the file holds the server's private key
  };
  $("srvGo").onclick = async () => {
    const label = $("srvName").value.trim(), endpoint = $("srvHost").value.trim();
    $("srvErr").textContent = "";
    if (!label) { $("srvErr").textContent = "Give the server a name."; return; }
    if (!endpoint) { $("srvErr").textContent = "Enter this server's address."; return; }
    if (!$("srvPw").value || $("srvCode").value.trim().length < 6) { $("srvErr").textContent = "Enter your panel password and 2FA code."; return; }
    $("srvGo").disabled = true; busy = true; $("srvErr").textContent = "Adding…";
    let d, msg;
    try { [d, msg] = await change("/api/network/vpn/easy/server", { label, endpoint, ...stepUp($("srvPw"), $("srvCode")) }); }
    finally { $("srvGo").disabled = false; busy = false; $("srvPw").value = ""; $("srvCode").value = ""; }
    if (!d) { $("srvErr").textContent = msg; return; }
    if (msg) { $("srvErr").textContent = "The server was not added: " + msg; return; }   // never show a code that was undone
    $("srvErr").textContent = "";
    try { localStorage.setItem("vpnHost", endpoint.replace(/:\d+$/, "")); } catch (e) {}
    joinText = d.join; srvConf = d.conf; srvName = d.label;
    $("srvTitle").textContent = d.label;
    $("srvUrl").textContent = location.protocol + "//" + d.address + (location.port ? ":" + location.port : "") + "/";
    $("srvJoin").value = d.join;
    $("sform").hidden = true; $("sres").hidden = false;
  };

  load();
  setInterval(() => { if (!document.hidden && !busy && !dlg.open && !sdlg.open) load(); }, 10000);
})();
