const $ = (id) => document.getElementById(id);
// No inline onsubmit="..." attributes: the panel's Content-Security-Policy blocks them, and the form would then reload the page.
document.querySelectorAll("form").forEach((f) => f.addEventListener("submit", (e) => e.preventDefault()));
let me = "", myRole = "", enrolFor = "";

async function api(path, opts) {
  const r = await fetch(path, opts);
  if (r.status === 401 && opts === undefined) { location.href = "/login.html"; throw new Error("not logged in"); }
  return r;
}
async function errText(r) {
  try { const j = await r.json(); if (typeof j.detail === "string") return j.detail; } catch (e) {}
  return "Request failed (" + r.status + ")";
}
function el(tag, text, cls) { const e = document.createElement(tag); if (text !== undefined) e.textContent = text; if (cls) e.className = cls; return e; }
function when(t) { return t ? new Date(t * 1000).toLocaleString() : ""; }
function step() { return { password: $("spw").value, code: $("scode").value.trim() }; }
function needStep() {
  if (!$("spw").value || $("scode").value.trim().length < 6) { $("err").textContent = "Type your password and a current code in the box at the top first."; return false; }
  return true;
}
async function post(path, body, withStep = true) {
  $("err").textContent = ""; $("msg").textContent = "";
  if (withStep) { if (!needStep()) return null; body = Object.assign({}, step(), body); }
  const r = await api(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  if (withStep) $("scode").value = "";          // a code works once
  if (!r.ok) { $("err").textContent = await errText(r); return null; }
  return r.json();
}

function showCodes(name, codes) {
  $("codesfor").textContent = name;
  $("codes").replaceChildren(...codes.map((c) => el("div", c)));
  $("codesbox").hidden = false;
  $("codesbox").scrollIntoView({ block: "nearest" });
}

function drawQr(m, id = "qr") {
  const c = $(id), ctx = c.getContext("2d"), n = m.length, px = Math.floor(200 / n) || 1;
  c.width = c.height = n * px;
  ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, c.width, c.height);
  ctx.fillStyle = "#000";
  for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) if (m[y][x]) ctx.fillRect(x * px, y * px, px, px);
}

async function startEnrol(name) {
  const d = await post("/api/panel/2fa/start", { name });
  if (!d) return;
  enrolFor = name;
  $("enroltitle").textContent = "Set up two-step verification for " + name;
  $("secret").textContent = d.secret;
  drawQr(d.qr);
  $("ecode").value = "";
  $("enrol").hidden = false;
  $("ecode").focus();
}

async function loadAdmins() {
  const r = await api("/api/panel/admins");
  if (!r.ok) { $("err").textContent = await errText(r); return; }
  const d = await r.json();
  me = d.user; myRole = d.role; $("minpw").textContent = d.min_password;
  $("addbox").hidden = myRole !== "admin";
  $("ipbox").hidden = myRole !== "admin";
  if (myRole === "admin") loadIp();
  $("adminshead").textContent = myRole === "admin" ? "Panel users" : "Your account";
  const tb = $("admins"); tb.replaceChildren();
  for (const a of d.admins) {
    const tr = el("tr");
    tr.append(el("td", a.name + (a.me ? " (you)" : "")), el("td", a.role),
      el("td", a.totp ? "On" : "Not set up: cannot sign in", a.totp ? "" : "crit"),
      el("td", a.totp ? String(a.recovery_left) : ""),
      el("td", a.sessions ? String(a.sessions) : ""));
    const td = el("td");
    const b1 = el("button", a.totp ? "Reset two-step" : "Set up");
    b1.onclick = () => startEnrol(a.name);
    td.append(b1);
    if (!a.me && myRole === "admin") {
      const bs = el("select");
      for (const [v, t] of [["viewer", "Viewer"], ["operator", "Operator"], ["admin", "Administrator"]]) { const o = el("option", t); o.value = v; bs.append(o); }
      bs.value = a.role;
      const br = el("button", "Change role");
      br.onclick = async () => {
        if (bs.value === a.role) return;
        if (await post("/api/panel/admins/role", { name: a.name, role: bs.value })) $("msg").textContent = a.name + " is now " + bs.value + ".";
        loadAdmins();
      };
      td.append(" ", bs, " ", br);
      const b2 = el("button", "Remove");
      b2.onclick = async () => {
        if (!confirm("Remove administrator " + a.name + "? They are signed out and can no longer use this panel.")) return;
        if (await post("/api/panel/admins/remove", { name: a.name })) $("msg").textContent = a.name + " was removed.";
        loadAdmins(); loadSessions();
      };
      td.append(" ", b2);
    }
    tr.append(td); tb.append(tr);
  }
}

async function loadSessions() {
  const r = await api("/api/security/status");
  if (!r.ok) return;
  const d = await r.json();
  $("left").textContent = d.totp ? d.recovery_left + " unused code(s) left" : "";
  const tb = $("sess"); tb.replaceChildren();
  for (const s of d.sessions.filter((x) => x.user === d.user)) {
    const tr = el("tr");
    tr.append(el("td", s.ip || ""), el("td", s.ua || ""), el("td", when(s.created)), el("td", when(s.last_seen)));
    const td = el("td");
    if (s.current) td.append(el("span", "this session", "muted"));
    else { const b = el("button", "Sign out"); b.onclick = async () => { await post("/api/security/sessions/revoke", { id: s.id }, false); loadSessions(); }; td.append(b); }
    tr.append(td); tb.append(tr);
  }
}

$("enrolform").onsubmit = async (e) => {
  e.preventDefault();
  const d = await post("/api/panel/2fa/confirm", { name: enrolFor, code: $("ecode").value.trim() }, false);
  if (!d) return;
  $("enrol").hidden = true; $("msg").textContent = "Two-step verification is on for " + enrolFor + ".";
  showCodes(enrolFor, d.codes); loadAdmins(); loadSessions();
};
$("ecancel").onclick = () => { $("enrol").hidden = true; enrolFor = ""; };
$("addform").onsubmit = async (e) => {
  e.preventDefault();
  const name = $("nname").value.trim();
  if (await post("/api/panel/admins/add", { name, new_password: $("npw").value, role: $("nrole").value })) {
    $("npw").value = ""; $("nname").value = "";
    $("msg").textContent = name + " was added. Press Set up beside the name to give them two-step verification; until then they cannot sign in.";
    loadAdmins();
  }
};
$("pwform").onsubmit = async (e) => {
  e.preventDefault();
  if ($("pw1").value !== $("pw2").value) { $("err").textContent = "The two passwords differ."; return; }
  const d = await post("/api/panel/password", { new_password: $("pw1").value });
  if (d) { $("pw1").value = $("pw2").value = ""; $("spw").value = ""; $("msg").textContent = "Password changed." + (d.sessions_ended ? " " + d.sessions_ended + " other session(s) signed out." : ""); loadSessions(); }
};
$("newcodes").onclick = async () => {
  if (!needStep()) return;
  if (!confirm("Make a new set of recovery codes? The old codes stop working.")) return;
  const d = await post("/api/security/recovery", {}, true);
  if (d) { showCodes(me, d.codes); loadAdmins(); loadSessions(); }
};
$("others").onclick = async () => { const d = await post("/api/security/sessions/revoke-others", {}, false); if (d) $("msg").textContent = d.count + " other session(s) signed out."; loadSessions(); loadAdmins(); };
$("copycodes").onclick = () => navigator.clipboard && navigator.clipboard.writeText([...$("codes").children].map((x) => x.textContent).join("\n"));
$("hidecodes").onclick = () => { $("codesbox").hidden = true; $("codes").replaceChildren(); };
loadAdmins(); loadSessions();

async function loadIp() {
  const r = await api("/api/ipallow");
  if (!r.ok) return;
  const d = await r.json();
  $("ipon").checked = d.enabled; $("iplist").value = d.entries.join("\n");
  $("myip").textContent = d.your_ip;
  $("localnote").textContent = d.on_this_machine ? "(this machine: always allowed)" : "";
  $("ipadd").hidden = d.on_this_machine;
}
$("ipadd").onclick = () => {
  const me = $("myip").textContent, lines = $("iplist").value.split("\n").map((x) => x.trim()).filter(Boolean);
  if (!lines.includes(me)) lines.push(me);
  $("iplist").value = lines.join("\n");
};
$("ipsave").onclick = async () => {
  $("err").textContent = ""; $("msg").textContent = "";
  if (!needStep()) return;
  const r = await api("/api/ipallow", { method: "PUT", headers: { "Content-Type": "application/json" },
    body: JSON.stringify(Object.assign({}, step(), { enabled: $("ipon").checked, entries: $("iplist").value.split("\n") })) });
  $("scode").value = "";
  if (!r.ok) { $("err").textContent = await errText(r); return; }
  const d = await r.json();
  $("msg").textContent = d.enabled ? "Saved. Only " + d.entries.length + " listed address(es) can reach the panel now." : "Saved. The list is off: any address may try to sign in.";
  loadIp();
};

let pairTimer = null;
function stopPair() { clearInterval(pairTimer); pairTimer = null; $("pairbox").hidden = true; $("pcode").textContent = ""; }
async function loadPhones() {
  const r = await api("/api/mobile/phones");
  if (!r.ok) return null;
  const d = await r.json();
  $("pnone").hidden = d.phones.length > 0;
  $("phones").replaceChildren(...d.phones.map((p) => {
    const tr = el("tr");
    tr.append(el("td", p.name + (p.current ? " (this phone)" : "")), el("td", p.user), el("td", p.read_only ? "Look only" : "Everyday actions"),
      el("td", when(p.created)), el("td", p.last_seen ? when(p.last_seen) + (p.last_ip ? " from " + p.last_ip : "") : "never"));
    const b = el("button", "Revoke");
    b.onclick = async () => {
      if (!confirm("Sign out " + p.name + "? It will have to be paired again.")) return;
      const x = await api("/api/mobile/phones/" + encodeURIComponent(p.id), { method: "DELETE" });
      if (!x.ok) $("err").textContent = await errText(x); else loadPhones();
    };
    const td = el("td"); td.append(b); tr.append(td);
    return tr;
  }));
  return d;
}
$("padd").onclick = async () => {
  const name = $("pname").value.trim();
  if (!name) { $("err").textContent = "Give the phone a name first."; return; }
  const d = await post("/api/mobile/pair/start", { name, read_only: $("pro").checked, address: $("paddr").value.trim() });
  if (!d) return;
  drawQr(d.qr, "pqr");
  $("pcode").textContent = d.code; $("phost").textContent = d.host; $("pfp").textContent = (d.fingerprint || "").match(/.{2}/g)?.join(":") || "unknown (no certificate found)";
  $("pairbox").hidden = false;
  const before = (await (await api("/api/mobile/phones")).json()).phones.length, end = Date.now() + d.expires_in * 1000;
  clearInterval(pairTimer);
  pairTimer = setInterval(async () => {
    const left = Math.max(0, Math.round((end - Date.now()) / 1000));
    $("pleft").textContent = "(expires in " + Math.floor(left / 60) + ":" + String(left % 60).padStart(2, "0") + ")";
    const x = await loadPhones();
    if (left === 0) { stopPair(); }
    else if (x && x.phones.length > before) { stopPair(); $("msg").textContent = "Phone paired."; $("pname").value = ""; }
  }, 3000);
};
$("pcancel").onclick = stopPair;
loadPhones();
