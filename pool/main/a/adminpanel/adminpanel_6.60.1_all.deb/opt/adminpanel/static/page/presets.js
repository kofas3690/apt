(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const EXAMPLES = [
    ["Disk usage", "Check disk usage", "/usr/bin/df -h -x tmpfs", "safe", 10, "Free space on each disk"],
    ["Uptime", "Show uptime and load", "/usr/bin/uptime", "safe", 5, ""],
    ["Memory", "Show memory", "/usr/bin/free -h", "safe", 5, ""],
    ["nginx log", "Last nginx errors", "/usr/bin/journalctl -u nginx -n 40 --no-pager", "safe", 10, ""],
    ["Restart nginx", "Restart nginx", "/usr/bin/systemctl restart nginx", "changes", 20, "Brief interruption of websites"],
  ];
  let list = [], editing = null, max = 20;

  /* A command line to a list of parts: spaces separate, 'single' and "double" quotes group, a backslash escapes the next character.
     Nothing is expanded or interpreted; this only splits the text the way you see it. */
  function split(line) {
    const out = []; let cur = "", has = false, q = null;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (q) {
        if (ch === q) q = null;
        else if (ch === "\\" && q === '"' && i + 1 < line.length) cur += line[++i];
        else cur += ch;
      } else if (ch === "'" || ch === '"') { q = ch; has = true; }
      else if (ch === "\\" && i + 1 < line.length) { cur += line[++i]; has = true; }
      else if (/\s/.test(ch)) { if (cur || has) { out.push(cur); cur = ""; has = false; } }
      else { cur += ch; has = true; }
    }
    if (q) return { error: "a quote is not closed" };
    if (cur || has) out.push(cur);
    return { parts: out };
  }
  const slug = (s) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 40);
  const join = (argv) => argv.map((a) => (/^[A-Za-z0-9_\/.,:=@%+-]+$/.test(a) ? a : '"' + a.replace(/(["\\])/g, "\\$1") + '"')).join(" ");

  function say(text, cls) { const m = $("msg"); m.textContent = text || ""; m.className = cls || ""; }

  async function api(path, opts) {
    const r = await fetch(path, opts);
    if (r.status === 401) { location.href = "/login.html"; throw new Error("not signed in"); }
    return r;
  }
  async function detail(r, fallback) { try { const j = await r.json(); return typeof j.detail === "string" ? j.detail : fallback; } catch (e) { return fallback; } }

  async function load() {
    try {
      const r = await api("/api/presetsadmin");
      if (!r.ok) { say(await detail(r, "Could not read the presets."), "bad"); return; }
      const d = await r.json();
      list = d.presets || []; max = d.max || 20;
      $("skipped").textContent = d.skipped ? d.skipped + " entr" + (d.skipped === 1 ? "y" : "ies") + " in the file " + (d.skipped === 1 ? "is" : "are") + " not valid and " + (d.skipped === 1 ? "is" : "are") + " ignored (they disappear the next time you save)." : "";
      draw();
    } catch (e) { say("Could not reach the panel.", "bad"); }
  }

  function cell(tr, text, cls) { const td = document.createElement("td"); td.textContent = text; if (cls) td.className = cls; tr.appendChild(td); return td; }

  function draw() {
    const body = $("rows"); body.replaceChildren();
    $("count").textContent = list.length + " of " + max;
    $("add").disabled = list.length >= max;
    if (!list.length) {
      const tr = document.createElement("tr"), td = cell(tr, "No presets yet. The phone shows none until you add one.", "muted"); td.colSpan = 6; body.appendChild(tr);
    }
    list.forEach((p, i) => {
      const tr = document.createElement("tr");
      const nm = cell(tr, p.label);
      if (p.description) { const s = document.createElement("div"); s.className = "muted"; s.style.fontSize = "12px"; s.textContent = p.description; nm.appendChild(s); }
      const c = cell(tr, ""); const code = document.createElement("code"); code.className = "cmd"; code.textContent = join(p.argv); c.appendChild(code);
      cell(tr, p.kind === "safe" ? "safe" : "changes", p.kind === "safe" ? "" : "warn");
      cell(tr, p.timeout + " s");
      cell(tr, p.admin_only ? "administrators" : "operators and administrators");
      const act = document.createElement("td");
      const e = document.createElement("button"); e.textContent = "Edit"; e.onclick = () => open(i);
      const u = document.createElement("button"); u.textContent = "Up"; u.disabled = i === 0; u.onclick = () => move(i, -1);
      const dn = document.createElement("button"); dn.textContent = "Down"; dn.disabled = i === list.length - 1; dn.onclick = () => move(i, 1);
      const x = document.createElement("button"); x.className = "danger"; x.textContent = "Delete"; x.onclick = () => remove(i);
      act.append(e, " ", u, " ", dn, " ", x); tr.appendChild(act);
      body.appendChild(tr);
    });
  }

  async function persist(next, okText) {
    say("Saving…");
    try {
      const r = await api("/api/presetsadmin", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ presets: next }) });
      if (!r.ok) { say(await detail(r, "Could not save."), "bad"); return false; }
      say(okText, "good");
      await load();
      return true;
    } catch (e) { say("Could not reach the panel.", "bad"); return false; }
  }

  function move(i, d) { const n = list.slice(); const j = i + d; if (j < 0 || j >= n.length) return; [n[i], n[j]] = [n[j], n[i]]; persist(n, "Order saved."); }
  function remove(i) {
    if (!confirm("Delete the preset \"" + list[i].label + "\"? The phone will no longer show it.")) return;
    persist(list.filter((_, k) => k !== i), "Deleted.");
  }

  function preview() {
    const r = split($("f_cmd").value), box = $("parts");
    box.replaceChildren();
    if (!$("f_cmd").value.trim()) return;
    if (r.error) { box.textContent = r.error; return; }
    box.append("Runs as: ");
    r.parts.forEach((p, i) => { if (i) box.append("  \u00b7  "); const b = document.createElement(i ? "span" : "b"); b.textContent = p; box.appendChild(b); });
    if (/[|;&<>`$]/.test($("f_cmd").value.replace(/(["'])(?:\\.|(?!\1).)*\1/g, ""))) {
      const w = document.createElement("div"); w.className = "warn";
      w.textContent = "Note: | ; & < > ` and $ are passed as plain text, not interpreted. Use a script for pipelines.";
      box.appendChild(w);
    }
  }

  function open(i) {
    editing = i;
    const p = i === null ? null : list[i];
    $("ftitle").textContent = p ? "Edit preset" : "New preset";
    $("f_label").value = p ? p.label : "";
    $("f_cmd").value = p ? join(p.argv) : "";
    $("f_desc").value = p ? p.description : "";
    $("f_kind").value = p ? p.kind : "safe";
    $("f_timeout").value = p ? p.timeout : 10;
    $("f_id").value = p ? p.id : "";
    $("f_id").disabled = !!p;                         // the phone refers to a preset by its id, so it stays fixed once created
    $("f_admin").checked = p ? !!p.admin_only : false;
    $("f_note").value = p ? p.note : "";
    $("examples").style.display = p ? "none" : "";
    $("formbox").hidden = false;
    preview();
    $("f_label").focus();
  }
  function close() { $("formbox").hidden = true; editing = null; }

  async function save() {
    const label = $("f_label").value.trim();
    if (!label) { say("Give the preset a name.", "bad"); return; }
    const r = split($("f_cmd").value);
    if (r.error || !r.parts.length) { say(r.error ? "Command: " + r.error + "." : "Type the command to run.", "bad"); return; }
    const id = editing === null ? ($("f_id").value.trim() || slug(label)) : list[editing].id;
    if (!/^[a-z0-9][a-z0-9_-]{0,39}$/.test(id)) { say("The id must be lower-case letters, digits, - or _.", "bad"); return; }
    if (editing === null && list.some((p) => p.id === id)) { say("A preset with the id \"" + id + "\" already exists. Change the id.", "bad"); return; }
    const t = parseInt($("f_timeout").value, 10);
    if (!(t >= 1 && t <= 25)) { say("The time limit is 1 to 25 seconds.", "bad"); return; }
    const p = { id, label, description: $("f_desc").value.trim(), kind: $("f_kind").value, argv: r.parts, timeout: t, note: $("f_note").value.trim(), admin_only: $("f_admin").checked };
    const next = list.slice();
    if (editing === null) next.push(p); else next[editing] = p;
    $("save").disabled = true;
    const ok = await persist(next, editing === null ? "Preset added." : "Preset saved.");
    $("save").disabled = false;
    if (ok) close();
  }

  EXAMPLES.forEach(([short, label, cmd, kind, t, desc], i) => {
    if (i) $("examples").append(" · ");
    const a = document.createElement("a"); a.href = "#"; a.textContent = short;
    a.onclick = (ev) => { ev.preventDefault(); $("f_label").value = label; $("f_cmd").value = cmd; $("f_kind").value = kind; $("f_timeout").value = t; $("f_desc").value = desc; $("f_id").value = slug(label); preview(); };
    $("examples").appendChild(a);
  });
  $("add").onclick = () => open(null);
  $("cancel").onclick = close;
  $("save").onclick = save;
  $("f_cmd").addEventListener("input", preview);
  $("f_label").addEventListener("input", () => { if (editing === null && !$("f_id").dataset.touched) $("f_id").value = slug($("f_label").value); });
  $("f_id").addEventListener("input", () => { $("f_id").dataset.touched = "1"; });
  async function loadPhone() {
    try {
      const r = await api("/api/presetsadmin/phone");
      if (r.ok) $("phoneedit").checked = !!(await r.json()).enabled;
    } catch (e) { /* the box stays unticked */ }
  }
  $("phoneedit").onchange = async () => {
    const box = $("phoneedit"), want = box.checked;
    box.disabled = true;
    try {
      const r = await api("/api/presetsadmin/phone", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ enabled: want }) });
      if (!r.ok) { box.checked = !want; say(await detail(r, "Could not change this setting."), "bad"); }
      else say(want ? "Phones can now edit presets (administrators on a full phone only)." : "Editing presets from the phone is off.", "good");
    } catch (e) { box.checked = !want; say("Could not reach the panel.", "bad"); }
    box.disabled = false;
  };
  load();
  loadPhone();
})();
