// A small, safe Markdown reader for release notes (6.60.1).
// parse(text) turns the text into plain data (blocks and inline pieces); render(blocks) builds the page from that data
// with createElement and textContent only. Nothing from the text is ever used as HTML, so a note cannot add a script, a
// style or an image. Links are kept only when they start with https:// and open in a new tab without access back.
// What it understands: # headings, paragraphs, - * + lists, 1. lists, ``` code blocks, | tables |, > quotes, --- lines,
// and inside a line `code`, **bold**, *italic* or _italic_, and [text](https://...). Anything else stays as text.
(function (root) {
  "use strict";

  function inline(s) {
    const out = [];
    let i = 0, buf = "";
    const flush = () => { if (buf) { out.push({ t: "text", v: buf }); buf = ""; } };
    while (i < s.length) {
      const c = s[i];
      if (c === "\\" && i + 1 < s.length && /[\\`*_\[\]()#|>-]/.test(s[i + 1])) { buf += s[i + 1]; i += 2; continue; }
      if (c === "`") {
        const j = s.indexOf("`", i + 1);
        if (j > i + 1) { flush(); out.push({ t: "code", v: s.slice(i + 1, j) }); i = j + 1; continue; }
      }
      if (s.startsWith("**", i)) {
        const j = s.indexOf("**", i + 2);
        if (j > i + 2) { flush(); out.push({ t: "b", v: inline(s.slice(i + 2, j)) }); i = j + 2; continue; }
      }
      if ((c === "*" || c === "_") && s[i + 1] && s[i + 1] !== " " && s[i + 1] !== c) {
        const j = s.indexOf(c, i + 1);
        const wordInside = c === "_" && i > 0 && /\w/.test(s[i - 1]);     // snake_case stays as it is
        if (j > i + 1 && s[j - 1] !== " " && !wordInside) { flush(); out.push({ t: "i", v: inline(s.slice(i + 1, j)) }); i = j + 1; continue; }
      }
      if (c === "[") {
        const m = /^\[([^\]]{1,200})\]\((https:\/\/[^\s()]{1,300})\)/.exec(s.slice(i));
        if (m) { flush(); out.push({ t: "a", v: inline(m[1]), href: m[2] }); i += m[0].length; continue; }
      }
      buf += c; i++;
    }
    flush();
    return out;
  }

  function cells(line) {
    let l = line.trim();
    if (l.startsWith("|")) l = l.slice(1);
    if (l.endsWith("|") && !l.endsWith("\\|")) l = l.slice(0, -1);
    const out = []; let cur = "";
    for (let i = 0; i < l.length; i++) {
      if (l[i] === "\\" && l[i + 1] === "|") { cur += "|"; i++; continue; }
      if (l[i] === "|") { out.push(cur.trim()); cur = ""; continue; }
      cur += l[i];
    }
    out.push(cur.trim());
    return out;
  }

  function parse(text) {
    const lines = String(text || "").replace(/\r\n?/g, "\n").split("\n");
    const blocks = [];
    let i = 0;
    const isTableSep = (l) => /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/.test(l || "");
    const listItem = (l) => /^(\s*)([-*+]|\d{1,3}[.)])\s+(.*)$/.exec(l);
    while (i < lines.length && blocks.length < 400) {
      const l = lines[i];
      if (!l.trim()) { i++; continue; }
      let m;
      if ((m = /^\s*(```|~~~)\s*([\w+-]{0,20})\s*$/.exec(l))) {             // code block
        const fence = m[1], body = [];
        i++;
        while (i < lines.length && !lines[i].trim().startsWith(fence)) body.push(lines[i++]);
        i++;
        blocks.push({ t: "pre", v: body.join("\n"), lang: m[2] || "" });
        continue;
      }
      if ((m = /^\s{0,3}(#{1,6})\s+(.*?)\s*#*\s*$/.exec(l))) {             // heading
        blocks.push({ t: "h", level: m[1].length, v: inline(m[2]) }); i++; continue;
      }
      if (/^\s{0,3}([-*_])(\s*\1){2,}\s*$/.test(l)) { blocks.push({ t: "hr" }); i++; continue; }
      if (l.includes("|") && isTableSep(lines[i + 1])) {                    // table
        const head = cells(l).map(inline), rows = [];
        i += 2;
        while (i < lines.length && lines[i].includes("|") && lines[i].trim()) rows.push(cells(lines[i++]).map(inline));
        blocks.push({ t: "table", head, rows: rows.slice(0, 100) });
        continue;
      }
      if (/^\s{0,3}>/.test(l)) {                                            // quote
        const body = [];
        while (i < lines.length && /^\s{0,3}>/.test(lines[i])) body.push(lines[i++].replace(/^\s{0,3}>\s?/, ""));
        blocks.push({ t: "quote", v: parse(body.join("\n")) });
        continue;
      }
      if ((m = listItem(l))) {                                               // list (one level; deeper items join it)
        const ordered = /\d/.test(m[2]), items = [];
        while (i < lines.length) {
          const x = listItem(lines[i]);
          if (x) { items.push(x[3]); i++; continue; }
          if (lines[i].includes("|") && isTableSep(lines[i + 1])) break;          // a table under an item: its own block
          if (lines[i].trim() && /^\s{2,}\S/.test(lines[i]) && items.length) { items[items.length - 1] += " " + lines[i].trim(); i++; continue; }
          break;
        }
        blocks.push({ t: ordered ? "ol" : "ul", items: items.slice(0, 200).map(inline) });
        continue;
      }
      const para = [];                                                       // paragraph
      while (i < lines.length && lines[i].trim() && !listItem(lines[i]) && !/^\s{0,3}(#{1,6}\s|```|~~~|>)/.test(lines[i])
             && !(lines[i].includes("|") && isTableSep(lines[i + 1]))) para.push(lines[i++].trim());
      if (!para.length) { para.push(l.trim()); i++; }
      blocks.push({ t: "p", v: inline(para.join(" ")) });
    }
    return blocks;
  }

  function renderInline(pieces, doc) {
    const f = doc.createDocumentFragment();
    for (const p of pieces) {
      if (p.t === "text") f.appendChild(doc.createTextNode(p.v));
      else if (p.t === "code") { const e = doc.createElement("code"); e.textContent = p.v; f.appendChild(e); }
      else if (p.t === "b" || p.t === "i") { const e = doc.createElement(p.t === "b" ? "strong" : "em"); e.appendChild(renderInline(p.v, doc)); f.appendChild(e); }
      else if (p.t === "a") {
        const e = doc.createElement("a");
        e.href = p.href; e.target = "_blank"; e.rel = "noopener noreferrer";
        e.appendChild(renderInline(p.v, doc)); f.appendChild(e);
      }
    }
    return f;
  }

  function render(blocks, doc) {
    doc = doc || document;
    const f = doc.createDocumentFragment();
    for (const b of blocks) {
      let e;
      if (b.t === "h") { e = doc.createElement("h" + Math.min(6, b.level + 3)); e.appendChild(renderInline(b.v, doc)); }
      else if (b.t === "p") { e = doc.createElement("p"); e.appendChild(renderInline(b.v, doc)); }
      else if (b.t === "pre") { e = doc.createElement("pre"); const c = doc.createElement("code"); c.textContent = b.v; e.appendChild(c); }
      else if (b.t === "hr") e = doc.createElement("hr");
      else if (b.t === "quote") { e = doc.createElement("blockquote"); e.appendChild(render(b.v, doc)); }
      else if (b.t === "ul" || b.t === "ol") {
        e = doc.createElement(b.t);
        for (const it of b.items) { const li = doc.createElement("li"); li.appendChild(renderInline(it, doc)); e.appendChild(li); }
      } else if (b.t === "table") {
        const wrap = doc.createElement("div"); wrap.className = "mdtable";
        const t = doc.createElement("table"), th = doc.createElement("thead"), tr = doc.createElement("tr");
        for (const c of b.head) { const x = doc.createElement("th"); x.appendChild(renderInline(c, doc)); tr.appendChild(x); }
        th.appendChild(tr); t.appendChild(th);
        const tb = doc.createElement("tbody");
        for (const r of b.rows) {
          const row = doc.createElement("tr");
          for (const c of r) { const x = doc.createElement("td"); x.appendChild(renderInline(c, doc)); row.appendChild(x); }
          tb.appendChild(row);
        }
        t.appendChild(tb); wrap.appendChild(t); e = wrap;
      }
      if (e) f.appendChild(e);
    }
    return f;
  }

  const api = { parse, inline, render };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.mdlite = api;
})(typeof window !== "undefined" ? window : this);
