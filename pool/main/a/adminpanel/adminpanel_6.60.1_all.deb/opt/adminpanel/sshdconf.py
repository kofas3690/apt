"""SSH server settings: show and change a fixed list of sshd settings.

A root helper writes only its own drop-in file under /etc/ssh/sshd_config.d, checks every change with `sshd -t`, reads
the effective value back, undoes the change if anything fails, and refuses changes that could lock everyone out.
"""
import json, subprocess
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from auth import current_user
from audit import audit

router = APIRouter(prefix="/api/sshd")

HELPER = "/usr/local/sbin/adminpanel-sshd"
SUDO = "/usr/bin/sudo"
ENV = {"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LC_ALL": "C"}
KEY = r"^[a-z0-9]{1,40}$"
VALUE = r"^[a-z0-9-]{1,30}$"


class Change(BaseModel):
    key: str = Field(pattern=KEY)
    value: str = Field(pattern=VALUE)


class Forget(BaseModel):
    key: str = Field(pattern=KEY)


def run(*args):
    try:
        r = subprocess.run([SUDO, "-n", HELPER, *args], capture_output=True, text=True, errors="replace", timeout=90,
                           env=ENV, stdin=subprocess.DEVNULL)
    except subprocess.TimeoutExpired:
        raise HTTPException(504, "The helper took too long")
    if r.returncode != 0:
        raise HTTPException(400, ((r.stderr or r.stdout).strip() or "The SSH settings helper failed")[:400])
    return r


@router.get("")
def listing(user: str = Depends(current_user)):
    try:
        return json.loads(run("list").stdout)
    except ValueError:
        raise HTTPException(500, "The SSH settings helper returned something unexpected")


@router.post("/set")
def set_value(body: Change, request: Request, user: str = Depends(current_user)):
    try:
        run("set", body.key, body.value)
    except HTTPException:
        audit(user, request.client.host, "sshd_set", target=body.key, ok=False, value=body.value)
        raise
    audit(user, request.client.host, "sshd_set", target=body.key, ok=True, value=body.value)
    return {"ok": True}


@router.post("/forget")
def forget(body: Forget, request: Request, user: str = Depends(current_user)):
    try:
        run("forget", body.key)
    except HTTPException:
        audit(user, request.client.host, "sshd_forget", target=body.key, ok=False)
        raise
    audit(user, request.client.host, "sshd_forget", target=body.key, ok=True)
    return {"ok": True}
