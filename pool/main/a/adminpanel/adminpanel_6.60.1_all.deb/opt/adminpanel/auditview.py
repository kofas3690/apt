"""Audit log viewer: read and search what has been done through this panel.

Reads /opt/adminpanel/data/audit.log (one JSON object per line, written by audit.py) and the weekly
rotated copies next to it (audit.log.1, audit.log.2.gz ...). Read only. Administrators only (see roles.py),
because the log holds every person's addresses and what they changed."""
import calendar, csv, gzip, io, json, time
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import Response
from auth import current_user
from paths import AUDIT_FILE

router = APIRouter(prefix="/api/auditlog")

MAX_BYTES = 12 * 1024 * 1024          # newest part of each file that is read
MAX_ROWS = 200_000                    # lines parsed per request
MAX_FILES = 13                        # audit.log plus twelve weekly copies
EXPORT_MAX = 50_000
RANGES = {"1h": 3600, "24h": 86400, "7d": 7 * 86400, "30d": 30 * 86400, "all": None}

LABELS = {
    "login_ok": "Signed in", "login_failed": "Sign-in failed", "logout": "Signed out",
    "login_refused_no_2fa": "Sign-in refused (no two-step)", "recovery_used": "Recovery code used",
    "recovery_generated": "New recovery codes", "session_revoked": "Session ended",
    "role_denied": "Refused by role", "panel_role_changed": "Role changed", "panel_admin_added": "Person added",
    "panel_admin_removed": "Person removed", "panel_password_changed": "Panel password changed",
    "panel_2fa_started": "Two-step setup started", "panel_2fa_enrolled": "Two-step turned on",
    "panel_stepup_failed": "Confirmation failed", "alert_notify_failed": "Alert could not be sent",
}


def files():
    base = AUDIT_FILE
    out = [base]
    for i in range(1, MAX_FILES):
        for cand in (base.with_name(f"{base.name}.{i}"), base.with_name(f"{base.name}.{i}.gz")):
            if cand.exists():
                out.append(cand)
                break
    return [p for p in out if p.exists()]


def read_tail(path):
    """The newest MAX_BYTES of one file, as text. Compressed copies are read whole but capped."""
    try:
        if path.suffix == ".gz":
            with gzip.open(path, "rb") as f:
                data = f.read(MAX_BYTES * 2)
        else:
            size = path.stat().st_size
            with path.open("rb") as f:
                f.seek(max(0, size - MAX_BYTES))
                data = f.read()
                if size > MAX_BYTES:
                    data = data.split(b"\n", 1)[-1]          # drop a cut-off first line
        return data.decode("utf-8", "replace")
    except OSError:
        return ""


def parse_ts(s):
    try:
        return calendar.timegm(time.strptime(s, "%Y-%m-%dT%H:%M:%SZ"))
    except (ValueError, TypeError):
        return 0


def rows(scope):
    """Newest first. Yields dicts with ts, t (epoch), user, ip, event, detail."""
    out, n = [], 0
    for p in (files() if scope == "all" else files()[:1]):
        for line in reversed(read_tail(p).splitlines()):
            try:
                e = json.loads(line)
            except ValueError:
                continue
            if not isinstance(e, dict) or "event" not in e:
                continue
            detail = {k: v for k, v in e.items() if k not in ("ts", "user", "ip", "event")}
            out.append({"ts": str(e.get("ts", "")), "t": parse_ts(e.get("ts")), "user": str(e.get("user", "")),
                        "ip": str(e.get("ip", "")), "event": str(e.get("event", "")), "detail": detail})
            n += 1
            if n >= MAX_ROWS:
                return out, True
    out.sort(key=lambda r: r["t"], reverse=True)
    return out, False


def select(user, event, q, rng, scope):
    if rng not in RANGES:
        raise HTTPException(400, "Unknown time range")
    allrows, capped = rows(scope)
    cutoff = time.time() - RANGES[rng] if RANGES[rng] else 0
    q = q.strip().lower()[:80]
    res = []
    for r in allrows:
        if r["t"] < cutoff:
            continue
        if user and r["user"] != user:
            continue
        if event and r["event"] != event:
            continue
        if q and q not in (r["user"] + " " + r["ip"] + " " + r["event"] + " " + json.dumps(r["detail"])).lower():
            continue
        res.append(r)
    return res, allrows, capped


@router.get("")
def view(user: str = "", event: str = "", q: str = "", range: str = "24h", scope: str = "current",
         limit: int = Query(300, ge=1, le=1000), who: str = Depends(current_user)):
    if scope not in ("current", "all"):
        raise HTTPException(400, "Unknown scope")
    res, allrows, capped = select(user, event, q, range, scope)
    users = sorted({r["user"] for r in allrows if r["user"]})
    events = sorted({r["event"] for r in allrows})
    return {"total": len(res), "rows": [dict(r, label=LABELS.get(r["event"], "")) for r in res[:limit]],
            "users": users, "events": [{"name": e, "label": LABELS.get(e, "")} for e in events],
            "capped": capped, "files": len(files())}


def safe_cell(v):
    v = str(v)
    return "'" + v if v[:1] in ("=", "+", "-", "@", "\t", "\r") else v


@router.get("/export")
def export(user: str = "", event: str = "", q: str = "", range: str = "24h", scope: str = "current",
           who: str = Depends(current_user)):
    if scope not in ("current", "all"):
        raise HTTPException(400, "Unknown scope")
    res, _, _ = select(user, event, q, range, scope)
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["time (UTC)", "person", "address", "event", "what happened", "details"])
    for r in res[:EXPORT_MAX]:
        w.writerow([r["ts"], safe_cell(r["user"]), safe_cell(r["ip"]), safe_cell(r["event"]),
                    LABELS.get(r["event"], ""), safe_cell(json.dumps(r["detail"], separators=(",", ":")))])
    name = "adminpanel-audit-" + time.strftime("%Y%m%d-%H%M%S") + ".csv"
    return Response(buf.getvalue(), media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": f'attachment; filename="{name}"', "Cache-Control": "no-store"})
