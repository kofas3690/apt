"""Saved snippets for the Terminal (6.53.0): commands you use often, kept on this server for each panel user.

GET /api/terminal/snippets, POST /api/terminal/snippets, PUT and DELETE /api/terminal/snippets/{id}.
Since 6.54.0 the phone can look at them: GET /api/mobile/v1/snippets (capability `snippets`: an administrator on a full
phone), only the snippets of the panel user the phone was paired as. The phone can copy one; it cannot change them and
it has no Terminal, so nothing runs from it.

A snippet is only text. The page puts it in the Terminal's command box, and nothing runs until you press Send, as the
Linux account you signed in to the Terminal with (never as root, unlike command presets). Under /api/terminal, so
administrators only and never from a phone (roles.ADMIN_ONLY). Each panel user sees only their own snippets.
At most 30 each; a name of up to 40 characters; a command of one line, up to 1000 characters, with no control
characters. The audit log records the name and the length, not the command, because a command may hold something
private. Do not save passwords in snippets: they are stored as plain text in the panel's database."""
import re, secrets, threading, time
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
import store
from audit import audit
from auth import current_user
from mobileapi import router as v1, reply, require

router = APIRouter(prefix="/api/terminal/snippets")
data = store.PersistentDict("term_snippets")
MAX = 30
NAME_RE = re.compile(r"^[^\x00-\x1f\x7f]{1,40}$")
CMD_RE = re.compile(r"^[^\x00-\x1f\x7f]{1,1000}$")
_lock = threading.Lock()


class Body(BaseModel):
    name: str = Field(min_length=1, max_length=40)
    cmd: str = Field(min_length=1, max_length=1000)


def clean(body):
    name, cmd = body.name.strip(), body.cmd.strip()
    if not NAME_RE.fullmatch(name):
        raise HTTPException(400, "Give the snippet a name of 1 to 40 characters, on one line.")
    if not CMD_RE.fullmatch(cmd):
        raise HTTPException(400, "A snippet is one line of up to 1000 characters, without tabs or other control characters.")
    return name, cmd


def mine(user):
    v = data.get(user, [])
    return [x for x in v if isinstance(x, dict) and {"id", "name", "cmd"} <= set(x)] if isinstance(v, list) else []


@router.get("")
def list_snippets(user: str = Depends(current_user)):
    return {"snippets": mine(user), "max": MAX}


@router.post("")
def add(body: Body, request: Request, user: str = Depends(current_user)):
    name, cmd = clean(body)
    with _lock:
        cur = mine(user)
        if len(cur) >= MAX:
            raise HTTPException(409, f"You have {MAX} snippets, the most there can be. Delete one first.")
        if any(x["name"].lower() == name.lower() for x in cur):
            raise HTTPException(409, "You already have a snippet with that name.")
        item = {"id": secrets.token_hex(6), "name": name, "cmd": cmd, "added": int(time.time())}
        data[user] = cur + [item]
    audit(user, request.client.host, "terminal_snippet_added", name=name, length=len(cmd))
    return {"snippets": mine(user), "max": MAX}


@router.put("/{sid}")
def edit(sid: str, body: Body, request: Request, user: str = Depends(current_user)):
    name, cmd = clean(body)
    with _lock:
        cur = mine(user)
        if not any(x["id"] == sid for x in cur):
            raise HTTPException(404, "That snippet is gone.")
        if any(x["name"].lower() == name.lower() and x["id"] != sid for x in cur):
            raise HTTPException(409, "You already have a snippet with that name.")
        data[user] = [{**x, "name": name, "cmd": cmd} if x["id"] == sid else x for x in cur]
    audit(user, request.client.host, "terminal_snippet_changed", name=name, length=len(cmd))
    return {"snippets": mine(user), "max": MAX}


@router.delete("/{sid}")
def remove(sid: str, request: Request, user: str = Depends(current_user)):
    with _lock:
        cur = mine(user)
        gone = [x for x in cur if x["id"] == sid]
        if not gone:
            raise HTTPException(404, "That snippet is gone.")
        data[user] = [x for x in cur if x["id"] != sid]
    audit(user, request.client.host, "terminal_snippet_deleted", name=gone[0]["name"])
    return {"snippets": mine(user), "max": MAX}


@v1.get("/snippets")
def phone_list(request: Request, user: str = Depends(current_user)):
    require(request, user, "snippets")
    return reply(request, {"snippets": [{"id": x["id"], "name": x["name"], "cmd": x["cmd"]} for x in mine(user)], "max": MAX})
