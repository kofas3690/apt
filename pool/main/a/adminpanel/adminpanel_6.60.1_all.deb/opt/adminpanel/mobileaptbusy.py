"""Who is holding apt, on the phone (6.57.0): GET /api/mobile/v1/apt-busy (docs/mobile-api-v1.md, section 30).

The same answer as the Software updates page (aptbusy.py, 6.56.0), for anyone who may view: which program is using
apt, in which terminal, and what to do. Looking only: it reads /proc, and the phone can stop nothing. The fields are
copied one by one and checked."""
from fastapi import Depends, Request
from auth import current_user
import aptbusy
from mobileapi import router, reply, require

KINDS = ("panel", "automatic", "stopped", "installing", "downloading", "waiting", "busy", "hidden")
LOCKS = tuple(aptbusy.LOCKS.values())


def _s(v, n):
    return v[:n] if isinstance(v, str) else ""


def clean(x):
    if not isinstance(x, dict) or not isinstance(x.get("pid"), int) or x.get("kind") not in KINDS:
        return None
    sec = x.get("seconds")
    return {"pid": x["pid"], "program": _s(x.get("program"), 32), "command": _s(x.get("command"), 160),
            "user": _s(x.get("user"), 32), "started_by": _s(x.get("started_by"), 32), "tty": _s(x.get("tty"), 16),
            "seconds": sec if isinstance(sec, int) and not isinstance(sec, bool) and sec >= 0 else None,
            "locks": [l for l in (x.get("locks") or []) if l in LOCKS], "kind": x["kind"], "stopped": x.get("stopped") is True,
            "hint": _s(x.get("hint"), 300)}


@router.get("/apt-busy")
def apt_busy(request: Request, user: str = Depends(current_user)):
    require(request, user, "view")
    rows = [r for r in (clean(x) for x in aptbusy.scan()) if r][:16]
    others = [r for r in rows if r["kind"] != "panel"]
    return reply(request, {"free": not others, "busy": rows})
