"""Blocked addresses: what fail2ban is blocking on this machine, lifting a block, and blocking or unblocking an address
by hand.

fail2ban goes through a root helper that can only list jails and lift one block, for a jail fail2ban itself lists.
Manual blocks are firewall (UFW) deny rules, made by a second root helper that tags them with a fixed comment, so it
can list them and remove only those. A block that would cut off the address you are using is refused.
If fail2ban is not installed or its service is stopped the page says so.
"""
import ipaddress, json, re, subprocess
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from auth import current_user
from audit import audit

router = APIRouter(prefix="/api/blocked")

HELPER = "/usr/local/sbin/adminpanel-f2b"
UFW_HELPER = "/usr/local/sbin/adminpanel-ufw"
SUDO = "/usr/bin/sudo"
ENV = {"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LC_ALL": "C"}


class Unban(BaseModel):
    jail: str = Field(pattern=r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,39}$")
    ip: str = Field(min_length=2, max_length=45, pattern=r"^[0-9A-Fa-f:.]+$")


class Target(BaseModel):
    address: str = Field(min_length=2, max_length=50, pattern=r"^[0-9A-Fa-f:.]+(/[0-9]{1,3})?$")


def run(*args, timeout=60, helper=HELPER):
    try:
        r = subprocess.run([SUDO, "-n", helper, *args], capture_output=True, text=True, errors="replace", timeout=timeout,
                           env=ENV, stdin=subprocess.DEVNULL)
    except subprocess.TimeoutExpired:
        raise HTTPException(504, "The helper took too long to answer")
    if r.returncode != 0:
        raise HTTPException(400, ((r.stderr or r.stdout).strip() or "The helper failed")[:300])
    return r


@router.get("")
def listing(user: str = Depends(current_user)):
    try:
        return json.loads(run("list", timeout=90).stdout)
    except ValueError:
        raise HTTPException(500, "The fail2ban helper returned something unexpected")


@router.post("/unban")
def unban(body: Unban, request: Request, user: str = Depends(current_user)):
    try:
        run("unban", body.jail, body.ip)
    except HTTPException:
        audit(user, request.client.host, "unban_address", target=body.ip, jail=body.jail, ok=False)
        raise
    audit(user, request.client.host, "unban_address", target=body.ip, jail=body.jail, ok=True)
    return {"ok": True}


@router.get("/manual")
def manual(user: str = Depends(current_user)):
    status = run("status", helper=UFW_HELPER).stdout
    m = re.search(r"^Status:\s*(\w+)", status, re.M)
    blocks = [l.strip() for l in run("blocks", helper=UFW_HELPER).stdout.splitlines() if l.strip()]
    return {"firewall_active": bool(m) and m[1] == "active", "blocks": blocks}


def refuse_self(request, address):
    try:
        net = ipaddress.ip_network(address, strict=False)
        me = ipaddress.ip_address((request.client.host or "").split("%")[0])
    except ValueError:
        return
    if me in net or (me.version == 6 and getattr(me, "ipv4_mapped", None) and me.ipv4_mapped in net):
        raise HTTPException(400, "That would block the address you are using right now, and cut you off from the panel")


@router.post("/block")
def block(body: Target, request: Request, user: str = Depends(current_user)):
    try:
        refuse_self(request, body.address)
        run("block", body.address, helper=UFW_HELPER)
    except HTTPException:
        audit(user, request.client.host, "block_address", target=body.address, ok=False)
        raise
    audit(user, request.client.host, "block_address", target=body.address, ok=True)
    return {"ok": True}


@router.post("/unblock")
def unblock(body: Target, request: Request, user: str = Depends(current_user)):
    try:
        run("unblock", body.address, helper=UFW_HELPER)
    except HTTPException:
        audit(user, request.client.host, "unblock_address", target=body.address, ok=False)
        raise
    audit(user, request.client.host, "unblock_address", target=body.address, ok=True)
    return {"ok": True}
