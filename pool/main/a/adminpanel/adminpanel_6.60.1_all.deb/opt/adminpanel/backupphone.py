"""The switches that let administrators browse and restore backup copies (and, since 6.35.0, delete them) from the phone app (web panel, administrators only).

Restoring copies files out of a backup into a protected "restored folder" on the server (never over live files), but it still
reads what is inside the backups, so a phone that could do it is worth protecting. It stays OFF until an administrator turns it
on here, in the web panel. The phone can never reach this route (roles.py: /api/backup/phone is ADMIN_ONLY, so it is also
denied to phones). If the setting cannot be read the answer is "off": an unreadable switch must never open anything."""
from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel
import store
from auth import current_user
from audit import audit

router = APIRouter(prefix="/api/backup/phone")

with store._lock:
    store._conn.execute("CREATE TABLE IF NOT EXISTS backup_phone_restore (id INTEGER PRIMARY KEY CHECK (id = 1), enabled INTEGER NOT NULL)")
    store._conn.commit()


with store._lock:
    store._conn.execute("CREATE TABLE IF NOT EXISTS backup_phone_delete (id INTEGER PRIMARY KEY CHECK (id = 1), enabled INTEGER NOT NULL)")
    store._conn.commit()


def delete_enabled():
    """Second switch (6.35.0): may administrators delete backup copies from the phone? Same rule: off unless clearly on."""
    try:
        with store._lock:
            r = store._conn.execute("SELECT enabled FROM backup_phone_delete WHERE id=1").fetchall()
            store._conn.commit()
        return bool(r and r[0][0])
    except Exception:
        return False


def enabled():
    try:
        with store._lock:
            r = store._conn.execute("SELECT enabled FROM backup_phone_restore WHERE id=1").fetchall()
            store._conn.commit()
        return bool(r and r[0][0])
    except Exception:
        return False


class Body(BaseModel):
    enabled: bool


@router.get("")
def get_flag(user: str = Depends(current_user)):
    return {"enabled": enabled()}


@router.put("")
def set_flag(body: Body, request: Request, user: str = Depends(current_user)):
    with store._lock:
        store._conn.execute("INSERT OR REPLACE INTO backup_phone_restore (id, enabled) VALUES (1, ?)", (int(body.enabled),))
        store._conn.commit()
    audit(user, request.client.host, "backup_phone_restore", enabled=bool(body.enabled))
    return {"enabled": enabled()}


@router.get("/delete")
def get_delete_flag(user: str = Depends(current_user)):
    return {"enabled": delete_enabled()}


@router.put("/delete")
def set_delete_flag(body: Body, request: Request, user: str = Depends(current_user)):
    with store._lock:
        store._conn.execute("INSERT OR REPLACE INTO backup_phone_delete (id, enabled) VALUES (1, ?)", (int(body.enabled),))
        store._conn.commit()
    audit(user, request.client.host, "backup_phone_delete", enabled=bool(body.enabled))
    return {"enabled": delete_enabled()}
