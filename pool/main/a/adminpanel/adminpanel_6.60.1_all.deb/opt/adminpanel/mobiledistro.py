"""The server's distribution logo for the phone app: GET /api/mobile/v1/distro (docs/mobile-api-v1.md, section 19).

Read only. Returns the short distribution name and, when the system has a logo (see distrologo.py), the image itself as base64
inside the normal envelope, so the phone gets it over the same pinned connection as everything else. Only .svg and .png files of
at most 120 KB are sent. With no logo the field is null and the app shows its own icon. Any phone that may view may read it."""
import base64, re
from fastapi import Depends, Request
from auth import current_user
import distrologo
from mobileapi import router, reply, require

MAX_BYTES = 120 * 1024

_STYLE_BLOCK = re.compile(r"<style\b[^>]*>(.*?)</style\s*>", re.S | re.I)
_RULE = re.compile(r"([^{}]+)\{([^{}]*)\}")
_CLASS_SEL = re.compile(r"^\.[A-Za-z_][\w-]*$")
_TAG_WITH_CLASS = re.compile(r'<([A-Za-z][\w:.-]*)\b([^<>]*?)\sclass="([^"]*)"([^<>]*?)(/?)>')
_STYLE_ATTR = re.compile(r'\sstyle="([^"]*)"')


def inline_styles(svg):
    """The phone's SVG drawer ignores CSS in a <style> block (every shape then comes out black), so simple class rules such as
    `.cls-1{fill:#e95420}` are copied onto each element as a style attribute and the block is removed. Returns the new text, or
    None when the file uses CSS this cannot translate (then the phone is sent no logo rather than a black square)."""
    blocks = _STYLE_BLOCK.findall(svg)
    if not blocks:
        return None if re.search(r"<style\b", svg, re.I) else svg
    rules = {}
    for css in blocks:
        css = re.sub(r"/\*.*?\*/", "", css, flags=re.S)
        if "@" in css:
            return None
        rest = _RULE.sub("", css).strip()
        if rest:
            return None
        for sel, body in _RULE.findall(css):
            decl = ";".join(d.strip() for d in body.split(";") if d.strip())
            for one in sel.split(","):
                one = one.strip()
                if not _CLASS_SEL.match(one):
                    return None
                rules[one[1:]] = rules.get(one[1:], "") + decl + ";"
    out = _STYLE_BLOCK.sub("", svg)

    def put(m):
        tag, before, cls, after, slash = m.groups()
        decl = "".join(rules.get(c, "") for c in cls.split())
        attrs = before + after
        old = _STYLE_ATTR.search(attrs)
        if old:
            attrs = attrs.replace(old.group(0), "", 1)
            decl = (old.group(1).rstrip(";") + ";" if old.group(1).strip() else "") + decl
        return "<%s%s%s%s>" % (tag, attrs, (' style="%s"' % decl) if decl else "", slash)
    out = _TAG_WITH_CLASS.sub(put, out)
    return None if re.search(r"<style\b", out, re.I) else out


@router.get("/distro")
def distro(request: Request, user: str = Depends(current_user)):
    require(request, user, "view")
    v = distrologo.info()
    logo = None
    p = v["path"]
    if p is not None:
        try:
            data = p.read_bytes()
        except OSError:
            data = b""
        if p.suffix.lower() == ".svg" and data:
            try:
                fixed = inline_styles(data.decode("utf-8"))
            except UnicodeDecodeError:
                fixed = None
            data = fixed.encode("utf-8") if fixed else b""
        if 0 < len(data) <= MAX_BYTES:
            logo = {"type": distrologo.TYPES.get(p.suffix.lower(), ""), "data": base64.b64encode(data).decode("ascii")}
    return reply(request, {"name": v["name"], "logo": logo})
