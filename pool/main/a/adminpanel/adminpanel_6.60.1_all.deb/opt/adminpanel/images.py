"""Images: Docker images on this machine. List them with their size and whether a container uses them, remove an
image nothing uses, and prune dangling (untagged) images to free disk space.

Docker access is the same as root, so everything goes through a root helper that allows only those things, only for an
image id Docker itself lists, and never forces a removal.
"""
import json, subprocess
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from auth import current_user
from audit import audit

router = APIRouter(prefix="/api/images")

HELPER = "/usr/local/sbin/adminpanel-images"
SUDO = "/usr/bin/sudo"
ENV = {"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LC_ALL": "C"}
ID = r"^[0-9a-f]{64}$"


class Remove(BaseModel):
    id: str = Field(pattern=ID)


def run(*args, timeout=130):
    try:
        r = subprocess.run([SUDO, "-n", HELPER, *args], capture_output=True, text=True, errors="replace", timeout=timeout,
                           env=ENV, stdin=subprocess.DEVNULL)
    except subprocess.TimeoutExpired:
        raise HTTPException(504, "Docker took too long to answer")
    if r.returncode != 0:
        raise HTTPException(400, ((r.stderr or r.stdout).strip() or "The images helper failed")[:300])
    return r


@router.get("")
def listing(user: str = Depends(current_user)):
    try:
        return json.loads(run("list", timeout=90).stdout)
    except ValueError:
        raise HTTPException(500, "The images helper returned something unexpected")


@router.post("/remove")
def remove(body: Remove, request: Request, user: str = Depends(current_user)):
    try:
        run("remove", body.id)
    except HTTPException:
        audit(user, request.client.host, "image_remove", target=body.id[:12], ok=False)
        raise
    audit(user, request.client.host, "image_remove", target=body.id[:12], ok=True)
    return {"ok": True}


@router.post("/prune")
def prune(request: Request, user: str = Depends(current_user)):
    try:
        out = run("prune", timeout=310).stdout
    except HTTPException:
        audit(user, request.client.host, "image_prune", ok=False)
        raise
    audit(user, request.client.host, "image_prune", ok=True)
    return {"ok": True, "output": out}
