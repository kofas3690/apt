"""Records for the phone app: audit log, incident timeline and incident list (docs/mobile-api-v1.md, section 14).

  GET /api/mobile/v1/audit      who did what, from which device, with what result; filters and a stable cursor
  GET /api/mobile/v1/timeline   alerts and actions merged into one chronology for a time window
  GET /api/mobile/v1/incidents  bursts of warning/critical alerts, so a person can pick "what happened Tuesday night"

Administrators only (the `audit_view` capability, the same rule as the web audit page), because the log holds every
person's addresses and what they changed. The panel redacts before anything leaves it: only a short list of harmless
detail fields is passed on, never paths, commands, passwords, keys, codes or file contents, and every address comes
with a masked twin for exports. The phone builds its exports from these answers, so what is redacted here stays redacted."""
import hashlib, re, time
from fastapi import Depends, HTTPException, Query, Request
import auditview, mobileevents
from auth import current_user
from mobileapi import router, reply, require

PAGE_MAX = 100
WINDOW_MAX = 30 * 86400
TIMELINE_MAX_SPAN = 7 * 86400
TIMELINE_CAP = 500
INCIDENT_GAP = 1800              # alerts closer together than this belong to one incident
INCIDENT_LOOKBACK = 30 * 86400
INCIDENTS_MAX = 20
RANGES = {"1h": 3600, "24h": 86400, "7d": 7 * 86400, "30d": 30 * 86400}

# The only detail fields that leave the panel (values are cut to 120 characters, containers are dropped).
SAFE = ("name", "unit", "action", "ok", "via", "phone", "request_id", "id", "minutes", "mute", "was", "start", "role", "metric", "count", "kind", "result", "requester", "updates_install", "backup_run")
TARGET_KEYS = ("unit", "name", "id", "metric", "kind")
LABELS = dict(auditview.LABELS, **{
    "service_action": "Service action", "unit_action": "Service action", "apt_started": "Updates started", "reboot_schedule": "Restart scheduled",
    "reboot_schedule_cancel": "Scheduled restart cancelled", "backup_start": "Backup started", "backup_cancel": "Backup cancelled",
    "maintenance_start": "Maintenance started", "maintenance_schedule": "Maintenance planned", "maintenance_end": "Maintenance ended",
    "approval_request": "Approval requested", "approval_approve": "Request approved", "approval_reject": "Request rejected", "approval_cancel": "Request cancelled",
    "approval_refused": "Approval refused", "approval_policy": "Approval policy changed",
    "preset_run": "Preset run", "preset_refused": "Preset refused", "presets_save": "Command presets changed", "presets_save_refused": "Command presets change refused",
    "presets_phone_edit": "Preset editing on the phone switched", "backup_phone_restore": "Restoring from the phone switched",
    "backup_restore": "Backup restored", "backup_restore_delete": "Restored folder deleted", "backup_check": "Backup copy checked", "backup_delete": "Backup copy deleted", "backup_phone_delete": "Phone backup deletion switched",
    "freespace_apt_clean": "Package cache cleaned", "freespace_autoremove": "Unused packages removed", "freespace_grow_root": "Root volume grown",
    "push_view": "Push alerts viewed", "push_test": "Push test sent", "push_test_failed": "Push test failed",
    "phone_paired": "Phone paired", "phone_revoked": "Phone removed", "phone_pair_started": "Phone pairing started", "phone_pair_failed": "Phone pairing failed",
    "power_action": "Power action", "power_refused": "Power action refused", "net_apply": "Network change applied", "net_revert": "Network change reverted",
    "net_confirm": "Network change confirmed", "vpn_easy_enable": "VPN turned on", "vpn_easy_disable": "VPN turned off", "vpn_easy_device_added": "VPN device added", "vpn_easy_device_removed": "VPN device removed", "vpn_easy_protect": "VPN protection repaired", "vpn_easy_server_added": "VPN server added", "vpn_easy_join": "Joined a VPN", "notify_prefs": "Alert settings changed", "notify_device_registered": "Phone alerts turned on",
    "notify_device_removed": "Phone alerts turned off", "service_denied": "Service action refused", "terminal_open": "Terminal opened", "terminal_close": "Terminal closed",
})
# What the timeline includes from the audit log (everything else is available in the audit screen but would drown a chronology).
TIMELINE_AUDIT = {"service_action", "unit_action", "apt_started", "reboot_schedule", "reboot_schedule_cancel", "backup_start", "backup_cancel", "power_action",
                  "power_refused", "net_apply", "net_revert", "net_confirm", "vpn_easy_enable", "vpn_easy_disable", "vpn_easy_device_added", "vpn_easy_device_removed", "vpn_easy_server_added", "vpn_easy_join", "login_failed", "phone_paired", "phone_revoked", "role_denied", "service_denied",
                  "preset_run", "preset_refused", "presets_save", "presets_phone_edit", "backup_phone_restore", "backup_restore", "backup_restore_delete", "backup_check", "backup_delete", "backup_phone_delete", "approval_request", "approval_approve", "approval_reject", "approval_refused", "panel_admin_added", "panel_admin_removed", "panel_role_changed", "terminal_open"}

_cache = {"key": None, "rows": [], "capped": False}


def label(ev):
    return LABELS.get(ev) or clean(ev, 60).replace("_", " ").strip().capitalize()


def mask_ip(ip):
    if re.fullmatch(r"\d{1,3}(\.\d{1,3}){3}", ip):
        return ip.rsplit(".", 1)[0] + ".x"
    if ":" in ip:
        return ":".join(ip.split(":")[:3]) + "::x"
    return ""


def clean(s, n):
    return "".join(ch for ch in str(s)[:n] if ch >= " ")


def safe_detail(d):
    out = {}
    for k in SAFE:
        v = d.get(k)
        if isinstance(v, bool) or isinstance(v, (int, float)):
            out[k] = v
        elif isinstance(v, str):
            out[k] = "".join(ch for ch in v[:120] if ch >= " ")
    return out


def result_of(event, d):
    if d.get("ok") is False or event.endswith("_failed") or event in ("login_failed", "panel_stepup_failed"):
        return "failed"
    if event.endswith("_denied") or event.endswith("_refused") or event == "login_refused_no_2fa":
        return "denied"
    if d.get("ok") is True:
        return "ok"
    return "info"


def normalise(r, n):
    d = safe_detail(r["detail"])
    target = next((d[k] for k in TARGET_KEYS if isinstance(d.get(k), str) and d[k]), None)
    h = hashlib.sha1(repr((r["ts"], r["user"], r["ip"], r["event"], sorted(r["detail"].items(), key=lambda kv: kv[0]))).encode(), usedforsecurity=False).hexdigest()[:12]   # only a short record id, not a security hash
    via = d.get("via") if d.get("via") in ("phone", "browser") else None
    return {"id": "%s-%d" % (h, n), "t": r["t"], "actor": clean(r["user"], 80), "action": clean(r["event"], 60), "label": label(r["event"]), "target": target,
            "result": result_of(r["event"], r["detail"]), "via": via, "phone": d.get("phone") if isinstance(d.get("phone"), str) else None,
            "request_id": d.get("request_id") if isinstance(d.get("request_id"), str) else None,
            "ip": clean(r["ip"], 60), "ip_masked": mask_ip(r["ip"]), "detail": d}


def all_rows():
    """Every readable audit line, newest first, normalised. Kept for a few seconds so paging does not re-read the files each time."""
    files = auditview.files()
    key = tuple((str(p), p.stat().st_mtime_ns, p.stat().st_size) for p in files)
    if _cache["key"] == key and time.time() - _cache.get("at", 0) < 20:
        return _cache["rows"], _cache["capped"]
    rows, capped = auditview.rows("all")
    seen, out = {}, []
    for r in rows:
        base = (r["ts"], r["user"], r["ip"], r["event"])
        seen[base] = seen.get(base, 0) + 1
        out.append(normalise(r, seen[base]))
    out.sort(key=lambda x: (x["t"], x["id"]), reverse=True)
    _cache.update(key=key, rows=out, capped=capped, at=time.time())
    return out, capped


def window(rng, t_from, t_to, now):
    if t_from is not None or t_to is not None:
        lo = t_from if t_from is not None else now - RANGES["24h"]
        hi = t_to if t_to is not None else now
    else:
        if rng not in RANGES:
            raise HTTPException(400, "range must be one of 1h, 24h, 7d, 30d.")
        lo, hi = now - RANGES[rng], now
    if lo >= hi:
        raise HTTPException(400, "The start of the time window must be before its end.")
    if hi - lo > WINDOW_MAX:
        raise HTTPException(400, "The time window can be at most 30 days.")
    return int(lo), int(hi)


def _cursor(c):
    m = re.fullmatch(r"(\d{1,12})\.([0-9a-f]{12}-\d{1,6})", c or "")
    if c and not m:
        raise HTTPException(400, "Invalid cursor.")
    return (int(m.group(1)), m.group(2)) if m else None


@router.get("/audit")
def audit_log(request: Request, user: str = Depends(current_user), actor: str = Query("", max_length=80), action: str = Query("", max_length=60),
              result: str = Query("", pattern="^(ok|failed|denied|info)?$"), q: str = Query("", max_length=80), range: str = "24h",
              t_from: int = Query(None, alias="from", ge=0), t_to: int = Query(None, alias="to", ge=0),
              cursor: str = "", limit: int = Query(50, ge=1, le=PAGE_MAX)):
    """Newest first, one page at a time. `next_cursor` continues strictly after the last row, so rows written meanwhile never shift a page."""
    require(request, user, "audit_view")
    now = int(time.time())
    lo, hi = window(range, t_from, t_to, now)
    cur = _cursor(cursor)
    rows, capped = all_rows()
    needle = q.strip().lower()
    match = []
    for r in rows:
        if r["t"] < lo or r["t"] > hi:
            continue
        if actor and r["actor"] != actor or action and r["action"] != action or result and r["result"] != result:
            continue
        if needle and needle not in (r["actor"] + " " + r["action"] + " " + r["label"] + " " + (r["target"] or "")).lower():
            continue
        match.append(r)
    page = [r for r in match if cur is None or (r["t"], r["id"]) < cur][:limit]
    nxt = None
    if page and len([r for r in match if (r["t"], r["id"]) < (page[-1]["t"], page[-1]["id"])]):
        nxt = "%d.%s" % (page[-1]["t"], page[-1]["id"])
    out = {"items": page, "next_cursor": nxt, "matching": len(match), "window": {"from": lo, "to": hi}, "capped": capped}
    if cur is None:
        window_rows = [r for r in rows if lo <= r["t"] <= hi]
        out["actors"] = sorted({r["actor"] for r in window_rows if r["actor"]})[:100]
        acts = {}
        for r in window_rows:
            acts.setdefault(r["action"], r["label"])
        out["actions"] = [{"name": k, "label": v} for k, v in sorted(acts.items(), key=lambda kv: kv[1].lower())][:200]
    return reply(request, out)


def _alerts(lo, hi):
    rows = mobileevents.q("SELECT seq, ts, type, severity, title, detail, tkind, tname, muted FROM events WHERE ts >= ? AND ts <= ? ORDER BY ts, seq LIMIT ?", (lo, hi, TIMELINE_CAP + 1))
    return [{"id": "evt_%06d" % r[0], "t": r[1], "source": "alert", "type": r[2], "severity": r[3], "title": r[4], "detail": r[5],
             "target": {"kind": r[6], "name": r[7]} if r[6] else None, "actor": None, "via": None, "muted": bool(r[8])} for r in rows]


@router.get("/timeline")
def timeline(request: Request, user: str = Depends(current_user), t_from: int = Query(None, alias="from", ge=0), t_to: int = Query(None, alias="to", ge=0)):
    """Alerts and actions in one chronology (oldest first) for up to 7 days. A source that cannot be read is named in `sources`, not hidden."""
    require(request, user, "audit_view")
    now = int(time.time())
    hi = t_to if t_to is not None else now
    lo = t_from if t_from is not None else hi - 86400
    if lo >= hi:
        raise HTTPException(400, "The start of the time window must be before its end.")
    if hi - lo > TIMELINE_MAX_SPAN:
        raise HTTPException(400, "The timeline window can be at most 7 days.")
    items, sources = [], {}
    try:
        items += _alerts(lo, hi)
        sources["alerts"] = {"ok": True}
    except Exception:
        sources["alerts"] = {"ok": False, "note": "Alert history could not be read."}
    try:
        rows, _ = all_rows()
        for r in rows:
            if lo <= r["t"] <= hi and r["action"] in TIMELINE_AUDIT:
                items.append({"id": r["id"], "t": r["t"], "source": "action", "type": r["action"], "severity": "warning" if r["result"] in ("failed", "denied") else "info",
                              "title": r["label"] + (": " + r["target"] if r["target"] else ""), "detail": r["detail"].get("action", "") if isinstance(r["detail"].get("action"), str) else "",
                              "target": None, "actor": r["actor"], "via": r["via"], "muted": False, "result": r["result"]})
        sources["actions"] = {"ok": True}
    except Exception:
        sources["actions"] = {"ok": False, "note": "The audit log could not be read, so actions are missing."}
    items.sort(key=lambda x: (x["t"], x["id"]))
    truncated = len(items) > TIMELINE_CAP
    return reply(request, {"items": items[:TIMELINE_CAP], "truncated": truncated, "window": {"from": lo, "to": hi}, "sources": sources})


@router.get("/incidents")
def incidents(request: Request, user: str = Depends(current_user)):
    """Bursts of warning or critical alerts (gap of more than 30 minutes starts a new one), newest first, last 30 days, at most 20."""
    require(request, user, "audit_view")
    now = int(time.time())
    rows = mobileevents.q("SELECT seq, ts, severity, title, tname, muted FROM events WHERE ts >= ? AND severity IN ('critical','warning') AND type NOT LIKE 'maintenance_%' ORDER BY ts, seq",
                          (now - INCIDENT_LOOKBACK,))
    groups, cur = [], None
    for seq, ts, sev, title, tname, muted in rows:
        if cur is None or ts - cur["end"] > INCIDENT_GAP:
            cur = {"start": ts, "end": ts, "events": []}
            groups.append(cur)
        cur["end"] = ts
        cur["events"].append((seq, sev, title, tname, muted))
    out = []
    for g in reversed(groups[-INCIDENTS_MAX:]):
        first_crit = next((e for e in g["events"] if e[1] == "critical"), g["events"][0])
        names = []
        for e in g["events"]:
            if e[3] and e[3] not in names:
                names.append(e[3])
        out.append({"id": "inc_%d" % g["start"], "start": g["start"], "end": g["end"], "title": first_crit[2], "count": len(g["events"]),
                    "critical": sum(1 for e in g["events"] if e[1] == "critical"), "held": sum(1 for e in g["events"] if e[4]), "targets": names[:5],
                    "ongoing": now - g["end"] <= INCIDENT_GAP})
    return reply(request, {"items": out})
