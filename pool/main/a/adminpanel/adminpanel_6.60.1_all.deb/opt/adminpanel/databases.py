"""Databases: a read-only overview of MariaDB/MySQL and PostgreSQL on this machine.

A root helper runs a few fixed queries (version, uptime, open connections, the size of each database). It takes no input
from the browser and never reads table contents, accounts or passwords.
"""
import json, subprocess
from fastapi import APIRouter, Depends, HTTPException
from auth import current_user

router = APIRouter(prefix="/api/databases")

HELPER = "/usr/local/sbin/adminpanel-databases"
SUDO = "/usr/bin/sudo"
ENV = {"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LC_ALL": "C"}


@router.get("")
def overview(user: str = Depends(current_user)):
    try:
        r = subprocess.run([SUDO, "-n", HELPER, "list"], capture_output=True, text=True, errors="replace", timeout=90,
                           env=ENV, stdin=subprocess.DEVNULL)
    except subprocess.TimeoutExpired:
        raise HTTPException(504, "The database helper took too long")
    if r.returncode != 0:
        raise HTTPException(400, ((r.stderr or r.stdout).strip() or "The database helper failed")[:300])
    try:
        return json.loads(r.stdout)
    except ValueError:
        raise HTTPException(500, "The database helper returned something unexpected")
