"""Command presets editor (web panel, administrators only).

The phone app runs presets that an administrator defined in /etc/adminpanel/presets.json. This page is the editor for that
file, so nobody has to edit JSON by hand. It never writes the file itself: the panel account cannot (the file is root-owned),
so every change goes through the root helper `adminpanel-presets save`, which checks each entry again and replaces the file
atomically. The phone can never use this route (roles.py: ADMIN_ONLY, and the phone is denied everything ADMIN_ONLY lists)."""
import json, subprocess
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from auth import current_user
from audit import audit

router = APIRouter(prefix="/api/presetsadmin")

HELPER = "/usr/local/sbin/adminpanel-presets"
SUDO = "/usr/bin/sudo"
ENV = {"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LC_ALL": "C"}


MAX_PRESETS = 20


class Preset(BaseModel):
    id: str = Field(max_length=40)
    label: str = Field(max_length=60)
    description: str = Field(default="", max_length=160)
    kind: str = "changes"
    argv: List[str] = Field(min_length=1, max_length=20)
    timeout: int = Field(default=20, ge=1, le=25)
    note: str = Field(default="", max_length=80)
    admin_only: bool = False


class Body(BaseModel):
    presets: List[Preset] = Field(max_length=20)


def helper(*args, stdin: Optional[str] = None, timeout=20):
    try:
        r = subprocess.run([SUDO, "-n", HELPER, *args], capture_output=True, text=True, errors="replace", timeout=timeout,
                           env=ENV, input=stdin if stdin is not None else None, stdin=None if stdin is not None else subprocess.DEVNULL)
    except (OSError, subprocess.TimeoutExpired):
        raise HTTPException(503, "The presets helper did not answer.")
    return r


@router.get("")
def get_all(user: str = Depends(current_user)):
    r = helper("dump")
    if r.returncode != 0:
        raise HTTPException(503, (r.stderr or "").strip()[:300] or "The presets could not be read.")
    try:
        return json.loads(r.stdout)
    except ValueError:
        raise HTTPException(503, "The presets helper answered something unexpected.")


@router.put("")
def save_all(body: Body, request: Request, user: str = Depends(current_user)):
    payload = json.dumps({"presets": [p.model_dump() for p in body.presets]})
    r = helper("save", stdin=payload)
    ids = [p.id for p in body.presets]
    if r.returncode != 0:
        msg = (r.stderr or "").strip()[:300] or "The presets could not be saved."
        audit(user, request.client.host, "presets_save_refused", reason=msg[:120], count=len(ids))
        raise HTTPException(400, msg)
    audit(user, request.client.host, "presets_save", count=len(ids), ids=ids[:20])
    return {"saved": len(ids)}
