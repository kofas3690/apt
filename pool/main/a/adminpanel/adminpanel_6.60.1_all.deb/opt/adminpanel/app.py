import psutil
from fastapi import Depends, FastAPI
from fastapi.staticfiles import StaticFiles
from auth import router as auth_router, current_user
from sshkeys import router as sshkeys_router
from userunits import router as userunits_router
from storage_admin import router as storage_admin_router
from security import router as security_router
from paneladmin import router as paneladmin_router
from roles import RolesMiddleware
from ipallow import router as ipallow_router, IpAllowMiddleware
from auditview import router as auditview_router
from mobile import router as mobile_router
import mobileaudit                      # records for the phone (v1 router; must come before include_router)
import mobilepresets                  # command presets (v1 router; must come before include_router)
import mobiledistro                   # the server's distribution logo (v1 router; must come before include_router)
import mobilepush                     # push alerts info (v1 router; must come before include_router)
import mobiletemp                     # temporary read-only access (v1 router; must come before include_router)
import mobileapprovals                 # two-person approval (v1 router; must come before include_router)
import mobilemaint                      # maintenance windows (v1 router; must come before include_router)
import mobileunits                      # service dependents (v1 router)
import mobilerestore                   # phone restore routes (6.31.0)
import mobilebackups                    # backup management routes on the v1 router (must come before include_router)
import mobilefreespace                   # free-space overview for the phone (v1 router; must come before include_router)
import mobilevpn                         # Quick VPN status for the phone (v1 router; must come before include_router)
import mobilepackages                    # software from the phone (v1 router; must come before include_router)
import updatecheck                       # is a newer AdminPanel out? (/api/selfupdate, and the phone call on the v1 router)
import termsnips                         # Terminal snippets (and the phone's look-only call on the v1 router)
import mobiledisks                       # disk health for the phone (v1 router; must come before include_router)
import mobileaptbusy                     # who is holding apt, for the phone (v1 router; must come before include_router)
import mobilemetrics                     # registers the performance-history route on the v1 router (must come before include_router)
import mobileevents                       # registers the alert-center routes on the v1 router (must come before include_router)
from mobileapi import router as mobileapi_router
from journal import router as journal_router
from fs import router as fs_router
from system import router as system_router
from units import router as units_router
from services import router as services_router
from remote import router as remote_router
from logs import router as logs_router
from updates import router as updates_router
from firewall import router as firewall_router
from users import router as users_router
from terminal import router as terminal_router
from termsnips import router as termsnips_router
from storage import router as storage_router
from network import router as network_router
from fleet import router as fleet_router, health_router
from power import router as power_router
from alerts import router as alerts_router, start_watcher as alerts_start
from metrics import router as metrics_router, start as metrics_start
from hardware import router as hardware_router
from logins import router as logins_router
from backup import router as backup_router
from processes import router as processes_router
from smart import router as smart_router, start as smart_start
from cron import router as cron_router
from clock import router as clock_router
from certs import router as certs_router, start as certs_start
from reboot import router as reboot_router
from kernel import router as kernel_router
from sudolog import router as sudo_router
from packages import router as packages_router
from diskusage import router as du_router
from shares import router as shares_router
from containers import router as containers_router
from blocked import router as blocked_router
from listening import router as listening_router
from startup import router as startup_router
from distrologo import router as distro_router
from presetsadmin import router as presetsadmin_router
from presetsphone import router as presetsphone_router
from backupphone import router as backupphone_router
from autoupdates import router as autoupdates_router
from swap import router as swap_router
from seccheck import router as seccheck_router
from authkeys import router as authkeys_router
from logclean import router as logclean_router
from freespace import router as freespace_router
from websites import router as websites_router
from certrenew import router as certrenew_router
from weblogs import router as weblogs_router
from hosts import router as hosts_router
from compose import router as compose_router
from databases import router as databases_router
from images import router as images_router
from volumes import router as volumes_router
from dnetworks import router as dnetworks_router
from schedule import router as schedule_router
from signinnotice import router as signinnotice_router
from chatalerts import router as chatalerts_router
from aging import router as aging_router
from sysctl import router as sysctl_router
from sshdconf import router as sshd_router
from nettools import router as nettools_router

app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)

class NoCacheStatic(StaticFiles):
    """Always revalidate pages, so a deploy shows up straight away."""

    async def get_response(self, path, scope):
        r = await super().get_response(path, scope)
        r.headers["Cache-Control"] = "no-cache"
        return r

app.add_middleware(RolesMiddleware)
app.add_middleware(IpAllowMiddleware)
app.include_router(auth_router)
app.include_router(sshkeys_router)
app.include_router(userunits_router)
app.include_router(storage_admin_router)
app.include_router(security_router)
app.include_router(paneladmin_router)
app.include_router(auditview_router)
app.include_router(mobile_router)
app.include_router(mobileapi_router)
app.include_router(ipallow_router)
app.include_router(journal_router)
app.include_router(fs_router)
app.include_router(system_router)
app.include_router(units_router)
app.include_router(services_router)
app.include_router(remote_router)
app.include_router(logs_router)
app.include_router(updates_router)
app.include_router(firewall_router)
app.include_router(users_router)
app.include_router(terminal_router)
app.include_router(termsnips_router)
app.include_router(storage_router)
app.include_router(network_router)
app.include_router(power_router)
app.include_router(alerts_router)
app.include_router(metrics_router)
app.include_router(hardware_router)
app.include_router(logins_router)
app.include_router(backup_router)
app.include_router(processes_router)
app.include_router(smart_router)
app.include_router(cron_router)
app.include_router(clock_router)
app.include_router(certs_router)
app.include_router(reboot_router)
app.include_router(kernel_router)
app.include_router(sudo_router)
app.include_router(packages_router)
app.include_router(du_router)
app.include_router(shares_router)
app.include_router(containers_router)
app.include_router(blocked_router)
app.include_router(listening_router)
app.include_router(startup_router)
app.include_router(distro_router)
app.include_router(presetsadmin_router)
app.include_router(presetsphone_router)
app.include_router(backupphone_router)
app.include_router(autoupdates_router)
app.include_router(swap_router)
app.include_router(seccheck_router)
app.include_router(authkeys_router)
app.include_router(logclean_router)
app.include_router(freespace_router)
app.include_router(websites_router)
app.include_router(certrenew_router)
app.include_router(weblogs_router)
app.include_router(hosts_router)
app.include_router(compose_router)
app.include_router(databases_router)
app.include_router(images_router)
app.include_router(volumes_router)
app.include_router(dnetworks_router)
app.include_router(schedule_router)
app.include_router(signinnotice_router)
app.include_router(chatalerts_router)
app.include_router(aging_router)
app.include_router(sysctl_router)
app.include_router(sshd_router)
app.include_router(nettools_router)

app.include_router(fleet_router)
app.include_router(health_router)
app.include_router(updatecheck.router)


@app.on_event("startup")
def _start_alert_mail():
    alerts_start()
    mobileevents.start()
    metrics_start()
    smart_start()
    certs_start()
    updatecheck.start()


@app.get("/api/stats")
def stats(user: str = Depends(current_user)):
    return {
        "cpu": psutil.cpu_percent(interval=0.5),
        "mem": psutil.virtual_memory().percent,
        "disk": psutil.disk_usage("/").percent,
    }


app.mount("/", NoCacheStatic(directory="static", html=True), name="static")
