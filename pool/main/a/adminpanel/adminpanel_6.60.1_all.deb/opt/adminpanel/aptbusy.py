"""Who is using apt right now? (6.56.0)  Used by GET /api/updates/busy and by adminpanel-selfcheck.

Only one program can change packages at a time; the others stop with "Could not get lock /var/lib/dpkg/lock-frontend".
This says which program that is, so you know what to do: answer the question it is waiting on, bring it back if it
was paused, or wait for it. It only reads /proc (any user may), runs nothing and stops nothing. It uses only the
standard library, so `python3 /opt/adminpanel/aptbusy.py` works on its own.

It looks for apt, apt-get, aptitude, dpkg and unattended-upgrade that were not started by another of them (a dpkg
under apt is part of that apt), and for whatever holds one of apt's lock files (from /proc/locks). For each it says
which program, run as which user, started by whom, in which terminal, how long ago, whether it holds a lock, and what
it seems to be doing:
  panel       the panel's own update job (Software updates, or the phone)
  automatic   automatic updates (unattended-upgrades or the apt-daily timers)
  stopped     paused with Ctrl+Z: it keeps the lock until it is brought back with fg in its terminal
  installing  dpkg is running under it: packages are being changed right now; do not stop it
  downloading apt is fetching packages
  waiting     in the foreground of a terminal with nothing running under it: most likely waiting for an answer there
              (such as "Do you want to continue? [Y/n]")
  busy        anything else
With sudo, apt often gets a terminal of its own; the terminal shown is the one the person typed in.
On a machine that hides other users' processes (/proc mounted with hidepid), a lock holder may show only its number."""
import os, pwd, sys
from pathlib import Path

PROC = Path("/proc")
WATCH = {"apt", "apt-get", "aptitude", "dpkg", "unattended-upgr"}
METHODS = {"http", "https", "store", "gpgv", "copy", "file", "rred", "cdrom", "mirror", "ftp", "tor+http", "tor+https"}
LOCKS = {"/var/lib/dpkg/lock-frontend": "dpkg frontend", "/var/lib/dpkg/lock": "dpkg",
         "/var/lib/apt/lists/lock": "package lists", "/var/cache/apt/archives/lock": "downloads"}
HINT = {
    "panel": "The panel's own update job. Follow it on the Software updates page; it ends by itself.",
    "automatic": "Automatic updates are running. Wait for them to finish, usually a few minutes.",
    "stopped": "It was paused (Ctrl+Z) in terminal {tty} and keeps the lock while paused. In that terminal type fg, then answer it or press Ctrl+C.",
    "installing": "Packages are being changed right now. Do not stop it; wait for it to finish.",
    "downloading": "It is downloading packages. Wait, or press Ctrl+C in terminal {tty} to stop it.",
    "waiting": "It is most likely waiting for an answer in terminal {tty}, such as \"Do you want to continue? [Y/n]\". Answer it there, or press Ctrl+C there.",
    "busy": "Wait a few minutes. If it does not end, look at it with: ps -o pid,stat,etime,cmd -p {pid}",
    "hidden": "This server hides other users' programs from the panel. See it with: sudo ps -o pid,user,tty,stat,etime,cmd -p {pid}",
}


def _stat(pid):
    """(comm, state, ppid, pgrp, tty_nr, tpgid, starttime) from /proc/PID/stat, or None."""
    try:
        s = (PROC / str(pid) / "stat").read_text()
        comm = s[s.index("(") + 1: s.rindex(")")]
        f = s[s.rindex(")") + 2:].split()
        return comm, f[0], int(f[1]), int(f[2]), int(f[4]), int(f[5]), int(f[19])
    except (OSError, ValueError, IndexError):
        return None


def _bytes(pid, name, limit=4096):
    try:
        with open(PROC / str(pid) / name, "rb") as fh:
            return fh.read(limit)
    except OSError:
        return b""


def tty_name(nr):
    if not nr:
        return ""
    major, minor = (nr >> 8) & 0xFFF, (nr & 0xFF) | ((nr >> 12) & 0xFFF00)
    if 136 <= major <= 143:
        return f"pts/{(major - 136) * 256 + minor}"
    if major == 4:
        return f"tty{minor}" if minor < 64 else f"ttyS{minor - 64}"
    return f"{major}:{minor}"


def _uid_name(pid):
    for line in _bytes(pid, "status").decode(errors="replace").splitlines():
        if line.startswith("Uid:"):
            try:
                return pwd.getpwuid(int(line.split()[1])).pw_name
            except (ValueError, IndexError, KeyError):
                return "?"
    return "?"


def lock_holders():
    """{pid: [lock names]} from /proc/locks, for apt's lock files."""
    want = {}
    for path, name in LOCKS.items():
        try:
            st = os.stat(path)
        except OSError:
            continue
        want[(os.major(st.st_dev), os.minor(st.st_dev), st.st_ino)] = name
    out = {}
    try:
        lines = (PROC / "locks").read_text().splitlines()
    except OSError:
        return out
    for line in lines:
        f = line.split()
        if "->" in f:                     # a waiter, not a holder
            continue
        try:
            pid = int(f[4])
            mj, mn, ino = f[5].split(":")
            key = (int(mj, 16), int(mn, 16), int(ino))
        except (IndexError, ValueError):
            continue
        if key in want and pid > 0:
            out.setdefault(pid, [])
            if want[key] not in out[pid]:
                out[pid].append(want[key])
    return out


def scan(me=None):
    """A list of dicts, one per program using apt, oldest first. `me`: a pid whose own ancestors are left out."""
    procs = {}
    try:
        names = [n for n in os.listdir(PROC) if n.isdigit()]
    except OSError:
        return []
    for n in names:
        st = _stat(int(n))
        if st:
            procs[int(n)] = st
    kids = {}
    for pid, st in procs.items():
        kids.setdefault(st[2], []).append(pid)

    def below(pid, depth=0):
        out = []
        for k in kids.get(pid, []):
            out.append(k)
            if depth < 8:
                out += below(k, depth + 1)
        return out

    def chain(pid):
        out, p = [], procs.get(pid, (None, None, 0))[2]
        for _ in range(12):
            if p not in procs:
                break
            out.append(p)
            p = procs[p][2]
        return out

    mine = set(chain(me) + [me]) if me else set()
    holders = lock_holders()

    def top(pid):                         # the outermost apt program this pid belongs to
        t = pid if pid in procs and procs[pid][0] in WATCH else None
        for a in chain(pid):
            if procs[a][0] in WATCH:
                t = a
        return t

    roots = {}
    for pid, st in procs.items():
        if st[0] in WATCH:
            t = top(pid)
            roots.setdefault(t, [])
    for pid, names_ in holders.items():
        t = top(pid) if pid in procs else None
        key = t if t is not None else pid
        roots.setdefault(key, [])
        for n in names_:
            if n not in roots[key]:
                roots[key].append(n)

    try:
        up = float((PROC / "uptime").read_text().split()[0])
    except (OSError, ValueError, IndexError):
        up = None
    hz = os.sysconf("SC_CLK_TCK")
    found = []
    for pid, locks in roots.items():
        if pid in mine:
            continue
        if pid not in procs:              # holds a lock, but this user cannot see it (hidepid)
            found.append({"pid": pid, "program": "?", "command": "", "user": "?", "started_by": "?", "tty": "",
                          "seconds": None, "locks": locks, "kind": "hidden", "stopped": False,
                          "hint": HINT["hidden"].format(pid=pid)})
            continue
        comm, state, ppid, pgrp, ttynr, tpgid, start = procs[pid]
        tree = below(pid)
        sub = [procs[k][0] for k in tree if k in procs]
        stopped = state == "T" or any(procs[k][1] == "T" for k in tree if k in procs)
        cgroup = _bytes(pid, "cgroup").decode(errors="replace")
        anc = chain(pid)
        # the terminal the person typed in: go up while the parent also has a terminal (sudo gives apt one of its own)
        tty, by = ttynr, pid
        for a in anc:
            if not procs[a][4]:
                break
            tty, by = procs[a][4], a
        if "adminpanel-apt-job" in cgroup:
            kind = "panel"
        elif comm == "unattended-upgr" or "apt-daily" in cgroup or "unattended-upgrades" in cgroup \
                or any(procs[a][0] in ("unattended-upgr", "apt.systemd.dai") for a in anc):
            kind = "automatic"
        elif stopped:
            kind = "stopped"
        elif comm == "dpkg" or "dpkg" in sub:
            kind = "installing"
        elif any(s in METHODS for s in sub):
            kind = "downloading"
        elif ttynr and tpgid == pgrp:
            kind = "waiting"
        else:
            kind = "busy"
        cmd = " ".join(a.decode(errors="replace") for a in _bytes(pid, "cmdline", 1024).split(b"\0") if a)[:160] or comm
        tname = tty_name(tty)
        found.append({"pid": pid, "program": "unattended-upgrade" if comm == "unattended-upgr" else comm,
                      "command": cmd, "user": _uid_name(pid), "started_by": _uid_name(by) if tty else "",
                      "tty": tname, "seconds": max(0, int(up - start / hz)) if up is not None else None,
                      "locks": locks, "kind": kind, "stopped": stopped,
                      "hint": HINT[kind].format(tty=tname or "?", pid=pid)})
    return sorted(found, key=lambda x: (x["seconds"] is None, -(x["seconds"] or 0), x["pid"]))


def age(s):
    if s is None:
        return "for an unknown time"
    if s < 120:
        return f"for {s} s"
    if s < 7200:
        return f"for {s // 60} min"
    return f"for {s // 3600} h {s % 3600 // 60} min"


def locks_text(locks):
    if len(locks) == 1:
        return f"{locks[0]} lock"
    return ", ".join(locks[:-1]) + f" and {locks[-1]} locks"


def line(x):
    where = f" in terminal {x['tty']}" if x["tty"] else ""
    by = f", started by {x['started_by']}" if x["started_by"] and x["started_by"] != x["user"] else ""
    lock = f", holds the {locks_text(x['locks'])}" if x["locks"] else ""
    return f"{x['program']} (process {x['pid']}, as {x['user']}{by}){where} {age(x['seconds'])}{lock}: {x['command']}. {x['hint']}"


if __name__ == "__main__":
    for x in scan(os.getpid()):
        print(line(x))
    sys.exit(0)
