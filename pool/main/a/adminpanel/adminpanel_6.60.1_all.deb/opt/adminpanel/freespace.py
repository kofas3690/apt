"""Free up space: what can be reclaimed safely, and three fixed actions (admins only to change anything).

A root helper (adminpanel-freespace) reports the package cache, the journal, packages nothing needs any more (old kernels are
the usual big one) and whether the root volume can simply be grown into unused LVM space. The page never sends a package
name, a path or a command: it only asks for one of three fixed actions, and the helper re-checks everything itself."""
import json, subprocess, threading
from fastapi import APIRouter, Depends, HTTPException, Request
from auth import current_user
from audit import audit

router = APIRouter(prefix="/api/freespace")

HELPER = "/usr/local/sbin/adminpanel-freespace"
SUDO = "/usr/bin/sudo"
ENV = {"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LC_ALL": "C"}
_busy = threading.Lock()


def run(*args, timeout=120):
    try:
        r = subprocess.run([SUDO, "-n", HELPER, *args], capture_output=True, text=True, errors="replace", timeout=timeout,
                           env=ENV, stdin=subprocess.DEVNULL)
    except subprocess.TimeoutExpired:
        raise HTTPException(504, "That took too long. It may still be running; reload the page in a minute.")
    if r.returncode != 0:
        raise HTTPException(400, ((r.stderr or r.stdout).strip() or "The helper failed")[:300])
    try:
        return json.loads(r.stdout)
    except ValueError:
        raise HTTPException(500, "The helper returned something unexpected")


@router.get("")
def status(user: str = Depends(current_user)):
    return run("status", timeout=150)


def action(name, event, request, user, timeout):
    if not _busy.acquire(blocking=False):
        raise HTTPException(409, "Another cleanup is running. Wait for it to finish.")
    try:
        res = run(name, timeout=timeout)
    except HTTPException as e:
        audit(user, request.client.host, event, ok=False, reason=str(e.detail)[:120])
        raise
    finally:
        _busy.release()
    audit(user, request.client.host, event, ok=True, freed=int(res.get("freed_bytes", 0)), removed=len(res.get("removed", []) or []))
    return res


@router.post("/apt-clean")
def apt_clean(request: Request, user: str = Depends(current_user)):
    return action("apt-clean", "freespace_apt_clean", request, user, 180)


@router.post("/autoremove")
def autoremove(request: Request, user: str = Depends(current_user)):
    return action("autoremove", "freespace_autoremove", request, user, 960)


@router.post("/grow-root")
def grow_root(request: Request, user: str = Depends(current_user)):
    return action("grow-root", "freespace_grow_root", request, user, 660)
