"""Sign-in address allow-list: only listed addresses or networks may reach the panel.

When it is on, a request from any other address gets "403" before it reaches the login page, so a stolen
password used from elsewhere is useless. Connections from this machine itself (127.0.0.0/8 and ::1, for example
an SSH tunnel or a person at the console) are always allowed, so the list can never lock out the server's own
administrator. The panel refuses to save a list that does not include the address you are using right now.

Stored in data/ipallow.json (mode 600). To switch it off from the server: sudo adminpanel-setup ipallow off."""
import ipaddress, json, os, time
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import Field
from audit import audit
from auth import current_user
from paths import DATA
from paneladmin import Step, step_up

FILE = DATA / "ipallow.json"
MAX_ENTRIES = 50
LOOPBACK = (ipaddress.ip_network("127.0.0.0/8"), ipaddress.ip_network("::1/128"))
router = APIRouter(prefix="/api/ipallow")
_cache = (None, None)            # (mtime_ns, config)
_denied_at = {}


def norm_ip(text):
    ip = ipaddress.ip_address(str(text).strip().split("%")[0])
    if ip.version == 6 and ip.ipv4_mapped:
        ip = ip.ipv4_mapped
    return ip


def parse_entry(text):
    t = str(text).strip()
    if not t or len(t) > 64 or any(c.isspace() for c in t):
        raise ValueError("Not an address: " + t[:40])
    try:
        net = ipaddress.ip_network(t, strict=False)
    except ValueError:
        raise ValueError("Not an address or network: " + t[:40])
    if net.version == 6 and net.network_address.ipv4_mapped:
        raise ValueError("Write IPv4 addresses without the ::ffff: prefix: " + t[:40])
    return net


def load():
    """The current settings, re-read only when the file changes. A missing or unreadable file means off."""
    global _cache
    try:
        m = FILE.stat().st_mtime_ns
    except OSError:
        _cache = (None, None)
        return {"enabled": False, "nets": [], "entries": []}
    if _cache[0] == m and _cache[1]:
        return _cache[1]
    try:
        raw = json.loads(FILE.read_text())
        nets = [parse_entry(e) for e in raw.get("entries", [])]
        cfg = {"enabled": bool(raw.get("enabled")), "nets": nets, "entries": [str(n) for n in nets]}
    except (OSError, ValueError, AttributeError):
        cfg = {"enabled": False, "nets": [], "entries": []}
    _cache = (m, cfg)
    return cfg


def allowed(addr, cfg=None):
    cfg = cfg or load()
    if not cfg["enabled"]:
        return True
    try:
        ip = norm_ip(addr)
    except ValueError:
        return False                       # an address that cannot be read is never trusted
    return any(ip in n for n in LOOPBACK) or any(ip in n for n in cfg["nets"] if n.version == ip.version)


class IpAllowMiddleware:
    """Outermost layer, pure ASGI so pages, the API and WebSockets are all covered."""

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] not in ("http", "websocket"):
            return await self.app(scope, receive, send)
        client = (scope.get("client") or ("", 0))[0]
        if allowed(client):
            return await self.app(scope, receive, send)
        now = time.time()
        if now - _denied_at.get(client, 0) > 300:                 # one audit line per address per five minutes
            if len(_denied_at) > 2000:
                _denied_at.clear()
            _denied_at[client] = now
            try:
                audit("", client, "ip_denied", path=scope.get("path", "")[:80])
            except OSError:
                pass
        if scope["type"] == "websocket":
            await receive()
            return await send({"type": "websocket.close", "code": 1008})
        body = b"This panel only accepts connections from approved addresses.\n"
        await send({"type": "http.response.start", "status": 403,
                    "headers": [(b"content-type", b"text/plain; charset=utf-8"), (b"content-length", str(len(body)).encode())]})
        await send({"type": "http.response.body", "body": body})


class IpBody(Step):
    enabled: bool
    entries: list[str] = Field(default_factory=list, max_length=MAX_ENTRIES)


@router.get("")
def get(request: Request, user: str = Depends(current_user)):
    cfg = load()
    me = request.client.host
    return {"enabled": cfg["enabled"], "entries": cfg["entries"], "your_ip": me,
            "on_this_machine": allowed(me, {"enabled": True, "nets": []}), "max": MAX_ENTRIES}


@router.put("")
def put(body: IpBody, request: Request, user: str = Depends(current_user)):
    me = request.client.host
    nets, seen = [], set()
    for e in body.entries:
        if not e.strip():
            continue
        try:
            n = parse_entry(e)
        except ValueError as ex:
            raise HTTPException(400, str(ex))
        if n not in seen:
            seen.add(n)
            nets.append(n)
    cfg = {"enabled": body.enabled, "nets": nets, "entries": [str(n) for n in nets]}
    if body.enabled:
        if not nets:
            raise HTTPException(400, "Add at least one address or network, or turn the list off.")
        if not allowed(me, cfg):
            raise HTTPException(400, f"This list does not include your own address ({me}), so you would be locked out. Add it first.")
    step_up(request, user, body)
    tmp = FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps({"enabled": body.enabled, "entries": cfg["entries"], "by": user, "at": int(time.time())}, indent=2))
    os.chmod(tmp, 0o600)
    os.replace(tmp, FILE)
    audit(user, me, "ipallow_changed", enabled=body.enabled, entries=cfg["entries"])
    return {"ok": True, "enabled": body.enabled, "entries": cfg["entries"]}
