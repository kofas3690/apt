"""Two-person approval for the phone app: /api/mobile/v1/approvals (docs/mobile-api-v1.md, section 15).

A risky action is *requested* by one account and *approved* by a different administrator; only then does the panel run it,
under the approver's name. Nobody can approve their own request, a request expires after 10 minutes, and every step is
written to the audit log with the phone and request ID.

  * Actions that can be approved are a fixed list: reboot, updates_install, backup_run. There is no free text and no command.
  * `reboot` from a phone is possible only through an approval. `updates_install` and `backup_run` can be made
    approval-only for phones by an administrator (the policy); the web panel is not affected by the policy.
  * Requesting needs the `approval_request` capability (operators and admins on a full phone), approving or rejecting
    needs `approval_decide` (admins on a full phone). The requester can cancel their own pending request.
  * Idempotency-Key is required on every POST."""
import threading, time, socket
from typing import Literal, Optional
from fastapi import Depends, HTTPException, Request
from pydantic import BaseModel, Field
import auth, roles, store
from audit import audit
from auth import current_user
from mobileapi import router, reply, require, idempotent

TTL = 600
MAX_PENDING = 10
KEEP_RECENT = 10
ACTIONS = {"reboot": "Reboot", "updates_install": "Install updates", "backup_run": "Run a backup"}
POLICY_ACTIONS = ("updates_install", "backup_run")      # reboot always needs approval from a phone
# The direct panel paths a phone could otherwise use for these actions (roles.decide asks required() about them).
GATED_PATHS = {"/api/updates/run/upgrade": "updates_install", "/api/backup/start": "backup_run"}

with store._lock:
    store._conn.execute("CREATE TABLE IF NOT EXISTS approvals (id INTEGER PRIMARY KEY AUTOINCREMENT, action TEXT NOT NULL, requester TEXT NOT NULL, "
                        "note TEXT NOT NULL, created INTEGER NOT NULL, expires INTEGER NOT NULL, state TEXT NOT NULL, decider TEXT, decided INTEGER, result TEXT NOT NULL DEFAULT '')")
    store._conn.execute("CREATE TABLE IF NOT EXISTS approval_policy (action TEXT PRIMARY KEY, required INTEGER NOT NULL)")
    store._conn.commit()

COLS = "id, action, requester, note, created, expires, state, decider, decided, result"
_exec_lock = threading.Lock()


def q(sql, args=()):
    with store._lock:
        rows = store._conn.execute(sql, args).fetchall()
        store._conn.commit()
        return rows


def required(action):
    """Does a phone need an approval for this action? Reboot always; the others only when an administrator turned the policy on.
    If the policy cannot be read the answer is yes: an unreadable rule must never loosen a gate."""
    if action == "reboot":
        return True
    if action not in POLICY_ACTIONS:
        return False
    try:
        r = q("SELECT required FROM approval_policy WHERE action=?", (action,))
        return bool(r and r[0][0])
    except Exception:
        return True


def policy():
    return {a: required(a) for a in POLICY_ACTIONS}


def gate_for_path(path):
    a = GATED_PATHS.get(path)
    return a if a and required(a) else None


def _row(r):
    return {"id": r[0], "action": r[1], "requester": r[2], "note": r[3], "created": r[4], "expires": r[5], "state": r[6], "decider": r[7], "decided": r[8], "result": r[9]}


def get(aid):
    r = q(f"SELECT {COLS} FROM approvals WHERE id=?", (aid,))  # nosec B608: COLS is a fixed module constant; the id is bound
    return _row(r[0]) if r else None


def _sweep(now):
    """Pending requests past their time become expired (once, so the history is stable)."""
    q("UPDATE approvals SET state='expired', decided=? WHERE state='pending' AND expires <= ?", (now, now))


def _caller(request, user):
    ph = getattr(request.state, "phone", None)
    role = roles.role_of(auth.load_users().get(user))
    ro = bool(ph and ph["ro"])
    return role, ro


def view(a, user, role, ro, now):
    pending = a["state"] == "pending"
    host = socket.gethostname()
    label = ACTIONS.get(a["action"], a["action"])
    if a["action"] == "reboot":
        label = f"Reboot {host}"
    return {"id": a["id"], "action": a["action"], "label": label, "note": a["note"], "state": a["state"], "requester": a["requester"],
            "created": a["created"], "expires": a["expires"], "seconds_left": max(0, a["expires"] - now) if pending else None,
            "decider": a["decider"], "decided": a["decided"], "result": a["result"],
            "mine": a["requester"] == user,
            "can_approve": bool(pending and role == "admin" and not ro and a["requester"] != user),
            "can_cancel": bool(pending and a["requester"] == user)}


def _who(request):
    ph = getattr(request.state, "phone", None)
    return {"via": "phone" if ph else "browser", "phone": ph["id"] if ph else None, "request_id": request.state.request_id}


@router.get("/approvals")
def overview(request: Request, user: str = Depends(current_user)):
    require(request, user, "view")
    now = int(time.time())
    _sweep(now)
    role, ro = _caller(request, user)
    rows = [_row(r) for r in q(f"SELECT {COLS} FROM approvals ORDER BY id DESC LIMIT 100")]  # nosec B608: COLS is a fixed module constant; nothing from the request is in the text
    pend = sorted([a for a in rows if a["state"] == "pending"], key=lambda a: a["created"])
    rec = [a for a in rows if a["state"] != "pending"][:KEEP_RECENT]
    return reply(request, {"pending": [view(a, user, role, ro, now) for a in pend], "recent": [view(a, user, role, ro, now) for a in rec],
                           "policy": policy(), "ttl_seconds": TTL})


class NewRequest(BaseModel):
    action: Literal["reboot", "updates_install", "backup_run"]
    note: str = Field("", max_length=120)


@router.post("/approvals")
def request_one(body: NewRequest, request: Request, user: str = Depends(current_user)):
    require(request, user, "approval_request")

    def make():
        now = int(time.time())
        _sweep(now)
        if q("SELECT id FROM approvals WHERE state='pending' AND action=? LIMIT 1", (body.action,)):
            raise HTTPException(409, "There is already a pending request for this. Wait for it to be decided or expire.")
        if q("SELECT COUNT(*) FROM approvals WHERE state='pending'")[0][0] >= MAX_PENDING:
            raise HTTPException(409, "Too many pending requests.")
        note = " ".join(body.note.split())
        aid = q("INSERT INTO approvals (action, requester, note, created, expires, state) VALUES (?,?,?,?,?,'pending') RETURNING id",
                (body.action, user, note, now, now + TTL))[0][0]
        audit(user, request.client.host, "approval_request", id=aid, action=body.action, **_who(request))
        role, ro = _caller(request, user)
        return 201, view(get(aid), user, role, ro, now)
    return idempotent(request, user, "approval_request", body.model_dump(), make)


def _finish(aid, state, decider, result):
    q("UPDATE approvals SET state=?, decider=?, decided=?, result=? WHERE id=?", (state, decider, int(time.time()), result[:200], aid))


def _run(action, request, user):
    """Does the approved thing. Returns a short sentence; raises HTTPException with the reason when it cannot."""
    if action == "reboot":
        import actions
        busy = actions.update_running()
        if busy:
            raise HTTPException(409, f"A software update is running ({busy}). Wait until it has finished.")
        audit(user, request.client.host, "power_action", action="reboot", host=socket.gethostname(), **_who(request))

        def go():
            try:
                actions.run_power("reboot")
            except Exception as e:
                audit(user, "-", "power_failed", action="reboot", error=str(getattr(e, "message", e))[:200])
        threading.Timer(3.0, go).start()               # after the answer has been sent: the panel stops with the machine
        return "The machine is rebooting now."
    if action == "updates_install":
        import updates
        updates.start("upgrade", request, user)
        return "The update job has started."
    if action == "backup_run":
        import backup, mobilebackups
        st = mobilebackups._status()
        if st.get("running"):
            raise HTTPException(409, "A backup is already running.")
        if not st.get("dest_ready"):
            raise HTTPException(409, "The backup destination is not connected, so a backup cannot start.")
        r = backup.run("start")
        audit(user, request.client.host, "backup_start", ok=(r.returncode == 0), **_who(request))
        backup.must(r)
        return "The backup has started."
    raise HTTPException(400, "Unknown action.")


@router.post("/approvals/{aid}/approve")
def approve(aid: int, request: Request, user: str = Depends(current_user)):
    require(request, user, "approval_decide")

    def make():
        now = int(time.time())
        _sweep(now)
        a = get(aid)
        if not a:
            raise HTTPException(404, "No such request.")
        if a["requester"] == user:
            audit(user, request.client.host, "approval_refused", id=aid, action=a["action"], result="own_request", **_who(request))
            raise HTTPException(403, "You can't approve your own request. A second administrator has to.")
        with _exec_lock:                                     # one approved action at a time, and each only once
            n = 0
            with store._lock:
                n = store._conn.execute("UPDATE approvals SET state='approving', decider=? WHERE id=? AND state='pending' AND expires > ?", (user, aid, now)).rowcount
                store._conn.commit()
            if n != 1:
                raise HTTPException(409, "This request is no longer pending (it was decided, cancelled or has expired).")
            try:
                msg = _run(a["action"], request, user)
            except HTTPException as e:
                _finish(aid, "failed", user, str(e.detail))
                audit(user, request.client.host, "approval_approve", id=aid, action=a["action"], requester=a["requester"], result="failed", **_who(request))
                raise
            except Exception:
                _finish(aid, "failed", user, "The action could not be started.")
                audit(user, request.client.host, "approval_approve", id=aid, action=a["action"], requester=a["requester"], result="failed", **_who(request))
                raise HTTPException(500, "The action could not be started.")
            _finish(aid, "done", user, msg)
            audit(user, request.client.host, "approval_approve", id=aid, action=a["action"], requester=a["requester"], result="ok", **_who(request))
        role, ro = _caller(request, user)
        return 200, view(get(aid), user, role, ro, int(time.time()))
    return idempotent(request, user, "approval_approve:%d" % aid, {}, make)


@router.post("/approvals/{aid}/reject")
def reject(aid: int, request: Request, user: str = Depends(current_user)):
    require(request, user, "approval_decide")

    def make():
        now = int(time.time())
        _sweep(now)
        a = get(aid)
        if not a:
            raise HTTPException(404, "No such request.")
        if a["state"] != "pending":
            raise HTTPException(409, "This request is no longer pending.")
        _finish(aid, "rejected", user, "Rejected.")
        audit(user, request.client.host, "approval_reject", id=aid, action=a["action"], requester=a["requester"], **_who(request))
        role, ro = _caller(request, user)
        return 200, view(get(aid), user, role, ro, now)
    return idempotent(request, user, "approval_reject:%d" % aid, {}, make)


@router.post("/approvals/{aid}/cancel")
def cancel(aid: int, request: Request, user: str = Depends(current_user)):
    require(request, user, "view")

    def make():
        now = int(time.time())
        _sweep(now)
        a = get(aid)
        if not a:
            raise HTTPException(404, "No such request.")
        if a["requester"] != user:
            raise HTTPException(403, "Only the person who asked can cancel a request. An administrator can reject it.")
        if a["state"] != "pending":
            raise HTTPException(409, "This request is no longer pending.")
        _finish(aid, "cancelled", user, "Cancelled by the requester.")
        audit(user, request.client.host, "approval_cancel", id=aid, action=a["action"], **_who(request))
        role, ro = _caller(request, user)
        return 200, view(get(aid), user, role, ro, now)
    return idempotent(request, user, "approval_cancel:%d" % aid, {}, make)


class PolicyBody(BaseModel):
    updates_install: Optional[bool] = None
    backup_run: Optional[bool] = None


@router.put("/approvals/policy")
def set_policy(body: PolicyBody, request: Request, user: str = Depends(current_user)):
    """Administrators on a full phone choose which actions a phone may only do through an approval."""
    require(request, user, "approval_decide")

    def make():
        changed = {}
        for a in POLICY_ACTIONS:
            v = getattr(body, a)
            if v is not None:
                q("INSERT OR REPLACE INTO approval_policy (action, required) VALUES (?,?)", (a, int(v)))
                changed[a] = bool(v)
        if changed:
            audit(user, request.client.host, "approval_policy", count=len(changed), **{k: v for k, v in changed.items()}, **_who(request))
        return 200, {"policy": policy()}
    return idempotent(request, user, "approval_policy", body.model_dump(), make)
