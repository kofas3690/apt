import json, re, subprocess, time
from pathlib import Path
from typing import Literal
import psutil
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from auth import current_user
from audit import audit

router = APIRouter(prefix="/api/network")

HELPER = "/usr/local/sbin/adminpanel-net"
ENV = {"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LC_ALL": "C"}
PROC = re.compile(r'\("([^"]+)",pid=(\d+)')
PROXY_RE = re.compile(r"(?P<scheme>https?|socks5h?)://(?P<host>[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?"
                      r"(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)*|\[[0-9A-Fa-f:]+\])"
                      r"(?::(?P<port>\d{1,5}))?/?")


def run(cmd, stdin=None, timeout=60):
    kw = {"input": stdin} if stdin is not None else {"stdin": subprocess.DEVNULL}
    try:
        return subprocess.run(["/usr/bin/sudo", "-n", HELPER, cmd], capture_output=True,
                              text=True, timeout=timeout, env=ENV, **kw)
    except subprocess.TimeoutExpired:
        raise HTTPException(504, "The network helper took too long to answer")


def must(r):
    if r.returncode != 0:
        raise HTTPException(400, (r.stderr or r.stdout).strip() or "Command failed")
    return r


def ipj(*args):
    try:
        r = subprocess.run(["ip", "-j", *args], capture_output=True, text=True,
                           timeout=10, env=ENV)
        return json.loads(r.stdout) if r.returncode == 0 and r.stdout.strip() else []
    except (OSError, ValueError, subprocess.TimeoutExpired):
        return []


def kind_of(link):
    if link.get("link_type") == "loopback":
        return "loopback"
    k = (link.get("linkinfo") or {}).get("info_kind")
    if k:
        return k
    name = link.get("ifname", "")
    return "physical" if Path(f"/sys/class/net/{name}/device").exists() else "other"


def dns_info():
    servers, search = [], []
    try:
        for line in Path("/run/systemd/resolve/resolv.conf").read_text().splitlines():
            p = line.split()
            if len(p) > 1 and p[0] == "nameserver":
                servers.append(p[1])
            elif p and p[0] == "search":
                search = p[1:]
    except OSError:
        pass
    return {"servers": servers, "search": search}


@router.get("/overview")
def overview(user: str = Depends(current_user)):
    counters = psutil.net_io_counters(pernic=True)
    stats = psutil.net_if_stats()
    ifaces = []
    for l in ipj("-d", "addr", "show"):
        name = l.get("ifname")
        if not name:
            continue
        c, s = counters.get(name), stats.get(name)
        addrs = [{"addr": f'{a["local"]}/{a["prefixlen"]}', "family": a["family"],
                  "dynamic": bool(a.get("dynamic"))}
                 for a in l.get("addr_info", []) if a.get("family") in ("inet", "inet6")]
        ifaces.append({
            "name": name, "kind": kind_of(l), "state": str(l.get("operstate", "")).lower(),
            "mac": l.get("address", ""), "mtu": l.get("mtu"), "master": l.get("master", ""),
            "speed": s.speed if s else 0, "addresses": addrs,
            "rx_bytes": c.bytes_recv if c else 0, "tx_bytes": c.bytes_sent if c else 0,
            "errors": (c.errin + c.errout) if c else 0,
            "drops": (c.dropin + c.dropout) if c else 0,
        })
    routes = []
    for r in ipj("route", "show") + ipj("-6", "route", "show"):
        routes.append({"dst": r.get("dst", ""), "gateway": r.get("gateway", ""),
                       "dev": r.get("dev", ""), "metric": r.get("metric"),
                       "src": r.get("prefsrc", "")})
    return {"ts": time.time(), "interfaces": ifaces, "routes": routes, "dns": dns_info()}


@router.get("/connections")
def connections(user: str = Depends(current_user)):
    out = must(run("connections")).stdout
    rows = []
    for line in out.splitlines():
        p = line.split(None, 6)
        if len(p) < 6:
            continue
        procs = ", ".join(f"{n} ({pid})" for n, pid in PROC.findall(p[6])) if len(p) > 6 else ""
        rows.append({"proto": p[0], "state": p[1], "local": p[4], "peer": p[5], "process": procs})
        if len(rows) >= 1000:
            break
    return rows


@router.get("/config")
def config(user: str = Depends(current_user)):
    return json.loads(must(run("state")).stdout)


class ApplyBody(BaseModel):
    state: dict
    timeout: int = Field(default=90, ge=30, le=600)
    scope: Literal["network", "vpn"] = "network"


@router.post("/apply")
def apply(body: ApplyBody, request: Request, user: str = Depends(current_user)):
    if body.scope == "vpn" and isinstance(body.state.get("wireguard"), dict):
        # Quick VPN's interface belongs to Quick VPN. A draft in the advanced editor may be older than its last
        # change (it could bring back a device that was just removed), so what the draft says about it is ignored.
        incoming = body.state["wireguard"]
        current = json.loads(must(run("state")).stdout)["state"].get("wireguard", {}).get("adminvpn")
        if current is None and "adminvpn" in incoming:
            raise HTTPException(400, "The name adminvpn is reserved for Quick VPN. Choose another name, such as wg0.")
        if current is not None:
            incoming["adminvpn"] = current
    payload = {"state": body.state, "timeout": body.timeout, "scope": body.scope,
               "admin_ip": request.client.host}
    r = run("apply", stdin=json.dumps(payload), timeout=100)
    items = body.state.get("items" if body.scope == "network" else "wireguard")
    names = sorted(items)[:64] if isinstance(items, dict) else []
    audit(user, request.client.host, "net_apply", scope=body.scope, items=names,
          timeout=body.timeout, ok=(r.returncode == 0))
    must(r)
    return json.loads(r.stdout)


@router.post("/confirm")
def confirm(request: Request, user: str = Depends(current_user)):
    r = run("confirm")
    audit(user, request.client.host, "net_confirm", ok=(r.returncode == 0))
    must(r)
    return {"ok": True}


@router.post("/revert")
def revert(request: Request, user: str = Depends(current_user)):
    r = run("revert")
    audit(user, request.client.host, "net_revert", ok=(r.returncode == 0))
    must(r)
    return {"ok": True}


# ---------------- WireGuard ----------------

@router.get("/wg/status")
def wg_status(user: str = Depends(current_user)):
    return json.loads(must(run("wg-status")).stdout)


class KeyBody(BaseModel):
    op: Literal["generate", "import-private", "import-psk"]
    name: str = Field(pattern=r"^[a-z][a-z0-9_.-]{0,14}$")
    value: str = Field(default="", max_length=128)


@router.post("/wg/key")
def wg_key(body: KeyBody, request: Request, user: str = Depends(current_user)):
    r = run("wg-key", stdin=json.dumps(body.model_dump()))
    # never log the key itself
    audit(user, request.client.host, "wg_key", op=body.op, name=body.name, ok=(r.returncode == 0))
    must(r)
    return json.loads(r.stdout)


# ---------------- proxy ----------------

class ProxyBody(BaseModel):
    enabled: bool
    http: str = Field(default="", max_length=300)
    https: str = Field(default="", max_length=300)
    no_proxy: list[str] = Field(default_factory=list, max_length=40)
    apt: bool = True
    environment: bool = True


@router.get("/proxy")
def proxy_get(user: str = Depends(current_user)):
    return json.loads(must(run("proxy-get")).stdout)


@router.post("/proxy")
def proxy_set(body: ProxyBody, request: Request, user: str = Depends(current_user)):
    r = run("proxy-set", stdin=json.dumps(body.model_dump()))
    audit(user, request.client.host, "proxy_set", enabled=body.enabled, http=body.http,
          https=body.https, apt=body.apt, environment=body.environment, ok=(r.returncode == 0))
    must(r)
    return {"ok": True}


class ProxyTest(BaseModel):
    url: str = Field(max_length=300)


@router.post("/proxy/test")
def proxy_test(body: ProxyTest, user: str = Depends(current_user)):
    url = body.url.strip().rstrip("/")
    m = PROXY_RE.fullmatch(url)
    if not m or len(m["host"]) > 253 or (m["port"] and not 1 <= int(m["port"]) <= 65535):
        raise HTTPException(400, "A proxy address looks like http://host:3128 (no user name or password)")
    results = []
    for label, target in (("HTTP", "http://connectivity-check.ubuntu.com/"),
                          ("HTTPS", "https://archive.ubuntu.com/")):
        try:
            r = subprocess.run(["/usr/bin/curl", "-sS", "-o", "/dev/null", "-w", "%{http_code}",
                                "--max-time", "10", "-x", url, target],
                               capture_output=True, text=True, timeout=20, env=ENV,
                               stdin=subprocess.DEVNULL)
            code = r.stdout.strip()
            good = r.returncode == 0 and code.isdigit() and 200 <= int(code) < 400
            results.append({"target": label, "ok": good, "code": code, "error": (r.stderr or "").strip()[:200]})
        except subprocess.TimeoutExpired:
            results.append({"target": label, "ok": False, "code": "", "error": "timed out"})
    return {"results": results}


# ---------------- peer config generator ----------------

from fastapi.responses import JSONResponse


class PeerBody(BaseModel):
    name: str = Field(pattern=r"^[a-z][a-z0-9_.-]{0,14}$")
    key_id: str = Field(pattern=r"^[0-9a-f]{8}$")
    address: str = Field(max_length=64)
    allowed: list[str] = Field(min_length=1, max_length=16)
    dns: list[str] = Field(default_factory=list, max_length=4)
    endpoint: str = Field(max_length=300)
    keepalive: int | None = Field(default=25, ge=0, le=65535)
    psk: bool = True


def qr_rows(text):
    try:
        import qrcode
        qr = qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_L, border=0)
        qr.add_data(text)
        qr.make(fit=True)
        return ["".join("1" if c else "0" for c in row) for row in qr.get_matrix()]
    except Exception:
        return None


@router.post("/wg/peer")
def wg_peer(body: PeerBody, request: Request, user: str = Depends(current_user)):
    r = run("wg-peer", stdin=json.dumps(body.model_dump()))
    # never log the config: it contains the device's private key
    audit(user, request.client.host, "wg_peer_generated", name=body.name,
          address=body.address, ok=(r.returncode == 0))
    must(r)
    d = json.loads(r.stdout)
    d["qr"] = qr_rows(d["conf"])
    return JSONResponse(d, headers={"Cache-Control": "no-store"})


# ---------------- quick VPN: one hub, devices, and servers that join ----------------
# The simple way to use WireGuard. One interface (adminvpn) with its own private /24:
#   .1 the hub (the server where the VPN was turned on), .2-.127 devices, .128/25 servers that joined it.
# Devices import a config by scanning a code. A server joins with a one-time join code made on the hub; the hub
# then relays: devices reach the servers, servers reach the whole VPN, devices never reach each other, and
# nothing in the VPN reaches anything beyond it (see render_isolation in the helper).
# Built from the same helper commands as the advanced editor (wg-key, wg-peer, apply, confirm).

import base64
import binascii
import copy
import ipaddress
import threading

import firewall as fw
from paneladmin import Step, step_up, my_role

EASY_IFACE = "adminvpn"
EASY_TIMEOUT = 120              # seconds the browser has to confirm a change before it undoes itself
EASY_PORT = 51820
EASY_DEVICES = 120              # .2-.127 of the VPN's /24
EASY_SERVERS = 120              # .129-.254
EASY_SUBNETS = [f"10.{n}.0.0/24" for n in range(77, 100)]
LABEL_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9 ._-]{0,39}")
KEY_RE = re.compile(r"[A-Za-z0-9+/]{43}=")
JOIN_PREFIX = "apvpn1."
WAITING = "A network change is waiting to be kept or reverted. Deal with that first."
_easy_lock = threading.Lock()


def net_state():
    return json.loads(must(run("state")).stdout)


def kernel_has_wg():
    """True when the WireGuard module is loaded, otherwise None (unknown). The panel's service runs with
    ProtectKernelModules=yes, so it cannot look into /lib/modules: an Ubuntu kernel has WireGuard as a module that
    only loads when the first WireGuard interface is made. If it really is missing, turning the VPN on says so."""
    return True if Path("/sys/module/wireguard").exists() else None


def used_networks(st):
    nets = []
    for link in ipj("addr", "show"):
        for a in link.get("addr_info", []):
            try:
                nets.append(ipaddress.ip_interface(f'{a["local"]}/{a["prefixlen"]}').network)
            except (KeyError, ValueError):
                pass
    for r in ipj("route", "show"):
        dst = r.get("dst")
        if dst and dst != "default":
            try:
                nets.append(ipaddress.ip_network(dst, strict=False))
            except ValueError:
                pass
    for it in st["state"].get("items", {}).values():
        for a in it.get("addresses", []) or []:
            try:
                nets.append(ipaddress.ip_interface(a).network)
            except ValueError:
                pass
    for it in st["state"].get("wireguard", {}).values():
        for a in it.get("addresses", []) or []:
            try:
                nets.append(ipaddress.ip_interface(a).network)
            except ValueError:
                pass
        for p in it.get("peers", []):
            for a in p.get("allowed_ips", []) or []:
                try:
                    nets.append(ipaddress.ip_network(a, strict=False))
                except ValueError:
                    pass
    return nets


def pick_subnet(st):
    used = used_networks(st)
    for s in EASY_SUBNETS:
        n = ipaddress.ip_network(s)
        if not any(n.version == u.version and n.overlaps(u) for u in used):
            return n
    raise HTTPException(400, "No free private network was found for the VPN: 10.77.0.0/24 to 10.99.0.0/24 are all in use here")


def halves(net):
    """The VPN's /24: .1 the hub, .2-.127 devices, .129-.254 servers (the /25 from .128)."""
    base = int(net.network_address)
    devices = [ipaddress.ip_address(base + i) for i in range(2, 128)]
    servers = [ipaddress.ip_address(base + i) for i in range(129, 255)]
    return devices, servers, ipaddress.ip_network(f"{ipaddress.ip_address(base + 128)}/25")


def peer_addr(p):
    return (p.get("allowed_ips") or [""])[0].split("/")[0]


def is_server_addr(addr, net):
    try:
        return int(ipaddress.ip_address(addr)) - int(net.network_address) >= 128
    except ValueError:
        return False


def role_of(it):
    return it.get("quick") or "hub"         # a VPN made by 6.37 is a hub


def apply_change(wg, request):
    """Apply a new list of VPN interfaces with the panel's usual safety net: the change undoes itself after
    EASY_TIMEOUT seconds unless the browser confirms it (POST /api/network/confirm), which proves the browser can
    still reach the panel. Everything the helper checks for the advanced editor is checked here too."""
    payload = {"state": {"wireguard": wg}, "timeout": EASY_TIMEOUT, "scope": "vpn", "admin_ip": request.client.host}
    r = must(run("apply", stdin=json.dumps(payload), timeout=100))
    try:
        warnings = json.loads(r.stdout).get("warnings") or []
    except (ValueError, AttributeError):
        warnings = []
    return {"pending": True, "seconds": EASY_TIMEOUT, "warnings": warnings}


def fw_allow(port, proto, source=None):
    try:
        r = fw.run("allow", str(port), proto, *([source] if source else []))
        return "ok" if r.returncode == 0 else ((r.stderr or r.stdout).strip() or "failed")
    except Exception as e:
        return str(e)[:200]


def fw_delete(port, proto, source=None):
    try:
        r = fw.run("delete", str(port), proto, *([source] if source else []))
        return "ok" if r.returncode == 0 else ((r.stderr or r.stdout).strip() or "failed")
    except Exception as e:
        return str(e)[:200]


def firewall_view(port, subnet, panel_port):
    try:
        ov = fw.overview("panel")
        rules = ov["rules"]
        return {"active": ov["active"],
                "udp_open": bool(port) and any(r["port"] == port and r["proto"] == "udp" and not r["source"] for r in rules),
                "panel_open": bool(panel_port) and any(r["port"] == panel_port and r["proto"] == "tcp"
                                                      and r["source"] == str(subnet) for r in rules),
                "relay_rule": any(f"route allow in on {EASY_IFACE} out on {EASY_IFACE}" in (r.get("raw") or "") for r in rules)}
    except Exception:
        return None


import store as _store
WANTED = _store.PersistentDict("vpn_only")    # "on" once "Allow only the VPN" was kept here; cleared by Open to everyone again (6.44.0)


def vpnonly_wanted():
    try:
        return WANTED.get("on") is True
    except Exception:
        return False


def vpnonly_view(net):
    """Is the panel's port open to the VPN only (6.42.0)? None when the firewall cannot be read."""
    try:
        r = fw.run("vpnonly-status", str(net))
        if r.returncode != 0:
            return None
        s = json.loads(r.stdout)
        return {"on": bool(s.get("vpn_rule")) and not s.get("outside"), "pending": bool(s.get("pending")),
                "outside": [str(x)[:200] for x in (s.get("outside") or [])][:20], "port": s.get("port"),
                "closed_by_default": bool(s.get("closed_by_default")), "wanted": vpnonly_wanted()}
    except Exception:
        return None


def forwarding_on():
    try:
        return Path(f"/proc/sys/net/ipv4/conf/{EASY_IFACE}/forwarding").read_text().strip() == "1"
    except OSError:
        return None                         # the tunnel is not running


def rules_view(it):
    """Are the VPN's routing rules really in the kernel? None when they cannot be read. They can be missing after an
    upgrade from 6.37 (its files lack the newer rules until the next change) or if something flushed them."""
    rules = ipj("rule", "show")
    if not rules:
        return None
    prios = {r.get("priority") for r in rules if isinstance(r, dict)}
    need = {74, 77, 78} | ({76} if it.get("relay") else set())
    return need <= prios


def signin_view(subnet):
    try:
        import ipallow
        cfg = ipallow.load()
        covered = any(n.version == subnet.version and subnet.subnet_of(n) for n in cfg["nets"])
        return {"enabled": bool(cfg["enabled"]), "covered": covered or not cfg["enabled"]}
    except Exception:
        return None


def easy_view(request, user, panel_port=None):
    d = net_state()
    it = d["state"].get("wireguard", {}).get(EASY_IFACE)
    out = {"available": bool(d["wg"]["available"]), "kernel": kernel_has_wg(), "pending": d.get("pending"),
           "enabled": it is not None, "name": EASY_IFACE, "host": request.url.hostname or "",
           "your_ip": request.client.host, "max_devices": EASY_DEVICES, "max_servers": EASY_SERVERS}
    if it is None:
        return out
    ai = ipaddress.ip_interface(it["addresses"][0])
    net = ai.network
    live = json.loads(must(run("wg-status")).stdout)
    iface = next((i for i in live.get("interfaces", []) if i["name"] == EASY_IFACE), None)
    peers = {p["public_key"]: p for p in (iface or {}).get("peers", [])}
    now = live.get("now", int(time.time()))
    views = []
    for p in it.get("peers", []):
        lp = peers.get(p["public_key"], {})
        hs = lp.get("latest_handshake", 0)
        addr = peer_addr(p)
        views.append({"label": p.get("label") or "device", "public_key": p["public_key"], "address": addr,
                      "handshake_ago": (now - hs) if hs else None, "online": bool(hs) and now - hs < 180,
                      "rx": lp.get("rx", 0), "tx": lp.get("tx", 0), "you": addr == request.client.host})
    role = role_of(it)
    try:
        via = ipaddress.ip_address(request.client.host) in net
    except ValueError:
        via = False
    port = it.get("listen_port") or (EASY_PORT if role == "hub" else None)
    out.update(role=role, address=str(ai.ip), subnet=str(net), port=port,
               public_key=d["wg"]["public"].get(it.get("key_id"), ""), up=iface is not None, via_vpn=via,
               firewall=firewall_view(port, net, panel_port), isolated=bool(it.get("isolate")),
               rules_ok=rules_view(it) if it.get("isolate") else None,
               relay=bool(it.get("relay")), forwarding=forwarding_on() if it.get("relay") else None,
               # the sign-in address list is an administrator-only setting, so only they learn about it here
               signin=signin_view(net) if my_role(user) == "admin" else None,
               vpn_only=vpnonly_view(net))
    if role == "member":
        hub = it.get("peers", [{}])[0] if it.get("peers") else {}
        hv = views[0] if views else {"online": False, "handshake_ago": None}
        out.update(devices=[], servers=[], hub={"endpoint": hub.get("endpoint", ""), "online": hv["online"],
                                                "handshake_ago": hv["handshake_ago"]})
    else:
        out.update(devices=[v for v in views if not is_server_addr(v["address"], net)],
                   servers=[v for v in views if is_server_addr(v["address"], net)], hub=None)
    return out


@router.get("/vpn/easy")
def easy_status(request: Request, panel_port: int | None = None, user: str = Depends(current_user)):
    return JSONResponse(easy_view(request, user, panel_port), headers={"Cache-Control": "no-store"})


class EasyEnable(Step):
    port: int = Field(default=EASY_PORT, ge=1024, le=65535)
    panel_port: int | None = Field(default=None, ge=1, le=65535)


@router.post("/vpn/easy/enable")
def easy_enable(body: EasyEnable, request: Request, user: str = Depends(current_user)):
    step_up(request, user, body)            # opening a way into the server: prove it is really you, as pairing a phone does
    with _easy_lock:
        d = net_state()
        if not d["wg"]["available"]:
            raise HTTPException(400, "WireGuard is not installed. Run: sudo apt install -y wireguard-tools")
        if d.get("pending"):
            raise HTTPException(400, WAITING)
        wg = copy.deepcopy(d["state"].get("wireguard", {}))
        if EASY_IFACE in wg:
            raise HTTPException(400, "The VPN is already on")
        subnet = pick_subnet(d)
        r = run("wg-key", stdin=json.dumps({"op": "generate", "name": EASY_IFACE}))
        audit(user, request.client.host, "wg_key", op="generate", name=EASY_IFACE, ok=(r.returncode == 0))
        key = json.loads(must(r).stdout)
        wg[EASY_IFACE] = {"key_id": key["id"], "listen_port": body.port, "isolate": True, "quick": "hub",
                          "addresses": [f"{subnet[1]}/{subnet.prefixlen}"], "dns": [], "mtu": None, "peers": []}
        ok = False
        try:
            pend = apply_change(wg, request)
            ok = True
        finally:
            audit(user, request.client.host, "vpn_easy_enable", port=body.port, subnet=str(subnet), ok=ok)
    result = {"udp": fw_allow(body.port, "udp")}
    if body.panel_port:
        result["panel"] = fw_allow(body.panel_port, "tcp", str(subnet))
    return {"ok": True, "subnet": str(subnet), "address": str(subnet[1]), "firewall": result, **pend}


class EasyDevice(Step):
    label: str = Field(min_length=1, max_length=40)
    endpoint: str = Field(min_length=1, max_length=300)


class EasyServer(EasyDevice):
    pass


def with_port(endpoint, port):
    e = endpoint.strip()
    if re.fullmatch(r"\[[0-9A-Fa-f:]+\]:\d{1,5}", e) or re.fullmatch(r"[^:\[\]\s]+:\d{1,5}", e):
        return e
    if re.fullmatch(r"[0-9A-Fa-f:]*:[0-9A-Fa-f:]+", e) and e.count(":") >= 2:      # a bare IPv6 address
        return f"[{e.strip('[]')}]:{port}"
    return f"{e}:{port}"


def check_label(label):
    label = label.strip()
    if LABEL_RE.fullmatch(label) is None:
        raise HTTPException(400, "A name may use letters, digits, spaces and . _ - (40 characters at most), and must start with a letter or digit")
    return label


def new_peer(request, user, body, label, kind):
    """Shared by adding a device and adding a server: check, make the keys, add the peer, apply.
    Returns (address, the helper's answer with the config, the pending-change info)."""
    with _easy_lock:
        d = net_state()
        wg = copy.deepcopy(d["state"].get("wireguard", {}))
        it = wg.get(EASY_IFACE)
        if it is None:
            raise HTTPException(400, "Turn the VPN on first")
        if role_of(it) == "member":
            raise HTTPException(400, "This server has joined another server's VPN. Add devices and servers on that server.")
        if d.get("pending"):
            raise HTTPException(400, WAITING)
        peers = it.get("peers", [])
        net = ipaddress.ip_interface(it["addresses"][0]).network
        devices, servers, servers_net = halves(net)
        mine = [p for p in peers if is_server_addr(peer_addr(p), net) == (kind == "server")]
        limit = EASY_SERVERS if kind == "server" else EASY_DEVICES
        if len(mine) >= limit:
            raise HTTPException(400, f"This VPN is limited to {limit} {kind}s")
        if any((p.get("label") or "").lower() == label.lower() for p in peers):
            raise HTTPException(400, "A device or server with that name already exists")
        host = with_port(body.endpoint, 1).rsplit(":", 1)[0].strip("[]")
        try:
            inside = ipaddress.ip_address(host) in net
        except ValueError:
            inside = False                  # a name: it is looked up on the device
        if inside:
            raise HTTPException(400, f"{host} is this server's address inside the VPN. A {kind} uses the server's public "
                                     "address to connect, such as its public IP or a domain name pointing to it.")
        taken = {ipaddress.ip_interface(a).ip for p in peers for a in p.get("allowed_ips", []) if "/" in a}
        free = next((h for h in (servers if kind == "server" else devices) if h not in taken), None)
        if free is None:
            raise HTTPException(400, f"The VPN has no free {kind} addresses left")
        spec = {"name": EASY_IFACE, "key_id": it["key_id"], "address": f"{free}/32", "allowed": [str(net)],
                "dns": [], "endpoint": with_port(body.endpoint, it.get("listen_port") or EASY_PORT),
                "keepalive": 25, "psk": True}
        r = run("wg-peer", stdin=json.dumps(spec))
        event = f"vpn_easy_{kind}_added"
        # never log the config: it holds the new device's or server's private key
        if r.returncode != 0:
            audit(user, request.client.host, event, label=label, ok=False)
        made = json.loads(must(r).stdout)
        peers.append({"label": label, "public_key": made["public_key"], "psk_id": made["psk_id"], "endpoint": "",
                      "allowed_ips": [made["address"]], "keepalive": None})
        it["isolate"] = True                # VPNs made by 6.37.0 get the protection with their next change
        it["quick"] = "hub"
        if kind == "server":
            it["relay"] = {"servers": str(servers_net)}
        ok = False
        try:
            pend = apply_change(wg, request)
            ok = True
        finally:
            audit(user, request.client.host, event, label=label, address=str(free), ok=ok)
    return free, net, made, pend


@router.post("/vpn/easy/device")
def easy_add_device(body: EasyDevice, request: Request, user: str = Depends(current_user)):
    label = check_label(body.label)
    step_up(request, user, body)            # a new device is a new way into the server
    free, net, made, pend = new_peer(request, user, body, label, "device")
    return JSONResponse({"label": label, "address": str(free), "conf": made["conf"], "qr": qr_rows(made["conf"]), **pend},
                        headers={"Cache-Control": "no-store"})


def make_join(conf, address, net):
    """A join code: the new server's config in one line, for the other panel's "Join a VPN". It holds a private
    key, so like a device's QR code it is shown once and never stored."""
    get = lambda k: re.search(rf"^{k} = (\S+)$", conf, re.M)[1]
    data = {"v": 1, "e": get("Endpoint"), "k": get("PublicKey"), "p": get("PresharedKey"), "s": get("PrivateKey"),
            "a": f"{address}/{net.prefixlen}", "n": str(net)}
    raw = json.dumps(data, separators=(",", ":")).encode()
    return JOIN_PREFIX + base64.urlsafe_b64encode(raw).decode().rstrip("=")


CONF_HOOKS = {"preup", "postup", "predown", "postdown"}


def read_conf(text):
    """A server's WireGuard config, the file "Add a server" offers to download, used instead of the join code.
    Only what a join code carries is taken from it (the server's private key and address, the hub's public key,
    preshared key and endpoint, the VPN network); DNS, MTU and keepalive lines are ignored, and nothing in it is ever
    run. It is checked by the same rules as a join code."""
    def bad(why):
        return HTTPException(400, "This WireGuard config cannot be used to join: " + why)
    sec, iface, peers = None, {}, []
    for raw in str(text).splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        if line.startswith("[") and line.endswith("]"):
            sec = line[1:-1].strip().lower()
            if sec == "peer":
                peers.append({})
            elif sec != "interface":
                raise bad(f"it has an unknown section {line[:40]}.")
            continue
        k, eq, v = line.partition("=")
        k, v = k.strip().lower(), v.strip()
        if not eq or sec is None:
            raise bad("a line is not \"Name = value\" inside [Interface] or [Peer].")
        if k in CONF_HOOKS:
            raise bad(f"it runs commands ({k}). Use the file made by Add a server, which has none.")
        (iface if sec == "interface" else peers[-1]).setdefault(k, v)
    if len(peers) != 1:
        raise bad(f"it must have exactly one [Peer], the server that runs the VPN (it has {len(peers)}).")
    peer = peers[0]
    for name, where, key in (("PrivateKey", iface, "privatekey"), ("PublicKey", peer, "publickey"), ("PresharedKey", peer, "presharedkey")):
        if KEY_RE.fullmatch(where.get(key, "")) is None:
            raise bad(f"{name} is missing or not a WireGuard key.")
    e = peer.get("endpoint", "")
    if not 3 <= len(e) <= 300 or any(c.isspace() for c in e):
        raise bad("Endpoint (the address of the server that runs the VPN) is missing.")
    addrs = [x.strip() for x in iface.get("address", "").split(",") if x.strip()]
    try:
        ips = [ipaddress.ip_interface(x) for x in addrs]
        allowed = [ipaddress.ip_network(x.strip(), strict=False) for x in peer.get("allowedips", "").split(",") if x.strip()]
    except ValueError:
        raise bad("Address or AllowedIPs is not a valid address.")
    v4 = [i for i in ips if i.version == 4]
    if len(v4) != 1:
        raise bad("it must have exactly one IPv4 Address.")
    ip = v4[0].ip
    if any(n.prefixlen == 0 for n in allowed):
        raise bad("it sends all traffic through the VPN (AllowedIPs 0.0.0.0/0). A joined server only carries the VPN's own network.")
    n = next((n for n in allowed if n.version == 4 and n.prefixlen == 24 and ip in n), None)
    if n is None:
        raise bad("AllowedIPs must include the VPN's network, a /24 that holds this server's Address.")
    data = {"v": 1, "e": e, "k": peer["publickey"], "p": peer["presharedkey"], "s": iface["privatekey"], "a": f"{ip}/24", "n": str(n)}
    return read_join(JOIN_PREFIX + base64.urlsafe_b64encode(json.dumps(data).encode()).decode())


def read_join(text):
    """A join code, or (since 6.40.0) the server's WireGuard config file instead."""
    if "[interface]" in str(text).lower():
        return read_conf(text)
    bad = HTTPException(400, "The join code is damaged or incomplete. Copy it again, all of it.")
    t = "".join(str(text).split())         # copying can add line breaks and spaces
    if not t.startswith(JOIN_PREFIX):
        raise HTTPException(400, "That is not a join code. A join code starts with " + JOIN_PREFIX)
    body = t[len(JOIN_PREFIX):]
    try:
        data = json.loads(base64.urlsafe_b64decode(body + "=" * (-len(body) % 4)).decode())
    except (ValueError, binascii.Error, UnicodeDecodeError):
        raise bad
    if not isinstance(data, dict) or data.get("v") != 1:
        raise bad
    for k in ("k", "p", "s"):
        if not isinstance(data.get(k), str) or KEY_RE.fullmatch(data[k]) is None:
            raise bad
    e = data.get("e")
    if not isinstance(e, str) or not 3 <= len(e) <= 300 or any(c.isspace() for c in e):
        raise bad
    try:
        a = ipaddress.ip_interface(data.get("a"))
        n = ipaddress.ip_network(data.get("n"))
    except (ValueError, TypeError):
        raise bad
    if (n.version != 4 or n.prefixlen != 24 or not n.is_private or a.network != n
            or a.ip in (n.network_address, n.broadcast_address, n.network_address + 1)):
        raise bad
    host = e.rsplit(":", 1)[0].strip("[]") if ":" in e else e
    try:
        inside = ipaddress.ip_address(host) in n
    except ValueError:
        inside = False
    if inside:
        raise HTTPException(400, f"The address of the server that runs the VPN is {host}, an address inside the VPN itself, so this "
                                 "server could never reach it. Make a new code or config on that server with its public IP or name.")
    return {"e": e, "k": data["k"], "p": data["p"], "s": data["s"], "a": str(a), "n": str(n)}


@router.post("/vpn/easy/server")
def easy_add_server(body: EasyServer, request: Request, user: str = Depends(current_user)):
    label = check_label(body.label)
    step_up(request, user, body)            # a joined server can reach the whole VPN
    free, net, made, pend = new_peer(request, user, body, label, "server")
    return JSONResponse({"label": label, "address": str(free), "join": make_join(made["conf"], free, net),
                         "conf": made["conf"], **pend}, headers={"Cache-Control": "no-store"})


class EasyJoin(Step):
    join: str = Field(min_length=10, max_length=4000)     # a join code, or the server's WireGuard config
    panel_port: int | None = Field(default=None, ge=1, le=65535)


@router.post("/vpn/easy/join")
def easy_join(body: EasyJoin, request: Request, user: str = Depends(current_user)):
    data = read_join(body.join)
    step_up(request, user, body)            # joining links this server into another network
    with _easy_lock:
        d = net_state()
        if not d["wg"]["available"]:
            raise HTTPException(400, "WireGuard is not installed. Run: sudo apt install -y wireguard-tools")
        if d.get("pending"):
            raise HTTPException(400, WAITING)
        wg = copy.deepcopy(d["state"].get("wireguard", {}))
        if EASY_IFACE in wg:
            raise HTTPException(400, "This server already has a Quick VPN. Turn it off before joining another one.")
        net = ipaddress.ip_network(data["n"])
        clash = next((u for u in used_networks(d) if u.version == 4 and u.overlaps(net)), None)
        if clash is not None:
            raise HTTPException(400, f"This server already uses {clash}, which overlaps the VPN's {net}, so it cannot join.")
        r = run("wg-key", stdin=json.dumps({"op": "import-private", "name": EASY_IFACE, "value": data["s"]}))
        audit(user, request.client.host, "wg_key", op="import-private", name=EASY_IFACE, ok=(r.returncode == 0))
        key = json.loads(must(r).stdout)
        r = run("wg-key", stdin=json.dumps({"op": "import-psk", "name": EASY_IFACE, "value": data["p"]}))
        audit(user, request.client.host, "wg_key", op="import-psk", name=EASY_IFACE, ok=(r.returncode == 0))
        psk = json.loads(must(r).stdout)
        wg[EASY_IFACE] = {"key_id": key["id"], "listen_port": None, "addresses": [data["a"]], "dns": [], "mtu": None,
                          "isolate": True, "quick": "member",
                          "peers": [{"label": "hub", "public_key": data["k"], "psk_id": psk["id"], "endpoint": data["e"],
                                     "allowed_ips": [data["n"]], "keepalive": 25}]}
        ok = False
        try:
            pend = apply_change(wg, request)
            ok = True
        finally:
            audit(user, request.client.host, "vpn_easy_join", hub=data["e"], address=data["a"],
                  source="config" if "[interface]" in body.join.lower() else "code", ok=ok)
    result = {}
    if body.panel_port:
        result["panel"] = fw_allow(body.panel_port, "tcp", data["n"])
    return {"ok": True, "address": data["a"].split("/")[0], "subnet": data["n"], "endpoint": data["e"], "firewall": result, **pend}


class EasyRevoke(BaseModel):
    public_key: str = Field(min_length=44, max_length=44)


@router.post("/vpn/easy/revoke")
def easy_revoke(body: EasyRevoke, request: Request, user: str = Depends(current_user)):
    with _easy_lock:
        d = net_state()
        wg = copy.deepcopy(d["state"].get("wireguard", {}))
        it = wg.get(EASY_IFACE)
        if it is None:
            raise HTTPException(400, "The VPN is off")
        if role_of(it) == "member":
            raise HTTPException(400, "This server has joined another server's VPN. To leave it, use Leave the VPN.")
        if d.get("pending"):
            raise HTTPException(400, WAITING)
        gone = next((p for p in it.get("peers", []) if p["public_key"] == body.public_key), None)
        if gone is None:
            raise HTTPException(404, "That device or server is not in the list (it may already have been removed)")
        addr = peer_addr(gone)
        if addr and addr == request.client.host:
            raise HTTPException(400, "This is the device you are using right now. Remove it from a connection outside the VPN, so you don't cut yourself off.")
        it["peers"] = [p for p in it["peers"] if p["public_key"] != body.public_key]
        it["isolate"] = True
        net = ipaddress.ip_interface(it["addresses"][0]).network
        if it.get("relay") and not any(is_server_addr(peer_addr(p), net) for p in it["peers"]):
            it["relay"] = None              # the last server left: nothing to relay, forwarding goes off again
        ok = False
        try:
            pend = apply_change(wg, request)
            ok = True
        finally:
            audit(user, request.client.host, "vpn_easy_device_removed", label=gone.get("label", ""), address=addr, ok=ok)
    return {"ok": True, **pend}


class EasyDisable(BaseModel):
    panel_port: int | None = Field(default=None, ge=1, le=65535)


@router.post("/vpn/easy/disable")
def easy_disable(body: EasyDisable, request: Request, user: str = Depends(current_user)):
    with _easy_lock:
        d = net_state()
        wg = copy.deepcopy(d["state"].get("wireguard", {}))
        it = wg.get(EASY_IFACE)
        if it is None:
            raise HTTPException(400, "The VPN is already off")
        if d.get("pending"):
            raise HTTPException(400, WAITING)
        ai = ipaddress.ip_interface(it["addresses"][0])
        try:
            on_vpn = ipaddress.ip_address(request.client.host) in ai.network
        except ValueError:
            on_vpn = False
        if on_vpn:
            raise HTTPException(400, "You are connected through the VPN right now. Turn it off from a connection outside it, so you don't cut yourself off.")
        role = role_of(it)
        port = it.get("listen_port") or EASY_PORT
        del wg[EASY_IFACE]
        ok = False
        try:
            pend = apply_change(wg, request)
            ok = True
        finally:
            audit(user, request.client.host, "vpn_easy_disable", role=role, port=port, ok=ok)
    result = {}
    if role == "hub":                       # a server that joined never opened a UDP port
        result["udp"] = fw_delete(port, "udp")
    if body.panel_port:
        result["panel"] = fw_delete(body.panel_port, "tcp", str(ai.network))
    return {"ok": True, "firewall": result, **pend}


class EasyVpnOnly(Step):
    on: bool


def _vpn_here(request, need_via=True):
    """The Quick VPN's network, refusing unless it is running (and, when asked, unless this request came through it)."""
    d = net_state()
    it = d["state"].get("wireguard", {}).get(EASY_IFACE)
    if it is None:
        raise HTTPException(400, "Quick VPN is off on this server.")
    net = ipaddress.ip_interface(it["addresses"][0]).network
    if need_via:
        try:
            via = ipaddress.ip_address(request.client.host) in net
        except ValueError:
            via = False
        if not via:
            raise HTTPException(400, f"Open this page through the VPN first (from a device on the VPN, at this server's address in {net}). "
                                     "That proves you can still reach the panel once it is open to the VPN only.")
    return net


@router.post("/vpn/easy/vpnonly")
def easy_vpnonly(body: EasyVpnOnly, request: Request, user: str = Depends(current_user)):
    """Open the panel's port to the VPN only, or to everyone again. Closing it is undone after 2 minutes unless this
    browser, through the VPN, says to keep it; reopening is immediate."""
    step_up(request, user, body)            # who may reach the panel at all: prove it is really you
    with _easy_lock:
        net = _vpn_here(request, need_via=body.on)
        r = fw.run("vpnonly-on", str(net)) if body.on else fw.run("vpnonly-off")
        ok = r.returncode == 0
        audit(user, request.client.host, "vpn_only_on" if body.on else "vpn_only_off", network=str(net), ok=ok,
              removed=len(json.loads(r.stdout).get("removed") or []) if ok and body.on else None)
        if not ok:
            raise HTTPException(400, (r.stderr or r.stdout).strip()[:500] or "The firewall could not be changed.")
        out = json.loads(r.stdout)
        if not body.on:
            WANTED["on"] = False                 # opened on purpose: no "open to everyone again" alert
        elif not out.get("changed"):
            WANTED["on"] = True                  # it already was VPN-only: nothing to keep, but it is what is wanted
    return {"ok": True, **out, "waiting": bool(body.on and out.get("changed"))}      # not "pending": that word means a network change to keep


@router.post("/vpn/easy/vpnonly/keep")
def easy_vpnonly_keep(request: Request, user: str = Depends(current_user)):
    """Keep the VPN-only change. Only a request through the VPN may keep it: that is the proof the panel can still be reached."""
    with _easy_lock:
        net = _vpn_here(request)
        r = fw.run("vpnonly-keep", str(net))
        audit(user, request.client.host, "vpn_only_keep", network=str(net), ok=(r.returncode == 0))
        if r.returncode != 0:
            raise HTTPException(400, (r.stderr or r.stdout).strip()[:500] or "Could not keep the change.")
        WANTED["on"] = True
    return {"ok": True, **json.loads(r.stdout)}


@router.post("/vpn/easy/protect")
def easy_protect(request: Request, user: str = Depends(current_user)):
    """Give a VPN made by 6.37.0 its protection, and repair a relay whose forwarding or firewall rule went missing
    (for example after other software switched forwarding off for the whole server). Re-applies the settings."""
    with _easy_lock:
        d = net_state()
        wg = copy.deepcopy(d["state"].get("wireguard", {}))
        it = wg.get(EASY_IFACE)
        if it is None:
            raise HTTPException(400, "The VPN is off")
        if d.get("pending"):
            raise HTTPException(400, WAITING)
        net = ipaddress.ip_interface(it["addresses"][0]).network
        fwv = firewall_view(None, net, None) if it.get("relay") else None
        relay_ok = not it.get("relay") or (forwarding_on() is not False
                                           and not (fwv and fwv["active"] and not fwv["relay_rule"]))
        if it.get("isolate") and relay_ok and rules_view(it) is not False:
            return {"ok": True, "pending": False}
        it["isolate"] = True
        if role_of(it) == "hub" and any(is_server_addr(peer_addr(p), net) for p in it.get("peers", [])):
            it["relay"] = {"servers": str(halves(net)[2])}
        ok = False
        try:
            pend = apply_change(wg, request)
            ok = True
        finally:
            audit(user, request.client.host, "vpn_easy_protect", ok=ok)
    return {"ok": True, **pend}
