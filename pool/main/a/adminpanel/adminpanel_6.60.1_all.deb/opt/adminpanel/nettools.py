"""Network tools: ping, DNS lookup, TCP port check and trace route, run from this machine.

These run as the panel's own unprivileged account, so no root helper is involved. A host must be a plain host name or IP
address (nothing that could be read as an option), commands are started without a shell, each run has a time limit and
only one runs at a time. Every use is recorded in the audit log, because the panel can reach networks the browser cannot.
"""
import ipaddress, os, re, socket, subprocess, threading, time
from typing import Literal
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from auth import current_user
from audit import audit

router = APIRouter(prefix="/api/nettools")

PING = "/usr/bin/ping"
DIG = "/usr/bin/dig"
TRACEPATH = "/usr/bin/tracepath"
ENV = {"PATH": "/usr/bin:/bin", "LC_ALL": "C"}
LABEL = r"[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?"
HOST_RE = re.compile(r"^" + LABEL + r"(\." + LABEL + r")*\.?$")
CTRL = re.compile(r"[\x00-\x08\x0b-\x1f\x7f]")
OUT_CAP = 20000
RECORDS = ("A", "AAAA", "MX", "NS", "TXT", "CNAME", "SOA", "PTR")
busy = threading.Lock()


class Run(BaseModel):
    tool: Literal["ping", "dns", "port", "trace"]
    host: str = Field(min_length=1, max_length=253)
    record: Literal["A", "AAAA", "MX", "NS", "TXT", "CNAME", "SOA", "PTR"] = "A"
    port: int = Field(default=80, ge=1, le=65535)


def check_host(h):
    h = h.strip()
    if ":" in h or re.fullmatch(r"[0-9.]+", h):
        try:
            return str(ipaddress.ip_address(h))
        except ValueError:
            raise HTTPException(422, "That is not a valid IP address")
    if len(h) > 253 or not HOST_RE.match(h):
        raise HTTPException(422, "That is not a valid host name or IP address (letters, digits, dots and hyphens)")
    return h


def run(cmd, timeout):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, errors="replace", timeout=timeout, env=ENV,
                           stdin=subprocess.DEVNULL)
    except subprocess.TimeoutExpired as e:
        out = (e.stdout.decode("utf-8", "replace") if isinstance(e.stdout, bytes) else (e.stdout or ""))
        return (out + "\n(stopped after %d seconds)" % timeout)
    except OSError as e:
        raise HTTPException(400, "Could not run the command: " + CTRL.sub("", str(e))[:100])
    return (r.stdout or "") + (r.stderr or "")


def do_ping(host):
    if not os.path.exists(PING):
        raise HTTPException(400, "ping is not installed (package iputils-ping)")
    return run([PING, "-c", "4", "-W", "2", "-n", host], 20)


def do_trace(host):
    if not os.path.exists(TRACEPATH):
        raise HTTPException(400, "tracepath is not installed (package iputils-tracepath)")
    return run([TRACEPATH, "-n", "-m", "20", host], 60)


def do_dns(host, record):
    if os.path.exists(DIG):
        if record == "PTR":
            try:
                ipaddress.ip_address(host)
            except ValueError:
                raise HTTPException(422, "A PTR lookup needs an IP address")
            cmd = [DIG, "+short", "+time=3", "+tries=1", "-x", host]
        else:
            cmd = [DIG, "+short", "+time=3", "+tries=1", record, host]
        out = run(cmd, 15).strip()
        return out or "No %s records found." % record
    if record not in ("A", "AAAA"):
        raise HTTPException(400, "dig is not installed (package bind9-dnsutils), so only A and AAAA lookups work")
    fam = socket.AF_INET if record == "A" else socket.AF_INET6
    try:
        infos = socket.getaddrinfo(host, None, fam, socket.SOCK_STREAM)
    except socket.gaierror as e:
        return "No %s records found (%s)." % (record, CTRL.sub("", str(e))[:80])
    return "\n".join(sorted({i[4][0] for i in infos}))


def do_port(host, port):
    t = time.monotonic()
    try:
        with socket.create_connection((host, port), timeout=4):
            return "Port %d on %s is OPEN (connected in %d ms)." % (port, host, (time.monotonic() - t) * 1000)
    except socket.timeout:
        return "Port %d on %s did not answer within 4 seconds (filtered or the host is down)." % (port, host)
    except ConnectionRefusedError:
        return "Port %d on %s is CLOSED (connection refused)." % (port, host)
    except OSError as e:
        return "Could not connect to port %d on %s: %s" % (port, host, CTRL.sub("", str(e))[:100])


@router.post("")
def tool(body: Run, request: Request, user: str = Depends(current_user)):
    host = check_host(body.host)
    if not busy.acquire(blocking=False):
        raise HTTPException(429, "Another network tool is still running: wait for it to finish")
    try:
        if body.tool == "ping":
            out = do_ping(host)
        elif body.tool == "trace":
            out = do_trace(host)
        elif body.tool == "dns":
            out = do_dns(host, body.record)
        else:
            out = do_port(host, body.port)
    except HTTPException:
        audit(user, request.client.host, "nettools_" + body.tool, target=host, ok=False)
        raise
    finally:
        busy.release()
    audit(user, request.client.host, "nettools_" + body.tool, target=host, ok=True)
    return {"output": CTRL.sub("", out)[-OUT_CAP:].strip() or "(no output)"}
