"""Instant alerts on the phone (6.48.0): a wake-up through UnifiedPush, using the ntfy app the phone already has.

Without this, Android wakes the AdminPanel app about every 15 minutes (often later) to look for new alerts. With it,
the phone gives the panel a UnifiedPush address (an ntfy topic made by the ntfy app, such as https://ntfy.sh/upAbC...?up=1),
and the moment the panel records an event that phone should hear about, it sends a tiny wake-up there. The ntfy app
passes it to the AdminPanel app, which asks the panel what is new, exactly as its background check does, and shows it.

  * The wake-up holds no alert text, only {"v": 1, "seq": N}, the number of the newest event. The phone fetches the
    details itself over its pinned connection to the panel, so the push server never sees what went wrong.
  * The phone's own choices still apply: held alerts (maintenance) and alerts below its "Tell me about" level wake nothing.
  * The address must be on the push server set on the Alerts page (ntfy.sh by default) or on ntfy.sh, use https (http
    only when that push server is http), and have the shape of a UnifiedPush topic. So a phone cannot make the panel
    send requests anywhere else. Redirects are never followed; the Alerts page's ntfy access token is sent only to that server.
  * An address the push server says is gone (404, 410) is dropped and that phone falls back to the 15-minute check.
  * One wake-up per phone at most every few seconds; several events close together become one wake-up."""
import json, re, ssl, threading, time, urllib.error, urllib.request
from urllib.parse import urlsplit

PROVIDER = "unifiedpush"
TIMEOUT = 10
MIN_GAP = 3                     # seconds between two wake-ups for the same phone
SETTLE = 1.5                    # wait a moment so events written together go in one wake-up
PATH_RE = re.compile(r"/[A-Za-z0-9_-]{8,64}")
_poke = threading.Event()
_last = {}                      # owner -> time of the last wake-up sent
_stats = {"sent": 0, "failed": 0}


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


def _push_server():
    try:
        import chatalerts
        return urlsplit(chatalerts.get()["ntfy"]["server"] or "https://ntfy.sh")
    except Exception:
        return urlsplit("https://ntfy.sh")


def check_endpoint(url):
    """The cleaned address, or a ValueError saying what is wrong with it."""
    if not isinstance(url, str) or not 10 <= len(url) <= 300 or any(ch.isspace() for ch in url):
        raise ValueError("That is not a push address")
    u = urlsplit(url)
    srv = _push_server()
    host = (u.hostname or "").lower()
    allowed = {"ntfy.sh": ("https", None)}
    if srv.hostname:
        allowed[srv.hostname.lower()] = (srv.scheme, srv.port)
    if host not in allowed or u.username or u.password or u.fragment:
        raise ValueError("Push addresses are accepted only on " + " or ".join(sorted(allowed)) + " (the ntfy app's server)")
    scheme, port = allowed[host]
    if u.scheme != "https" and not (u.scheme == "http" and scheme == "http"):
        raise ValueError("The push address must use https")
    if u.port != port:
        raise ValueError("The push address uses another port than the push server")
    if not PATH_RE.fullmatch(u.path or ""):
        raise ValueError("That does not look like a UnifiedPush address from the ntfy app")
    if u.query not in ("", "up=1"):
        raise ValueError("That does not look like a UnifiedPush address from the ntfy app")
    return f"{u.scheme}://{u.netloc}{u.path}" + (f"?{u.query}" if u.query else "")


def poke():
    """Something was recorded: look soon whether a phone should be woken."""
    _poke.set()


def _send(url, seq):
    """POST the wake-up. Returns 'ok', 'gone' or 'retry'."""
    import chatalerts
    head = {"User-Agent": "AdminPanel", "Content-Type": "application/json"}
    srv = _push_server()
    token = chatalerts._token("ntfy") if (urlsplit(url).hostname or "").lower() == (srv.hostname or "").lower() else ""
    if token:
        head["Authorization"] = "Bearer " + token
    req = urllib.request.Request(url, data=json.dumps({"v": 1, "seq": seq}).encode(), method="POST", headers=head)
    opener = urllib.request.build_opener(_NoRedirect, urllib.request.HTTPSHandler(context=ssl.create_default_context()))
    try:
        with opener.open(req, timeout=TIMEOUT) as r:          # nosec B310: the address was checked by check_endpoint
            r.read(2000)
            return "ok" if 200 <= r.status < 300 else "retry"
    except urllib.error.HTTPError as e:
        return "gone" if e.code in (404, 410) else "retry"
    except (OSError, ValueError, ssl.SSLError):
        return "retry"


def deliver_once(now=None):
    """Wake every phone that has something new it wants to hear about. Returns how many were woken."""
    import mobileevents as E
    from audit import audit
    now = time.time() if now is None else now
    woke = 0
    for owner, endpoint, pushed, min_sev, types in E.q("SELECT owner, endpoint, COALESCE(push_seq, 0), min_severity, types FROM event_dev "
                                                       "WHERE provider=? AND endpoint IS NOT NULL", (PROVIDER,)):
        where, args = E.pref_where(min_sev, types)
        top = E.q("SELECT COALESCE(MAX(e.seq), 0) FROM events e WHERE e.seq > ? AND " + " AND ".join(where), [pushed] + args)[0][0]  # nosec B608: fixed pieces, values bound
        if not top:
            continue
        if now - _last.get(owner, 0) < MIN_GAP:
            _poke.set()                                     # too soon for this phone: look again shortly
            continue
        _last[owner] = now
        res = _send(endpoint, top)
        if res == "ok":
            E.q("UPDATE event_dev SET push_seq=? WHERE owner=?", (top, owner))
            _stats["sent"] += 1
            woke += 1
        elif res == "gone":
            E.q("UPDATE event_dev SET provider='poll', endpoint=NULL WHERE owner=?", (owner,))
            audit("system", "-", "notify_push_address_gone", phone=owner)
        else:
            _stats["failed"] += 1                           # left as it is: the next event or the minute check tries again
    return woke


def any_registered():
    import mobileevents as E
    try:
        return bool(E.q("SELECT 1 FROM event_dev WHERE provider=? AND endpoint IS NOT NULL LIMIT 1", (PROVIDER,)))
    except Exception:
        return False


def worker():
    while True:
        _poke.wait(60)                                      # also a minute check, so a failed wake-up is tried again
        _poke.clear()
        time.sleep(SETTLE)
        try:
            deliver_once()
        except Exception:
            pass


def start():
    threading.Thread(target=worker, name="mobile-wake", daemon=True).start()
