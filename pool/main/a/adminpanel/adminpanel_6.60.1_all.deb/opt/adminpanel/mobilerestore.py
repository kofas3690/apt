"""Browsing and restoring backup copies from the phone app: /api/mobile/v1/backups/{name}/files and friends
(docs/mobile-api-v1.md, section 22).

Restoring only ever copies files out of a copy into a protected "restored folder" on the server, which only root can open. It never
touches live files, and the phone cannot download what it restored: putting a file back is still done on the server's console.

  * Every call needs the capability `restore`: an administrator on a full phone, and only after an administrator turned
    "Let administrators restore from the phone" on in the web panel (Backups). Off by default.
  * The phone sends the name of a copy (a fixed pattern) and plain paths inside it. The root helper checks everything again.
  * Restoring and deleting a restored folder need an Idempotency-Key. One restore runs at a time (409 otherwise).
  * Every restore and delete is written to the audit log with the phone and the request ID."""
import json, re
import threading
from fastapi import Depends, HTTPException, Path, Query, Request
from pydantic import BaseModel, Field
import backup
from audit import audit
from auth import current_user
from mobileapi import router, reply, require, idempotent

NAME_RE = re.compile(backup.NAME)
STEM_RE = re.compile(r"^adminpanel-backup-\d{8}-\d{6}$")
MAX_PATHS = 50
_lock = threading.Lock()


def _who(request):
    ph = getattr(request.state, "phone", None)
    return {"via": "phone" if ph else "browser", "phone": ph["id"] if ph else None, "request_id": request.state.request_id}


def _json(*args, stdin=None, timeout=60):
    r = backup.must(backup.run(*args, stdin=stdin, timeout=timeout))
    try:
        return json.loads(r.stdout)
    except ValueError:
        raise HTTPException(502, "The backup helper returned something unexpected.")


def _name(name):
    if not NAME_RE.fullmatch(name):
        raise HTTPException(404, "No such backup copy.")
    return name


@router.get("/backups/{name}/files")
def files(request: Request, name: str = Path(max_length=64), q: str = Query("", max_length=200), user: str = Depends(current_user)):
    require(request, user, "restore")
    data = _json("contents", _name(name), stdin=q, timeout=300)
    return reply(request, {"name": name, "total": int(data.get("total", 0)), "matched": int(data.get("matched", 0)), "truncated": bool(data.get("truncated")),
                           "files": [{"name": str(x.get("name", ""))[:400], "size": int(x.get("size", 0)), "kind": str(x.get("kind", "f"))[:1]}
                                     for x in (data.get("shown") or [])[:1000]]})


class Pick(BaseModel):
    paths: list[str] = Field(default_factory=list, max_length=MAX_PATHS)      # empty means the whole copy


@router.post("/backups/{name}/restore")
def restore(body: Pick, request: Request, name: str = Path(max_length=64), user: str = Depends(current_user)):
    require(request, user, "restore")
    _name(name)
    paths = [p.strip() for p in body.paths if p.strip() and len(p) <= 500]
    payload = {"name": name, "paths": paths}

    def make():
        if not _lock.acquire(blocking=False):
            raise HTTPException(409, "Another restore is running. Try again in a moment.")
        try:
            r = backup.run("restore", name, stdin=json.dumps({"paths": paths}), timeout=3700)
        finally:
            _lock.release()
        audit(user, request.client.host, "backup_restore", target=name, ok=(r.returncode == 0), paths=len(paths), **_who(request))
        res = backup.must(r)
        try:
            d = json.loads(res.stdout)
        except ValueError:
            raise HTTPException(502, "The backup helper returned something unexpected.")
        folder = str(d.get("folder", "")).rsplit("/", 1)[-1]
        return 200, {"folder": folder, "restored": int(d.get("restored", 0)), "skipped": int(d.get("skipped", 0))}
    return idempotent(request, user, "backup_restore:" + name, payload, make)


@router.get("/restores")
def restores(request: Request, user: str = Depends(current_user)):
    require(request, user, "restore")
    d = _json("restores")
    return reply(request, {"restores": [{"name": str(x.get("name", "")), "files": int(x.get("files", 0)), "size": int(x.get("size", 0)), "t": int(x.get("t", 0))}
                                        for x in (d.get("restores") or []) if STEM_RE.fullmatch(str(x.get("name", "")))][:10],
                           "where": "the server's restored-folders area (root only)"})


@router.post("/restores/{folder}/delete")
def restore_delete(request: Request, folder: str = Path(max_length=64), user: str = Depends(current_user)):
    require(request, user, "restore")
    if not STEM_RE.fullmatch(folder):
        raise HTTPException(404, "No such restored folder.")

    def make():
        r = backup.run("restore-delete", folder, timeout=300)
        audit(user, request.client.host, "backup_restore_delete", target=folder, ok=(r.returncode == 0), **_who(request))
        backup.must(r)
        return 200, {"deleted": folder}
    return idempotent(request, user, "restore_delete:" + folder, {}, make)
