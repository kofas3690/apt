"""Maintenance windows for the phone app: /api/mobile/v1/maintenance (docs/mobile-api-v1.md, section 13).

A window is a planned period in which expected alerts are *held*: they are still recorded (and shown in the alert list
with a "held" label and in the history), but they do not raise the unread badge and are not delivered to a phone's
background check. Nothing is ever deleted or hidden. When a window ends, an alert that is still active is announced again.

  * Reading needs `view`. Starting, scheduling or ending a window needs the `maintenance` capability (admins, never a
    read-only phone), plus an Idempotency-Key. Every change is written to the audit log with the phone and request ID.
  * Windows last 5 minutes to 24 hours, start at most 30 days ahead, and never overlap.
  * The panel's own clock decides what is active; the phone only displays."""
import time
from typing import Optional
from fastapi import Depends, HTTPException, Request
from pydantic import BaseModel, Field
import store
from audit import audit
from auth import current_user
from mobileapi import router, reply, require, idempotent

MAX_AHEAD = 30 * 86400
MAX_PENDING = 20
KEEP_PAST = 10
START_GRACE = 60

with store._lock:
    store._conn.execute("CREATE TABLE IF NOT EXISTS maint (id INTEGER PRIMARY KEY AUTOINCREMENT, start INTEGER NOT NULL, end INTEGER NOT NULL, "
                        "reason TEXT NOT NULL, mute INTEGER NOT NULL, owner TEXT NOT NULL, created INTEGER NOT NULL, ended INTEGER)")
    store._conn.commit()

COLS = "id, start, end, reason, mute, owner, created, ended"


def q(sql, args=()):
    with store._lock:
        rows = store._conn.execute(sql, args).fetchall()
        store._conn.commit()
        return rows


def state_of(w, now):
    """scheduled | active | done | cancelled (a window ended before it began never happened)."""
    if w["ended"] is not None:
        return "cancelled" if w["ended"] <= w["start"] else "done"
    if now < w["start"]:
        return "scheduled"
    return "active" if now < w["end"] else "done"


def _row(r):
    return {"id": r[0], "start": r[1], "end": r[2], "reason": r[3], "mute": bool(r[4]), "owner": r[5], "created": r[6], "ended": r[7]}


def get(wid):
    r = q(f"SELECT {COLS} FROM maint WHERE id=?", (wid,))  # nosec B608: COLS is a fixed module constant; the id is bound
    return _row(r[0]) if r else None


def active(now=None):
    now = int(now or time.time())
    r = q(f"SELECT {COLS} FROM maint WHERE ended IS NULL AND start <= ? AND end > ? ORDER BY start DESC LIMIT 1", (now, now))  # nosec B608: COLS is a fixed module constant; times are bound
    return _row(r[0]) if r else None


def muting(now=None):
    w = active(now)
    return bool(w and w["mute"])


def held(w):
    """How many alerts were held during this window (recorded but not delivered)."""
    end = w["ended"] if w["ended"] is not None else w["end"]
    try:
        return q("SELECT COUNT(*) FROM events WHERE muted=1 AND ts >= ? AND ts <= ?", (w["start"], end))[0][0]
    except Exception:
        return 0


def window_view(w, now):
    st = state_of(w, now)
    end = w["ended"] if (w["ended"] is not None and w["ended"] > w["start"]) else w["end"]
    return {"id": w["id"], "state": st, "start": w["start"], "end": end, "planned_end": w["end"], "minutes": max(1, round((w["end"] - w["start"]) / 60)),
            "reason": w["reason"], "mute": w["mute"], "by": w["owner"], "created": w["created"],
            "held": held(w) if st in ("active", "done") else 0,
            "seconds_left": max(0, w["end"] - now) if st == "active" else None}


@router.get("/maintenance")
def overview(request: Request, user: str = Depends(current_user)):
    """The window in progress, what is planned, and the last few that finished. `muting` says whether alerts are held right now."""
    require(request, user, "view")
    now = int(time.time())
    ws = [_row(r) for r in q(f"SELECT {COLS} FROM maint ORDER BY start DESC LIMIT 200")]  # nosec B608: COLS is a fixed module constant
    act = next((w for w in ws if state_of(w, now) == "active"), None)
    up = sorted([w for w in ws if state_of(w, now) == "scheduled"], key=lambda w: w["start"])
    past = [w for w in ws if state_of(w, now) in ("done", "cancelled")][:KEEP_PAST]
    return reply(request, {"active": window_view(act, now) if act else None, "muting": bool(act and act["mute"]),
                           "upcoming": [window_view(w, now) for w in up], "past": [window_view(w, now) for w in past]})


class NewWindow(BaseModel):
    start: Optional[int] = Field(None, ge=0, description="Unix seconds on the panel's clock; omit to start now")
    minutes: int = Field(..., ge=5, le=1440)
    reason: str = Field("", max_length=120)
    mute: bool = True


def _who(request):
    ph = getattr(request.state, "phone", None)
    return {"via": "phone" if ph else "browser", "phone": ph["id"] if ph else None, "request_id": request.state.request_id}


def _nudge():
    try:                                   # let the alert center notice the change now instead of at its next look
        import mobileevents
        mobileevents.sweep(force=True)
    except Exception:
        pass


@router.post("/maintenance")
def start_window(body: NewWindow, request: Request, user: str = Depends(current_user)):
    require(request, user, "maintenance")

    def make():
        now = int(time.time())
        start = now if body.start is None or body.start <= now else body.start
        if body.start is not None and body.start < now - START_GRACE:
            raise HTTPException(400, "The start time is in the past.")
        if start > now + MAX_AHEAD:
            raise HTTPException(400, "A window can start at most 30 days ahead.")
        end = start + body.minutes * 60
        if q("SELECT id FROM maint WHERE ended IS NULL AND end > ? AND start < ? LIMIT 1", (start, end)):
            raise HTTPException(409, "Another maintenance window overlaps this time.")
        if q("SELECT COUNT(*) FROM maint WHERE ended IS NULL AND start > ?", (now,))[0][0] >= MAX_PENDING:
            raise HTTPException(409, "Too many planned windows. End one first.")
        reason = " ".join(body.reason.split())
        wid = q("INSERT INTO maint (start, end, reason, mute, owner, created) VALUES (?,?,?,?,?,?) RETURNING id", (start, end, reason, int(body.mute), user, now))[0][0]
        audit(user, request.client.host, "maintenance_start" if start <= now else "maintenance_schedule",
              id=wid, minutes=body.minutes, mute=body.mute, start=start, **_who(request))
        _nudge()
        return 201, window_view(get(wid), int(time.time()))
    return idempotent(request, user, "maintenance_start", body.model_dump(), make)


@router.post("/maintenance/{wid}/end")
def end_window(wid: int, request: Request, user: str = Depends(current_user)):
    """Ends the window in progress now, or cancels a planned one."""
    require(request, user, "maintenance")

    def make():
        now = int(time.time())
        w = get(wid)
        if not w:
            raise HTTPException(404, "No such maintenance window.")
        st = state_of(w, now)
        if st not in ("active", "scheduled"):
            raise HTTPException(409, "That window is already over.")
        q("UPDATE maint SET ended=? WHERE id=?", (now, wid))
        audit(user, request.client.host, "maintenance_end", id=wid, was=st, **_who(request))
        _nudge()
        return 200, window_view(get(wid), int(time.time()))
    return idempotent(request, user, "maintenance_end:%d" % wid, {}, make)
