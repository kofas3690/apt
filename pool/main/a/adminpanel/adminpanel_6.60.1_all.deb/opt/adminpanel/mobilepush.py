"""Push alerts for the phone app: /api/mobile/v1/push (docs/mobile-api-v1.md, section 18).

The panel sends alerts to a topic on an ntfy server (the free ntfy.sh, or your own); the ntfy Android app, subscribed to
that topic, shows them the moment they arrive, even when the AdminPanel app is closed. The settings are made on the web
Alerts page (chatalerts.py). This endpoint only lets an administrator's own full phone see how to subscribe and send a test.

  * Needs the `push_info` capability: admins on a full phone only, because the topic works like a password for reading alerts.
  * Never returns the access token (it only says whether one is saved).
  * The test goes through the same sender as real alerts and needs an Idempotency-Key. Both calls are in the audit log."""
from urllib.parse import urlsplit
from fastapi import Depends, HTTPException, Request
from audit import audit
import chatalerts
from auth import current_user
from mobileapi import router, reply, require, idempotent


def _who(request):
    ph = getattr(request.state, "phone", None)
    return {"via": "phone" if ph else "browser", "phone": ph["id"] if ph else None, "request_id": request.state.request_id}


def subscribe_link(server, topic):
    """The ntfy app's own address form: ntfy://host/topic (https), with ?secure=false for a plain-http server."""
    u = urlsplit(server)
    if not u.hostname or not topic:
        return ""
    return "ntfy://" + u.netloc + "/" + topic + ("" if u.scheme == "https" else "?secure=false")


@router.get("/push")
def push_info(request: Request, user: str = Depends(current_user)):
    require(request, user, "push_info")
    c = chatalerts.get()["ntfy"]
    ok = chatalerts.ready("ntfy")
    audit(user, request.client.host, "push_view", **_who(request))
    return reply(request, {"configured": ok, "enabled": bool(c["enabled"]) and ok, "server": c["server"], "topic": c["topic"] if ok else "",
                           "has_token": chatalerts.has_token("ntfy"), "link": subscribe_link(c["server"], c["topic"]) if ok else ""})


@router.post("/push/test")
def push_test(request: Request, user: str = Depends(current_user)):
    require(request, user, "push_info")

    def make():
        import socket
        if not chatalerts.ready("ntfy"):
            raise HTTPException(409, "Push is not set up yet. Set it up on the panel's Alerts page.")
        try:
            chatalerts.send_ntfy("AdminPanel test from " + socket.gethostname() + ". If this appeared on your phone, push alerts work.")
        except chatalerts.ChatError as e:
            audit(user, request.client.host, "push_test_failed", error=str(e)[:200], **_who(request))
            raise HTTPException(502, str(e))
        audit(user, request.client.host, "push_test", **_who(request))
        return 200, {"sent": True}
    return idempotent(request, user, "push_test", {}, make)
