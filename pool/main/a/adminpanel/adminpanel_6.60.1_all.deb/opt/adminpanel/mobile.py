"""Phones: pair a companion app, then let it monitor and do a few safe actions.

How pairing works
  1. A signed-in person opens Accounts, Panel access, Phones and presses Add phone (password + current code).
     The panel makes a one-time pairing code (10 minutes, used once) and shows it as a QR code that also
     carries the panel's address and its certificate fingerprint.
  2. The app scans it, connects, checks the certificate against the fingerprint, and sends the code to
     POST /api/mobile/pair. It gets back a long-lived token.
  3. From then on the app sends "Authorization: Bearer <token>". The token works like a session of that person,
     with extra limits (see roles.decide(..., phone=True)): no Terminal, no File manager, no account or panel
     administration, and only a short list of safe actions (restart a service, run updates, start a backup).
     A phone can also be made read-only. The token can be revoked at any time from the Phones list.

Only a SHA-256 of each token is stored (data/phones.json, mode 600); the token itself exists only on the phone."""
import hashlib, json, os, re, secrets, ssl, threading, time
from pathlib import Path
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
import auth
from audit import audit
from auth import current_user
from paths import DATA
from paneladmin import Step, step_up, qr_matrix
import roles

router = APIRouter(prefix="/api/mobile")
FILE = DATA / "phones.json"
CERT = Path(os.environ.get("ADMINPANEL_CERT", "/etc/ssl/certs/adminpanel.crt"))
CODE_TTL = 600
IDLE_DAYS = 90                      # a phone unused for this long stops working
MAX_PER_USER = 5
ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"        # no 0/O/1/I
lock = threading.Lock()
codes = {}                          # sha256(code) -> {user, name, ro, exp}
seen = {}                           # phone id -> (time, ip): last use, kept in memory and saved with the next change


def h(s):
    return hashlib.sha256(s.encode()).hexdigest()


def load():
    try:
        d = json.loads(FILE.read_text())
        return d if isinstance(d, dict) and isinstance(d.get("phones"), dict) else {"phones": {}}
    except (OSError, ValueError):
        return {"phones": {}}


def save(d):
    for pid, (t, ip) in seen.items():
        if pid in d["phones"]:
            d["phones"][pid]["last_seen"], d["phones"][pid]["last_ip"] = int(t), ip
    tmp = FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(d, indent=1))
    os.chmod(tmp, 0o600)
    os.replace(tmp, FILE)


def bearer(headers):
    """The token from an Authorization header (a dict-like of str or a list of byte pairs), or None."""
    if isinstance(headers, (list, tuple)):
        v = next((v.decode("latin-1") for k, v in headers if k == b"authorization"), "")
    else:
        v = headers.get("authorization", "")
    return v[7:].strip() if v[:7].lower() == "bearer " and len(v) < 200 else None


def lookup(token, ip=""):
    """-> {id, user, ro} for a valid token, else None. Marks the phone as seen."""
    if not token:
        return None
    th = h(token)
    with lock:
        d = load()
        for pid, p in d["phones"].items():
            if secrets.compare_digest(p["hash"], th):
                last = max(p.get("created", 0), (seen.get(pid) or (0,))[0], p.get("last_seen", 0))
                if time.time() - last > IDLE_DAYS * 86400:
                    return None
                if p.get("exp") and time.time() > p["exp"]:       # temporary access (6.11.0) has ended
                    return None
                if time.time() - (seen.get(pid) or (0,))[0] > 60:
                    seen[pid] = (time.time(), ip)
                return {"id": pid, "user": p["user"], "ro": bool(p.get("ro"))}
    return None


def fingerprint():
    try:
        der = ssl.PEM_cert_to_DER_cert(CERT.read_text())
        return hashlib.sha256(der).hexdigest().upper()
    except (OSError, ValueError):
        return ""


class Start(Step):
    name: str = Field(min_length=1, max_length=40, pattern=r"^[\w .,'()-]+$")
    read_only: bool = False
    address: str = Field("", max_length=100)       # optional: the address the PHONE should use, if not the one this browser used


HOST_RE = r"[A-Za-z0-9.\-\[\]:]{1,100}"


class Pair(BaseModel):
    code: str = Field(min_length=8, max_length=20)
    device: str = Field("", max_length=60)


def info(p, pid, me=None):
    return {"id": pid, "name": p["name"], "user": p["user"], "read_only": bool(p.get("ro")), "created": p["created"],
            "last_seen": int((seen.get(pid) or (p.get("last_seen", 0),))[0]), "last_ip": (seen.get(pid) or (0, p.get("last_ip", "")))[1],
            "current": pid == me, "temporary": bool(p.get("exp")), "expires": p.get("exp")}


@router.post("/pair/start")
def pair_start(body: Start, request: Request, user: str = Depends(current_user)):
    host = body.address.strip()
    if host:
        if not re.fullmatch(HOST_RE, host):
            raise HTTPException(400, "The phone address should look like 192.168.1.5:8443 or panel.example.com, with no https:// and no path")
    else:
        host = request.headers.get("host", "")
        if not re.fullmatch(HOST_RE, host):
            raise HTTPException(400, "Cannot tell which address the phone should use. Type it in the Phone address box.")
        if request.url.scheme != "https":
            # the phone only talks TLS and pins the certificate, so a QR made from a plain-http page can never work
            raise HTTPException(400, "You opened the panel over plain http. Open its https:// address (port 8443) and try again, or type the address the phone should use in the Phone address box.")
    step_up(request, user, body)
    with lock:
        d = load()
        mine = [p for p in d["phones"].values() if p["user"] == user and not p.get("exp")]   # temporary guest access has its own limit
        if len(mine) >= MAX_PER_USER:
            raise HTTPException(400, f"You already have {MAX_PER_USER} phones. Remove one first.")
        now = time.time()
        for k in [k for k, v in codes.items() if v["exp"] < now]:
            del codes[k]
        for k in [k for k, v in codes.items() if v["user"] == user and not v.get("life")][:-2]:      # at most three open codes per person
            del codes[k]
        raw = "".join(secrets.choice(ALPHABET) for _ in range(12))
        code = raw[:4] + "-" + raw[4:8] + "-" + raw[8:]
        codes[h(raw)] = {"user": user, "name": body.name.strip(), "ro": body.read_only, "exp": now + CODE_TTL}
    fp = fingerprint()
    payload = json.dumps({"v": 1, "host": host, "fp": fp, "code": code}, separators=(",", ":"))
    audit(user, request.client.host, "phone_pair_started", name=body.name.strip(), read_only=body.read_only)
    return {"code": code, "expires_in": CODE_TTL, "payload": payload, "qr": qr_matrix(payload), "host": host,
            "fingerprint": fp, "fingerprint_known": bool(fp)}


@router.post("/pair")
def pair(body: Pair, request: Request):
    ip = request.client.host
    key = f"pair:{ip}"
    if auth.locked(key):
        raise HTTPException(429, "Too many attempts. Try again in a few minutes.")
    raw = re.sub(r"[^A-Za-z0-9]", "", body.code).upper()
    with lock:
        item = codes.pop(h(raw), None)
        if not item or item["exp"] < time.time():
            auth.record_failure(key)
            audit("", ip, "phone_pair_failed")
            raise HTTPException(401, "That pairing code is wrong or has expired")
        users = auth.load_users()
        role = roles.role_of(users.get(item["user"]))
        if role is None:
            raise HTTPException(401, "That account no longer exists")
        d = load()
        pid = secrets.token_hex(6)
        token = secrets.token_urlsafe(32)
        name = item["name"] if not body.device.strip() else f'{item["name"]}'
        d["phones"][pid] = {"name": name, "user": item["user"], "ro": item["ro"], "hash": h(token),
                            "created": int(time.time()), "device": body.device.strip()[:60], "last_seen": int(time.time()), "last_ip": ip}
        if item.get("life"):                                   # temporary read-only access: it ends by itself
            d["phones"][pid]["exp"] = int(time.time()) + int(item["life"])
        seen[pid] = (time.time(), ip)
        save(d)
    auth.failures.pop(key, None)
    audit(item["user"], ip, "phone_paired", phone=pid, name=name, read_only=item["ro"])
    return {"token": token, "phone_id": pid, "user": item["user"], "read_only": item["ro"],
            "role": "viewer" if item["ro"] else role}


def me_phone(request):
    return getattr(request.state, "phone", None)


@router.get("/phones")
def phones(request: Request, user: str = Depends(current_user)):
    me = (me_phone(request) or {}).get("id")
    admin = roles.role_of(auth.load_users().get(user)) == "admin" and not me
    d = load()
    rows = [info(p, pid, me) for pid, p in d["phones"].items() if admin or p["user"] == user]
    rows.sort(key=lambda r: r["created"])
    return {"phones": rows, "max": MAX_PER_USER, "all": admin}


@router.delete("/phones/{pid}")
def revoke(pid: str, request: Request, user: str = Depends(current_user)):
    me = me_phone(request)
    with lock:
        d = load()
        p = d["phones"].get(pid)
        admin = roles.role_of(auth.load_users().get(user)) == "admin" and not me
        if not p or (p["user"] != user and not admin):
            raise HTTPException(404, "No such phone")
        del d["phones"][pid]
        seen.pop(pid, None)
        save(d)
    forget_events(pid)
    audit(user, request.client.host, "phone_revoked", phone=pid, name=p["name"], owner=p["user"])
    return {"ok": True}


@router.post("/unpair")
def unpair(request: Request, user: str = Depends(current_user)):
    """The app removes its own pairing (for example when you sign out of it)."""
    me = me_phone(request)
    if not me:
        raise HTTPException(400, "Only a paired phone can do this")
    return revoke(me["id"], request, user)


def drop_user(name):
    """A person was removed from the panel: their phones stop working."""
    with lock:
        d = load()
        gone = [pid for pid, p in d["phones"].items() if p["user"] == name]
        for pid in gone:
            del d["phones"][pid]
            seen.pop(pid, None)
            forget_events(pid)
        if gone:
            save(d)
    return len(gone)


def forget_events(pid):
    """A phone's alert-center state (read marks, notification registration) goes with it."""
    try:
        import mobileevents
        mobileevents.forget(pid)
    except Exception:
        pass


def part(fn):
    try:
        return fn()
    except Exception:                      # one broken source must not blank the whole card
        return None


@router.get("/summary")
def summary(request: Request, user: str = Depends(current_user)):
    """Everything the app's first screen needs, in one request."""
    import alerts, backupcheck, reboot, system
    s = part(lambda: system.system(user)) or {}
    out = {"hostname": s.get("hostname"), "os": s.get("os"), "uptime": s.get("uptime"), "time": s.get("time"),
           "cpu_percent": s.get("cpu_percent"), "cpu_cores": s.get("cpu_cores"), "load": s.get("load"),
           "mem": s.get("mem"), "swap": s.get("swap"), "disk": s.get("disk"), "net": s.get("net"), "ips": s.get("ips")}
    sc = part(alerts.scan)
    if sc:
        act = sc[1]
        out["alerts"] = {"critical": sum(a["severity"] == "critical" for a in act), "warning": sum(a["severity"] == "warning" for a in act),
                         "top": [{"severity": a["severity"], "title": a["title"], "detail": a.get("detail", "")[:200]} for a in act[:5]]}
    else:
        out["alerts"] = None
    b = part(backupcheck.brief)
    out["backup"] = None if not b else {"schedule": b.get("schedule"), "hour": b.get("hour"), "running": bool(b.get("running")),
                                         "last": None if not isinstance(b.get("last"), dict) else
                                         {"ok": bool(b["last"].get("ok")), "t": b["last"].get("t"), "error": str(b["last"].get("error") or "")[:200]}}
    r = part(reboot.info)
    out["reboot"] = None if not r else {"required": r.get("required"), "days": r.get("days"), "packages": (r.get("packages") or [])[:10]}
    out["role"] = roles.role_of(auth.load_users().get(user))
    p = me_phone(request)
    if p and p["ro"] and out["role"]:
        out["role"] = "viewer"
    out["phone"] = {"id": p["id"], "read_only": p["ro"]} if p else None
    return out
