"""The logo of the Linux distribution this panel runs on (Ubuntu, Debian, Mint, ...).

The panel does not ship any distribution's artwork. It looks for the logo files the system itself has
(icon themes, desktop-base, a file the admin dropped in /etc/adminpanel/logos) and serves the first match.
With no logo found it serves nothing and the pages show the panel's own mark. Nothing here writes anything.
"""
import os, re
from pathlib import Path
from fastapi import APIRouter
from fastapi.responses import Response, JSONResponse

router = APIRouter(prefix="/api")

OS_RELEASE = "/etc/os-release"
OVERRIDE_DIR = "/etc/adminpanel/logos"           # <id>.svg or <id>.png, put there by the admin
SEARCH = ("/usr/share/pixmaps", "/usr/share/icons", "/usr/share/desktop-base", "/usr/share/plymouth")
MAX_BYTES = 300 * 1024
NAME_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{0,63}$")
TYPES = {".svg": "image/svg+xml", ".png": "image/png"}
_cache = {"t": 0.0, "v": None}


def read_release(path=OS_RELEASE):
    """The few os-release fields we use, with quotes removed. Never raises."""
    out = {}
    try:
        for line in Path(path).read_text(errors="replace").splitlines():
            k, sep, v = line.partition("=")
            if sep and k in ("ID", "ID_LIKE", "NAME", "LOGO"):
                out[k] = v.strip().strip('"').strip("'")
    except OSError:
        pass
    return out


def candidates(rel):
    """Icon names to try, best first: the distribution's own LOGO field, then common names for its id."""
    ids = [rel.get("ID", "").lower()] + rel.get("ID_LIKE", "").lower().split()
    names = []
    logo = rel.get("LOGO", "").lower()
    if logo:
        names.append(logo)
    for i in ids:
        if not NAME_RE.match(i or ""):
            continue
        names += ["distributor-logo-" + i, i + "-logo", i + "-logo-icon", "start-here-" + i, i]
    names.append("distributor-logo")
    seen, out = set(), []
    for n in names:
        if NAME_RE.match(n) and n not in seen:
            seen.add(n); out.append(n)
    return out


def _size_ok(p):
    try:
        return p.is_file() and 0 < p.stat().st_size <= MAX_BYTES
    except OSError:
        return False


def find_logo(rel=None, search=SEARCH, override=OVERRIDE_DIR):
    """Path of the best logo file, or None. Only exact file names, only .svg or .png, never follows names from the web."""
    rel = read_release() if rel is None else rel
    ids = [rel.get("ID", "").lower()] + rel.get("ID_LIKE", "").lower().split()
    for i in ids:                                              # the admin's own file wins
        if NAME_RE.match(i or ""):
            for ext in TYPES:
                p = Path(override) / (i + ext)
                if _size_ok(p):
                    return p
    names = candidates(rel)
    best = None                                                # (name rank, scalable first, path)
    for root in search:
        if not os.path.isdir(root):
            continue
        depth0 = root.rstrip("/").count("/")
        for dp, dn, fn in os.walk(root):
            if dp.count("/") - depth0 >= 6:
                dn[:] = []
            for f in fn:
                stem, ext = os.path.splitext(f)
                if ext.lower() not in TYPES or stem.lower() not in names:
                    continue
                p = Path(dp) / f
                if not _size_ok(p):
                    continue
                plain = 1 if re.search(r"mono|symbolic|light|dark", str(p).lower()) else 0   # coloured artwork reads on both themes
                key = (names.index(stem.lower()), plain, 0 if ext.lower() == ".svg" else 1, str(p))
                if best is None or key < best[0]:
                    best = (key, p)
    return best[1] if best else None


def info():
    """{'name', 'path'} cached for a minute; the logo file is looked up once, not per request."""
    import time
    now = time.time()
    if _cache["v"] is None or now - _cache["t"] > 60:
        rel = read_release()
        _cache["v"] = {"name": rel.get("NAME", "") or "Linux", "path": find_logo(rel)}
        _cache["t"] = now
    return _cache["v"]


@router.get("/distro")
def distro():
    """Public (shown on the sign-in page): only the distribution's short name, never the version."""
    v = info()
    return JSONResponse({"name": v["name"], "logo": v["path"] is not None},
                        headers={"Cache-Control": "no-store"})


@router.get("/distro-logo")
def distro_logo():
    p = info()["path"]
    if p is None:
        return Response(status_code=404)
    try:
        data = p.read_bytes()
    except OSError:
        return Response(status_code=404)
    if len(data) > MAX_BYTES:
        return Response(status_code=404)
    return Response(data, media_type=TYPES[p.suffix.lower()], headers={
        "Cache-Control": "public, max-age=3600", "X-Content-Type-Options": "nosniff",
        "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; sandbox"})
