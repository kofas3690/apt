"""Is the backup healthy? Turns the backup helper's short report into alerts.

Five things are worth a message: the last backup failed, backups are switched on but the last good one is older than
the schedule allows (a day and a half for daily, eight days for weekly), and backups are switched on but none has ever
run, copies that the "keep N" rule should still hold are gone (deleted by hand, the folder cleaned), and a check found a copy damaged (checks are run one copy a day by the scheduled run, and by the Check button). Nothing is said while a backup is running. With backups off, only a failed backup you started by hand is reported (for a
week, or until one succeeds), because a manual backup that failed is still a copy you thought you had. The report comes from the root helper
(`adminpanel-backup brief`, which does not connect any share), and is kept for two minutes because the Alerts list is
asked for often.
"""
import json, subprocess, threading, time

HELPER = "/usr/local/sbin/adminpanel-backup"
SUDO = "/usr/bin/sudo"
ENV = {"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LC_ALL": "C"}
KEEP_FOR = 120
MANUAL_FAIL_FOR = 7 * 86400
MAX_AGE = {"daily": 36 * 3600, "weekly": 8 * 86400}
JUMP_RATIO = 2.0                  # a copy this many times the usual size ...
JUMP_MIN = 50 * 1024 * 1024       # ... and at least this much bigger is called out
TYPICAL_OF = 7                    # "usual" is the median of up to this many earlier copies
_lock = threading.Lock()
_cache = {"t": 0.0, "data": None}


def brief():
    """The helper's report, or None if it cannot be read (the previous reading is kept for a while)."""
    now = time.time()
    with _lock:
        if _cache["data"] is not None and now - _cache["t"] < KEEP_FOR:
            return _cache["data"]
        try:
            r = subprocess.run([SUDO, "-n", HELPER, "brief"], capture_output=True, text=True, errors="replace",
                               timeout=20, env=ENV, stdin=subprocess.DEVNULL)
            d = json.loads(r.stdout) if r.returncode == 0 else None
            if isinstance(d, dict):
                _cache.update(t=now, data=d)
                return d
        except (OSError, ValueError, subprocess.TimeoutExpired):
            pass
        _cache["t"] = now - KEEP_FOR + 30            # try again in 30 seconds, not on every request
        return _cache["data"]                        # the last good reading, or None if there never was one


def ago(sec):
    if sec < 5400:
        return f"{max(1, round(sec / 60))} minutes"
    if sec < 2 * 86400:
        return f"{round(sec / 3600)} hours"
    return f"{round(sec / 86400)} days"


def growth(rows):
    """rows: successful copies, oldest first, each with a `size`. None until there are three; then how the newest compares with the
    median of the earlier ones, and whether it is a jump (see JUMP_RATIO and JUMP_MIN)."""
    sizes = [int(r["size"]) for r in rows if isinstance(r, dict) and isinstance(r.get("size"), int) and r["size"] > 0]
    if len(sizes) < 3:
        return None
    earlier = sorted(sizes[-1 - TYPICAL_OF:-1])
    typical, newest = earlier[len(earlier) // 2], sizes[-1]
    return {"newest": newest, "typical": typical, "ratio": round(newest / typical, 1),
            "jumped": bool(newest >= typical * JUMP_RATIO and newest - typical >= JUMP_MIN)}


def mb(n):
    return f"{n / 1048576:.0f} MB" if n < 1073741824 else f"{n / 1073741824:.1f} GB"


def jump_alert(b, last, now):
    """The newest backup is much bigger than the ones before it (a hidden editor folder once took one from 110 MB to 600 MB).
    Only while that copy is the latest result, so it clears itself once a normal-sized backup follows."""
    g = growth(b.get("sizes") or [])
    sizes = b.get("sizes") or []
    if not g or not g["jumped"] or not last or not last.get("ok") or not sizes:
        return []
    if abs(int(last.get("t") or 0) - int(sizes[-1].get("t") or 0)) > 60:       # the latest run is not the one that grew
        return []
    return [{"id": "backup-grew", "severity": "warning", "kind": "backup", "title": "The newest backup is much bigger than usual",
             "detail": f"It is {mb(g['newest'])}, about {g['ratio']:g} times the usual {mb(g['typical'])}. Something large may have been added to a saved folder. "
                       "On the Backups page, \"What makes a backup big\" shows where; leave out what you do not need.",
             "link": "/backups.html"}]


def missing_alert(b):
    """Copies the "keep N" rule should still hold are gone (deleted by hand, the backup folder cleaned or replaced). Old copies
    are only removed when newer ones push them out, so this is never normal pruning. It clears once newer copies replace the
    missing ones in the last N."""
    k = b.get("kept")
    if not isinstance(k, dict):
        return []
    miss, exp = k.get("missing"), k.get("expected")
    if not (isinstance(miss, int) and isinstance(exp, int) and not isinstance(miss, bool) and 1 <= miss <= exp and exp >= 2):
        return []
    sev = "critical" if miss >= exp - 1 else "warning"      # all or all but one of the recent copies are gone
    return [{"id": "backup-copies-missing", "severity": sev, "kind": "backup",
             "title": "Some backups are missing" if miss > 1 else "A backup is missing",
             "detail": f"{miss} of the last {exp} backups that should still be kept can no longer be found in the backup folder. "
                       "Someone may have deleted them, or the folder was cleaned or replaced. The Backups page shows the copies that are left.",
             "link": "/backups.html"}]


def damaged_alert(b):
    """A check (the daily scheduled one, or the Check button) could not read a copy that is in the backup folder. A damaged copy
    cannot be restored, so this is critical. It clears when the copy is deleted, pushed out by newer ones, or checked again
    and found fine."""
    v = b.get("verify")
    if not isinstance(v, dict):
        return []
    bad, copies = v.get("bad"), v.get("copies")
    if not (isinstance(bad, int) and isinstance(copies, int) and not isinstance(bad, bool) and not isinstance(copies, bool)
            and 1 <= bad <= copies):
        return []
    t = v.get("bad_t")
    when = ""
    if isinstance(t, int) and not isinstance(t, bool) and t > 0 and isinstance(b.get("now"), int) and b["now"] >= t:
        when = f" (checked {ago(b['now'] - t)} ago)"
    return [{"id": "backup-copy-damaged", "severity": "critical", "kind": "backup",
             "title": "Some backup copies are damaged" if bad > 1 else "A backup copy is damaged",
             "detail": f"A check could not read {bad} of the {copies} copies in the backup folder{when}. A damaged copy cannot be restored. "
                       "Make a new backup now, then press Check on the Backups page to test the others, and delete the damaged one.",
             "link": "/backups.html"}]


def extra_alerts(b, last, now):
    """What is worth saying when the last backup itself was fine."""
    return jump_alert(b, last, now) + missing_alert(b)


def evaluate(b, now=None):
    """Alerts for one report: the backup's own state, and any copy a check found damaged."""
    if not b or b.get("running"):
        return []
    return evaluate_state(b, now) + damaged_alert(b)


def evaluate_state(b, now=None):
    now = now or time.time()
    last = b.get("last") if isinstance(b.get("last"), dict) else None
    link = "/backups.html"
    if b.get("schedule") not in MAX_AGE:             # scheduled backups are off: only a recent manual failure or jump matters
        if last and last.get("ok") and now - int(last.get("t") or 0) <= MANUAL_FAIL_FOR:
            return extra_alerts(b, last, now)
        if last and not last.get("ok") and now - int(last.get("t") or 0) <= MANUAL_FAIL_FOR:
            err = str(last.get("error") or "no reason was recorded")[:200]
            return [{"id": "backup-failed", "severity": "critical", "kind": "backup", "title": "The last backup failed",
                     "detail": f"It failed {ago(now - int(last.get('t') or 0))} ago: {err}. No new copy was made.",
                     "link": link}]
        return []
    limit = MAX_AGE[b["schedule"]]
    if last and not last.get("ok"):
        err = str(last.get("error") or "no reason was recorded")[:200]
        t = int(last.get("t") or 0)
        return [{"id": "backup-failed", "severity": "critical", "kind": "backup", "title": "The last backup failed",
                 "detail": f"It failed {ago(now - t)} ago: {err}. Until a backup succeeds, your data is not protected by a new copy.",
                 "link": link}]
    if last and last.get("ok"):
        age = now - int(last.get("t") or 0)
        if age > limit:
            return [{"id": "backup-stale", "severity": "warning", "kind": "backup",
                     "title": f"No backup for {ago(age)}",
                     "detail": f"Backups are set to run {b['schedule']}, but the last good one is {ago(age)} old. Check that the machine is on at the scheduled hour ({int(b.get('hour', 0)):02d}:00) and that the backup destination is available.",
                     "link": link}]
        return extra_alerts(b, last, now)
    ct = b.get("config_t")
    if ct and now - ct > limit:
        return [{"id": "backup-never", "severity": "warning", "kind": "backup", "title": "Backups are on but none has run",
                 "detail": f"Backups are set to run {b['schedule']} at {int(b.get('hour', 0)):02d}:00, but no backup has been recorded. Press Back up now on the Backups page to see what is wrong.",
                 "link": link}]
    return []
