"""Docker networks: the networks on this machine with their address ranges and attached containers, and removal of a
network that nothing uses.

Docker access is the same as root, so everything goes through a root helper that allows only those two things, only for
a network name Docker itself lists, never for bridge, host or none, and never while a container is attached.
"""
import json, subprocess
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from auth import current_user
from audit import audit

router = APIRouter(prefix="/api/dnetworks")

HELPER = "/usr/local/sbin/adminpanel-dnetworks"
SUDO = "/usr/bin/sudo"
ENV = {"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LC_ALL": "C"}
NAME = r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$"


class Remove(BaseModel):
    name: str = Field(pattern=NAME)


def run(*args, timeout=100):
    try:
        r = subprocess.run([SUDO, "-n", HELPER, *args], capture_output=True, text=True, errors="replace", timeout=timeout,
                           env=ENV, stdin=subprocess.DEVNULL)
    except subprocess.TimeoutExpired:
        raise HTTPException(504, "Docker took too long to answer")
    if r.returncode != 0:
        raise HTTPException(400, ((r.stderr or r.stdout).strip() or "The networks helper failed")[:300])
    return r


@router.get("")
def listing(user: str = Depends(current_user)):
    try:
        return json.loads(run("list").stdout)
    except ValueError:
        raise HTTPException(500, "The networks helper returned something unexpected")


@router.post("/remove")
def remove(body: Remove, request: Request, user: str = Depends(current_user)):
    try:
        run("remove", body.name, timeout=70)
    except HTTPException:
        audit(user, request.client.host, "dnetwork_remove", target=body.name, ok=False)
        raise
    audit(user, request.client.host, "dnetwork_remove", target=body.name, ok=True)
    return {"ok": True}
