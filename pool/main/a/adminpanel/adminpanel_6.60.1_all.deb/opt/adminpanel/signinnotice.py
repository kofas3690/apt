"""Settings and test button for the sign-in notices (the notices themselves are sent by signin_hooks.py)."""
import socket
from typing import Literal
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from auth import current_user
from audit import audit
import chatalerts, mailer
import signin_hooks as hooks

router = APIRouter(prefix="/api/signinnotice")


class Body(BaseModel):
    enabled: bool = False
    mode: Literal["new", "all"] = "new"
    lockout: bool = True


def channels():
    out = []
    if mailer.get()["enabled"]:
        out.append("email")
    out += [n for n in chatalerts.enabled_channels() if chatalerts.ready(n)]
    return out


def view(user):
    return {**hooks.get(), "channels": channels(), "known_addresses": len(hooks.known.get(user) or [])}


@router.get("")
def get_settings(user: str = Depends(current_user)):
    return view(user)


@router.put("")
def save(body: Body, request: Request, user: str = Depends(current_user)):
    cfg = {"enabled": body.enabled, "mode": body.mode, "lockout": body.lockout}
    hooks.settings_store["cfg"] = cfg
    audit(user, request.client.host, "signin_notice_settings", **cfg)
    return view(user)


@router.post("/test")
def test(request: Request, user: str = Depends(current_user)):
    if not channels():
        raise HTTPException(400, "No alert channel is switched on yet. Set up email, Telegram or WhatsApp above first.")
    host = socket.gethostname()
    done = hooks.send_all(f"[{host}] AdminPanel sign-in notice test",
                          "This is a test of the sign-in notices from the AdminPanel on " + host + ".\nIf you can read it, real notices will reach you here.")
    audit(user, request.client.host, "signin_notice_test", sent_to=",".join(done) or "nothing")
    if not done:
        raise HTTPException(400, "Sending failed on every channel. See the audit log for the reason.")
    return {"ok": True, "sent_to": done}


@router.post("/forget")
def forget(request: Request, user: str = Depends(current_user)):
    """Forget the known addresses of the signed-in account; the next sign-in is learned again without a notice."""
    hooks.known.pop(user, None)
    audit(user, request.client.host, "signin_known_cleared")
    return view(user)
