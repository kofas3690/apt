"""Temporary read-only access for another phone: /api/mobile/v1/temporary (docs/mobile-api-v1.md, section 17).

An administrator on a full phone can make a pairing QR for someone else (a colleague on call, a visitor) that gives
READ-ONLY access which ends by itself after 15 minutes, 1 hour or 24 hours. The other phone is a viewer: it sees status,
services, updates and alerts, and cannot restart, install, back up, reboot, approve, or read the audit log.

  * Needs the `temp_access` capability (admins on a full phone, never a read-only phone) and an Idempotency-Key.
  * The QR works once and for 10 minutes; the access time starts when the other phone pairs, not when the QR is made.
  * At most 3 temporary accesses (paired or waiting) at a time. An access can be revoked at once.
  * Every step is in the audit log with the phone and request ID. The pairing code and the token never appear in it.
  * The phone app does not ask for the account password here (the web panel does): the admin's own phone token, the
    fingerprint or screen-lock check on that phone, and the limits above are what protect this."""
import re, secrets, time
from typing import Literal
from fastapi import Depends, HTTPException, Request
from pydantic import BaseModel, Field
from audit import audit
import mobile as M
from auth import current_user
from paneladmin import qr_matrix
from mobileapi import router, reply, require, idempotent

OPTIONS = (15, 60, 1440)
MAX_TEMP = 3


def _who(request):
    ph = getattr(request.state, "phone", None)
    return {"via": "phone" if ph else "browser", "phone": ph["id"] if ph else None, "request_id": request.state.request_id}


def _word(minutes):
    return "15 min" if minutes == 15 else "1 hour" if minutes == 60 else "24 hours"


def _state(now):
    """(active temporary phones, waiting codes). Expired temporary phones are removed here."""
    d = M.load()
    gone = [pid for pid, p in d["phones"].items() if p.get("exp") and p["exp"] <= now]
    for pid in gone:
        del d["phones"][pid]
        M.seen.pop(pid, None)
    if gone:
        M.save(d)
    active = [(pid, p) for pid, p in d["phones"].items() if p.get("exp")]
    for k in [k for k, v in M.codes.items() if v["exp"] < now]:
        del M.codes[k]
    waiting = [v for v in M.codes.values() if v.get("life")]
    return active, waiting


def _row(pid, p, now):
    return {"id": pid, "name": p["name"], "by": p["user"], "created": p["created"], "expires": p["exp"], "seconds_left": max(0, p["exp"] - now),
            "last_seen": int((M.seen.get(pid) or (p.get("last_seen", 0),))[0])}


@router.get("/temporary")
def overview(request: Request, user: str = Depends(current_user)):
    require(request, user, "temp_access")
    now = int(time.time())
    with M.lock:
        active, waiting = _state(now)
        return reply(request, {"options": list(OPTIONS), "max": MAX_TEMP, "active": [_row(pid, p, now) for pid, p in active],
                               "waiting": [{"name": v["name"], "minutes": v["life"] // 60, "code_expires_in": max(0, int(v["exp"] - now))} for v in waiting]})


class NewTemp(BaseModel):
    minutes: Literal[15, 60, 1440]
    name: str = Field("", max_length=40, pattern=r"^[\w .,'()-]*$")
    address: str = Field("", max_length=100)


@router.post("/temporary")
def create(body: NewTemp, request: Request, user: str = Depends(current_user)):
    require(request, user, "temp_access")

    def make():
        host = body.address.strip() or request.headers.get("host", "")
        if not re.fullmatch(M.HOST_RE, host):
            raise HTTPException(400, "The address should look like 192.168.1.5:8443 or panel.example.com, with no https:// and no path.")
        now = time.time()
        with M.lock:
            active, waiting = _state(int(now))
            if len(active) + len(waiting) >= MAX_TEMP:
                raise HTTPException(409, f"There are already {MAX_TEMP} temporary accesses. Revoke one first.")
            raw = "".join(secrets.choice(M.ALPHABET) for _ in range(12))
            code = raw[:4] + "-" + raw[4:8] + "-" + raw[8:]
            name = " ".join(body.name.split()) or f"Guest ({_word(body.minutes)})"
            M.codes[M.h(raw)] = {"user": user, "name": name, "ro": True, "exp": now + M.CODE_TTL, "life": body.minutes * 60}
        fp = M.fingerprint()
        import json
        payload = json.dumps({"v": 1, "host": host, "fp": fp, "code": code}, separators=(",", ":"))
        audit(user, request.client.host, "phone_pair_started", name=name, read_only=True, minutes=body.minutes, kind="temporary", **_who(request))
        return 201, {"code": code, "expires_in": M.CODE_TTL, "payload": payload, "qr": qr_matrix(payload), "host": host, "fingerprint": fp,
                     "fingerprint_known": bool(fp), "minutes": body.minutes, "name": name, "read_only": True}
    return idempotent(request, user, "temp_create", body.model_dump(), make)


@router.post("/temporary/{pid}/revoke")
def revoke(pid: str, request: Request, user: str = Depends(current_user)):
    require(request, user, "temp_access")

    def make():
        with M.lock:
            d = M.load()
            p = d["phones"].get(pid)
            if not p or not p.get("exp"):
                raise HTTPException(404, "No such temporary access.")
            del d["phones"][pid]
            M.seen.pop(pid, None)
            M.save(d)
        M.forget_events(pid)
        audit(user, request.client.host, "phone_revoked", phone=pid, name=p["name"], owner=p["user"], kind="temporary", **{k: v for k, v in _who(request).items() if k != "phone"})
        return 200, {"revoked": True}
    return idempotent(request, user, "temp_revoke:" + pid, {}, make)
