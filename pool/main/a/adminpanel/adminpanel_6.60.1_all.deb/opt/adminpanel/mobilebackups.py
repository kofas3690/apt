"""Backup management for the phone app: /api/mobile/v1/backups (docs/mobile-api-v1.md, section 12).

It shapes what the root backup helper already knows (and, since 6.7.0, how long runs took, a bounded history, and
progress while one runs) into a few safe answers. Rules:
  * read access for every role; starting or cancelling needs `backup_run` (operators and admins on a full phone)
  * starting and cancelling need an Idempotency-Key, so a retry after a dropped connection never starts a second job
  * only one backup can run: a second request while one is running or just starting is 409, never a second job
  * the answers never contain credentials, share passwords or what is inside a copy (copies are root-only and the
    panel cannot read them); host paths are replaced by a short label
  * every start and cancel is written to the audit log with the phone and the request ID
  * since 6.35.0 an administrator on a full phone can delete one copy (never the last one), only when switched on in the web panel"""
import json, re, threading, time
from fastapi import Depends, HTTPException, Path, Query, Request
from pydantic import BaseModel, Field
import backup, backupcheck
from audit import audit
from auth import current_user
from mobileapi import router, reply, require, idempotent

NAME_RE = re.compile(backup.NAME)
START_GRACE = 20                 # seconds a just-accepted run may take to grab the helper's lock
MAX_SOURCES = 20
_check_lock = threading.Lock()   # one copy check at a time (a check reads the whole copy)
_pending = {"t": 0.0}            # when the last start was accepted (so "starting" is a real state, not a blank)


def _json(*args, timeout=60):
    r = backup.must(backup.run(*args, timeout=timeout))
    try:
        return json.loads(r.stdout)
    except ValueError:
        raise HTTPException(502, "The backup helper returned something unexpected.")


def dest_label(d):
    d = str(d or "local")
    return "This server (local folder)" if d == "local" else "Disk " + d[4:] if d.startswith("mnt:") else "Share " + d


def _txt(v, n=200):
    return None if v is None else str(v)[:n]


def _int(v):
    return int(v) if isinstance(v, (int, float)) and not isinstance(v, bool) else None


def _entry(e, now, names=()):
    """One result of a backup run, as the phone sees it."""
    t = _int(e.get("t")) or 0
    return {"t": t, "age_seconds": max(0, now - t), "ok": bool(e.get("ok")), "cancelled": bool(e.get("cancelled")),
            "name": _txt(e.get("name"), 80), "size": _int(e.get("size")), "started": _int(e.get("started")), "seconds": _int(e.get("seconds")),
            "error": _txt(e.get("error")), "warning": _txt(e.get("warning")), "pruned": _int(e.get("pruned")),
            "destination": dest_label(e.get("dest")) if e.get("dest") else None, "available": e.get("name") in names if e.get("name") else False,
            "checked": names.get(e.get("name")) if isinstance(names, dict) and e.get("name") else None}


def _copies(st):
    out = []
    for a in st.get("archives") or []:
        if isinstance(a, dict) and NAME_RE.fullmatch(str(a.get("name", ""))):
            ct, ok = _int(a.get("checked_t")), a.get("checked_ok")
            out.append({"name": a["name"], "size": _int(a.get("size")) or 0, "t": _int(a.get("t")) or 0,
                        "checked": {"t": ct, "ok": ok} if ct and isinstance(ok, bool) else None})
    return sorted(out, key=lambda c: c["t"], reverse=True)


def _checks(copies):
    """{copy name: {t, ok} or None}: lets _entry say whether a copy was checked, and when ("in" still tells whether it exists)."""
    return {c["name"]: c["checked"] for c in copies}


def _starting(st, now):
    last = st.get("last") if isinstance(st.get("last"), dict) else None
    return (not st.get("running")) and now - _pending["t"] < START_GRACE and (last is None or (_int(last.get("t")) or 0) < _pending["t"])


def _health(cfg, last, running, copies, ready, now):
    if not ready and cfg.get("schedule") != "off":
        return {"level": "warning", "title": "The backup destination is not connected", "detail": "Backups cannot run until the destination is available again."}
    if cfg.get("schedule") == "off":
        a = backupcheck.evaluate({"schedule": "off", "last": last, "running": running}, now)
        if a:
            return {"level": a[0]["severity"], "title": a[0]["title"], "detail": a[0]["detail"]}
        return {"level": "off", "title": "Scheduled backups are off", "detail": "You can still start one by hand."}
    alerts = backupcheck.evaluate({"schedule": cfg.get("schedule"), "hour": cfg.get("hour", 0), "last": last, "running": running, "config_t": None}, now)
    if alerts:
        return {"level": alerts[0]["severity"], "title": alerts[0]["title"], "detail": alerts[0]["detail"]}
    if running:
        return {"level": "ok", "title": "A backup is running", "detail": ""}
    if not last and not copies:
        return {"level": "warning", "title": "No backup has run yet", "detail": "Start one by hand to check that it works."}
    return {"level": "ok", "title": "Backups are healthy", "detail": ""}


TREND_POINTS = 10          # successful copies drawn in the size trend (the rule for "much bigger than usual" is backupcheck.growth)


def trend(hist, copies):
    """Sizes of the successful copies, oldest first, and whether the newest is much bigger than usual (as it was when a hidden
    editor folder swelled a backup from 110 MB to 600 MB). Needs two earlier copies to say what is usual."""
    seen, rows = set(), []
    for h in hist:
        if h.get("ok") and h.get("name") and _int(h.get("size")) and h["name"] not in seen:
            seen.add(h["name"]); rows.append({"t": _int(h.get("t")) or 0, "size": _int(h["size"])})
    for c in copies:                       # copies from before the helper kept a history
        if c["name"] not in seen and c["size"]:
            seen.add(c["name"]); rows.append({"t": c["t"], "size": c["size"]})
    rows.sort(key=lambda r: r["t"])
    points = rows[-TREND_POINTS:]
    return {"points": points, "growth": backupcheck.growth(rows)}


def snapshot(st, hist, now=None):
    now = int(now or time.time())
    cfg = st.get("config") if isinstance(st.get("config"), dict) else {}
    last = st.get("last") if isinstance(st.get("last"), dict) else None
    copies = _copies(st)
    names = _checks(copies)
    running = bool(st.get("running"))
    starting = _starting(st, now)
    state = "running" if running else "starting" if starting else "idle"
    ready = bool(st.get("dest_ready"))
    prog = st.get("progress") if isinstance(st.get("progress"), dict) else {}
    since = _int(prog.get("since"))
    ok_hist = [h for h in reversed(hist) if h.get("ok") and h.get("name")]
    if last and last.get("ok"):
        good = last
    elif ok_hist:
        good = ok_hist[0]
    elif copies:
        good = {"t": copies[0]["t"], "name": copies[0]["name"], "size": copies[0]["size"], "ok": True}
    else:
        good = None
    keep = _int(cfg.get("keep")) or 0
    sources = [str(s)[:200] for s in (cfg.get("sources") or [])[:MAX_SOURCES] if isinstance(s, str)]
    block = None
    if state != "idle":
        block = "A backup is already running." if state == "running" else "A backup was just started."
    elif not ready:
        block = "The backup destination is not connected."
    elif not sources:
        block = "No folders are chosen for backup."
    return {
        "state": state, "enabled": cfg.get("schedule") in ("daily", "weekly"),
        "can_run": block is None, "run_blocked_reason": block,
        "config": {"schedule": cfg.get("schedule", "off"), "hour": _int(cfg.get("hour")), "keep": keep, "sources": sources,
                   "destination": {"id": str(cfg.get("dest", "local")), "label": dest_label(cfg.get("dest")), "ready": ready},
                   "left_out": {"standard": [str(n)[:60] for n in (st.get("skip_names") or [])[:10] if isinstance(n, str)],
                                "chosen": [str(x)[:200] for x in (cfg.get("exclude") or [])[:MAX_SOURCES * 2] if isinstance(x, str)]}},
        "size_trend": trend(hist, copies),
        "running": {"since": since, "elapsed_seconds": max(0, now - since) if since else None, "partial_bytes": _int(prog.get("partial_bytes"))} if running else None,
        "last": _entry(last, now, names) if last else None,
        "last_success": _entry(good, now, names) if good else None,
        "health": _health(cfg, last, running, copies, ready, now),
        "copies": {"count": len(copies), "bytes": sum(c["size"] for c in copies), "newest_t": copies[0]["t"] if copies else None,
                   "oldest_t": copies[-1]["t"] if copies else None, "disk_free_bytes": _int(st.get("free")), "disk_total_bytes": _int(st.get("total"))},
        "retention": {"keep": keep, "next_run_removes_oldest": bool(keep and len(copies) >= keep)},
    }


def _status():
    return _json("status")


@router.get("/backups")
def backups(request: Request, user: str = Depends(current_user)):
    """Is the machine protected? State, the last result, the last good copy, destination, schedule and retention."""
    require(request, user, "view")
    return reply(request, snapshot(_status(), _hist()))


def _hist():
    h = _json("history")
    return [x for x in h if isinstance(x, dict)] if isinstance(h, list) else []


@router.get("/backups/history")
def history(request: Request, user: str = Depends(current_user), limit: int = Query(20, ge=1, le=50)):
    """Newest first: what the helper recorded (successes, failures, cancellations) plus copies that exist from before it
    kept a history. A failure that left no copy is still listed."""
    require(request, user, "view")
    now = int(time.time())
    st, hist = _status(), _hist()
    copies = _copies(st)
    names = _checks(copies)
    seen = {h.get("name") for h in hist if h.get("name")}
    rows = [_entry(h, now, names) for h in hist]
    rows += [_entry({"t": c["t"], "ok": True, "name": c["name"], "size": c["size"]}, now, names) for c in copies if c["name"] not in seen]
    rows.sort(key=lambda r: r["t"], reverse=True)
    return reply(request, {"items": rows[:limit], "count": len(rows)})


@router.get("/backups/copies")
def copies(request: Request, user: str = Depends(current_user)):
    """The copies that exist now, newest first. Names, sizes and times only: the panel cannot read inside them."""
    require(request, user, "view")
    now = int(time.time())
    cs = _copies(_status())
    return reply(request, {"items": [{**c, "age_seconds": max(0, now - c["t"])} for c in cs[:100]], "count": len(cs)})


@router.get("/backups/copies/{name}")
def copy_detail(name: str = Path(...), request: Request = None, user: str = Depends(current_user)):
    require(request, user, "view")
    if not NAME_RE.fullmatch(name):
        raise HTTPException(404, "No such backup.")
    now = int(time.time())
    st, hist = _status(), _hist()
    cs = _copies(st)
    pos = next((i for i, c in enumerate(cs) if c["name"] == name), None)
    if pos is None:
        raise HTTPException(404, "No such backup.")
    c = cs[pos]
    keep = _int((st.get("config") or {}).get("keep")) or 0
    run = next((h for h in reversed(hist) if h.get("name") == name), None)
    return reply(request, {**c, "age_seconds": max(0, now - c["t"]), "position": pos + 1, "of": len(cs),
                           "removed_by_next_run": bool(keep and pos == len(cs) - 1 and len(cs) >= keep),
                           "run": _entry(run, now, {name: c["checked"]}) if run else None,
                           "destination": dest_label((st.get("config") or {}).get("dest"))})


def _who(request):
    ph = getattr(request.state, "phone", None)
    return {"via": "phone" if ph else "browser", "phone": ph["id"] if ph else None, "request_id": request.state.request_id}


@router.post("/backups/{name}/check")
def check_copy(request: Request, name: str = Path(max_length=64), user: str = Depends(current_user)):
    """Reads one copy right through to see that it can still be restored (nothing is extracted or sent back). Same right as starting
    a backup. Needs an Idempotency-Key. 200 {name, ok, entries | error, checked_t}: a damaged copy is an answer (ok false), not an
    error. 404 no such copy, 409 another check is running or the destination is not connected. Can take minutes on a big copy."""
    require(request, user, "backup_run")
    if not NAME_RE.fullmatch(name):
        raise HTTPException(404, "No such backup.")

    def make():
        if not _check_lock.acquire(blocking=False):
            raise HTTPException(409, "Another check is running. Try again in a moment.")
        try:
            r = backup.run("verify", name, timeout=3700)
        finally:
            _check_lock.release()
        err = (r.stderr or r.stdout or "").strip()
        if r.returncode == 0:
            try:
                entries = _int(json.loads(r.stdout).get("entries")) or 0
            except ValueError:
                raise HTTPException(502, "The backup helper returned something unexpected.")
            audit(user, request.client.host, "backup_check", target=name, ok=True, **_who(request))
            return 200, {"name": name, "ok": True, "entries": entries, "checked_t": int(time.time())}
        if "damaged" in err:
            audit(user, request.client.host, "backup_check", target=name, ok=False, **_who(request))
            return 200, {"name": name, "ok": False, "error": err[:200], "checked_t": int(time.time())}
        if "no such backup" in err:
            raise HTTPException(404, "No such backup.")
        if "not connected" in err:
            raise HTTPException(409, "The backup destination is not connected.")
        raise HTTPException(502, (err or "The backup helper failed")[:200])
    return idempotent(request, user, "backup_check:" + name, {}, make)


class DeleteBody(BaseModel):
    name: str = Field(max_length=64)       # must repeat the copy's name: a stray call can never delete by accident


@router.post("/backups/{name}/delete")
def delete_copy(body: DeleteBody, request: Request, name: str = Path(max_length=64), user: str = Depends(current_user)):
    """Deletes one backup copy for good (6.35.0). Needs the capability `backup_delete` (an administrator on a full phone, and only
    after an administrator switched it on in the web panel), an Idempotency-Key, and the copy's name repeated in the body.
    404 no such copy, 400 name mismatch, 409 when it is the only copy, a backup or a check is running, or the destination is not
    connected. 200 {deleted, remaining}."""
    require(request, user, "backup_delete")
    if not NAME_RE.fullmatch(name):
        raise HTTPException(404, "No such backup.")
    if body.name != name:
        raise HTTPException(400, "The name in the body must match the copy.")

    def make():
        st = _status()
        if st.get("running") or _starting(st, time.time()):
            raise HTTPException(409, "A backup is running. Wait for it to finish.")
        if _check_lock.locked():
            raise HTTPException(409, "A copy is being checked. Try again in a moment.")
        if not st.get("dest_ready"):
            raise HTTPException(409, "The backup destination is not connected.")
        cs = _copies(st)
        if name not in {c["name"] for c in cs}:
            raise HTTPException(404, "No such backup.")
        if len(cs) <= 1:
            raise HTTPException(409, "This is the only backup copy, so it cannot be deleted from the phone. Make a new backup first.")
        r = backup.run("delete", name)
        audit(user, request.client.host, "backup_delete", target=name, ok=(r.returncode == 0), **_who(request))
        if r.returncode != 0 and "no such backup" in ((r.stderr or "") + (r.stdout or "")):
            raise HTTPException(404, "No such backup.")
        backup.must(r)
        return 200, {"deleted": name, "remaining": len(cs) - 1}
    return idempotent(request, user, "backup_delete:" + name, {"name": body.name}, make)


@router.post("/backups/run")
def run_backup(request: Request, user: str = Depends(current_user)):
    """Starts a backup now. Needs an Idempotency-Key. 409 when one is already running or just starting."""
    require(request, user, "backup_run")

    def make():
        st = _status()
        now = time.time()
        if st.get("running") or _starting(st, now):
            raise HTTPException(409, "A backup is already running.")
        if not st.get("dest_ready"):
            raise HTTPException(409, "The backup destination is not connected, so a backup cannot start.")
        r = backup.run("start")
        audit(user, request.client.host, "backup_start", ok=(r.returncode == 0), **_who(request))
        backup.must(r)
        _pending["t"] = time.time()
        for _ in range(10):                                  # a moment for the helper to take its lock, so the answer is the real state
            time.sleep(0.3)
            if _status().get("running"):
                break
        st = _status()
        return 202, {"started": True, "state": "running" if st.get("running") else "starting"}
    return idempotent(request, user, "backup_run", {}, make)


@router.post("/backups/cancel")
def cancel_backup(request: Request, user: str = Depends(current_user)):
    """Stops the running backup safely (the unfinished file is removed, finished copies and the last result are untouched).
    409 when nothing is running or the run was started from a terminal."""
    require(request, user, "backup_run")

    def make():
        st = _status()
        if not st.get("running"):
            raise HTTPException(409, "The backup is still starting. Try again in a few seconds." if _starting(st, time.time()) else "No backup is running.")
        r = backup.run("cancel", timeout=150)
        audit(user, request.client.host, "backup_cancel", ok=(r.returncode == 0), **_who(request))
        if r.returncode in (3, 4):
            raise HTTPException(409, ((r.stderr or "").strip() or "The backup cannot be cancelled.")[:200])
        if r.returncode != 0:
            raise HTTPException(502, ((r.stderr or r.stdout).strip() or "The backup did not stop.")[:200])
        _pending["t"] = 0.0
        return 200, {"cancelled": True}
    return idempotent(request, user, "backup_cancel", {}, make)
