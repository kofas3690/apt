"""The switch that lets administrators edit command presets from the phone app (web panel, administrators only).

Presets are commands that run as root, so a phone that could define them would be a powerful thing to lose. The editor in the
phone app therefore stays OFF until an administrator turns it on here, in the web panel. The phone can never reach this route
(roles.py: it lives under /api/presetsadmin, which is ADMIN_ONLY and denied to phones). If the setting cannot be read the answer
is "off": an unreadable switch must never open anything."""
from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel
import store
from auth import current_user
from audit import audit

router = APIRouter(prefix="/api/presetsadmin/phone")

with store._lock:
    store._conn.execute("CREATE TABLE IF NOT EXISTS presets_phone_edit (id INTEGER PRIMARY KEY CHECK (id = 1), enabled INTEGER NOT NULL)")
    store._conn.commit()


def enabled():
    try:
        with store._lock:
            r = store._conn.execute("SELECT enabled FROM presets_phone_edit WHERE id=1").fetchall()
            store._conn.commit()
        return bool(r and r[0][0])
    except Exception:
        return False


class Body(BaseModel):
    enabled: bool


@router.get("")
def get_flag(user: str = Depends(current_user)):
    return {"enabled": enabled()}


@router.put("")
def set_flag(body: Body, request: Request, user: str = Depends(current_user)):
    with store._lock:
        store._conn.execute("INSERT OR REPLACE INTO presets_phone_edit (id, enabled) VALUES (1, ?)", (int(body.enabled),))
        store._conn.commit()
    audit(user, request.client.host, "presets_phone_edit", enabled=bool(body.enabled))
    return {"enabled": enabled()}
