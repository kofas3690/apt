"""Kernel settings: show and change a fixed list of kernel (sysctl) settings.

A root helper only accepts the listed keys, each with its own allowed values, applies a change at once and saves it in
/etc/sysctl.d/90-adminpanel.conf so that it survives a reboot.
"""
import json, subprocess
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from auth import current_user
from audit import audit

router = APIRouter(prefix="/api/sysctl")

HELPER = "/usr/local/sbin/adminpanel-sysctl"
SUDO = "/usr/bin/sudo"
ENV = {"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LC_ALL": "C"}
KEY = r"^[a-z0-9_.-]{1,60}$"


class Change(BaseModel):
    key: str = Field(pattern=KEY)
    value: int = Field(ge=0, le=999999999)


class Forget(BaseModel):
    key: str = Field(pattern=KEY)


def run(*args):
    try:
        r = subprocess.run([SUDO, "-n", HELPER, *args], capture_output=True, text=True, errors="replace", timeout=30,
                           env=ENV, stdin=subprocess.DEVNULL)
    except subprocess.TimeoutExpired:
        raise HTTPException(504, "The helper took too long")
    if r.returncode != 0:
        raise HTTPException(400, ((r.stderr or r.stdout).strip() or "The kernel settings helper failed")[:300])
    return r


@router.get("")
def listing(user: str = Depends(current_user)):
    try:
        return json.loads(run("list").stdout)
    except ValueError:
        raise HTTPException(500, "The kernel settings helper returned something unexpected")


@router.post("/set")
def set_value(body: Change, request: Request, user: str = Depends(current_user)):
    try:
        run("set", body.key, str(body.value))
    except HTTPException:
        audit(user, request.client.host, "sysctl_set", target=body.key, ok=False)
        raise
    audit(user, request.client.host, "sysctl_set", target=body.key, ok=True, value=body.value)
    return {"ok": True}


@router.post("/forget")
def forget(body: Forget, request: Request, user: str = Depends(current_user)):
    try:
        run("forget", body.key)
    except HTTPException:
        audit(user, request.client.host, "sysctl_forget", target=body.key, ok=False)
        raise
    audit(user, request.client.host, "sysctl_forget", target=body.key, ok=True)
    return {"ok": True}
