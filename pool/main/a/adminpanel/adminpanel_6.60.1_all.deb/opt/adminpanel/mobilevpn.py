"""Quick VPN status for the phone: GET /api/mobile/v1/vpn (docs/mobile-api-v1.md, section 25).

Read only. It shapes what the web page's own status (network.easy_view, the same code the VPN page uses) reports into what
the phone needs: is the VPN on, which devices and servers are connected right now, and is anything wrong with it.
Changing the VPN (turning it on, adding a device, making a join code) stays on the web panel: each of those asks for the
password and 2FA code again and hands out keys, so it is not offered from the phone.
  * every role may read it (`view`), as on the web page
  * never keys (not even public ones), never the sign-in address list, never firewall rule text
  * each problem comes as a short sentence and the web page that fixes it, so the phone never needs to know the rules"""
from fastapi import Depends, HTTPException, Request
import network
from auth import current_user
from mobileapi import router, reply, require

MAX_LIST = 250                      # the helper allows 250 peers on one interface
WHERE = "Networking, Configuration, VPN"


def _int(v):
    return int(v) if isinstance(v, (int, float)) and not isinstance(v, bool) and v >= 0 else 0


def _ago(v):
    return int(v) if isinstance(v, (int, float)) and not isinstance(v, bool) and v >= 0 else None


def _peer(v, kind, panel_port):
    addr = v.get("address") if isinstance(v.get("address"), str) else ""
    return {"name": str(v.get("label") or kind)[:64], "address": addr, "online": bool(v.get("online")),
            "seen_ago": _ago(v.get("handshake_ago")), "rx": _int(v.get("rx")), "tx": _int(v.get("tx")),
            "this_phone": bool(v.get("you")),
            "panel_url": f"https://{addr}:{panel_port}/" if kind == "server" and addr and panel_port else None}


def _access(v):
    """Who can reach the panel's port (6.44.0): {vpn_only, pending, port}; vpn_only is null when the firewall cannot be read."""
    vo = v.get("vpn_only") if isinstance(v.get("vpn_only"), dict) else None
    if vo is None:
        return {"vpn_only": None, "pending": False, "port": None}
    port = vo.get("port")
    return {"vpn_only": bool(vo.get("on")), "pending": bool(vo.get("pending")),
            "port": port if isinstance(port, int) and not isinstance(port, bool) and 0 < port < 65536 else None}


def problems(v):
    """What is wrong, in the order the web page shows it. Each item: {id, text, where}."""
    out = []

    def add(pid, text):
        out.append({"id": pid, "text": text, "where": WHERE})
    if not v.get("enabled"):
        return out
    role = v.get("role") or "hub"
    f = v.get("firewall") if isinstance(v.get("firewall"), dict) else None
    if v.get("pending"):
        add("pending", "A network change is waiting to be kept or undone on the web panel. Quick VPN is paused until then.")
    if not v.get("up"):
        add("tunnel_down", "The VPN is set up but its tunnel is not running on the server.")
    if role == "member":
        hub = v.get("hub") if isinstance(v.get("hub"), dict) else {}
        if not hub.get("online") and hub.get("handshake_ago") is None:
            add("never_connected", "This server has never reached the server that runs the VPN. Check the address in the join code and that "
                                   "server's UDP port, in its firewall and in its cloud provider's firewall.")
    else:
        if f and f.get("active") and not f.get("udp_open"):
            add("udp_closed", f"The firewall is not allowing UDP port {v.get('port')}, so devices cannot connect.")
        if not v.get("isolated"):
            add("unprotected", "This VPN was made before the rule that keeps devices from reaching anything but this server. Add the protection.")
        elif v.get("rules_ok") is False:
            add("rules_missing", "The VPN's protection rules are not active on this server. Press Repair.")
        if v.get("relay") and v.get("forwarding") is False:
            add("forwarding_off", "Forwarding for the VPN is off, so your devices cannot reach your other servers. Press Repair.")
        if v.get("relay") and f and f.get("active") and not f.get("relay_rule"):
            add("relay_rule_missing", "The firewall is missing the rule that lets VPN traffic pass between your devices and your servers. Press Repair.")
    s = v.get("signin")
    if isinstance(s, dict) and s.get("enabled") and not s.get("covered"):
        add("signin_blocks", f"\"Where people may sign in from\" does not include {v.get('subnet')}, so the panel refuses devices that come "
                             "through the VPN. Add it in Accounts, Panel access.")
    return out


def shape(v, panel_port):
    """The web page's status as the phone sees it."""
    if not v.get("available"):
        state = "unavailable"
    elif not v.get("enabled"):
        state = "off"
    else:
        state = "member" if v.get("role") == "member" else "hub"
    devices = [_peer(p, "device", panel_port) for p in (v.get("devices") or [])[:MAX_LIST] if isinstance(p, dict)]
    servers = [_peer(p, "server", panel_port) for p in (v.get("servers") or [])[:MAX_LIST] if isinstance(p, dict)]
    hub = None
    if state == "member":
        hv = v.get("hub") if isinstance(v.get("hub"), dict) else {}
        hub = {"endpoint": str(hv.get("endpoint") or "")[:120], "online": bool(hv.get("online")), "seen_ago": _ago(hv.get("handshake_ago"))}
    on = state in ("hub", "member")
    addr = v.get("address") if on and isinstance(v.get("address"), str) else None
    return {
        "state": state, "kernel": v.get("kernel") if v.get("kernel") in (True, False) else None,
        "up": bool(v.get("up")) if on else False, "pending": bool(v.get("pending")),
        "address": addr, "subnet": v.get("subnet") if on else None, "port": v.get("port") if on else None,
        "panel_url": f"https://{addr}:{panel_port}/" if addr and panel_port else None,
        "via_vpn": bool(v.get("via_vpn")) if on else False,
        "devices": devices, "servers": servers, "hub": hub,
        "counts": {"devices": len(devices), "devices_online": sum(1 for p in devices if p["online"]),
                   "servers": len(servers), "servers_online": sum(1 for p in servers if p["online"]),
                   "max_devices": _int(v.get("max_devices")), "max_servers": _int(v.get("max_servers"))},
        "problems": problems(v),
        "panel_access": _access(v) if on else None,
        "where": WHERE,
    }


@router.get("/vpn")
def vpn(request: Request, user: str = Depends(current_user)):
    require(request, user, "view")
    panel_port = request.url.port or 443
    try:
        v = network.easy_view(request, user, panel_port)
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(502, "The panel could not read the VPN status right now.")
    return reply(request, shape(v, panel_port))
