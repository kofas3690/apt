"""Alert center for the phone app: a log of things that happened, plus who has read what.

The panel's alert engine (alerts.py) only knows what is wrong *right now*. This module watches it and writes an
event whenever something new goes wrong (and a calmer "ok" event when a failed service recovers), so a phone can
show a history, an unread count and deep links, and a background check on the phone can find out what is new
since it last looked. Events use the shape in docs/mobile-api-v1.md (section 7).

  * The log keeps the newest 2000 events or 30 days, whichever is less.
  * Read state, filters and device registration belong to one phone (or one browser person); a revoked phone's
    state is deleted with it, so a revoked phone receives nothing.
  * Delivery is "poll": the app asks for what is new since its last event, about every 15 minutes. Since 6.48.0 a phone
    can also register "unifiedpush" with an address from the ntfy app, and the panel wakes it the moment an event it
    wants is recorded (mobilewake.py); it still asks for the details the same way.
  * Events never carry tokens, passwords, certificate fingerprints or file contents."""
import hashlib, re, threading, time
from urllib.parse import urlsplit
from typing import List, Literal, Optional
from fastapi import Depends, HTTPException, Query, Request
from pydantic import BaseModel, Field
import store
from audit import audit
from auth import current_user
from mobileapi import router, reply, LIMITS

KEEP_EVENTS, KEEP_DAYS = 2000, 30
SWEEP_EVERY, UPDATES_EVERY = 30, 600
PROVIDERS = ("poll", "unifiedpush")
POLL_SECONDS = 900
RANK = {"ok": 1, "info": 1, "warning": 2, "critical": 3}
SEV = ("critical", "warning", "info", "ok")
state = store.PersistentDict("mobile_event_state")
_sweep_lock = threading.Lock()
_last = {"sweep": 0.0, "updates": 0.0}

with store._lock:
    store._conn.executescript("""
CREATE TABLE IF NOT EXISTS events (seq INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, type TEXT NOT NULL, severity TEXT NOT NULL,
  title TEXT NOT NULL, detail TEXT NOT NULL, tkind TEXT, tname TEXT, screen TEXT, params TEXT, muted INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS event_read (owner TEXT NOT NULL, seq INTEGER NOT NULL, PRIMARY KEY (owner, seq));
CREATE TABLE IF NOT EXISTS event_dev (owner TEXT PRIMARY KEY, provider TEXT NOT NULL, platform TEXT, app_version TEXT, min_severity TEXT NOT NULL,
  types TEXT, generation INTEGER NOT NULL, updated INTEGER NOT NULL, last_poll INTEGER);
""")
    store._conn.commit()
    try:                                                      # panels from before 6.8.0 have no `muted` column
        store._conn.execute("ALTER TABLE events ADD COLUMN muted INTEGER NOT NULL DEFAULT 0")
        store._conn.commit()
    except Exception:
        pass
    for col in ("endpoint TEXT", "push_seq INTEGER"):          # 6.48.0: the UnifiedPush address and the newest event it was woken for
        try:
            store._conn.execute("ALTER TABLE event_dev ADD COLUMN " + col)
            store._conn.commit()
        except Exception:
            pass


def q(sql, args=()):
    with store._lock:
        cur = store._conn.execute(sql, args)
        rows = cur.fetchall()
        store._conn.commit()
        return rows


# ---- writing events ------------------------------------------------------------------------------------------

def emit(etype, severity, title, detail="", tkind=None, tname=None, screen=None, params=None):
    import json, mobilemaint
    try:       # during a muting maintenance window an event is still recorded, but marked held (no badge, no background delivery)
        muted = 1 if not etype.startswith("maintenance_") and mobilemaint.muting() else 0
    except Exception:
        muted = 0
    q("INSERT INTO events (ts, type, severity, title, detail, tkind, tname, screen, params, muted) VALUES (?,?,?,?,?,?,?,?,?,?)",
      (int(time.time()), etype, severity, title[:200], detail[:400], tkind, tname, screen, json.dumps(params) if params else None, muted))
    if not muted:
        try:
            import mobilewake
            mobilewake.poke()
        except Exception:
            pass


def classify(a):
    """alerts.py alert -> (type, target kind, target name, screen, params)"""
    kind, aid = a.get("kind"), a.get("id", "")
    if kind == "unit":
        return "service_failed", "service", a.get("unit"), "service", {"name": a.get("unit")}
    if kind == "backup":
        return ("backup_overdue" if aid in ("backup-stale", "backup-never") else "backup_grew" if aid == "backup-grew" else "backup_missing" if aid == "backup-copies-missing" else "backup_damaged" if aid == "backup-copy-damaged" else "backup_failed"), "backup", None, "backups", None
    if kind == "disk":
        return "disk_high", "host", aid.split(":", 1)[-1], "performance", {"metric": "disk"}
    if kind == "memory":
        return "memory_high", "host", None, "performance", {"metric": "memory"}
    if kind == "disk-health":
        return "disk_health", "host", aid.split(":", 1)[-1], "disks", None      # 6.55.0: opens the phone's Disk health screen
    if kind == "certificate":
        return "certificate_expiring", "host", None, None, None
    if kind == "vpn":
        t = {"vpn-down": "vpn_down", "vpn-unprotected": "vpn_unprotected", "vpn-panel-open": "vpn_panel_open", "vpn-link": "vpn_link_lost", "vpn-never": "vpn_link_lost",
             "vpn-forwarding": "vpn_relay_broken", "vpn-relay-rule": "vpn_relay_broken", "vpn-udp": "vpn_port_closed"}.get(aid)
        if aid.startswith("vpn-server:"):
            return "vpn_server_lost", "vpn_server", aid.split(":", 1)[1], "vpn", None
        return t or "vpn_problem", "host", None, "vpn", None
    return "alert", "host", None, None, None


def security_names():
    """Names of packages with a pending security update (a few seconds of work, so it runs every 10 minutes)."""
    import updates
    r = updates.subprocess.run(["/usr/bin/apt", "list", "--upgradable"], capture_output=True, text=True, timeout=60, env=updates.ENV)
    out = []
    for line in r.stdout.splitlines():
        m = updates.LINE.match(line)
        if m and "-security" in m[2]:
            out.append(m[1])
    return sorted(set(out))


def sweep(force=False):
    """Look at the machine and write events for what changed since the last look. Safe to call often."""
    now = time.time()
    if not force and now - _last["sweep"] < SWEEP_EVERY:
        return
    if not _sweep_lock.acquire(blocking=False):
        return
    try:
        _last["sweep"] = now
        _sweep_maintenance()
        _sweep_alerts()
        _sweep_reboot()
        _sweep_apt()
        if force or now - _last["updates"] >= UPDATES_EVERY:
            _last["updates"] = now
            _sweep_updates()
        _prune()
    finally:
        _sweep_lock.release()


def _sweep_maintenance():
    """Announce when a window starts or ends (these are never held), with how many alerts it held."""
    import mobilemaint
    try:
        cur = mobilemaint.active()
    except Exception:
        return
    cid = cur["id"] if cur else None
    prev = state.get("maint_id")
    if cid == prev:
        return
    if prev:
        w = mobilemaint.get(prev)
        n = mobilemaint.held(w) if w else 0
        emit("maintenance_ended", "info", "Maintenance finished",
             (f"{n} alert{'' if n == 1 else 's'} " + ("was" if n == 1 else "were") + " held during the window.") if n else "No alerts were held.",
             "host", None, "maintenance", None)
    if cid:
        why = f": {cur['reason']}" if cur["reason"] else ""
        emit("maintenance_started", "info", "Maintenance started" + why,
             "Expected alerts are held until the window ends." if cur["mute"] else "Alerts are not muted during this window.",
             "host", None, "maintenance", None)
    state["maint_id"] = cid


def _sweep_alerts():
    import alerts, mobilemaint
    try:
        _, active, _ = alerts.scan()
    except Exception:
        return                                  # could not look: change nothing, so nothing is reported falsely
    cur = {a["id"] + "|" + a["severity"]: a for a in active}
    prev = state.get("active")
    prev = prev if isinstance(prev, dict) else {}
    try:
        quiet = mobilemaint.muting()
    except Exception:
        quiet = False
    held = set(state.get("muted_keys") or [])
    if not quiet and held:
        for k in held:
            prev.pop(k, None)           # first seen while held: if it is still active now, it is announced now
        held = set()
    for k, a in cur.items():
        if k not in prev:
            t, tk, tn, sc, pr = classify(a)
            emit(t, a["severity"], a["title"], a.get("detail", ""), tk, tn, sc, pr)
            if quiet:
                held.add(k)
    state["muted_keys"] = sorted(held)
    for k, old in prev.items():
        if k not in cur and (old.get("type") or "").startswith("vpn_"):
            if any(k2.split("|")[0] == k.split("|")[0] for k2 in cur):
                continue                                                        # same alert, other severity
            back = {"vpn_server_lost": "is back on the VPN", "vpn_link_lost": "VPN link is back", "vpn_down": "The VPN is running again",
                    "vpn_panel_open": "The panel is reachable only through the VPN again"}.get(old["type"])
            title = (f"Server {old.get('label') or old.get('name')} {back}" if old["type"] == "vpn_server_lost" else back or "VPN problem cleared")
            emit("vpn_recovered", "ok", title, "Cleared: " + old["title"], "host", None, "vpn", None)
            continue
        if k not in cur and old.get("type") in ("service_failed", "backup_failed"):
            still = any(k2.split("|")[0] == k.split("|")[0] for k2 in cur)      # same alert, other severity: not recovered
            if still:
                continue
            if old["type"] == "service_failed":
                emit("service_recovered", "ok", old["title"].replace(" has failed", "") + " is running again", "", "service", old.get("name"), "service", {"name": old.get("name")})
            else:
                emit("backup_succeeded", "ok", "Backup problem cleared", "", "backup", None, "backups", None)
    state["active"] = {k: {"title": a["title"], "type": classify(a)[0], "name": classify(a)[2],
                           **({"label": a["title"][len("Server "):-len(" lost its VPN link")]} if a.get("id", "").startswith("vpn-server:") else {})}
                       for k, a in cur.items()}


APT_HELD_AFTER = 1800          # 6.58.0: tell phones when apt has been held this long by someone who must act
APT_TITLES = {"stopped": "{prog} is paused and holding apt ({age})", "waiting": "{prog} is waiting for an answer and holding apt ({age})",
              "busy": "{prog} has held apt's lock for {age}"}


def _apt_age(s):
    return f"{s // 60} min" if s < 7200 else f"{s // 3600} h {s % 3600 // 60} min"


def _sweep_apt():
    """One warning when a program has held apt for 30 minutes while it needs a person (paused with Ctrl+Z, waiting for an
    answer, or another program holding a lock), and one ok event when apt is free of it again. Automatic updates, the
    panel's own job, and a program that is installing or downloading are left alone: they end by themselves."""
    try:
        import aptbusy
        rows = aptbusy.scan()
    except Exception:
        return
    told = state.get("apt_held") or {}
    if not isinstance(told, dict):
        told = {}
    now = {}
    for x in rows:
        key = f"{x.get('pid')}:{x.get('program')}:{x.get('command', '')[:60]}"
        if key in told:                   # already told; it may have moved on (answered, now installing): free only when gone
            now[key] = told[key]
            continue
        k, sec = x.get("kind"), x.get("seconds")
        if k not in APT_TITLES or (k == "busy" and not x.get("locks")):
            continue
        if not isinstance(sec, int) or sec < APT_HELD_AFTER:
            continue
        where = f" in terminal {x['tty']}" if x.get("tty") else ""
        who = f", started by {x['started_by']}" if x.get("started_by") and x.get("started_by") != x.get("user") else ""
        title = APT_TITLES[k].format(prog=x.get("program") or "A program", age=_apt_age(sec))
        detail = f"{x.get('program')}{where} (process {x.get('pid')}{who}): {x.get('command', '')[:120]}. {x.get('hint', '')} Updates wait until it is done."
        emit("apt_held", "warning", title, detail, "host", None, "updates", None)
        now[key] = {"program": x.get("program"), "tty": x.get("tty", "")}
    for key, v in told.items():
        if key not in now:
            where = f" in terminal {v.get('tty')}" if isinstance(v, dict) and v.get("tty") else ""
            prog = v.get("program") if isinstance(v, dict) else "apt"
            emit("apt_free", "ok", "apt is free again", f"{prog}{where} has ended. Updates can run.", "host", None, "updates", None)
    state["apt_held"] = now


def _sweep_reboot():
    import reboot
    try:
        r = reboot.info()
    except Exception:
        return
    was = state.get("reboot") is True
    if r.get("required") and not was:
        pk = ", ".join((r.get("packages") or [])[:5])
        emit("reboot_required", "info", "A restart is needed", ("Because of: " + pk) if pk else "Updates are installed but not fully in effect until the machine restarts.", "host", None, "updates", None)
    state["reboot"] = bool(r.get("required"))


def _sweep_updates():
    try:
        names = security_names()
    except Exception:
        return
    key = hashlib.sha256(",".join(names).encode()).hexdigest()[:16] if names else ""
    prev = state.get("security") or ""
    if names and key != prev:
        more = f" and {len(names) - 5} more" if len(names) > 5 else ""
        emit("security_updates", "warning", f"{len(names)} security update" + ("" if len(names) == 1 else "s") + " available",
             ", ".join(names[:5]) + more, "update", None, "updates", None)
    elif not names and prev:
        emit("updates_installed", "ok", "Security updates installed", "", "update", None, "updates", None)
    state["security"] = key


def _prune():
    q("DELETE FROM events WHERE ts < ?", (int(time.time()) - KEEP_DAYS * 86400,))
    q("DELETE FROM events WHERE seq <= (SELECT COALESCE(MAX(seq), 0) - ? FROM events)", (KEEP_EVENTS,))
    q("DELETE FROM event_read WHERE seq NOT IN (SELECT seq FROM events)")


def watcher():
    time.sleep(20)
    while True:
        try:
            sweep(force=True)
        except Exception:
            pass
        try:                    # a phone woken through UnifiedPush wants to hear soon, so look twice as often then
            import mobilewake
            fast = mobilewake.any_registered()
        except Exception:
            fast = False
        time.sleep(SWEEP_EVERY if fast else 60)


def start():
    threading.Thread(target=watcher, name="mobile-events", daemon=True).start()
    import mobilewake
    mobilewake.start()


def forget(owner):
    """A phone was unpaired or its person removed: its read state and registration go too."""
    q("DELETE FROM event_read WHERE owner=?", (owner,))
    q("DELETE FROM event_dev WHERE owner=?", (owner,))


# ---- reading -------------------------------------------------------------------------------------------------

def who(request, user):
    ph = getattr(request.state, "phone", None)
    return ph["id"] if ph else "web:" + user


def seq_of(s):
    m = re.search(r"(\d{1,12})$", str(s or ""))
    return int(m.group(1)) if m else 0


def view(row, read):
    import json
    seq, ts, t, sev, title, detail, tk, tn, sc, pr, muted = row
    return {"id": f"evt_{seq:06d}", "type": t, "severity": sev, "title": title, "detail": detail,
            "target": {"kind": tk, "name": tn} if tk else None,
            "deep_link": {"screen": sc, "params": json.loads(pr) if pr else {}} if sc else None,
            "created": ts, "actor": None, "result": None, "request_id": None, "read": bool(read), "muted": bool(muted)}


def counts(owner):
    unread = q("SELECT COUNT(*), COALESCE(SUM(severity='critical'),0) FROM events e WHERE e.muted=0 AND NOT EXISTS (SELECT 1 FROM event_read r WHERE r.owner=? AND r.seq=e.seq)", (owner,))[0]
    latest = q("SELECT COALESCE(MAX(seq),0) FROM events")[0][0]
    return {"unread": unread[0], "unread_critical": int(unread[1]), "latest_seq": latest}


def pref_where(min_severity, types_json):
    """The WHERE parts (and their values) for what a phone said it wants: not held, at least its level, its types."""
    import json
    where, args = ["e.muted = 0"], []
    floor = RANK.get(min_severity, 1)
    allowed = [s for s in SEV if RANK[s] >= floor]
    where.append("e.severity IN (%s)" % ",".join("?" * len(allowed))); args += allowed
    if types_json:
        pt = json.loads(types_json)
        where.append("e.type IN (%s)" % ",".join("?" * len(pt)) if pt else "0"); args += pt
    return where, args


def device_row(owner):
    r = q("SELECT provider, platform, app_version, min_severity, types, generation, updated FROM event_dev WHERE owner=?", (owner,))
    return r[0] if r else None


def device_view(owner):
    import json
    r = device_row(owner)
    base = {"providers_available": list(PROVIDERS), "poll_interval_seconds": POLL_SECONDS}
    if not r:
        return {"registered": False, **base}
    ep = q("SELECT endpoint FROM event_dev WHERE owner=?", (owner,))
    host = urlsplit(ep[0][0]).hostname if ep and ep[0][0] else None
    return {"registered": True, "provider": r[0], "platform": r[1], "app_version": r[2], "min_severity": r[3],
            "types": json.loads(r[4]) if r[4] else None, "generation": r[5], "updated": r[6], "push_server": host, **base}


@router.get("/notifications")
def notifications(request: Request, user: str = Depends(current_user), severity: str = "", etype: str = Query("", alias="type"),
                  unread: bool = False, after: str = "", cursor: str = "", for_me: bool = False,
                  limit: int = Query(LIMITS["page_default"], ge=1, le=LIMITS["page_max"])):
    """Newest first (with `cursor` to go further back), or oldest first from `after` (what a background check uses).
    `for_me=true` applies this phone's registered preferences."""
    sweep()
    owner = who(request, user)
    where, args = [], [owner]
    sevs = [s for s in severity.split(",") if s]
    if any(s not in SEV for s in sevs):
        raise HTTPException(400, "severity must be a comma list of: " + ", ".join(SEV))
    if sevs:
        where.append("e.severity IN (%s)" % ",".join("?" * len(sevs))); args += sevs
    types = [t for t in etype.split(",") if t]
    if any(not re.fullmatch(r"[a-z_]{1,40}", t) for t in types):
        raise HTTPException(400, "type must be a comma list of event types")
    if types:
        where.append("e.type IN (%s)" % ",".join("?" * len(types))); args += types
    if unread:
        where.append("NOT EXISTS (SELECT 1 FROM event_read r WHERE r.owner=? AND r.seq=e.seq)"); args.append(owner)
    if for_me:
        d = device_row(owner)               # held alerts are never delivered to a phone's background check
        w, a = pref_where(d[3], d[4]) if d else (["e.muted = 0"], [])
        where += w; args += a
    poll = bool(after)
    if poll:
        where.append("e.seq > ?"); args.append(seq_of(after))
        q("UPDATE event_dev SET last_poll=? WHERE owner=?", (int(time.time()), owner))
    elif cursor:
        where.append("e.seq < ?"); args.append(seq_of(cursor))
    sql = ("SELECT e.seq, e.ts, e.type, e.severity, e.title, e.detail, e.tkind, e.tname, e.screen, e.params, e.muted, "  # nosec B608: the text is built from fixed pieces and limit is an int checked to 1..100; every value is bound
           "EXISTS (SELECT 1 FROM event_read r WHERE r.owner=? AND r.seq=e.seq) FROM events e"
           + (" WHERE " + " AND ".join(where) if where else "") + f" ORDER BY e.seq {'ASC' if poll else 'DESC'} LIMIT {limit + 1}")
    rows = q(sql, args)           # args[0] is the owner for the read flag, the rest belong to the WHERE parts
    more = len(rows) > limit
    rows = rows[:limit]
    items = [view(r[:11], r[11]) for r in rows]
    nxt = f"evt_{rows[-1][0]:06d}" if more and rows else None
    return reply(request, {"items": items, "next_cursor": nxt, **counts(owner)})


@router.get("/notifications/unread-count")
def unread_count(request: Request, user: str = Depends(current_user)):
    sweep()
    return reply(request, counts(who(request, user)))


class ReadBody(BaseModel):
    ids: List[str] = Field(default_factory=list, max_length=200)
    up_to: Optional[str] = Field(None, max_length=40)
    all: bool = False


@router.post("/notifications/read")
def mark_read(body: ReadBody, request: Request, user: str = Depends(current_user)):
    owner = who(request, user)
    if body.all or body.up_to:
        top = None if body.all else seq_of(body.up_to)
        q("INSERT OR IGNORE INTO event_read (owner, seq) SELECT ?, seq FROM events" + ("" if top is None else " WHERE seq <= ?"), (owner,) if top is None else (owner, top))  # nosec B608: fixed text; every value is bound
    for i in body.ids:
        s = seq_of(i)
        if s:
            q("INSERT OR IGNORE INTO event_read (owner, seq) SELECT ?, seq FROM events WHERE seq=?", (owner, s))
    return reply(request, counts(owner))


class DeviceBody(BaseModel):
    provider: str = Field("poll", max_length=20)
    platform: str = Field("android", pattern=r"^[a-z]{2,12}$")
    app_version: str = Field("", max_length=20)
    endpoint: Optional[str] = Field(None, max_length=300)       # unifiedpush only: the address from the ntfy app


@router.post("/notifications/devices")
def register(body: DeviceBody, request: Request, user: str = Depends(current_user)):
    import mobilewake
    if body.provider not in PROVIDERS:
        raise HTTPException(400, "This panel delivers notifications by: " + ", ".join(PROVIDERS))
    endpoint = None
    if body.provider == mobilewake.PROVIDER:
        if not getattr(request.state, "phone", None):
            raise HTTPException(400, "Only a paired phone can register for instant alerts")
        try:
            endpoint = mobilewake.check_endpoint(body.endpoint)
        except ValueError as e:
            raise HTTPException(400, str(e))
    elif body.endpoint:
        raise HTTPException(400, "A push address is only used with the unifiedpush provider")
    owner = who(request, user)
    old = device_row(owner)
    latest = q("SELECT COALESCE(MAX(seq),0) FROM events")[0][0]      # wake only for what happens from now on
    q("INSERT INTO event_dev (owner, provider, platform, app_version, min_severity, types, generation, updated, endpoint, push_seq) VALUES (?,?,?,?,?,?,?,?,?,?) "
      "ON CONFLICT(owner) DO UPDATE SET provider=excluded.provider, platform=excluded.platform, app_version=excluded.app_version, generation=generation+1, "
      "updated=excluded.updated, endpoint=excluded.endpoint, "
      "push_seq=CASE WHEN event_dev.endpoint IS excluded.endpoint THEN event_dev.push_seq ELSE excluded.push_seq END",   # the same address again (app start) keeps its place
      (owner, body.provider, body.platform, body.app_version, "info", None, 1, int(time.time()), endpoint, latest))
    audit(user, request.client.host, "notify_device_registered", phone=owner, provider=body.provider, again=bool(old),
          **({"push_server": urlsplit(endpoint).hostname} if endpoint else {}))
    return reply(request, device_view(owner))


@router.get("/notifications/devices/me")
def my_device(request: Request, user: str = Depends(current_user)):
    return reply(request, device_view(who(request, user)))


@router.delete("/notifications/devices/me")
def unregister(request: Request, user: str = Depends(current_user)):
    owner = who(request, user)
    q("DELETE FROM event_dev WHERE owner=?", (owner,))
    audit(user, request.client.host, "notify_device_removed", phone=owner)
    return reply(request, device_view(owner))


class PrefBody(BaseModel):
    min_severity: Literal["info", "warning", "critical"] = "info"
    types: Optional[List[str]] = Field(None, max_length=40)


@router.put("/notifications/preferences")
def set_prefs(body: PrefBody, request: Request, user: str = Depends(current_user)):
    import json
    owner = who(request, user)
    if not device_row(owner):
        raise HTTPException(409, "Register this phone for notifications first.")
    if body.types is not None and any(not re.fullmatch(r"[a-z_]{1,40}", t) for t in body.types):
        raise HTTPException(400, "Invalid event type in the list")
    q("UPDATE event_dev SET min_severity=?, types=?, updated=? WHERE owner=?",
      (body.min_severity, json.dumps(sorted(set(body.types))) if body.types is not None else None, int(time.time()), owner))
    audit(user, request.client.host, "notify_prefs", phone=owner, min_severity=body.min_severity, types=len(body.types) if body.types is not None else "all")
    return reply(request, device_view(owner))
