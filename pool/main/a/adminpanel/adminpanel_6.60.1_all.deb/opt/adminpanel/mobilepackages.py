"""Software from the phone (6.47.0): search, see what a change would do, and install or remove a package.
GET /api/mobile/v1/packages, /packages/plan; POST /packages/run (docs/mobile-api-v1.md, section 26).

Installing software runs as root, so this is the strictest phone feature:
  * searching is open to every role (like the web Packages page)
  * planning and changing need the capability `packages_change`: an administrator, on a full (not read-only) phone, after an
    administrator switched "Software from the phone" on in the web panel (Packages page). An unreadable switch is "off".
  * while installing updates from a phone needs a second administrator's approval, software changes from the phone are off too:
    a package can do as much as an update, and the approval flow has no way to name a package
  * the change goes through the same root helper as the web page (adminpanel-apt install|remove NAME), which re-checks the name,
    refuses an install that would remove anything, and refuses removing what the machine needs (adminpanel, sudo, ssh, nginx,
    systemd, apt, the kernel...). The phone sees the plan from apt's own dry run before it confirms.
  * each change needs an Idempotency-Key, so a retry after a dropped connection never starts a second job, and is audited
  * progress is the same job the web page and the Updates screen follow: GET /api/updates/job"""
from typing import Literal
from fastapi import Depends, HTTPException, Request
from pydantic import BaseModel, Field
import store, packages
from audit import audit
from auth import current_user
from mobileapi import router, reply, require, idempotent

with store._lock:
    store._conn.execute("CREATE TABLE IF NOT EXISTS packages_phone (id INTEGER PRIMARY KEY CHECK (id = 1), enabled INTEGER NOT NULL)")
    store._conn.commit()


def enabled():
    """May administrators install and remove software from the phone? Off unless clearly on."""
    try:
        with store._lock:
            r = store._conn.execute("SELECT enabled FROM packages_phone WHERE id=1").fetchall()
            store._conn.commit()
        return bool(r and r[0][0])
    except Exception:
        return False


def set_enabled(on):
    with store._lock:
        store._conn.execute("INSERT OR REPLACE INTO packages_phone (id, enabled) VALUES (1, ?)", (int(bool(on)),))
        store._conn.commit()


def approval_on():
    try:
        import mobileapprovals
        return bool(mobileapprovals.required("updates_install"))
    except Exception:
        return True                     # unreadable policy: stay closed


def why_not():
    """Why software changes are off for an administrator's full phone, or None when they are on."""
    if not enabled():
        return "Installing and removing software from the phone is switched off. An administrator can switch it on in the web panel, on the Packages page."
    if approval_on():
        return ("Installing and removing software from the phone is off while installing updates from a phone needs a second "
                "administrator's approval. Use the web panel.")
    return None


def gate(request, user):
    """packages_change, and when an administrator's full phone is only held back by the switch or the approval rule, say which."""
    try:
        require(request, user, "packages_change")
    except HTTPException:
        try:
            require(request, user, "temp_access")      # true exactly for an administrator on a full phone
        except HTTPException:
            raise HTTPException(403, "Only an administrator on a full (not read-only) phone can install or remove software.")
        raise HTTPException(403, why_not() or "Installing and removing software from the phone is not available.")


@router.get("/packages")
def search(q: str, request: Request, user: str = Depends(current_user)):
    require(request, user, "view")
    d = packages.search(q, user)
    return reply(request, {"results": d["results"][:packages.MAX_RESULTS], "capped": d["capped"], "query": q.strip()})


@router.get("/packages/plan")
def plan(action: Literal["install", "remove"], name: str, request: Request, user: str = Depends(current_user)):
    gate(request, user)
    return reply(request, packages.plan(action, name, user))


class Change(BaseModel):
    action: Literal["install", "remove"]
    name: str = Field(min_length=2, max_length=100)


@router.post("/packages/run")
def run(body: Change, request: Request, user: str = Depends(current_user)):
    gate(request, user)
    if not packages.NAME_RE.fullmatch(body.name):
        raise HTTPException(400, "That is not a valid package name")

    def make():
        try:
            d = packages.run_change(packages.Change(action=body.action, name=body.name), request, user)
        except HTTPException as e:
            audit(user, request.client.host, "apt_phone_refused", kind=body.action, package=body.name, reason=str(e.detail)[:200])
            raise
        audit(user, request.client.host, "apt_phone", kind=body.action, package=body.name, job=d.get("id"))
        return 202, {"id": d.get("id"), "action": body.action, "name": body.name, "job": "/api/updates/job"}
    return idempotent(request, user, "packages:" + body.action, {"action": body.action, "name": body.name}, make)
