"""Volumes: Docker volumes on this machine. List them with their size and whether a container uses them, and remove a
volume that nothing uses. Removing a volume deletes its data for good, so the page asks for the name to be typed.

Docker access is the same as root, so everything goes through a root helper that allows only those two things, only for a
volume name Docker itself lists, and never forces a removal.
"""
import json, subprocess
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from auth import current_user
from audit import audit

router = APIRouter(prefix="/api/volumes")

HELPER = "/usr/local/sbin/adminpanel-volumes"
SUDO = "/usr/bin/sudo"
ENV = {"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LC_ALL": "C"}
NAME = r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$"


class Remove(BaseModel):
    name: str = Field(pattern=NAME)
    confirm: str = Field(max_length=200)


def run(*args, timeout=200):
    try:
        r = subprocess.run([SUDO, "-n", HELPER, *args], capture_output=True, text=True, errors="replace", timeout=timeout,
                           env=ENV, stdin=subprocess.DEVNULL)
    except subprocess.TimeoutExpired:
        raise HTTPException(504, "Docker took too long to answer")
    if r.returncode != 0:
        raise HTTPException(400, ((r.stderr or r.stdout).strip() or "The volumes helper failed")[:300])
    return r


@router.get("")
def listing(user: str = Depends(current_user)):
    try:
        return json.loads(run("list", timeout=220).stdout)
    except ValueError:
        raise HTTPException(500, "The volumes helper returned something unexpected")


@router.post("/remove")
def remove(body: Remove, request: Request, user: str = Depends(current_user)):
    if body.confirm != body.name:
        raise HTTPException(400, "The name you typed does not match the volume")
    try:
        run("remove", body.name, timeout=130)
    except HTTPException:
        audit(user, request.client.host, "volume_remove", target=body.name, ok=False)
        raise
    audit(user, request.client.host, "volume_remove", target=body.name, ok=True)
    return {"ok": True}
