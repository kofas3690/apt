"""Alerts about the Quick VPN (6.41.0), for the Alerts page, email, chat, push and the phone's alert list.

It reads the same status the VPN page shows (network.easy_view) and reports only what needs someone's attention:
  * the tunnel is set up but not running                                  critical
  * the protection rules are not active (devices could reach each other)  critical
  * a joined server lost its link to this hub (no handshake for 10 min)   warning
  * this server lost its link to the hub (no handshake for 10 min)        warning
  * this server joined but never reached the hub                          warning
  * forwarding or the firewall rule for the servers is missing            warning
  * the firewall blocks the VPN's UDP port                                warning
Phones and laptops going offline is normal and never raises an alert.

A problem must last a while before it is reported (see DELAY), so a change being applied (which briefly removes the rules
and the tunnel) never sends an alert. Nothing is reported while a network change is waiting to be kept, and nothing at all
when the status cannot be read: an alert must never be invented. The status is read at most once a minute."""
import threading, time, types

KEEP_FOR = 60                   # seconds a status reading is reused
LINK_LOST = 600                 # seconds without a handshake before a server's link counts as lost (keepalive is 25 s)
DELAY = {"vpn-down": 120, "vpn-unprotected": 120, "vpn-forwarding": 180, "vpn-relay-rule": 180, "vpn-udp": 180,
         "vpn-never": 300, "vpn-panel-open": 180}      # how long a problem must last before it is reported; link alerts are already 10 minutes old
LINK = "/vpn.html"
_lock = threading.Lock()
_cache = {"t": 0.0, "v": None}
_since = {}                     # alert id -> when it was first seen


def _read():
    """The VPN page's status, without a browser request behind it (no signed-in person, so no admin-only parts)."""
    import network
    req = types.SimpleNamespace(url=types.SimpleNamespace(hostname=""), client=types.SimpleNamespace(host="127.0.0.1"))   # never a VPN address
    return network.easy_view(req, None, None)


def status(now=None):
    now = time.time() if now is None else now
    with _lock:
        if _cache["v"] is not None and now - _cache["t"] < KEEP_FOR:
            return _cache["v"]
    v = _read()
    with _lock:
        _cache.update(t=now, v=v)
    return v


def problems(v):
    """Every VPN problem in the status `v`, before the waiting time is applied."""
    out = []

    def add(aid, sev, title, detail):
        out.append({"id": aid, "severity": sev, "kind": "vpn", "title": title, "detail": detail, "link": LINK})
    if not v.get("enabled") or not v.get("available"):
        return out
    role = v.get("role") or "hub"
    if not v.get("up"):
        add("vpn-down", "critical", "The VPN is not running",
            "Quick VPN is set up but its tunnel is not running on this server, so nothing can connect. Open the VPN page; "
            "the reason is usually in: journalctl -u systemd-networkd -n 20")
        return out                                  # everything else follows from this one
    if v.get("isolated") and v.get("rules_ok") is False:
        add("vpn-unprotected", "critical", "The VPN's protection rules are not active",
            "Devices on the VPN may be able to reach each other or what lies beyond the VPN. Press Repair on the VPN page.")
    f = v.get("firewall") if isinstance(v.get("firewall"), dict) else None
    vo = v.get("vpn_only") if isinstance(v.get("vpn_only"), dict) else None
    if vo and vo.get("wanted") and vo.get("on") is False and not vo.get("pending"):
        rules = "; ".join(str(x) for x in (vo.get("outside") or [])[:3]) or "a firewall rule"
        add("vpn-panel-open", "warning", "The panel is open to everyone again",
            f"It was set to be reachable only through the VPN, but port {vo.get('port')} is open outside it again ({rules}). If that was not you, "
            "check the Firewall page. To close it: VPN page, Panel access, Allow only the VPN. If it was on purpose, press Open to everyone again there.")
    if role == "member":
        hub = v.get("hub") if isinstance(v.get("hub"), dict) else {}
        ago = hub.get("handshake_ago")
        where = hub.get("endpoint") or "the server that runs it"
        if ago is None:
            add("vpn-never", "warning", "This server has never reached the VPN",
                f"It joined the VPN run by {where} but has not connected yet. Check that address and that server's UDP port, "
                "in its firewall and in its cloud provider's firewall.")
        elif ago >= LINK_LOST:
            add("vpn-link", "warning", "This server lost its link to the VPN",
                f"No contact with {where} for {ago // 60} minutes. Your devices cannot reach this server through the VPN until it is back.")
        return out
    for s in v.get("servers") or []:
        ago = s.get("handshake_ago")
        if isinstance(ago, (int, float)) and ago >= LINK_LOST:
            name = str(s.get("label") or "server")[:60]
            add("vpn-server:" + str(s.get("address", "")), "warning", f"Server {name} lost its VPN link",
                f"{name} ({s.get('address')}) has not been in contact for {int(ago) // 60} minutes. Its panel cannot be reached "
                "through the VPN until it is back. Is it running, and is its VPN on?")
    if v.get("relay") and v.get("forwarding") is False:
        add("vpn-forwarding", "warning", "VPN forwarding is off",
            "Your devices cannot reach your other servers through the VPN. Something switched forwarding off. Press Repair on the VPN page.")
    if v.get("relay") and f and f.get("active") and not f.get("relay_rule"):
        add("vpn-relay-rule", "warning", "The firewall rule for the VPN's servers is missing",
            "Your devices cannot reach your other servers through the VPN. Press Repair on the VPN page.")
    if f and f.get("active") and not f.get("udp_open"):
        add("vpn-udp", "warning", f"The firewall blocks the VPN's port (UDP {v.get('port')})",
            "Devices and servers cannot connect to the VPN. Open the port on the VPN page.")
    return out


def alerts(now=None):
    """The VPN alerts to report now. Never raises: a status that cannot be read gives no alerts."""
    now = time.time() if now is None else now
    try:
        v = status(now)
    except Exception:
        return []
    if v.get("pending"):
        return []                                   # a change is being tried: wait for it to be kept or undone
    found = problems(v)
    ids = {a["id"] for a in found}
    with _lock:
        for k in list(_since):
            if k not in ids:
                del _since[k]                       # it cleared: if it comes back, the wait starts again
        out = []
        for a in found:
            first = _since.setdefault(a["id"], now)
            if now - first >= DELAY.get(a["id"], 0):
                out.append(a)
    return out


def reset():
    with _lock:
        _cache.update(t=0.0, v=None)
        _since.clear()
