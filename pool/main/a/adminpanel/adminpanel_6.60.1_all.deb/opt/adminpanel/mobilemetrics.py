"""Performance history for the phone app: GET /api/mobile/v1/metrics/history.

The panel's sampler (metrics.py) already writes one row a minute for seven days. This module only reads it and shapes
the answer the phone needs (docs/mobile-api-v1.md, section 11):
  * ranges are fixed (1h, 6h, 24h, 7d), so the work and the size of the reply are bounded: at most 241 points
  * every timestamp is the panel's own clock (Unix seconds); the envelope's server_time says what "now" is on the panel
  * a metric the machine does not have (no temperature sensor in a VM) or could not read is null, never 0
  * min / average / max come from the raw one-minute samples, so a short spike is not averaged away
  * the reply says how much of the range was actually recorded (coverage) and whether the collector looks stuck,
    so the app can label old data as old instead of presenting it as live
Thresholds are the panel's own alert settings, returned for display only; the phone cannot change them."""
import os, time
import psutil
from fastapi import Depends, Query, Request
import alerts, metrics, store
from auth import current_user
from mobileapi import router, reply, require

RANGES = metrics.RANGES                  # {"1h": 3600, "6h": 21600, "24h": 86400, "7d": 604800}
POINTS = metrics.POINTS
COLS = {"cpu": "cpu", "mem": "mem", "disk": "disk", "load": "load1", "temp": "temp"}


def _r(v, n=1):
    return None if v is None else round(float(v), n)


def history(seconds, now=None):
    """Everything the performance screen needs for the last `seconds`, as plain data."""
    now = int(now if now is not None else time.time())
    since = now - seconds
    # whole minutes, rounded UP, so a range never has more than POINTS + 1 buckets (the first and last are partial)
    bucket = max(metrics.INTERVAL, -(-(seconds // POINTS) // metrics.INTERVAL) * metrics.INTERVAL)
    sel = ", ".join(f"AVG({c})" for c in COLS.values())
    with store._lock:
        rows = store._conn.execute(
            f"SELECT (ts / ?) * ? AS t, {sel}, MAX(cpu), group_concat(err) FROM metrics WHERE ts >= ? AND ts <= ? GROUP BY t ORDER BY t",  # nosec B608: column names come from the fixed COLS table; every value is bound
            (bucket, bucket, since, now)).fetchall()
        agg = ", ".join(f"MIN({c}), AVG({c}), MAX({c}), COUNT({c})" for c in COLS.values())
        s = store._conn.execute(f"SELECT COUNT(*), {agg} FROM metrics WHERE ts >= ? AND ts <= ?", (since, now)).fetchone()  # nosec B608: column names come from the fixed COLS table; every value is bound
        last = store._conn.execute(
            "SELECT ts, " + ", ".join(COLS.values()) + " FROM metrics WHERE ts <= ? ORDER BY ts DESC LIMIT 1", (now,)).fetchone()  # nosec B608: column names come from the fixed COLS table; every value is bound
        errs = store._conn.execute("SELECT COUNT(*) FROM metrics WHERE ts >= ? AND ts <= ? AND err IS NOT NULL", (since, now)).fetchone()[0]
    points = []
    for r in rows:
        p = {"t": r[0]}
        for i, k in enumerate(COLS):
            p[k] = _r(r[1 + i], 2 if k == "load" else 1)
        p["cpu_peak"] = _r(r[1 + len(COLS)])
        if r[2 + len(COLS)]:
            p["errors"] = sorted(set(r[2 + len(COLS)].split(",")))
        points.append(p)
    total, summary, available = s[0], {}, {}
    for i, k in enumerate(COLS):
        mn, av, mx, n = s[1 + 4 * i: 5 + 4 * i]
        available[k] = n > 0
        summary[k] = None if n == 0 else {"min": _r(mn, 2 if k == "load" else 1), "avg": _r(av, 2 if k == "load" else 1),
                                          "max": _r(mx, 2 if k == "load" else 1), "samples": n}
    expected = max(1, seconds // metrics.INTERVAL)
    cur = None
    if last:
        cur = {"sample_at": last[0], "age_seconds": max(0, now - last[0])}
        for i, k in enumerate(COLS):
            cur[k] = _r(last[1 + i], 2 if k == "load" else 1)
    try:
        l1, l5, l15 = os.getloadavg()
        load_avg = [round(l1, 2), round(l5, 2), round(l15, 2)]
    except (OSError, AttributeError):
        load_avg = None
    cfg = alerts.settings()
    last_ok = metrics.status["last_ok"] or (last[0] if last else None)
    return {
        "from": since, "to": now, "step_seconds": bucket, "points": points, "summary": summary, "available": available,
        "current": cur,
        "host": {"cores": psutil.cpu_count() or None, "uptime_seconds": max(0, int(now - psutil.boot_time())), "load_average": load_avg},
        "thresholds": {"cpu": None, "load": None, "temp": None,
                       "mem": {"warning": cfg["mem_warn"], "critical": None},
                       "disk": {"warning": cfg["disk_warn"], "critical": cfg["disk_crit"]}},
        "coverage": {"samples": total, "expected": expected, "ratio": round(min(1.0, total / expected), 3)},
        "collector": {"interval_seconds": metrics.INTERVAL, "last_sample_at": last_ok,
                      "stale": last_ok is None or now - last_ok > 3 * metrics.INTERVAL,
                      "samples_with_errors": errs, "failures_since_start": metrics.status["failures"],
                      "last_error": metrics.status["last_error"]},
        "retention_seconds": metrics.KEEP,
    }


@router.get("/metrics/history")
def metrics_history(request: Request, user: str = Depends(current_user), range: str = Query("24h", pattern=r"^(1h|6h|24h|7d)$")):
    """The last 1 hour, 6 hours, 24 hours or 7 days of CPU, memory, disk, load average and temperature (where the
    machine has a sensor). Allowed for every role: it shows what the Overview graphs already show."""
    require(request, user, "view")
    return reply(request, {"range": range, **history(RANGES[range])})
