"""Command presets for the phone app: /api/mobile/v1/presets (docs/mobile-api-v1.md, section 16).

An administrator defines presets in the root-owned file /etc/adminpanel/presets.json on the server. The phone can list them and
ask for one to run BY ID. It can never send a command or an argument: the root helper adminpanel-presets re-reads the file,
re-checks the entry and runs its stored argument list (no shell, 25 seconds at most).

  * Listing needs `view`; running needs `presets_run` (operators and admins on a full phone) and an Idempotency-Key.
    A preset marked "admin_only" runs only for admins.
  * One preset runs at a time (409 otherwise). Every run is written to the audit log with the phone and request ID.
  * The output (at most 4 KB) comes back to the phone. It is whatever the administrator's command prints."""
import json, subprocess, threading
from fastapi import Depends, HTTPException, Request
from audit import audit
import auth, roles
import presetsadmin
from auth import current_user
from mobileapi import router, reply, require, idempotent

HELPER = "/usr/local/sbin/adminpanel-presets"
_run_lock = threading.Lock()


def helper(*args, timeout=40):
    """Runs the root helper. Returns its parsed JSON, or raises HTTPException with a plain reason."""
    try:
        r = subprocess.run(["sudo", "-n", HELPER, *args], capture_output=True, text=True, timeout=timeout, stdin=subprocess.DEVNULL)
    except (OSError, subprocess.TimeoutExpired):
        raise HTTPException(503, "The presets helper did not answer.")
    if r.returncode == 3:
        raise HTTPException(404, "No such preset.")
    if r.returncode != 0:
        raise HTTPException(503, (r.stderr or "").strip()[:200] or "The presets could not be read.")
    try:
        return json.loads(r.stdout)
    except ValueError:
        raise HTTPException(503, "The presets helper answered something unexpected.")


def _who(request):
    ph = getattr(request.state, "phone", None)
    return {"via": "phone" if ph else "browser", "phone": ph["id"] if ph else None, "request_id": request.state.request_id}


def _role(request, user):
    ph = getattr(request.state, "phone", None)
    role = roles.role_of(auth.load_users().get(user))
    return "viewer" if (ph and ph["ro"] and role) else role


@router.get("/presets")
def listing(request: Request, user: str = Depends(current_user)):
    require(request, user, "view")
    role = _role(request, user)
    data = helper("list")
    can = role in ("operator", "admin")
    items = [{**p, "can_run": bool(can and (role == "admin" or not p.get("admin_only")))} for p in data.get("presets", [])]
    return reply(request, {"presets": items, "skipped": int(data.get("skipped", 0)), "max_seconds": 25})


@router.post("/presets/{pid}/run")
def run_one(pid: str, request: Request, user: str = Depends(current_user)):
    require(request, user, "presets_run")
    role = _role(request, user)

    def make():
        data = helper("list")
        p = next((x for x in data.get("presets", []) if x["id"] == pid), None)
        if p is None:
            raise HTTPException(404, "No such preset.")
        if p.get("admin_only") and role != "admin":
            audit(user, request.client.host, "preset_refused", id=pid, **_who(request))
            raise HTTPException(403, "Only an administrator can run this preset.")
        if not _run_lock.acquire(blocking=False):
            raise HTTPException(409, "Another preset is running. Try again in a moment.")
        try:
            res = helper("run", pid, timeout=45)
        finally:
            _run_lock.release()
        audit(user, request.client.host, "preset_run", id=pid, ok=bool(res.get("ok")), result="ok" if res.get("ok") else "failed", **_who(request))
        return 200, {"id": pid, "label": p["label"], "ok": bool(res.get("ok")), "code": int(res.get("code", -1)), "output": str(res.get("output", ""))[:4000],
                     "seconds": float(res.get("seconds", 0))}
    return idempotent(request, user, "preset_run:" + pid, {}, make)


# ---- editing presets from the phone (section 20): admin on a full phone, and only after an administrator turned it on in the web panel
@router.get("/presets/manage")
def manage_get(request: Request, user: str = Depends(current_user)):
    require(request, user, "presets_edit")
    r = presetsadmin.helper("dump")
    if r.returncode != 0:
        raise HTTPException(503, (r.stderr or "").strip()[:200] or "The presets could not be read.")
    try:
        data = json.loads(r.stdout)
    except ValueError:
        raise HTTPException(503, "The presets helper answered something unexpected.")
    return reply(request, {"presets": data.get("presets", []), "skipped": int(data.get("skipped", 0)), "max": int(data.get("max", presetsadmin.MAX_PRESETS)),
                           "max_seconds": 25})


@router.put("/presets/manage")
def manage_put(body: presetsadmin.Body, request: Request, user: str = Depends(current_user)):
    require(request, user, "presets_edit")
    payload = {"presets": [p.model_dump() for p in body.presets]}

    def make():
        r = presetsadmin.helper("save", stdin=json.dumps(payload))
        ids = [p["id"] for p in payload["presets"]]
        if r.returncode != 0:
            msg = (r.stderr or "").strip()[:300] or "The presets could not be saved."
            audit(user, request.client.host, "presets_save_refused", reason=msg[:120], count=len(ids), **_who(request))
            raise HTTPException(400, msg)
        audit(user, request.client.host, "presets_save", count=len(ids), ids=ids[:20], **_who(request))
        return 200, {"saved": len(ids)}
    return idempotent(request, user, "presets_save", payload, make)
