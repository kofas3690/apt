"""Sending alerts to Telegram and WhatsApp.

Both are plain HTTPS calls from the panel to the service's own address (api.telegram.org and graph.facebook.com),
so no root helper and no extra package is needed. The settings (chat, phone number, on or off) are saved in the
panel database. The access tokens are kept in their own files in the data folder (readable only by the panel
account), are never sent back to the browser, never written to the audit log, and are only used to call the
service they belong to.

Telegram: create a bot with @BotFather, send the bot a message, then let the page find your chat ID.
WhatsApp: uses Meta's WhatsApp Business Cloud API. A free-text message only reaches a person who has written to
the business number within the last 24 hours; for anything else Meta requires an approved message template, which
can be named here (it must have one body variable, which receives the alert text).
"""
import json, os, re, secrets, ssl, urllib.error, urllib.request
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from auth import current_user
from audit import audit
from paths import DATA
from store import PersistentDict

router = APIRouter(prefix="/api/chatalerts")
store = PersistentDict("chat_settings")
states = {"telegram": PersistentDict("alert_notified_telegram"), "whatsapp": PersistentDict("alert_notified_whatsapp"),
          "ntfy": PersistentDict("alert_notified_ntfy")}
TOKEN_FILES = {"telegram": DATA / "telegram_token", "whatsapp": DATA / "whatsapp_token", "ntfy": DATA / "ntfy_token"}

TG_BASE = "https://api.telegram.org"
WA_BASE = "https://graph.facebook.com/v26.0"
TIMEOUT = 15
MAX_TEXT = 3500

TG_TOKEN_RE = re.compile(r"[0-9]{5,15}:[A-Za-z0-9_-]{30,60}")
TG_CHAT_RE = re.compile(r"-?[0-9]{1,20}|@[A-Za-z][A-Za-z0-9_]{4,31}")
WA_TOKEN_RE = re.compile(r"[A-Za-z0-9_.-]{20,1000}")
WA_PHONE_ID_RE = re.compile(r"[0-9]{5,25}")
WA_TO_RE = re.compile(r"[0-9]{7,15}")
WA_TEMPLATE_RE = re.compile(r"[a-z0-9_]{1,200}")
WA_LANG_RE = re.compile(r"[a-z]{2,3}(_[A-Z]{2})?")
NTFY_SERVER_RE = re.compile(r"https?://[A-Za-z0-9]([A-Za-z0-9.-]{0,251}[A-Za-z0-9])?(:[0-9]{1,5})?")
NTFY_TOPIC_RE = re.compile(r"[A-Za-z0-9_-]{16,64}")
NTFY_TOKEN_RE = re.compile(r"[A-Za-z0-9_.-]{8,200}")

DEFAULTS = {
    "telegram": {"enabled": False, "chat_id": ""},
    "whatsapp": {"enabled": False, "phone_number_id": "", "to": "", "template": "", "language": "en_US"},
    "ntfy": {"enabled": False, "server": "https://ntfy.sh", "topic": ""},
}


class ChatError(Exception):
    pass


def get():
    s = json.loads(json.dumps(DEFAULTS))
    saved = store.get("cfg") or {}
    for k in s:
        if isinstance(saved.get(k), dict):
            s[k].update({a: b for a, b in saved[k].items() if a in s[k]})
    return s


def has_token(name):
    try:
        return TOKEN_FILES[name].stat().st_size > 0
    except OSError:
        return False


def _token(name):
    try:
        return TOKEN_FILES[name].read_text().strip()
    except OSError:
        return ""


def _set_token(name, value):
    fd = os.open(TOKEN_FILES[name], os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        f.write(value)


def ready(name, cfg=None):
    c = (cfg or get())[name]
    if name == "telegram":
        return bool(c["chat_id"]) and has_token(name)
    if name == "ntfy":
        return bool(c["server"] and c["topic"])           # the access token is optional (only for a private server)
    return bool(c["phone_number_id"] and c["to"]) and has_token(name)


def enabled_channels():
    c = get()
    return [n for n in ("telegram", "whatsapp", "ntfy") if c[n]["enabled"]]


def _post(url, payload, headers=None, secret=""):
    """POST JSON, return (status, parsed body). The secret is removed from anything that is raised."""
    if not url.lower().startswith(("https://", "http://")):
        raise ChatError("Only http and https addresses are used for alerts")
    data = json.dumps(payload).encode()
    req = urllib.request.Request(url, data=data, method="POST",
                                 headers={"Content-Type": "application/json", "User-Agent": "AdminPanel", **(headers or {})})
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT, context=ssl.create_default_context()) as r:  # nosec B310: the scheme was checked above
            body = r.read(200000)
            return r.status, _json(body)
    except urllib.error.HTTPError as e:
        return e.code, _json(e.read(200000))
    except ssl.SSLError as e:
        raise ChatError("The secure connection failed: " + _scrub(str(getattr(e, "reason", e)), secret)[:100])
    except (OSError, ValueError) as e:
        raise ChatError("Could not reach the service: " + _scrub(str(getattr(e, "reason", e)), secret)[:120])


def _json(b):
    try:
        v = json.loads(b.decode("utf-8", "replace"))
        return v if isinstance(v, dict) else {}
    except ValueError:
        return {}


def _scrub(text, secret):
    return text.replace(secret, "***") if secret else text


# ---- Telegram ----------------------------------------------------------------------------------

def tg_call(method, payload, token=None):
    token = token or _token("telegram")
    if not TG_TOKEN_RE.fullmatch(token or ""):
        raise ChatError("Telegram is not set up yet: save the bot token first")
    status, body = _post(f"{TG_BASE}/bot{token}/{method}", payload, secret=token)
    if status == 200 and body.get("ok"):
        return body.get("result")
    why = _scrub(str(body.get("description") or ("HTTP " + str(status))), token)[:150]
    if status in (401, 404):
        why = "Telegram did not accept the bot token (" + why + ")"
    raise ChatError(why)


def send_telegram(text, cfg=None):
    c = (cfg or get())["telegram"]
    if not c["chat_id"]:
        raise ChatError("Telegram is not set up yet: give the chat ID")
    tg_call("sendMessage", {"chat_id": c["chat_id"], "text": text[:MAX_TEXT], "disable_web_page_preview": True})


def find_chats(token=None):
    """Chats that have recently written to the bot: [{id, kind, name}]."""
    res = tg_call("getUpdates", {"limit": 100, "timeout": 0, "allowed_updates": ["message", "channel_post"]}, token)
    seen, out = set(), []
    for u in res or []:
        m = u.get("message") or u.get("channel_post") or {}
        ch = m.get("chat") or {}
        cid = ch.get("id")
        if not isinstance(cid, int) or cid in seen:
            continue
        seen.add(cid)
        name = ch.get("title") or " ".join(x for x in (ch.get("first_name"), ch.get("last_name")) if x) or ch.get("username") or ""
        out.append({"id": str(cid), "kind": str(ch.get("type", ""))[:20], "name": re.sub(r"[\x00-\x1f\x7f]", "", str(name))[:80]})
    return out[:20]


# ---- WhatsApp ----------------------------------------------------------------------------------

def send_whatsapp(text, cfg=None):
    c = (cfg or get())["whatsapp"]
    token = _token("whatsapp")
    if not (c["phone_number_id"] and c["to"] and token):
        raise ChatError("WhatsApp is not set up yet")
    if c["template"]:
        flat = re.sub(r"\s*\n+\s*", " | ", text.strip())[:1000]
        msg = {"type": "template", "template": {"name": c["template"], "language": {"code": c["language"]},
                                                "components": [{"type": "body", "parameters": [{"type": "text", "text": flat}]}]}}
    else:
        msg = {"type": "text", "text": {"body": text[:4000], "preview_url": False}}
    payload = {"messaging_product": "whatsapp", "recipient_type": "individual", "to": c["to"], **msg}
    status, body = _post(f"{WA_BASE}/{c['phone_number_id']}/messages", payload,
                         headers={"Authorization": "Bearer " + token}, secret=token)
    if status in (200, 201) and body.get("messages"):
        return
    err = body.get("error") or {}
    why = _scrub(str(err.get("message") or ("HTTP " + str(status))), token)[:200]
    if status in (401, 403) or err.get("code") == 190:
        why = "WhatsApp did not accept the access token (" + why + ")"
    elif err.get("code") == 131047:
        why = "The 24-hour window is closed: send a message to the business number first, or set an approved template name (" + why + ")"
    raise ChatError(why)


# ---- ntfy (push to the phone through the ntfy app) -----------------------------------------------

class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None                                      # never follow a redirect: the access token must only go where it was set


def _ascii(s, n):
    return re.sub(r"[^\x20-\x7e]", "", s).strip()[:n]


def send_ntfy(text, cfg=None):
    c = (cfg or get())["ntfy"]
    if not (c["server"] and NTFY_TOPIC_RE.fullmatch(c["topic"] or "")):
        raise ChatError("Push is not set up yet: give the server and the topic")
    token = _token("ntfy")
    first = text.strip().split("\n", 1)[0]
    title = _ascii(first, 100) or "AdminPanel alert"
    head = {"User-Agent": "AdminPanel", "Title": title, "Tags": "rotating_light", "Priority": "4",
            "Content-Type": "text/plain; charset=utf-8"}
    if token:
        head["Authorization"] = "Bearer " + token
    req = urllib.request.Request(c["server"].rstrip("/") + "/" + c["topic"], data=text[:MAX_TEXT].encode("utf-8"), method="POST", headers=head)
    opener = urllib.request.build_opener(_NoRedirect, urllib.request.HTTPSHandler(context=ssl.create_default_context()))
    try:
        with opener.open(req, timeout=TIMEOUT) as r:
            r.read(20000)
            if 200 <= r.status < 300:
                return
            raise ChatError("The push server answered HTTP " + str(r.status))
    except urllib.error.HTTPError as e:
        why = {401: "The push server wants a sign-in: save the access token", 403: "The push server refused this topic (check the access token)",
               404: "The push server has no such address", 429: "The push server says too many messages; try again later"}.get(e.code, "The push server answered HTTP " + str(e.code))
        raise ChatError(why)
    except ssl.SSLError as e:
        raise ChatError("The secure connection failed: " + _scrub(str(getattr(e, "reason", e)), token)[:100])
    except (OSError, ValueError) as e:
        raise ChatError("Could not reach the push server: " + _scrub(str(getattr(e, "reason", e)), token)[:120])


def new_topic():
    return "adminpanel-" + secrets.token_urlsafe(18).replace("=", "")[:24]


def send(name, text):
    if name == "ntfy":
        return send_ntfy(text)
    if name == "telegram":
        return send_telegram(text)
    if name == "whatsapp":
        return send_whatsapp(text)
    raise ChatError("Unknown channel")


# ---- settings ----------------------------------------------------------------------------------

class Telegram(BaseModel):
    enabled: bool = False
    chat_id: str = ""
    token: Optional[str] = None                 # empty or missing keeps the saved token


class WhatsApp(BaseModel):
    enabled: bool = False
    phone_number_id: str = ""
    to: str = ""
    template: str = ""
    language: str = "en_US"
    token: Optional[str] = None


class Ntfy(BaseModel):
    enabled: bool = False
    server: str = "https://ntfy.sh"
    topic: str = ""
    token: Optional[str] = None                 # empty or missing keeps the saved token (only for a private server)


class Body(BaseModel):
    telegram: Telegram = Telegram()
    whatsapp: WhatsApp = WhatsApp()
    ntfy: Ntfy = Ntfy()


def view():
    c = get()
    return {"telegram": {**c["telegram"], "has_token": has_token("telegram")},
            "whatsapp": {**c["whatsapp"], "has_token": has_token("whatsapp")},
            "ntfy": {**c["ntfy"], "has_token": has_token("ntfy")}}


def clean(body: Body):
    t, w = body.telegram, body.whatsapp
    tg = {"enabled": t.enabled, "chat_id": t.chat_id.strip()}
    to = re.sub(r"[\s().+-]", "", w.to)
    wa = {"enabled": w.enabled, "phone_number_id": w.phone_number_id.strip(), "to": to,
          "template": w.template.strip(), "language": w.language.strip() or "en_US"}
    ttok = (t.token or "").strip() or None
    wtok = (w.token or "").strip() or None
    if tg["chat_id"] and not TG_CHAT_RE.fullmatch(tg["chat_id"]):
        raise ChatError("The Telegram chat ID is a number (it may start with -) or a channel name like @mychannel")
    if ttok and not TG_TOKEN_RE.fullmatch(ttok):
        raise ChatError("That does not look like a Telegram bot token (it looks like 123456789:ABC...)")
    if wa["phone_number_id"] and not WA_PHONE_ID_RE.fullmatch(wa["phone_number_id"]):
        raise ChatError("The WhatsApp phone number ID is a number from the Meta developer page")
    if wa["to"] and not WA_TO_RE.fullmatch(wa["to"]):
        raise ChatError("Give the WhatsApp number with its country code, digits only (for example 233201234567)")
    if wtok and not WA_TOKEN_RE.fullmatch(wtok):
        raise ChatError("That does not look like a WhatsApp access token")
    if wa["template"] and not WA_TEMPLATE_RE.fullmatch(wa["template"]):
        raise ChatError("A template name uses lowercase letters, digits and underscores")
    if not WA_LANG_RE.fullmatch(wa["language"]):
        raise ChatError("The template language looks like en_US or en")
    if tg["enabled"] and not (tg["chat_id"] and (ttok or has_token("telegram"))):
        raise ChatError("To turn Telegram on, fill in the bot token and the chat ID")
    if wa["enabled"] and not (wa["phone_number_id"] and wa["to"] and (wtok or has_token("whatsapp"))):
        raise ChatError("To turn WhatsApp on, fill in the access token, the phone number ID and the number to send to")
    n = body.ntfy
    nt = {"enabled": n.enabled, "server": n.server.strip().rstrip("/") or "https://ntfy.sh", "topic": n.topic.strip()}
    ntok = (n.token or "").strip() or None
    if not NTFY_SERVER_RE.fullmatch(nt["server"]):
        raise ChatError("The push server looks like https://ntfy.sh (an address only, no path)")
    if nt["topic"] and not NTFY_TOPIC_RE.fullmatch(nt["topic"]):
        raise ChatError("The topic is 16 to 64 letters, digits, - or _. Use Make a topic: it must be hard to guess, because anyone who knows it can read your alerts")
    if ntok and not NTFY_TOKEN_RE.fullmatch(ntok):
        raise ChatError("That does not look like an access token")
    if nt["enabled"] and not nt["topic"]:
        raise ChatError("To turn push on, make a topic first")
    return tg, wa, ttok, wtok, nt, ntok


@router.get("")
def get_settings(user: str = Depends(current_user)):
    return view()


@router.put("")
def save(body: Body, request: Request, user: str = Depends(current_user)):
    try:
        tg, wa, ttok, wtok, nt, ntok = clean(body)
    except ChatError as e:
        raise HTTPException(400, str(e))
    old = get()
    if ttok:
        _set_token("telegram", ttok)
    if wtok:
        _set_token("whatsapp", wtok)
    if ntok:
        _set_token("ntfy", ntok)
    for name, new in (("telegram", tg), ("whatsapp", wa), ("ntfy", nt)):      # a new setup starts fresh and reports what exists now
        o = old[name]
        if not new["enabled"] or any(new[k] != o[k] for k in new if k not in ("enabled", "template", "language")) or \
                (name == "telegram" and ttok) or (name == "whatsapp" and wtok) or (name == "ntfy" and ntok):
            for k, _ in states[name].items():
                del states[name][k]
    store["cfg"] = {"telegram": tg, "whatsapp": wa, "ntfy": nt}
    audit(user, request.client.host, "chat_alert_settings", telegram=tg["enabled"], whatsapp=wa["enabled"], ntfy=nt["enabled"], ntfy_token_changed=bool(ntok),
          telegram_token_changed=bool(ttok), whatsapp_token_changed=bool(wtok))
    return view()


class TestBody(BaseModel):
    channel: str


@router.post("/test")
def test(body: TestBody, request: Request, user: str = Depends(current_user)):
    import socket
    if body.channel not in ("telegram", "whatsapp", "ntfy"):
        raise HTTPException(400, "Unknown channel")
    if not ready(body.channel):
        raise HTTPException(400, "Save the settings for this channel first")
    host = socket.gethostname()
    try:
        send(body.channel, "AdminPanel test message from " + host + ". If you can read this, alerts will reach you here.")
    except ChatError as e:
        audit(user, request.client.host, "chat_alert_test_failed", channel=body.channel, error=str(e)[:200])
        raise HTTPException(400, str(e))
    audit(user, request.client.host, "chat_alert_test", channel=body.channel)
    return {"ok": True}


class FindBody(BaseModel):
    token: Optional[str] = None


@router.post("/telegram/chats")
def telegram_chats(body: FindBody, request: Request, user: str = Depends(current_user)):
    tok = (body.token or "").strip() or None
    if tok and not TG_TOKEN_RE.fullmatch(tok):
        raise HTTPException(400, "That does not look like a Telegram bot token")
    try:
        chats = find_chats(tok)
    except ChatError as e:
        raise HTTPException(400, str(e))
    audit(user, request.client.host, "chat_alert_find_chats", found=len(chats))
    return {"chats": chats}


@router.post("/ntfy/topic")
def ntfy_topic(request: Request, user: str = Depends(current_user)):
    """A fresh hard-to-guess topic. It is only shown here; saving it is a separate step."""
    audit(user, request.client.host, "ntfy_topic_made")
    return {"topic": new_topic()}
