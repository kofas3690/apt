"""History for the Overview graphs: CPU, memory, disk, network, load average and temperature, sampled once a minute.

A background thread in the panel records one row per minute in the panel database and keeps seven
days. Gaps are real: while the panel is stopped (or the machine is off) nothing is recorded, and the
graphs show a break instead of inventing values. The CPU figure is computed here from the kernel's
cumulative counters, separately from the live Overview card, so the two never disturb each other.
"""
import os, threading, time
import psutil
from fastapi import APIRouter, Depends, HTTPException
from auth import current_user
import store

router = APIRouter(prefix="/api/metrics")

INTERVAL = 60                      # seconds between samples
KEEP = 7 * 86400                   # how long samples are kept
RANGES = {"1h": 3600, "6h": 6 * 3600, "24h": 86400, "7d": 7 * 86400}
POINTS = 240                       # about this many points are returned, whatever the range

with store._lock:
    store._conn.execute("CREATE TABLE IF NOT EXISTS metrics ("
                        "ts INTEGER PRIMARY KEY, cpu REAL, mem REAL, disk REAL, rx REAL, tx REAL)")
    # Added in 6.6.0 for the phone app. Older rows keep NULL here, which the app shows as "not recorded".
    have = {r[1] for r in store._conn.execute("PRAGMA table_info(metrics)")}
    for col, typ in (("load1", "REAL"), ("temp", "REAL"), ("err", "TEXT")):
        if col not in have:
            store._conn.execute(f"ALTER TABLE metrics ADD COLUMN {col} {typ}")
    store._conn.commit()

# What the collector itself has been through since the panel started (never contains paths or messages).
status = {"last_ok": None, "failures": 0, "last_error": None}


def _temperature():
    """The hottest sensor reading in degrees Celsius, or None when the machine has no sensors (most VMs)."""
    fn = getattr(psutil, "sensors_temperatures", None)
    if fn is None:
        return None
    best = None
    for readings in (fn() or {}).values():
        for t in readings:
            v = getattr(t, "current", None)
            if isinstance(v, (int, float)) and -30 <= v <= 150 and (best is None or v > best):
                best = float(v)
    return best


def _cpu_times():
    t = psutil.cpu_times()
    total = sum(t)
    idle = t.idle + getattr(t, "iowait", 0)
    return total, idle


def _net_bytes():
    rx = tx = 0
    for name, c in psutil.net_io_counters(pernic=True).items():
        if name != "lo":
            rx += c.bytes_recv
            tx += c.bytes_sent
    return rx, tx


class Sampler:
    def __init__(self):
        self.cpu = _cpu_times()
        self.net = _net_bytes()
        self.at = time.time()

    def take(self):
        """One reading. Rates cover the time since the previous reading."""
        now = time.time()
        total, idle = _cpu_times()
        dt = max(now - self.at, 1e-3)
        dtotal = total - self.cpu[0]
        cpu = None if dtotal <= 0 else max(0.0, min(100.0, 100.0 * (1 - (idle - self.cpu[1]) / dtotal)))
        rx, tx = _net_bytes()
        drx, dtx = rx - self.net[0], tx - self.net[1]
        self.cpu, self.net, self.at = (total, idle), (rx, tx), now
        if drx < 0 or dtx < 0:          # counters restarted
            drx = dtx = 0
        errs = []
        try:
            disk = psutil.disk_usage("/").percent
        except OSError:
            disk = None
            errs.append("disk")
        try:
            mem = psutil.virtual_memory().percent
        except Exception:
            mem = None
            errs.append("mem")
        try:
            load = os.getloadavg()[0]
        except (OSError, AttributeError):
            load = None
            errs.append("load")
        try:
            temp = _temperature()
        except Exception:
            temp = None
            errs.append("temp")
        return {"ts": int(now), "cpu": cpu, "mem": mem, "disk": disk, "rx": drx / dt, "tx": dtx / dt,
                "load1": load, "temp": temp, "err": ",".join(errs) or None}


def record(row):
    with store._lock:
        store._conn.execute("INSERT OR REPLACE INTO metrics (ts, cpu, mem, disk, rx, tx, load1, temp, err) VALUES (?,?,?,?,?,?,?,?,?)",
                            (row["ts"], row["cpu"], row["mem"], row["disk"], row["rx"], row["tx"],
                             row.get("load1"), row.get("temp"), row.get("err")))
        store._conn.execute("DELETE FROM metrics WHERE ts < ?", (row["ts"] - KEEP,))
        store._conn.commit()


def series(seconds, now=None):
    now = int(now or time.time())
    bucket = max(INTERVAL, (seconds // POINTS) // INTERVAL * INTERVAL)
    with store._lock:
        rows = store._conn.execute(
            "SELECT (ts / ?) * ? AS t, AVG(cpu), AVG(mem), AVG(disk), AVG(rx), AVG(tx) FROM metrics "
            "WHERE ts >= ? GROUP BY t ORDER BY t", (bucket, bucket, now - seconds)).fetchall()
    r = lambda v, n: None if v is None else round(v, n)
    return bucket, [{"t": t, "cpu": r(c, 1), "mem": r(m, 1), "disk": r(d, 1), "rx": r(rx, 0), "tx": r(tx, 0)}
                    for t, c, m, d, rx, tx in rows]


@router.get("")
def history(rng: str = "1h", user: str = Depends(current_user)):
    if rng not in RANGES:
        raise HTTPException(400, "Invalid range")
    step, points = series(RANGES[rng])
    return {"step": step, "points": points}


def _loop():
    s = Sampler()
    time.sleep(10)
    while True:
        try:
            row = s.take()
            record(row)
            status["last_ok"] = row["ts"]
        except Exception as e:           # never let the sampler die
            status["failures"] += 1
            status["last_error"] = type(e).__name__
        time.sleep(INTERVAL)


def start():
    threading.Thread(target=_loop, name="metrics", daemon=True).start()
