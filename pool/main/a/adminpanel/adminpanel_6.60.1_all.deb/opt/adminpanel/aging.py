"""Password aging: how long a Linux account's password may be used, when it warns, and when the account expires.

A root helper reads /etc/shadow (it never prints a hash) and applies changes with `chage`. It handles ordinary login
accounts only (user ids from 1000), never root or system accounts.
"""
import json, subprocess
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from auth import current_user
from audit import audit

router = APIRouter(prefix="/api/aging")

HELPER = "/usr/local/sbin/adminpanel-aging"
SUDO = "/usr/bin/sudo"
ENV = {"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LC_ALL": "C"}
NAME = r"^[a-z_][a-z0-9_-]{0,31}$"


class Setting(BaseModel):
    name: str = Field(pattern=NAME)
    max_days: Optional[int] = Field(default=None, ge=1, le=99999)  # None means never
    warn_days: int = Field(ge=0, le=30)
    expires: Optional[str] = Field(default=None, pattern=r"^\d{4}-\d{2}-\d{2}$")  # None means never


def run(*args):
    try:
        r = subprocess.run([SUDO, "-n", HELPER, *args], capture_output=True, text=True, errors="replace", timeout=40,
                           env=ENV, stdin=subprocess.DEVNULL)
    except subprocess.TimeoutExpired:
        raise HTTPException(504, "The helper took too long")
    if r.returncode != 0:
        raise HTTPException(400, ((r.stderr or r.stdout).strip() or "The password aging helper failed")[:300])
    return r


@router.get("")
def listing(user: str = Depends(current_user)):
    try:
        return json.loads(run("list").stdout)
    except ValueError:
        raise HTTPException(500, "The password aging helper returned something unexpected")


@router.post("/set")
def set_aging(body: Setting, request: Request, user: str = Depends(current_user)):
    mx = "never" if body.max_days is None else str(body.max_days)
    ex = "never" if body.expires is None else body.expires
    try:
        run("set", body.name, mx, str(body.warn_days), ex)
    except HTTPException:
        audit(user, request.client.host, "aging_set", target=body.name, ok=False)
        raise
    audit(user, request.client.host, "aging_set", target=body.name, ok=True, max_days=mx, warn_days=body.warn_days, expires=ex)
    return {"ok": True}
