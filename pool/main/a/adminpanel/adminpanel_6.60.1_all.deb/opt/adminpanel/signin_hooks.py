"""Sign-in notices: tell the administrator about sign-ins worth knowing about.

This part has no web routes and imports nothing from auth (auth calls it), so the sign-in code can use it without
circular imports. The settings page and the test button are in signinnotice.py.

What counts: a sign-in from an address this account has not signed in from before, a sign-in with a recovery code, and
a lock-out after too many wrong attempts. Addresses are learned on every successful sign-in, also while the notices are
off, so switching them on does not make the first ordinary sign-in look new. The very first address an account ever signs
in from is learned without a notice. Messages go to every channel that is switched on (email, Telegram, WhatsApp) from a
background thread, so a slow mail server never delays a sign-in, and a failure is audited once and never blocks anyone.
"""
import re, socket, threading, time
from audit import audit
from store import PersistentDict

settings_store = PersistentDict("signin_notice")
known = PersistentDict("signin_known")           # user -> [[address, first seen], ...]
DEFAULTS = {"enabled": False, "mode": "new", "lockout": True}
MAX_KNOWN = 50
LOCKOUT_EVERY = 600                              # at most one lock-out message per account and address in ten minutes
_lock = threading.Lock()
_last_lockout = {}
CTRL = re.compile(r"[\x00-\x1f\x7f]")


def get():
    s = dict(DEFAULTS)
    s.update(settings_store.get("cfg") or {})
    if s["mode"] not in ("new", "all"):
        s["mode"] = "new"
    return s


def clean(text, n):
    return CTRL.sub(" ", str(text))[:n]


def learn(user, ip):
    """Remember the address. Returns 'first' (account's first ever address), 'new' or 'known'."""
    with _lock:
        lst = known.get(user) or []
        if any(a == ip for a, _ in lst):
            return "known"
        state = "first" if not lst else "new"
        lst = (lst + [[ip, int(time.time())]])[-MAX_KNOWN:]
        known[user] = lst
        return state


def clock():
    return time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime())


def send_all(subject, text):
    """Send to every channel that is on. Returns the list of channel names that worked; raises nothing."""
    import mailer, chatalerts
    done, errors = [], []
    mc = mailer.get()
    if mc["enabled"]:
        try:
            mailer.send(subject, text, mc)
            done.append("email")
        except mailer.MailError as e:
            errors.append("email: " + str(e))
    for name in chatalerts.enabled_channels():
        if not chatalerts.ready(name):
            continue
        try:
            chatalerts.send(name, subject + "\n\n" + text)
            done.append(name)
        except chatalerts.ChatError as e:
            errors.append(name + ": " + str(e))
    if errors:
        audit("system", "-", "signin_notice_failed", error="; ".join(errors)[:300])
    return done


def _background(subject, text):
    threading.Thread(target=lambda: send_all(subject, text), name="signin-notice", daemon=True).start()


def on_login(user, ip, recovery=False, agent=""):
    """Called after a successful sign-in."""
    try:
        state = learn(user, ip)
        cfg = get()
        if not cfg["enabled"]:
            return
        reasons = []
        if recovery:
            reasons.append("a recovery code was used")
        if state == "new":
            reasons.append("from an address this account has not used before")
        elif cfg["mode"] == "all" and state != "first":
            reasons.append("sign-in")
        if not reasons:
            return
        host = socket.gethostname()
        u, a = clean(user, 64), clean(ip, 64)
        text = (f"Someone signed in to the AdminPanel on {host}.\n\nAccount: {u}\nAddress: {a}\nTime: {clock()}\n"
                f"Browser: {clean(agent, 100) or 'unknown'}\nWhy you are told: {'; '.join(reasons)}\n\n"
                "If this was not you, change the password and recovery codes now and end the other sessions on the Security page.")
        _background(f"[{host}] AdminPanel sign-in: {u} from {a}" + (" (recovery code)" if recovery else ""), text)
    except Exception as e:                       # a notice must never break signing in
        try:
            audit("system", "-", "signin_notice_failed", error=str(e)[:200])
        except Exception:
            pass


def on_lockout(user, ip, scope):
    """Called when a sign-in lock-out starts. scope is 'address' or 'account'."""
    try:
        cfg = get()
        if not (cfg["enabled"] and cfg["lockout"]):
            return
        key = (clean(user, 64), scope, ip if scope == "address" else "")
        now = time.time()
        with _lock:
            if now - _last_lockout.get(key, 0) < LOCKOUT_EVERY:
                return
            _last_lockout[key] = now
            for k in [k for k, t in _last_lockout.items() if now - t > LOCKOUT_EVERY]:
                del _last_lockout[k]
        host = socket.gethostname()
        u, a = clean(user, 64), clean(ip, 64)
        what = (f"too many wrong attempts for account {u} from {a}" if scope == "address"
                else f"too many wrong attempts for account {u} from many addresses together")
        text = (f"The AdminPanel on {host} has locked sign-in: {what}.\n\nTime: {clock()}\n\n"
                "The lock ends by itself after a few minutes. If you do not recognise this, someone may be guessing the password; "
                "check the Security page and the firewall.")
        _background(f"[{host}] AdminPanel sign-in locked: {u}", text)
    except Exception as e:
        try:
            audit("system", "-", "signin_notice_failed", error=str(e)[:200])
        except Exception:
            pass
