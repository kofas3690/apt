"""Panel access: who can sign in to this panel, and how.

Everything here changes users.json (the panel's own administrators), which the panel account can already
write, so no root helper is involved. Changes that matter ask again for the signed-in person's password and
a current two-step code, and share the "step-up" lock-out with the recovery-code page."""
import threading, time
import pyotp, qrcode
from argon2.exceptions import VerifyMismatchError
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
import auth
import roles
from audit import audit
from auth import (current_user, sessions, load_users, save_users, users_lock, ph,
                  check_totp, new_recovery_codes, pretty)

router = APIRouter(prefix="/api/panel")

MIN_PASSWORD = 8
NAME_RE = r"^[a-z][a-z0-9_.-]{0,31}$"
PENDING_TTL = 600
MAX_ADMINS = 20
pending = {}                      # name -> (secret, actor, expires): a 2FA setup waiting for its first code
pending_lock = threading.Lock()


class Step(BaseModel):
    """The signed-in person proves it is really them before a sensitive change."""
    password: str = Field(min_length=1, max_length=256)
    code: str = Field(min_length=6, max_length=8)


class NewAdmin(Step):
    name: str = Field(pattern=NAME_RE)
    new_password: str = Field(min_length=1, max_length=256)
    role: str = Field("viewer", pattern="^(admin|operator|viewer)$")


class NewPassword(Step):
    new_password: str = Field(min_length=1, max_length=256)


class Named(Step):
    name: str = Field(pattern=NAME_RE)


class RoleBody(Named):
    role: str = Field(pattern="^(admin|operator|viewer)$")


class Confirm(BaseModel):
    name: str = Field(pattern=NAME_RE)
    code: str = Field(min_length=6, max_length=8)


def password_problem(pw):
    if len(pw) < MIN_PASSWORD:
        return f"The password must be at least {MIN_PASSWORD} characters long."
    if not any(not c.isalnum() and not c.isspace() for c in pw):
        return "Add at least one symbol, such as ! @ # $ % - _ ."
    return None


def record(users, name):
    rec = users.get(name)
    if isinstance(rec, str):
        rec = {"hash": rec}
    return rec if isinstance(rec, dict) else None


def step_up(request, user, body):
    """Check the actor's password and current code. Call with users_lock NOT held."""
    key = f"stepup:{request.client.host}:{user}"
    if auth.locked(key):
        raise HTTPException(429, "Too many attempts. Try again in a few minutes.")
    with users_lock:
        rec = record(load_users(), user)
    good = False
    if rec and rec.get("totp"):
        try:
            ph.verify(rec["hash"], body.password)
            good = True
        except VerifyMismatchError:
            pass
        if good:
            good = check_totp(user, rec["totp"], body.code.replace(" ", ""))
    if not good:
        auth.record_failure(key)
        audit(user, request.client.host, "panel_stepup_failed")
        raise HTTPException(401, "Wrong password or code")
    auth.failures.pop(key, None)


def my_role(user):
    return roles.role_of(load_users().get(user))


def need_admin(user):
    if my_role(user) != "admin":
        raise HTTPException(403, "Only administrators can do this.")


def other_admins_who_can_sign_in(users, skip):
    return [n for n in users if n != skip and roles.role_of(users[n]) == "admin" and (record(users, n) or {}).get("totp")]


def qr_matrix(text):
    qr = qrcode.QRCode(border=2)
    qr.add_data(text)
    qr.make(fit=True)
    return [[bool(c) for c in row] for row in qr.get_matrix()]


def drop_sessions(name, keep=None):
    n = 0
    for k, v in list(sessions.items()):
        if v[0] == name and k != keep:
            sessions.delete_raw(k)
            n += 1
    return n


@router.get("/admins")
def admins(user: str = Depends(current_user)):
    users = load_users()
    rows = []
    mine = roles.role_of(users.get(user))
    for name in sorted(users):
        rec = record(users, name)
        if rec is None or (mine != "admin" and name != user):
            continue
        rows.append({"name": name, "totp": bool(rec.get("totp")), "role": roles.role_of(users[name]),
                     "recovery_left": len(rec.get("recovery", [])), "me": name == user,
                     "sessions": sum(1 for _, v in sessions.items() if v[0] == name)})
    return {"user": user, "role": mine, "admins": rows, "min_password": MIN_PASSWORD}


@router.post("/password")
def change_password(body: NewPassword, request: Request, user: str = Depends(current_user)):
    problem = password_problem(body.new_password)
    if problem:
        raise HTTPException(400, problem)
    step_up(request, user, body)
    with users_lock:
        users = load_users()
        rec = record(users, user)
        if rec is None:
            raise HTTPException(404, "No such administrator")
        rec["hash"] = ph.hash(body.new_password)
        users[user] = rec
        save_users(users)
    ended = drop_sessions(user, keep=sessions.stored_key(request.cookies.get("session")))
    audit(user, request.client.host, "panel_password_changed", other_sessions_ended=ended)
    return {"ok": True, "sessions_ended": ended}


@router.post("/admins/add")
def add_admin(body: NewAdmin, request: Request, user: str = Depends(current_user)):
    need_admin(user)
    problem = password_problem(body.new_password)
    if problem:
        raise HTTPException(400, problem)
    step_up(request, user, body)
    with users_lock:
        users = load_users()
        if body.name in users:
            raise HTTPException(400, "That administrator already exists")
        if len(users) >= MAX_ADMINS:
            raise HTTPException(400, f"No more than {MAX_ADMINS} administrators")
        users[body.name] = {"hash": ph.hash(body.new_password), "role": body.role}
        save_users(users)
    audit(user, request.client.host, "panel_admin_added", target=body.name, role=body.role)
    return {"ok": True}


@router.post("/admins/remove")
def remove_admin(body: Named, request: Request, user: str = Depends(current_user)):
    need_admin(user)
    if body.name == user:
        raise HTTPException(400, "You cannot remove the account you are signed in with")
    step_up(request, user, body)
    with users_lock:
        users = load_users()
        if record(users, body.name) is None:
            raise HTTPException(404, "No such administrator")
        if roles.role_of(users[body.name]) == "admin" and not other_admins_who_can_sign_in(users, body.name):
            raise HTTPException(400, "That would leave no administrator who can sign in")
        del users[body.name]
        save_users(users)
    ended = drop_sessions(body.name)
    import mobile
    phones = mobile.drop_user(body.name)
    with pending_lock:
        pending.pop(body.name, None)
    audit(user, request.client.host, "panel_admin_removed", target=body.name, sessions_ended=ended, phones_removed=phones)
    return {"ok": True}


@router.post("/2fa/start")
def start_2fa(body: Named, request: Request, user: str = Depends(current_user)):
    """Begin (or redo) two-step verification. Nothing is saved until the first code works."""
    if body.name != user:
        need_admin(user)
    step_up(request, user, body)
    with users_lock:
        if record(load_users(), body.name) is None:
            raise HTTPException(404, "No such administrator")
    secret = pyotp.random_base32()
    uri = pyotp.TOTP(secret).provisioning_uri(name=body.name, issuer_name="AdminPanel")
    matrix = qr_matrix(uri)
    with pending_lock:
        pending[body.name] = (secret, user, time.time() + PENDING_TTL)
    audit(user, request.client.host, "panel_2fa_started", target=body.name)
    return {"secret": secret, "uri": uri, "qr": matrix, "expires_in": PENDING_TTL}


@router.post("/2fa/confirm")
def confirm_2fa(body: Confirm, request: Request, user: str = Depends(current_user)):
    key = f"enrol:{request.client.host}:{user}"
    if auth.locked(key):
        raise HTTPException(429, "Too many attempts. Try again in a few minutes.")
    with pending_lock:
        item = pending.get(body.name)
    if not item or item[1] != user or item[2] < time.time():
        raise HTTPException(400, "Setup expired. Start again.")
    totp = pyotp.TOTP(item[0])
    if not (body.code.isascii() and body.code.isdigit() and totp.verify(body.code, valid_window=1)):
        auth.record_failure(key)
        raise HTTPException(401, "That code is not right. Check the app and the clock, then try again.")
    codes = new_recovery_codes()
    with users_lock:
        users = load_users()
        rec = record(users, body.name)
        if rec is None:
            raise HTTPException(404, "No such administrator")
        rec["totp"] = item[0]
        rec["recovery"] = [ph.hash(c) for c in codes]
        users[body.name] = rec
        save_users(users)
    with pending_lock:
        pending.pop(body.name, None)
    auth.failures.pop(key, None)
    ended = 0
    if body.name != user:
        ended = drop_sessions(body.name)
    audit(user, request.client.host, "panel_2fa_enrolled", target=body.name, sessions_ended=ended)
    return {"codes": [pretty(c) for c in codes]}


@router.post("/admins/role")
def set_role(body: RoleBody, request: Request, user: str = Depends(current_user)):
    need_admin(user)
    if body.name == user:
        raise HTTPException(400, "You cannot change your own role. Ask another administrator.")
    step_up(request, user, body)
    with users_lock:
        users = load_users()
        rec = record(users, body.name)
        if rec is None:
            raise HTTPException(404, "No such administrator")
        old = roles.role_of(users[body.name])
        if old == "admin" and body.role != "admin" and not other_admins_who_can_sign_in(users, body.name):
            raise HTTPException(400, "That would leave no administrator who can sign in")
        rec["role"] = body.role
        users[body.name] = rec
        save_users(users)
    audit(user, request.client.host, "panel_role_changed", target=body.name, old=old, role=body.role)
    return {"ok": True}
