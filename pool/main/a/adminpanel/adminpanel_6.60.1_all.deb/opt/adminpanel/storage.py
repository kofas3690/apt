import json, subprocess
import psutil
import fsusage
from fastapi import APIRouter, Depends
from auth import current_user

router = APIRouter(prefix="/api/storage")

LSBLK = "/usr/bin/lsblk"
ENV = {"PATH": "/usr/bin:/bin", "LC_ALL": "C"}
FIELDS = "NAME,TYPE,SIZE,FSTYPE,MOUNTPOINTS,MODEL,RM,RO"


def truthy(v):
    return v in (True, 1, "1", "true")


def flatten(nodes, depth=0, out=None):
    out = [] if out is None else out
    for n in nodes:
        out.append({
            "name": n.get("name"),
            "type": n.get("type"),
            "size": int(n.get("size") or 0),
            "fstype": n.get("fstype") or "",
            "model": (n.get("model") or "").strip(),
            "mounts": [m for m in (n.get("mountpoints") or []) if m],
            "removable": truthy(n.get("rm")),
            "readonly": truthy(n.get("ro")),
            "depth": depth,
        })
        flatten(n.get("children") or [], depth + 1, out)
    return out


@router.get("")
def overview(user: str = Depends(current_user)):
    groups = {}
    for m in fsusage.mounts(network=True):
        groups.setdefault(m["device"], []).append(m)
    mounts = []
    for device, lst in groups.items():
        lst.sort(key=lambda m: (len(m["mount"]), m["mount"]))
        m, others = lst[0], [x["mount"] for x in lst[1:]]
        status, u = fsusage.stat(m["mount"])
        row = {"device": device, "mount": m["mount"], "fstype": m["fstype"], "readonly": m["readonly"],
               "network": m["network"], "also": others[:10], "status": status}
        if status == "ok":
            row.update(total=u["total"], used=u["used"], free=u["free"], percent=u["percent"],
                       inodes_total=u["inodes_total"], inodes_free=u["inodes_free"])
        elif status == "stuck":
            row["error"] = "Not answering. The disk or share behind it may be disconnected."
        else:
            continue                            # gone between listing and asking
        mounts.append(row)
    mounts.sort(key=lambda r: r["mount"])

    devices = []
    try:
        r = subprocess.run([LSBLK, "-e", "1,7", "-J", "-b", "-o", FIELDS],
                           capture_output=True, text=True, timeout=15, env=ENV)
        if r.returncode == 0:
            devices = flatten(json.loads(r.stdout).get("blockdevices", []))
    except (OSError, ValueError, subprocess.TimeoutExpired):
        pass

    sw = psutil.swap_memory()
    return {
        "mounts": mounts,
        "devices": devices,
        "swap": {"total": sw.total, "used": sw.used, "percent": sw.percent},
    }
