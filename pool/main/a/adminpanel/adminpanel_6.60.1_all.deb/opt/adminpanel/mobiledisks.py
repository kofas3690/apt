"""Disk health on the phone (6.55.0): GET /api/mobile/v1/disks (docs/mobile-api-v1.md, section 29).

The same hourly SMART reading as Storage > Health on the web panel (smart.py), for anyone who may view. Looking only:
the phone never starts a reading, because asking every disk takes up to a few minutes and runs a root helper; it
gets the last reading and when it was made. The fields are copied one by one and checked, so nothing else from the
helper's answer reaches the phone. A failing disk, or one showing warning signs, already arrives as an alert
(type disk_health); since 6.55.0 tapping it opens this screen."""
from fastapi import Depends, Request
from auth import current_user
import smart
from mobileapi import router, reply, require

STATUSES = ("ok", "warning", "failing", "asleep", "unavailable")
KINDS = ("nvme", "ssd", "hdd", "disk")


def _int(v, lo, hi):
    return v if isinstance(v, int) and not isinstance(v, bool) and lo <= v <= hi else None


def clean(x):
    if not isinstance(x, dict) or not isinstance(x.get("device"), str):
        return None
    reasons = [r[:200] for r in (x.get("reasons") or []) if isinstance(r, str)][:6]
    return {"device": x["device"][:32], "model": str(x.get("model") or "")[:80], "kind": x.get("kind") if x.get("kind") in KINDS else "disk",
            "size": _int(x.get("size"), 0, 10 ** 16) or 0, "status": x.get("status") if x.get("status") in STATUSES else "unavailable",
            "reasons": reasons, "temp": _int(x.get("temp"), -40, 150), "hours": _int(x.get("hours"), 0, 10 ** 7),
            "cycles": _int(x.get("cycles"), 0, 10 ** 8), "wear": _int(x.get("wear"), 0, 255)}


@router.get("/disks")
def disks(request: Request, user: str = Depends(current_user)):
    require(request, user, "view")
    d = smart.cached()
    if d is None:
        return reply(request, {"checked": None, "installed": None, "disks": [], "counts": {}})
    rows = [r for r in (clean(x) for x in d.get("disks", [])) if r][:32]
    counts = {s: sum(1 for r in rows if r["status"] == s) for s in STATUSES}
    return reply(request, {"checked": smart._cache.get("t") or None, "installed": bool(d.get("installed")), "disks": rows, "counts": counts})
