"""How full a mounted filesystem is, without letting one stuck mount freeze the panel.

Asking a filesystem for its size (statvfs) can wait forever when the disk behind it has disappeared (a lost iSCSI
disk, a network share whose server is down). The Storage page, the Alerts page and the alert checker all ask, so one
stuck mount would otherwise tie up every request and the background checker. Here each question gets a few
seconds; a mount that does not answer is reported as not answering and is left alone for a minute before the next try.
"""
import os, threading, time
import psutil

SKIP_FS = {"squashfs", "tmpfs", "devtmpfs", "overlay", "iso9660", "ramfs"}
NET_FS = {"nfs", "nfs4", "cifs", "smb3"}
TIMEOUT = 5
RETRY_AFTER = 60
_down = {}                                      # mount point -> time (monotonic) when it may be asked again
_lock = threading.Lock()


def stat(path, timeout=TIMEOUT):
    """(status, numbers). status is 'ok', 'stuck' (no answer in time) or 'error'. numbers is a dict when ok."""
    now = time.monotonic()
    with _lock:
        if _down.get(path, 0) > now:
            return "stuck", None
    box = {}

    def work():
        try:
            box["v"] = os.statvfs(path)
        except OSError as e:
            box["e"] = e

    t = threading.Thread(target=work, daemon=True, name="statvfs")
    t.start()
    t.join(timeout)
    if t.is_alive():
        with _lock:
            _down[path] = time.monotonic() + RETRY_AFTER
        return "stuck", None
    with _lock:
        _down.pop(path, None)
    v = box.get("v")
    if v is None:
        return "error", None
    fr = v.f_frsize or v.f_bsize
    total, free = v.f_blocks * fr, v.f_bavail * fr
    used = (v.f_blocks - v.f_bfree) * fr
    user_total = used + free
    percent = round(used / user_total * 100, 1) if user_total else 0.0
    return "ok", {"total": total, "used": used, "free": free, "percent": percent,
                  "inodes_total": v.f_files, "inodes_free": v.f_ffree}


def mounts(network=False):
    """Mounted filesystems that are real storage: [{device, mount, fstype, readonly, network}].
    With network=True, NFS and SMB shares are included as well."""
    out, seen = [], set()
    for p in psutil.disk_partitions(all=False):
        if p.fstype in SKIP_FS or p.mountpoint.startswith("/snap/"):
            continue
        seen.add(p.mountpoint)
        out.append({"device": p.device, "mount": p.mountpoint, "fstype": p.fstype,
                    "readonly": "ro" in p.opts.split(","), "network": False})
    if network:
        for p in psutil.disk_partitions(all=True):
            if p.fstype in NET_FS and p.mountpoint not in seen:
                seen.add(p.mountpoint)
                out.append({"device": p.device, "mount": p.mountpoint, "fstype": p.fstype,
                            "readonly": "ro" in p.opts.split(","), "network": True})
    return out
