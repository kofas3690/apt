"""What depends on a service, for the phone's stop/restart confirmation: /api/mobile/v1/units/dependents (section 13).
Read-only. Lists the units that need the one asked about (systemd's reverse dependencies), with their current state,
so the phone can say "3 running services depend on this" before anything is stopped. Targets are left out: they are
boot stages, not things anyone uses."""
from fastapi import Depends, HTTPException, Query, Request
import units
from auth import current_user
from mobileapi import router, reply, require

MAX_LISTED = 60


@router.get("/units/dependents")
def dependents(request: Request, user: str = Depends(current_user), name: str = Query(..., min_length=3, max_length=220)):
    require(request, user, "view")
    units.check(name)
    r = units.sc("list-dependencies", "--reverse", "--plain", "--no-pager", name)
    if r.returncode != 0:
        raise HTTPException(502, "The system could not list what depends on this unit.")
    seen, names = set(), []
    for line in r.stdout.splitlines():
        n = line.strip().lstrip("●").strip()
        if n and n != name and n not in seen and units.UNIT_RE.fullmatch(n) and not n.endswith(".target"):
            seen.add(n)
            names.append(n)
    shown = names[:MAX_LISTED]
    states = units.sc("is-active", *shown).stdout.split() if shown else []     # one word per unit, in the order asked
    rows = [{"name": n, "active": states[i] if i < len(states) else "unknown"} for i, n in enumerate(shown)]
    rows.sort(key=lambda x: (x["active"] != "active", x["name"]))
    return reply(request, {"name": name, "dependents": rows, "running": sum(1 for x in rows if x["active"] == "active"),
                           "total": len(names), "truncated": len(names) > MAX_LISTED})
