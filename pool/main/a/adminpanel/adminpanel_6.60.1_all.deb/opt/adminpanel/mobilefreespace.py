"""Free-space overview for the phone: /api/mobile/v1/freespace (docs/mobile-api-v1.md, section 21).

Read only. It shapes what the root helper `adminpanel-freespace status` already reports (see freespace.py) into a short list of
things that could give space back, largest first. Cleaning up is deliberately not offered from the phone: it removes packages and
resizes volumes, so it stays on the web panel (Storage, Free up space), where only administrators can do it.
  * every role may read it (`view`)
  * the answer holds sizes and at most eight package names, never paths or commands
  * the helper takes a few seconds (it asks apt), so the answer is kept for 30 seconds"""
import threading, time
from fastapi import Depends, Request
import freespace
from auth import current_user
from mobileapi import router, reply, require

KEEP_FOR = 30
MAX_NAMES = 8
_lock = threading.Lock()
_cache = {"t": 0.0, "data": None}


def _int(v):
    return int(v) if isinstance(v, (int, float)) and not isinstance(v, bool) and v >= 0 else 0


def shape(d):
    """The helper's report as the phone sees it."""
    total, free = _int(d.get("total")), _int(d.get("free"))
    used = max(0, total - free)
    pk = [p for p in (d.get("removable") or []) if isinstance(p, dict) and isinstance(p.get("name"), str)]
    pk_bytes = sum(_int(p.get("bytes")) for p in pk)
    protected = any(bool(p.get("protected")) for p in pk)
    lv = d.get("lvm") if isinstance(d.get("lvm"), dict) else None
    can_grow = bool(lv and lv.get("can_grow"))
    grow = _int(lv.get("vg_free_bytes")) if lv else 0
    cache, journal = _int(d.get("apt_cache_bytes")), _int(d.get("journal_bytes"))
    names = [p["name"][:80] for p in sorted(pk, key=lambda p: -_int(p.get("bytes")))[:MAX_NAMES]]
    ideas = [
        {"id": "apt_cache", "title": "Package cache", "bytes": cache, "available": cache >= 1024 * 1024,
         "detail": "Downloaded installer files. Safe to empty; nothing installed is touched.", "where": "Storage, Free up space"},
        {"id": "unused_packages", "title": "Unused packages and old kernels", "bytes": pk_bytes, "available": bool(pk) and not protected,
         "detail": (f"{len(pk)} package{'s' if len(pk) != 1 else ''} nothing needs any more." if pk else "Nothing to remove.")
                   + (" The list holds a protected package, so the panel will refuse it." if protected else ""),
         "where": "Storage, Free up space", "examples": names},
        {"id": "journal", "title": "System journal", "bytes": journal, "available": journal >= 100 * 1024 * 1024,
         "detail": "Old system log entries. Trim them by size or age.", "where": "Logs, Log cleanup"},
        {"id": "grow_root", "title": "Grow the root volume", "bytes": grow if can_grow else 0, "available": can_grow,
         "detail": "The volume group has unused space the main disk can grow into." if can_grow
                   else "No unused space in the volume group. Enlarge the virtual disk first." if lv else "The main disk is not on LVM.",
         "where": "Storage, Free up space"},
    ]
    ideas.sort(key=lambda i: (-int(i["available"]), -i["bytes"]))
    return {"disk": {"total": total, "free": free, "used": used, "percent": round(used / total * 100, 1) if total else None},
            "ideas": ideas, "removable_error": str(d["removable_error"])[:200] if d.get("removable_error") else None}


@router.get("/freespace")
def overview(request: Request, user: str = Depends(current_user)):
    require(request, user, "view")
    now = time.time()
    with _lock:
        if _cache["data"] is None or now - _cache["t"] >= KEEP_FOR:
            _cache.update(data=shape(freespace.run("status", timeout=150)), t=now)      # raises HTTPException with a reason
        data = _cache["data"]
    return reply(request, data)
