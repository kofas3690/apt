"""Scheduled reboot: book a reboot for a time you choose (for example tonight at 03:00), see it, and cancel it.

The caller gives a point in time; the panel turns it into a number of minutes from now and a root helper books it with the
system's own scheduler (shutdown). The helper only books reboots, within two minutes to thirty days, and only changes a
booking that is a reboot. A booked reboot survives a restart of the panel, because the system keeps it, not the panel.
A booked reboot does not check whether a software update is running when the time comes.
"""
import json, math, subprocess, time
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from auth import current_user
from audit import audit
import reboot

router = APIRouter(prefix="/api/schedule")

HELPER = "/usr/local/sbin/adminpanel-schedule"
SUDO = "/usr/bin/sudo"
ENV = {"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LC_ALL": "C"}
MIN_MINUTES, MAX_MINUTES = 2, 43200


class When(BaseModel):
    at: int = Field(ge=0, le=4102444800)         # seconds since 1970 (UTC)


def run(*args, timeout=40):
    try:
        r = subprocess.run([SUDO, "-n", HELPER, *args], capture_output=True, text=True, errors="replace", timeout=timeout,
                           env=ENV, stdin=subprocess.DEVNULL)
    except subprocess.TimeoutExpired:
        raise HTTPException(504, "The scheduling helper took too long")
    if r.returncode != 0:
        raise HTTPException(400, ((r.stderr or r.stdout).strip() or "The scheduling helper failed")[:300])
    return r


def minutes_until(at, now=None):
    return math.ceil((at - (now if now is not None else time.time())) / 60)


@router.get("")
def status(user: str = Depends(current_user)):
    try:
        d = json.loads(run("status").stdout)
    except ValueError:
        raise HTTPException(500, "The scheduling helper returned something unexpected")
    d["reboot_required"] = reboot.info()["required"]
    return d


@router.post("/set")
def set_reboot(body: When, request: Request, user: str = Depends(current_user)):
    n = minutes_until(body.at)
    if n < MIN_MINUTES:
        raise HTTPException(400, "Choose a time at least %d minutes from now" % MIN_MINUTES)
    if n > MAX_MINUTES:
        raise HTTPException(400, "Choose a time within the next %d days" % (MAX_MINUTES // 1440))
    try:
        run("set", str(n))
    except HTTPException as e:
        audit(user, request.client.host, "reboot_schedule", ok=False, at=body.at, minutes=n, error=str(e.detail)[:200])
        raise
    audit(user, request.client.host, "reboot_schedule", ok=True, at=body.at, minutes=n)
    return status(user)


@router.post("/cancel")
def cancel(request: Request, user: str = Depends(current_user)):
    try:
        run("cancel")
    except HTTPException as e:
        audit(user, request.client.host, "reboot_schedule_cancel", ok=False, error=str(e.detail)[:200])
        raise
    audit(user, request.client.host, "reboot_schedule_cancel", ok=True)
    return status(user)
