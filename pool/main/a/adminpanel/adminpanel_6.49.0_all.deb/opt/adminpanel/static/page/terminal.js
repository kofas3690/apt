const TERM_THEMES = {
  dark: { background: "#000000" },
  light: { background: "#ffffff", foreground: "#1f2328", cursor: "#1f2328", cursorAccent: "#ffffff",
    selectionBackground: "#b6d4f5",
    black: "#24292f", red: "#cf222e", green: "#116329", yellow: "#4d2d00", blue: "#0969da",
    magenta: "#8250df", cyan: "#1b7c83", white: "#6e7781",
    brightBlack: "#57606a", brightRed: "#a40e26", brightGreen: "#1a7f37", brightYellow: "#633c01",
    brightBlue: "#218bff", brightMagenta: "#a475f9", brightCyan: "#3192aa", brightWhite: "#8c959f" },
};
const term = new Terminal({ cursorBlink: true, fontSize: 14, scrollback: 5000,
                            theme: TERM_THEMES[AdminTheme.get()] });
window.addEventListener("themechange", (e) => { term.options.theme = TERM_THEMES[e.detail]; });
const fit = new FitAddon.FitAddon();
term.loadAddon(fit);
term.open(document.getElementById("term"));
fit.fit();

const enc = new TextEncoder();
let ws = null;

function setState(text, connected) {
  document.getElementById("state").textContent = text;
  document.getElementById("connect").disabled = connected;
  document.getElementById("disconnect").disabled = !connected;
  for (const b of document.querySelectorAll("#tbar button")) b.disabled = !connected;
}

function connect() {
  if (ws) return;
  const user = document.getElementById("luser").value.trim();
  if (!/^[A-Za-z_][A-Za-z0-9_.-]{0,31}$/.test(user)) { alert("Invalid user name"); return; }
  term.reset();
  fit.fit();
  const proto = location.protocol === "https:" ? "wss:" : "ws:";
  const url = `${proto}//${location.host}/api/terminal/ws` +
    `?u=${encodeURIComponent(user)}&cols=${term.cols}&rows=${term.rows}`;
  const sock = new WebSocket(url);
  sock.binaryType = "arraybuffer";
  let opened = false;
  ws = sock;
  setState("connecting…", true);
  sock.onopen = () => {
    opened = true; setState("connected", true); term.focus();
    try { localStorage.setItem("termUser", user); } catch (e) {}
  };
  sock.onmessage = (e) => {
    if (e.data instanceof ArrayBuffer) term.write(new Uint8Array(e.data));
  };
  sock.onclose = () => {
    if (ws === sock) ws = null;
    setState("disconnected", false);
    term.write(opened
      ? "\r\n[connection closed]\r\n"
      : "\r\n[could not connect: not logged in, too many terminals open, or the host key file is missing]\r\n");
  };
}

term.onData((d) => {
  if (ws && ws.readyState === WebSocket.OPEN) ws.send(enc.encode(d));
});

term.onResize(({ cols, rows }) => {
  if (ws && ws.readyState === WebSocket.OPEN)
    ws.send(JSON.stringify({ type: "resize", cols, rows }));
});

window.addEventListener("resize", () => fit.fit());
/* Start with the account used last time in this browser; empty on a first visit. */
(function () {
  const box = document.getElementById("luser");
  try { box.value = localStorage.getItem("termUser") || ""; } catch (e) {}
  if (!box.value) box.focus();
})();
document.getElementById("connect").onclick = connect;
{
  document.getElementById("luser").addEventListener("keydown", (e) => { if (e.key === "Enter") connect(); });
}
document.getElementById("disconnect").onclick = () => { if (ws) ws.close(); };

/* Pasting and the keys a phone keyboard lacks (6.48.1). A phone cannot paste into the terminal itself, so:
   - Send: the line typed or pasted in the box below the terminal goes in as if typed, then Enter.
   - Paste: what you copied goes in as if typed (no Enter, so a pasted command can be checked first). term.paste()
     handles several lines and "bracketed paste", so the shell does not run lines one by one while they arrive.
   Nothing is sent while the terminal is not connected. */
const sendRaw = (d) => { if (ws && ws.readyState === WebSocket.OPEN) ws.send(enc.encode(d)); };
const tmsg = (t) => { document.getElementById("tmsg").textContent = t; };
const tline = document.getElementById("tline");
function sendLine() {
  const t = tline.value;
  if (!ws || ws.readyState !== WebSocket.OPEN) { tmsg("Connect first."); return; }
  if (t) term.paste(t);
  sendRaw("\r");
  tline.value = ""; tmsg("");
  tline.focus();
}
document.getElementById("tsend").onclick = sendLine;
tline.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); sendLine(); } });
document.getElementById("tpaste").onclick = async () => {
  let t = null;
  try { t = await navigator.clipboard.readText(); } catch (e) { t = null; }
  if (t === null) {
    tline.focus();
    tmsg("This browser did not allow reading what you copied. Long-press the box above, choose Paste, then Send.");
    return;
  }
  if (!t) { tmsg("Nothing has been copied."); return; }
  term.paste(t); tmsg(""); term.focus();
};
const KEYS = { tab: "\t", ctrlc: "\x03", esc: "\x1b", enter: "\r" };
const ARROWS = { up: "A", down: "B", right: "C", left: "D" };
for (const b of document.querySelectorAll("#tbar [data-k]")) {
  b.addEventListener("click", () => {
    const k = b.dataset.k;
    if (ARROWS[k]) sendRaw((term.modes && term.modes.applicationCursorKeysMode ? "\x1bO" : "\x1b[") + ARROWS[k]);
    else sendRaw(KEYS[k]);
  });
}
