let jobId = "", since = 0, timer = null, wasRunning = false;

async function api(path, opts) {
  const r = await fetch(path, opts);
  if (r.status === 401) { location.href = "/login.html"; throw new Error("not logged in"); }
  return r;
}

function fmtAge(s) {
  if (s === null) return "unknown";
  if (s < 3600) return Math.round(s / 60) + " min ago";
  if (s < 86400) return Math.round(s / 3600) + " h ago";
  return Math.round(s / 86400) + " days ago";
}

async function loadOverview() {
  const d = await (await api("/api/updates")).json();
  const info = document.getElementById("info");
  info.textContent = `Package lists refreshed: ${fmtAge(d.cache_age)}. ` +
    `${d.packages.length} package(s) can be upgraded.` +
    (d.reboot_required ? " A reboot is required." : "");
  info.className = d.reboot_required ? "warn" : "";
  const upg = document.getElementById("upg");
  upg.textContent = `Upgrade all (${d.packages.length})`;
  upg.dataset.count = d.packages.length;
  const body = document.getElementById("pk");
  body.replaceChildren();
  for (const p of d.packages) {
    const tr = document.createElement("tr");
    const cells = [p.name, p.old, p.new, p.security ? "security" : p.suite];
    cells.forEach((text, i) => {
      const td = document.createElement("td");
      td.textContent = text;
      if (i === 3 && p.security) td.className = "sec";
      tr.appendChild(td);
    });
    body.appendChild(tr);
  }
  setButtons(wasRunning);
}

function setButtons(running) {
  document.getElementById("upd").disabled = running;
  const upg = document.getElementById("upg");
  upg.disabled = running || Number(upg.dataset.count || 0) === 0;
}

async function startJob(kind) {
  if (kind === "upgrade" &&
      !confirm("Upgrade all packages now? Do not stop the panel while it runs.")) return;
  const r = await api(`/api/updates/run/${kind}`, { method: "POST" });
  if (!r.ok) { alert((await r.json()).detail); return; }
  poll();
}

async function poll() {
  clearTimeout(timer);
  let d;
  try {
    d = await (await api(`/api/updates/job?since=${since}&id=${jobId}`)).json();
  } catch (e) { return; }
  if (d.status === "none") return;

  const box = document.getElementById("box");
  if (d.id !== jobId) { jobId = d.id; box.textContent = ""; }
  box.textContent += d.lines.map(l => l + "\n").join("");
  since = d.next;
  box.scrollTop = box.scrollHeight;

  const running = d.status === "running";
  document.getElementById("status").textContent = running
    ? `Running ${d.kind}…`
    : `${d.kind} ${d.status} (exit code ${d.returncode})`;
  setButtons(running);

  if (running) {
    wasRunning = true;
    timer = setTimeout(poll, 1000);
  } else if (wasRunning) {
    wasRunning = false;
    loadOverview();
  }
}

loadOverview();
poll();

document.getElementById("upd").addEventListener("click", () => startJob("update"));
document.getElementById("upg").addEventListener("click", () => startJob("upgrade"));
