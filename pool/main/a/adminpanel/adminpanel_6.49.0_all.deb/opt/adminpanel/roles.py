"""Roles: what each kind of panel administrator may do.

  admin     everything (this is what every account was before 6.0.0, so nothing changes for them)
  operator  runs the machine: services, storage, backups, updates, logs, certificates, containers.
            Can read every page, but cannot change accounts, SSH, sudo, the firewall, the network, kernel
            settings, alert channels or other servers, and cannot use the Terminal or the File manager.
  viewer    read-only: can look at every page but change nothing, and cannot use the Terminal or File manager.

One check sits in front of every request (an ASGI middleware), so a page that forgets to ask cannot leak a
permission: anything not listed here as allowed for a role is refused. The role is read from users.json on every
request, so changing or removing a person takes effect at once."""
import json, time
from audit import audit

ROLES = ("admin", "operator", "viewer")
DEFAULT_ROLE = "admin"

# Never for operators or viewers, whatever the method (they open shells or read other accounts' files).
ADMIN_ONLY = ("/api/terminal", "/api/fs", "/api/auditlog", "/api/ipallow", "/api/presetsadmin", "/api/backup/phone", "/api/packages/phone")
# Administrators only may change these; operators and viewers can still look.
ADMIN_WRITE = ("/api/users", "/api/authkeys", "/api/sshkeys", "/api/aging", "/api/sshd", "/api/sudo", "/api/firewall",
               "/api/blocked", "/api/network", "/api/sysctl", "/api/signinnotice", "/api/chatalerts", "/api/alerts",
               "/api/fleet", "/api/remote", "/api/hosts", "/api/freespace")
# Every role may do these (sign out, change their own password and two-step, manage their own sessions).
ANY_ROLE = ("/api/logout", "/api/login", "/api/me", "/api/panel/password", "/api/panel/2fa/",
            "/api/security/", "/api/mobile/")
# A phone token is narrower than the person's own sign-in: never these, whatever the person's role...
PHONE_DENY = ADMIN_ONLY + ("/api/panel", "/api/security", "/api/mobile/pair/start")
# ...and besides reading, only these actions.
PHONE_POST = ("/api/units/action", "/api/backup/start", "/api/updates/run/", "/api/schedule/set", "/api/schedule/cancel", "/api/mobile/")
# POSTs that only read, so viewers may use them.
VIEWER_POST = ("/api/backup/contents", "/api/nettools", "/api/weblogs/tail")


def _under(path, prefixes):
    return any(path == p or path.startswith(p + "/") or (p.endswith("/") and path.startswith(p)) for p in prefixes)


def decide(role, method, path, phone=False):
    """None when allowed, otherwise the sentence to show the person. `phone` is True for a paired phone's token;
    a read-only phone passes role="viewer"."""
    method = method.upper()
    if phone:
        if _under(path, PHONE_DENY):
            return "This is not available from the phone app. Use the web panel."
        if method not in ("GET", "HEAD", "WS") and not _under(path, PHONE_POST):
            return "This action is not available from the phone app. Use the web panel."
        if method == "POST":
            try:
                import mobileapprovals
                gated = mobileapprovals.gate_for_path(path)
            except Exception:
                gated = path in ("/api/updates/run/upgrade", "/api/backup/start")      # the gate module cannot be read: stay closed
            if gated:
                return "This needs a second administrator's approval. Ask for approval in the app."
    if role == "admin":
        return None
    if _under(path, ANY_ROLE):
        return None
    if role not in ("operator", "viewer"):
        return "Your account has no valid role."
    read = method in ("GET", "HEAD", "WS")
    if path == "/api/panel/admins" and read:
        return None                  # everyone sees their own row; the list itself is filtered for non-administrators
    if _under(path, ADMIN_ONLY) or path.startswith("/api/panel"):
        return f"Only administrators can do this (you are signed in as {role})."
    if role == "viewer":
        if read or _under(path, VIEWER_POST):
            return None
        return "You have read-only access (viewer). Ask an administrator for the operator role."
    # operator
    if _under(path, ADMIN_WRITE) and not read:
        return "Only administrators can change this (you are signed in as operator)."
    return None


def role_of(rec):
    if isinstance(rec, str):
        return "admin"
    if not isinstance(rec, dict):
        return None
    r = rec.get("role", DEFAULT_ROLE)
    return r if r in ROLES else "viewer"          # an unknown value gets the least power, never the most


class RolesMiddleware:
    """Pure ASGI, so WebSocket connections (the Terminal, live logs) are covered too."""

    def __init__(self, app):
        self.app = app
        self._cache = (0.0, None, {})

    def users(self):
        import auth
        try:
            m = auth.USERS_FILE.stat().st_mtime_ns
        except OSError:
            return {}
        if self._cache[1] != m or time.time() - self._cache[0] > 5:
            self._cache = (time.time(), m, auth.load_users())
        return self._cache[2]

    async def __call__(self, scope, receive, send):
        if scope["type"] not in ("http", "websocket") or not scope["path"].startswith("/api/"):
            return await self.app(scope, receive, send)
        import auth
        token = None
        for k, v in scope.get("headers", []):
            if k == b"cookie":
                for part in v.decode("latin-1").split(";"):
                    n, _, val = part.strip().partition("=")
                    if n == "session":
                        token = val
        rec = auth.sessions.get(token) if token else None
        phone = None
        if rec and rec[1] >= time.time():
            who = rec[0]
        else:
            import mobile
            phone = mobile.lookup(mobile.bearer(scope.get("headers", [])), (scope.get("client") or ("",))[0])
            if not phone:
                return await self.app(scope, receive, send)   # not signed in: the normal 401 follows
            who = phone["user"]
        role = role_of(self.users().get(who))
        if phone and phone["ro"] and role is not None:
            role = "viewer"
        why = decide(role, "WS" if scope["type"] == "websocket" else scope["method"], scope["path"], phone=bool(phone))
        if why is None:
            return await self.app(scope, receive, send)
        client = scope.get("client") or ("", 0)
        audit(who, client[0], "role_denied", role=role, method=scope.get("method", "WS"), path=scope["path"][:120])
        if scope["type"] == "websocket":
            await receive()
            return await send({"type": "websocket.close", "code": 1008})
        if scope["path"].startswith("/api/mobile/v1/"):          # the phone app's v1 contract uses its error envelope everywhere
            import mobileapi
            rid = mobileapi.new_request_id(next((v.decode("latin-1") for k, v in scope.get("headers", []) if k == b"x-request-id"), None))
            body = json.dumps(mobileapi.error_body(403, why, rid)).encode()
            return await send_json(send, 403, body, rid)
        body = json.dumps({"detail": why}).encode()
        await send({"type": "http.response.start", "status": 403,
                    "headers": [(b"content-type", b"application/json"), (b"content-length", str(len(body)).encode())]})
        await send({"type": "http.response.body", "body": body})


async def send_json(send, status, body, rid):
    await send({"type": "http.response.start", "status": status, "headers": [
        (b"content-type", b"application/json"), (b"content-length", str(len(body)).encode()), (b"x-request-id", rid.encode()), (b"cache-control", b"no-store")]})
    await send({"type": "http.response.body", "body": body})
