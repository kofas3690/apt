/* Is a newer AdminPanel out? (6.51.0)  On the Overview: one line when there is. On Software updates: the details,
   how to update, Check now and the GitHub switch (administrators). It only tells; nothing is installed from here. */
(function () {
  const $ = (id) => document.getElementById(id);
  async function errText(r) {
    try { const j = await r.json(); if (typeof j.detail === "string") return j.detail; } catch (e) {}
    return "Request failed (" + r.status + ")";
  }
  const when = (t) => t ? new Date(t * 1000).toLocaleString() : "not yet";

  function banner(d) {
    const p = $("panelupd");
    if (!p) return;
    if (!d.newer) { p.hidden = true; return; }
    p.replaceChildren(document.createTextNode("AdminPanel " + d.latest + " is available (this server has " + d.current + "). "));
    const a = document.createElement("a"); a.href = "/updates.html#panel"; a.textContent = "How to update";
    p.appendChild(a);
    p.hidden = false;
  }

  function details(d) {
    const box = $("selfupd");
    if (!box) return;
    let t;
    if (d.newer) t = "AdminPanel " + d.latest + " is available. This server has " + d.current + ".";
    else if (d.checked) t = "AdminPanel " + d.current + " is the newest version found.";
    else t = "AdminPanel " + d.current + ". Not checked yet.";
    t += " Last checked: " + when(d.checked) + ".";
    if (d.github_off) t += " GitHub is not asked (switched off below); only apt is.";
    else if (d.github_error) t += " GitHub: " + d.github_error + ".";
    if (!d.apt_repository) t += " This server does not have the AdminPanel APT repository added, so apt cannot update it.";
    box.textContent = t;
    box.className = d.newer ? "warn" : "muted";
    const how = $("selfhow"), link = $("selfnotes");
    how.textContent = d.how || "";
    how.hidden = !d.how;
    if (link) { link.href = d.url; link.hidden = !d.newer; }
    $("selfgh").checked = d.enabled;
  }

  async function load() {
    try {
      const r = await fetch("/api/selfupdate");
      if (!r.ok) return;
      const d = await r.json();
      banner(d); details(d);
    } catch (e) {}
  }

  const say = (t) => { const m = $("selfmsg"); if (m) m.textContent = t; };
  if ($("selfcheck")) {
    $("selfcheck").onclick = async () => {
      $("selfcheck").disabled = true; say("Checking…");
      try {
        const r = await fetch("/api/selfupdate/check", { method: "POST" });
        if (!r.ok) { say(await errText(r)); return; }
        say(""); details(await r.json());
      } catch (e) { say("Could not reach the panel."); }
      finally { $("selfcheck").disabled = false; }
    };
    $("selfgh").onchange = async () => {
      const on = $("selfgh").checked;
      const r = await fetch("/api/selfupdate/settings", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ enabled: on }) });
      if (!r.ok) { $("selfgh").checked = !on; say(await errText(r)); return; }
      say(on ? "GitHub will be asked again." : "GitHub will not be asked. apt is still read on this server."); details(await r.json());
    };
  }
  load();
})();
