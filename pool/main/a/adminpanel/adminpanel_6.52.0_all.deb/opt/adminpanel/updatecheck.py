"""Is a newer AdminPanel out? (6.51.0)  GET /api/selfupdate, POST /api/selfupdate/check, PUT /api/selfupdate/settings,
and for the phone GET /api/mobile/v1/panel-update.

It only looks and tells; it never installs anything by itself.

Two places are asked:
  * apt, locally: `apt-cache policy adminpanel` shows the version apt would install (the Candidate). On a server that has
    the AdminPanel APT repository added, a newer Candidate means `sudo apt upgrade` (or Upgrade all on the Software
    updates page) brings it. Nothing goes over the network for this; it reflects the last `apt update`.
  * GitHub, over the network: the latest release of kofas3690/AdminPanel, from one fixed https address
    (api.github.com/repos/kofas3690/AdminPanel/releases/latest). No redirects are followed, the answer is capped, and
    only a version like v6.51.0 is taken from it; the release page link is used only if it is on that project's
    releases page. An administrator can switch this part off (Software updates page); apt is still read.

Every 12 hours, and when an administrator presses Check now (at most every 30 seconds). When a newer version is
found for the first time, one info alert is recorded (type panel_update), so phones see it in Alerts too."""
import json, re, ssl, subprocess, threading, time, urllib.error, urllib.request
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
import store
from audit import audit
from auth import current_user
from fleet import own_version
from mobileapi import router as v1, reply, require

router = APIRouter(prefix="/api/selfupdate")
REPO = "kofas3690/AdminPanel"
API = f"https://api.github.com/repos/{REPO}/releases/latest"
PAGE = f"https://github.com/{REPO}/releases"
EVERY = 12 * 3600
FIRST = 120                      # the first check, a little after start-up
MIN_GAP = 30                     # Check now, at most this often
MAX_BYTES = 256 * 1024
VER_RE = re.compile(r"^v?(\d{1,4}\.\d{1,4}\.\d{1,4})$")
state = store.PersistentDict("selfupdate")
_lock = threading.Lock()


def vkey(v):
    m = VER_RE.match(v or "")
    return tuple(int(x) for x in m.group(1).split(".")) if m else None


def enabled():
    return state.get("enabled", True) is not False


def apt_info():
    """What apt knows: installed, candidate, and whether any network repository offers adminpanel."""
    try:
        r = subprocess.run(["apt-cache", "policy", "adminpanel"], capture_output=True, text=True, timeout=20,
                           env={"LC_ALL": "C", "PATH": "/usr/bin:/bin"})
        out = r.stdout
    except (OSError, subprocess.SubprocessError):
        return {"ok": False}
    inst = re.search(r"^\s*Installed:\s*(\S+)", out, re.M)
    cand = re.search(r"^\s*Candidate:\s*(\S+)", out, re.M)
    origins = sorted(set(re.findall(r"^\s+\d+\s+(https?://\S+)", out, re.M)))[:5]
    c = cand.group(1) if cand else ""
    return {"ok": True, "installed": inst.group(1) if inst else "", "candidate": c if vkey(c) else "",
            "repository": bool(origins), "origins": origins}


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


def github_latest():
    """{"version", "url", "published"} or {"error"}."""
    req = urllib.request.Request(API, headers={"Accept": "application/vnd.github+json", "User-Agent": "AdminPanel-update-check",
                                               "X-GitHub-Api-Version": "2022-11-28"})
    opener = urllib.request.build_opener(_NoRedirect, urllib.request.HTTPSHandler(context=ssl.create_default_context()))
    try:
        with opener.open(req, timeout=15) as r:              # nosec B310: a fixed https address
            body = r.read(MAX_BYTES + 1)
    except urllib.error.HTTPError as e:
        return {"error": "GitHub has no release yet" if e.code == 404 else f"GitHub answered {e.code}"}
    except (OSError, ValueError, ssl.SSLError):
        return {"error": "Could not reach GitHub (no internet from this server, or blocked)"}
    if len(body) > MAX_BYTES:
        return {"error": "GitHub's answer was too large"}
    try:
        d = json.loads(body)
    except ValueError:
        return {"error": "GitHub's answer was not readable"}
    tag = d.get("tag_name") if isinstance(d, dict) else None
    if not isinstance(tag, str) or not vkey(tag):
        return {"error": "The latest release has no version number like v6.51.0"}
    url = d.get("html_url")
    if not (isinstance(url, str) and url.startswith(PAGE + "/") and len(url) < 200 and re.fullmatch(r"[\w./:-]+", url)):
        url = PAGE
    pub = d.get("published_at")
    return {"version": VER_RE.match(tag).group(1), "url": url, "published": pub[:25] if isinstance(pub, str) else ""}


def check():
    """Ask apt and (if switched on) GitHub; remember the answer; announce a new version once."""
    with _lock:
        current = own_version()
        res = {"checked": int(time.time()), "current": current, "apt": apt_info(),
               "github": github_latest() if enabled() else {"off": True}}
        state["last"] = res
    view = summary(res)
    if view["newer"] and state.get("announced") != view["latest"]:
        state["announced"] = view["latest"]
        try:
            import mobileevents
            mobileevents.emit("panel_update", "info", f"AdminPanel {view['latest']} is available",
                              f"This server has {current}. {view['how_short']}", "host", None, "updates", None)
        except Exception:
            pass
        audit("system", "-", "selfupdate_found", version=view["latest"], current=current, source=view["source"])
    return view


def summary(res=None):
    """What the pages show."""
    res = res or state.get("last") or {}
    current = own_version()
    cur = vkey(current)
    apt = res.get("apt") or {}
    gh = res.get("github") or {}
    best, source, url = None, "", PAGE
    for ver, src in ((apt.get("candidate"), "apt"), (gh.get("version"), "github")):
        k = vkey(ver)
        if k and cur and k > cur and (best is None or k > vkey(best)):
            best, source = ver, src
    if gh.get("version") and gh.get("url") and best == gh.get("version"):
        url = gh["url"]
    elif best:
        url = f"{PAGE}/tag/v{best}"
    if not best:
        how, short = "", ""
    elif source == "apt" or apt.get("repository"):
        how = "sudo apt update && sudo apt upgrade\nsudo adminpanel-selfcheck"
        short = "Update with sudo apt update && sudo apt upgrade, or Upgrade all on the Software updates page."
    else:
        deb = f"adminpanel_{best}_all.deb"
        how = (f"curl -fLO https://github.com/{REPO}/releases/download/v{best}/{deb}\n"
               f"sudo apt install ./{deb}\nsudo adminpanel-selfcheck")
        short = "Download the .deb from the release page and install it with apt."
    return {"current": current, "latest": best or "", "newer": bool(best), "source": source, "url": url, "how": how,
            "how_short": short, "checked": res.get("checked"), "enabled": enabled(),
            "apt_repository": bool(apt.get("repository")), "apt_candidate": apt.get("candidate", ""),
            "github_version": gh.get("version", ""), "github_error": gh.get("error", ""), "github_off": bool(gh.get("off"))}


@router.get("")
def view(user: str = Depends(current_user)):
    return summary()


_last_manual = [0.0]


@router.post("/check")
def check_now(request: Request, user: str = Depends(current_user)):
    now = time.time()
    if now - _last_manual[0] < MIN_GAP:
        raise HTTPException(429, "Checked a moment ago. Try again in half a minute.")
    _last_manual[0] = now
    audit(user, request.client.host, "selfupdate_check")
    return check()


class Settings(BaseModel):
    enabled: bool


@router.put("/settings")
def settings(body: Settings, request: Request, user: str = Depends(current_user)):
    state["enabled"] = bool(body.enabled)
    audit(user, request.client.host, "selfupdate_settings", github=bool(body.enabled))
    return summary()


@v1.get("/panel-update")
def phone_view(request: Request, user: str = Depends(current_user)):
    require(request, user, "view")
    s = summary()
    return reply(request, {k: s[k] for k in ("current", "latest", "newer", "source", "url", "how", "checked")})


def worker():
    time.sleep(FIRST)
    while True:
        try:
            check()
        except Exception:
            pass
        time.sleep(EVERY)


def start():
    threading.Thread(target=worker, name="selfupdate", daemon=True).start()
