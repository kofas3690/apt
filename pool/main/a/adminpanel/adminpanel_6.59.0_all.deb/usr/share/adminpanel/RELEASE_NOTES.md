# Release notes

Install guide: [docs/INSTALL.md](docs/INSTALL.md). Upgrading from any earlier version: `sudo apt install ./adminpanel_VERSION_all.deb` then `sudo adminpanel-selfcheck`. Accounts, certificate, port and settings are kept.

---

## v6.59.0: Release notes on Software updates (2026-11-27)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.59.0_all.deb
sudo adminpanel-selfcheck
```

Or, with the APT repository added: `sudo apt update && sudo apt upgrade`.

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: release notes on Software updates
Under **AdminPanel itself**, a **Release notes** box now shows what is in each version, without leaving the panel:
- **When a newer version is out:** *What is new since 6.58.1 (2 versions)*. Each newer version is listed, newest first, with its date, its notes and a link to its release page. The newest is open.
- **When this server is up to date:** *What is in 6.59.0*, this version's own notes.

**Where the notes come from:**
- **Newer versions:** GitHub. With GitHub switched on, each update check (every 12 hours, or **Check now**) also reads the newest 10 releases. It reads only from one fixed address, and leaves out drafts and pre-releases. Each release's notes are capped at 8000 characters, with a pointer to the release page.
- **A version that only apt offers:** it is listed with a link to its release page, because apt has no notes.
- **This version:** the package now installs `RELEASE_NOTES.md`.

**Safety:** the notes are shown as plain text, never as HTML, and control characters are removed. Everyone who may view the panel can read them. Nothing here installs anything.

### Under the hood
- `updatecheck.py`: `github_releases()`, `parse_releases()`, `local_notes()`, `GET /api/selfupdate/releases`.
- `selfupdate.js`, `updates.html`, `app.css`.
- `packaging/build.sh` installs `/usr/share/adminpanel/RELEASE_NOTES.md`. It is not put under `/usr/share/doc`, which minimal images leave out.
- Tests: `tests/test_relnotes.py`. `tests/test_selfupdate.py` now expects the two fixed GitHub addresses.

---

## v6.58.1: Release in one command (2026-11-27)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.58.1_all.deb
sudo adminpanel-selfcheck
```

Or, with the APT repository added: `sudo apt update && sudo apt upgrade`.

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: release in one command
`tools/release.sh` releases the version in `packaging/VERSION` in one go. It runs these steps in order:
1. The release check, which also builds the .deb.
2. It asks once (type `yes`).
3. It tags and pushes `main` and the tag.
4. It makes the GitHub release, with the .deb and `docs/release-vX.md`.
5. It publishes to the APT repository. gpg asks for the key's passphrase here, on its own line.

**It stops at the first failure,** says what to do, and the release check prints it as the first way to release. Run it again after fixing the problem. Steps that are already done are recognised and passed over: a tag on this commit, a pushed tag, an existing release, a version already in the APT repository. Nothing is done twice.

**Before anything, it checks** that:
- you are on `main` with nothing uncommitted;
- the release notes are there;
- `gh` is signed in.

**It never moves, deletes or replaces a tag or a release.** A tag on another commit, here or on GitHub, stops it.

**Options:**
- `--yes` does not ask.
- `--no-apt` leaves out the APT repository. Without `~/apt` that step is left out anyway.

The panel itself is unchanged.

### Under the hood
- New `tools/release.sh`.
- `tools/release-check.sh` names it.
- Tests: `tests/test_release.py`. It works in throw-away repositories with a stand-in `gh`, release check and apt-publish. It covers:
  - a failed check;
  - no yes;
  - gh not signed in;
  - a failed release, then running it again;
  - a failed publish, then running it again;
  - a tag on another commit, here or on GitHub;
  - changes that are not committed, and not being on `main`.

---

## v6.58.0: A phone alert when apt is held too long (2026-11-27)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.58.0_all.deb
sudo adminpanel-selfcheck
```

Or, with the APT repository added: `sudo apt update && sudo apt upgrade`.

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: a phone alert when apt is held too long
Phones now get one **warning** alert when a program has held apt for **30 minutes** while it needs a person:
- **Paused with Ctrl+Z:** *apt is paused and holding apt (2 h 1 min)*.
- **Waiting for an answer in a terminal:** *apt is waiting for an answer and holding apt (31 min)*.
- **Any other program holding one of apt's locks.**

The alert names the program, its terminal (such as `pts/2`), who started it, and what to do. Tapping it opens the **Updates** screen, where app 0.43.0 shows the details. When the program has ended, one **ok** alert says *apt is free again*.

There is one alert for each program, not one on every check. Some programs end by themselves, so they never cause an alert:
- the panel's own update job;
- automatic updates;
- a program that is installing or downloading.

This works with every app version that shows alerts. App 0.43.0 shows them with a general icon.

### Under the hood
- `mobileevents.py`: `_sweep_apt()` runs with the other event checks (every 30 to 60 seconds) and uses `aptbusy.py`. New event types `apt_held` and `apt_free` (contract sections 7 and 30).
- Tests: `tests/test_apt_held.py`.

---

## v6.57.2: Building never waits for a password (2026-11-27)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.57.2_all.deb
sudo adminpanel-selfcheck
```

Or, with the APT repository added: `sudo apt update && sudo apt upgrade`.

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Fixed: building never waits for a password
`packaging/build.sh` checks the sudo rules with `visudo`. That program lives in `/usr/sbin`, which is not on a normal user's PATH on Debian. The build then fell back to `sudo visudo`, which waited for your password with nothing on the screen. That is why applying 6.56.0 seemed stuck. Now:
- **visudo is found** in `/usr/sbin` even when it is not on the PATH. Any user may run it on a file, so no sudo is needed.
- **sudo is never asked for a password.** It is used only with `-n`, and only when it needs no password. Otherwise the build says the check was left to `tools/release-check.sh`, which checks the same rules.
- **A real mistake in a rule still stops the build,** with visudo's message.
- **The release check finds visudo in `/usr/sbin` too.**

The update kits now show the whole build as it runs, instead of only its last line.

### Fixed: publishing with a path like dist/adminpanel_X_all.deb
6.57.1 changed into the APT repository before copying the package, so `tools/apt-publish.sh --push dist/adminpanel_6.57.1_all.deb` said *cannot stat* and undid itself. The path is now made full first, so the release steps work as written.

The panel itself is unchanged.

### Under the hood
- `packaging/build.sh`, `tools/release-check.sh`, `tools/apt-publish.sh`.
- Tests: `tests/test_build_noprompt.py` runs the real build:
  - with a PATH without `/usr/sbin`;
  - with a visudo that cannot run;
  - with a mistake in a rule;
  - with a sudo that would wait for a password unless `-n` is given.
- `tests/test_apt_publish.py` also publishes with a relative path.

---

## v6.57.1: Safer apt publish (2026-11-27)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.57.1_all.deb
sudo adminpanel-selfcheck
```

Or, with the APT repository added: `sudo apt update && sudo apt upgrade`.

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Fixed: a failed signature no longer leaves the APT repository half-published
`tools/apt-publish.sh` is the tool you use to publish a release. When gpg could not sign the index (for example *gpg: signing failed: Timeout*, because no one typed the key's passphrase in time), the new package had already been copied in. `~/apt` was then left with changes, so the next `--push` refused to run. Now:
- **The key is tried first.** Before anything is changed, it signs a small test text, so gpg asks for the passphrase at the start. If that fails, it stops and says nothing was changed, and how to run it again.
- **Failures part-way are undone.** If anything fails after that, the run puts back what it changed. That means the copied packages, the index, the signatures, `key.asc`, `fingerprint.txt` and `README.md`. Pressing Ctrl+C does the same. Once the index is complete and signed, nothing is undone. A failed push keeps its commit, as before.

The panel itself is unchanged.

### Under the hood
- `tools/apt-publish.sh`: the packages are checked first and copied only after the key has signed. An `EXIT` trap puts the APT repository back from a copy taken before the first change.
- Tests: `tests/test_apt_publish.py`, with a gpg that fails on purpose at the test signature, the index signature, the second signature, and on a first publish into an empty folder.

---

## v6.57.0: Who is holding apt, on the phone (2026-11-27)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.57.0_all.deb
sudo adminpanel-selfcheck
```

Or, with the APT repository added: `sudo apt update && sudo apt upgrade`.

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: who is holding apt, on the phone
With phone app **0.43.0**, the **Updates** screen shows the same box as the Software updates page (6.56.0) when another program is using apt:
- **What it shows:** the program and its command, its terminal (such as `pts/2`), who started it, how long it has run, and which locks it holds.
- **What to do:** one plain sentence for each case. It might be waiting for an answer, paused with Ctrl+Z, installing, downloading, or running automatic updates.
- **When it shows:** when you open the screen, and again when an update fails because apt was busy. It refreshes until apt is free.
- **Who can see it:** everyone who may view the panel.

Looking only: the phone can stop nothing, and nothing deletes a lock file.

### Under the hood
- New `mobileaptbusy.py`: `GET /api/mobile/v1/apt-busy` (`features.apt_busy`; contract section 30). It uses `aptbusy.py`, and each field is copied one by one and checked.
- Tests: `tests/test_aptbusy_v1.py`.

---

## v6.56.0: Who is holding apt's lock (2026-11-27)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.56.0_all.deb
sudo adminpanel-selfcheck
```

Or, with the APT repository added: `sudo apt update && sudo apt upgrade`.

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: who is holding apt
Only one program can change packages at a time. The others stop with *Could not get lock /var/lib/dpkg/lock-frontend*. **Software updates** and `sudo adminpanel-selfcheck` now say which program that is and what to do about it:
- **What is shown:** the program and its command, the process number, who started it and in which terminal (such as `pts/2`, the one the person typed in, even with sudo), how long it has run, and which of apt's locks it holds.
- **What it is doing, and what to do:**

  | It is | What to do |
  |---|---|
  | **Waiting for an answer** (in the foreground of a terminal, with nothing running under it) | Answer it in that terminal, or press Ctrl+C there |
  | **Paused with Ctrl+Z** (it keeps the lock while paused) | Type `fg` in that terminal, then answer it or press Ctrl+C |
  | **Installing** (dpkg is running under it) | Do not stop it; wait |
  | **Downloading** | Wait, or press Ctrl+C in its terminal |
  | **Automatic updates** | Wait, usually a few minutes |

- **When the page shows it:** when you open the page, and again when an update job fails because of the lock. The box refreshes every 5 seconds and goes away when apt is free.
- **The self-check:** a warning line for each one, or *no other program is using apt*.

It only looks: it reads `/proc`, runs nothing and stops nothing. Never delete apt's lock files to get past a busy apt, because that can break the package database.

### Under the hood
- New `aptbusy.py` (standard library only, so `python3 /opt/adminpanel/aptbusy.py` works on its own): reads `/proc/*/stat` and `/proc/locks`, and finds the panel's own job by its `adminpanel-apt-job` cgroup.
- `updates.py`: `GET /api/updates/busy`, for everyone who may view the panel.
- The Software updates page (`updates.js`, `app.css`) and `adminpanel-selfcheck`.
- Tests: `tests/test_aptbusy.py`, on a made-up `/proc`.

---

## v6.55.0: Disk health on the phone (2026-11-27)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.55.0_all.deb
sudo adminpanel-selfcheck
```

Or, with the APT repository added: `sudo apt update && sudo apt upgrade`.

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: disk health on the phone
With phone app **0.42.0**, **More, Disk health** shows each disk's SMART health, the same hourly reading as **Storage, Health** on the web panel:
- **For each disk:** its status (*Healthy*, *Warning signs*, *Failing*, *Asleep* or *No SMART*), its temperature, how long it has run, its wear (NVMe), and the reasons in plain sentences.
- **Who can see it:** everyone who may view the panel.
- **Looking only:** the phone never starts a reading, because asking every disk takes a few minutes and runs a root helper. It shows when the last reading was made.
- **Alerts:** a *disk is failing* or *shows warning signs* alert now opens this screen when tapped.

Serial numbers never reach the phone. Virtual and cloud disks usually have no SMART; the screen says so instead of showing an error.

### Under the hood
- New `mobiledisks.py`: `GET /api/mobile/v1/disks` (`features.disk_health`; contract section 29). Each field is copied one by one and checked.
- `mobileevents.py`: `disk_health` alerts get `deep_link.screen` `disks`.
- Tests: `tests/test_disks_v1.py`.

---

## v6.54.0: Your Terminal snippets on the phone (2026-11-26)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.54.0_all.deb
sudo adminpanel-selfcheck
```

Or, with the APT repository added: `sudo apt update && sudo apt upgrade`.

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: your Terminal snippets on the phone
With phone app **0.41.0**, an administrator on a full phone sees their saved Terminal snippets (6.53.0) under **More, Snippets**. Tapping one copies the command, for example to paste into an SSH app.

- **Look and copy only.** The phone cannot add, change or delete snippets, and it has no Terminal, so nothing runs from it.
- **Your own list only,** for the panel user the phone was paired as.
- **Administrators on a full phone only.** A read-only phone and operators' and viewers' phones get no access, because a command can hold something private.

### Under the hood
- `GET /api/mobile/v1/snippets` in `termsnips.py`; the capability `snippets` and `features.snippets` in `mobileapi.py`. Contract: `docs/mobile-api-v1.md`, section 28.
- Tests: `tests/test_snippets_v1.py`.

---

## v6.53.0: Saved snippets in the Terminal (2026-11-26)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.53.0_all.deb
sudo adminpanel-selfcheck
```

Or, with the APT repository added: `sudo apt update && sudo apt upgrade`.

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: saved snippets in the Terminal
Under the Terminal, **Saved snippets** keeps the commands you use often.
- **Save one:** type the command in the box, give it a name, and press **Save the box**.
- **Use one:** tap it to put it in the box. Nothing runs until you press **Send**, and then it runs as the Linux account you signed in with, never as root. Command presets are different: they run as root.
- **Kept on the server for your panel user,** so the same list is there from your laptop and your phone. Other administrators have their own list.
- **Delete** asks with a second tap.

Limits: up to 30 snippets, a name of up to 40 characters, and a command of one line up to 1000 characters with no control characters. Administrators only, like the Terminal itself, and never from the phone app. The audit log records each snippet's name and length, never the command.

**Do not save passwords in snippets:** they are stored as plain text in the panel's database.

### Fixed
A long command in **Recent commands** (6.52.1) made the page wider than a phone screen. Long commands are now cut short with "..." instead.

### Under the hood
- New `termsnips.py`: `GET`/`POST /api/terminal/snippets`, `PUT`/`DELETE /api/terminal/snippets/{id}`.
- `static/terminal.html`, `static/page/terminal.js`, `static/app.css`.
- Tests: `tests/test_termsnips.py`.

---

## v6.52.1: Terminal text size, pinch-zoom and recent commands (2026-11-26)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.52.1_all.deb
sudo adminpanel-selfcheck
```

Or, with the APT repository added: `sudo apt update && sudo apt upgrade`.

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### The Terminal on a phone, part 2
- **Text size:** **A−** and **A+** under the terminal, from 8 to 28. Or pinch with two fingers on the terminal, which zooms its text instead of the whole page. The terminal then re-fits its columns and tells the server, so programs like `top` redraw at the new size. The size is remembered in that browser. A phone starts at 15 instead of 14.
- **Recent commands:** the commands you sent with the command box, newest first, at most 20.
  - Tap one to put it back in the box. Nothing runs until you press **Send**.
  - The list is kept only in that browser tab and is gone when you close it. **Clear** empties it at once.
  - As in bash, a command that starts with a space is not kept, so start a line with a space when it holds something private.

Text size and recent commands also work while the terminal is not connected.

### Under the hood
- `static/terminal.html`, `static/page/terminal.js`, `static/app.css`. No server change.
- `tests/test_terminal_paste.py`; also tried in a phone-sized Chromium.

---

## v6.52.0: The Servers page shows which servers are behind (2026-11-26)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.52.0_all.deb
sudo adminpanel-selfcheck
```

Or, with the APT repository added: `sudo apt update && sudo apt upgrade`.

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: the Servers page shows which servers are behind
Each server's AdminPanel version is compared with the newest one known here: the highest version any listed server runs, or a newer one this server's own update check found (6.51.0).
- A line above the list says how many are behind, for example *2 of 4 servers run an older AdminPanel than 6.52.0*, or that all run the newest.
- An older server gets a **Behind** mark and a **How to update** link. The link opens that server's own **Software updates, AdminPanel itself** section, which shows the exact command for it.

A server that is down, has a changed certificate, or answers with something that is not a version is never marked. Versions compare as numbers, so 6.10.0 is newer than 6.9.9. Nothing is updated from this page: each server keeps its own administrators.

### Under the hood
- `fleet.py`: `behind_marks()`; `GET /api/fleet/hosts` adds `newest`, `behind` (a count), and `behind` on each row.
- `static/fleet.html`, `static/page/fleet.js`.
- Tests: `tests/test_fleet_versions.py`.

---

## v6.51.0: The panel tells you when a newer AdminPanel is out (2026-11-26)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.51.0_all.deb
sudo adminpanel-selfcheck
```

Or, with the APT repository added: `sudo apt update && sudo apt upgrade`.

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: the panel tells you when a newer AdminPanel is out
- **Overview:** one line, *AdminPanel X is available (this server has Y)*, with a link to how to update.
- **Software updates, AdminPanel itself:** the versions, when it last looked, the release notes link, and the exact command for this server. With the APT repository added that is `sudo apt update && sudo apt upgrade`, and **Upgrade all** on the same page includes AdminPanel. Without it, the command downloads the release's .deb and installs it.
- **Phones:** the first time a newer version is found, one *info* alert, *AdminPanel X is available*, which opens the Updates screen. It works with every app version.

It only tells you; nothing is installed by itself.

### Where it looks
- **apt, on the server itself:** `apt-cache policy adminpanel`, no network. It reflects the last `apt update`.
- **GitHub:** the latest release of kofas3690/AdminPanel, from one fixed https address. No redirects are followed, the answer is capped, and only a version like v6.51.0 is taken from it. The release link is used only when it points to this project's releases page.

It looks every 12 hours, and when an administrator presses **Check now** (at most every 30 seconds). An administrator can untick **Also ask GitHub for new versions**; apt is then still read.

### Under the hood
- New `updatecheck.py`: `GET /api/selfupdate` (every role), `POST /api/selfupdate/check` and `PUT /api/selfupdate/settings` (administrators), and the phone call `GET /api/mobile/v1/panel-update` (`features.panel_update`, contract section 27). Audit: `selfupdate_found`, `selfupdate_check`, `selfupdate_settings`.
- `static/page/selfupdate.js` on the Overview and Software updates pages.
- Tests: `tests/test_selfupdate.py`.

---

## v6.50.1: Publishing the same version again changes nothing (2026-11-26)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.50.1_all.deb
sudo adminpanel-selfcheck
```

Or, with the APT repository added: `sudo apt update && sudo apt upgrade`.

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

This includes everything from 6.50.0 (`tools/apt-publish.sh --push`), which was not released on its own.

### Fixed: publishing the same version again signed the index again
Running `tools/apt-publish.sh` with a package that was already in the repository rebuilt and re-signed the index anyway. The index carries the time to the second, so a repeat a second later always had changes, and `--push` pushed a new commit for nothing. This also made the release check's `test_apt_publish.py` fail on some runs. Now, when every package given is already there, it says *Nothing new to publish* and changes nothing. To sign the index again on purpose, use `--resign`.

### Under the hood
- `tools/apt-publish.sh`, `tests/test_apt_publish.py` (now also a second later, as on a real machine). No change to the panel itself.

---

## v6.50.0: Publishing to apt is one command (2026-11-26)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.50.0_all.deb
sudo adminpanel-selfcheck
```

Or, with the APT repository added: `sudo apt update && sudo apt upgrade`.

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### For maintainers: publishing to apt is one command
After `gh release create`, this publishes the release to the APT repository, commits, pushes, and waits until GitHub Pages serves it:

```bash
tools/apt-publish.sh --push dist/adminpanel_6.50.0_all.deb
```

- **Safe start.** It refuses to begin if `~/apt` has changes of its own, so a push holds only this release, and it first takes what the remote has (`git pull --ff-only`).
- **Your name on it.** It commits as the git user of the AdminPanel folder.
- **It checks the result.** It works out the address from the GitHub remote (`--url` to give another) and waits until that address serves exactly the new signed index, up to 5 minutes (`--wait`). If Pages is slower it warns; the push is done either way.
- `--resign --push` signs the index again and pushes it, for `--valid-days`.
- Without `--push` it works as before and prints the commands.

The release check's last lines now show this one command once `~/apt` exists.

### Under the hood
- `tools/apt-publish.sh`, `tools/release-check.sh`, `docs/INSTALL.md`. No change to the panel itself.
- `tests/test_apt_publish.py`: a throw-away remote: refused with its own changes, pushed and live, catching up with the remote first, nothing to push, and not live in time.

---

## v6.49.1: The apt instructions work on a minimal server (2026-11-25)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.49.1_all.deb
sudo adminpanel-selfcheck
```

Or, with the APT repository added: `sudo apt update && sudo apt upgrade`.

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Fixed: the apt instructions on a minimal server
A minimal Debian or Ubuntu has no `gpg`, so the first step of *Install from the APT repository* stopped with `sudo: gpg: command not found`. The step now installs `gnupg`, `curl` and `ca-certificates` first.

### Under the hood
- `docs/INSTALL.md` only; the test checks the order. No change to the panel itself.

---

## v6.49.0: Install and update AdminPanel with apt (2026-11-25)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.49.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: install and update AdminPanel with apt
AdminPanel can now be published as a signed APT repository on GitHub Pages, so others install it with `sudo apt install adminpanel` and get new versions with `sudo apt upgrade`. How to add it, limited to AdminPanel only: *Install from the APT repository* in [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md). Downloading the .deb from this page works as before.

### For maintainers: `tools/apt-publish.sh`
Adds a release to the repository, rebuilds the index for every architecture and signs it. It refuses to publish:
- anything that looks like a private key, in the APT repository folder or the source folder;
- any package other than AdminPanel, so the repository can never offer a replacement for a system package;
- a version that is already published with different contents.

It warns when the signing key expires within 90 days, and when the README does not show the key's fingerprint yet. `--valid-days N` makes the signed index expire (run `--resign` and push before then), so nobody can keep serving an old index to hide a fix. `--check` only runs the checks. Nothing is pushed for you. One-time setup: *Publishing to the APT repository* in docs/INSTALL.md. The release check now prints the publish command too, once `~/apt` exists.

### Under the hood
- New: `tools/apt-publish.sh`, `tests/test_apt_publish.py` (a throw-away key and repository; a real `apt` client must accept it, pick the newest AdminPanel through the pin, and refuse a changed index). The test is skipped where `apt-utils` is not installed.
- No change to the panel itself.

---

## v6.48.1: Paste and keys for the Terminal on a phone (2026-11-25)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.48.1_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Fixed: you could not paste into the Terminal on a phone
A phone has no way to paste straight into the terminal, and its keyboard has no Tab, Ctrl or arrow keys. Under the terminal there is now:
- **A command box with Send.** Type or paste a command (long-press, Paste), then Send or Enter: it goes in as if typed, then runs.
- **Paste.** Puts what you copied into the terminal without pressing Enter, so you can check it first. Several lines work; the shell does not run them one by one while they arrive. If the browser will not let the page read what you copied, it says so and you use the command box instead.
- **Tab, Ctrl+C, Esc, the four arrows and Enter.** The arrows also work inside `less`, `top`, `nano` and `vim`.

They work only while the terminal is connected. On a computer, Ctrl+V (or Ctrl+Shift+V) in the terminal works as before.

### Under the hood
- `static/terminal.html`, `static/page/terminal.js`, `static/app.css`. No server change.
- `tests/test_terminal_paste.py`.

---

## v6.48.0: The phone app's own alerts arrive at once (2026-11-25)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.48.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: the phone app's own alerts arrive at once
Until now the AdminPanel app learned about new alerts only when Android woke it, about every 15 minutes and often later. With phone app **0.38.0** and the free **ntfy** app on the phone, the panel now wakes the AdminPanel app the moment it records an alert. The app asks the panel what is new and shows it, usually within half a minute of the problem starting.

How it works: the ntfy app gives the AdminPanel app a private UnifiedPush address. The app hands it to the panel when *Alerts while the app is closed* is on. When something new goes wrong, the panel sends a tiny wake-up to that address, and the ntfy app passes it on.

- **No alert text goes through ntfy** for this. The wake-up holds only a number; the app fetches the details from the panel itself, over its pinned connection.
- Your choices still apply: alerts held during maintenance, and alerts below the phone's *Tell me about* level, wake nothing.
- The 15-minute check keeps running as a backup.
- The phone must be able to reach the panel at that moment (Wi-Fi or the VPN), exactly as for the 15-minute check.
- The existing *Push to the phone (ntfy)* alerts on the Alerts page are separate and unchanged.

### Safety
- The panel only accepts push addresses on the push server set on the Alerts page or on ntfy.sh, with the shape of a UnifiedPush topic, so a phone cannot make the panel send requests anywhere else. Redirects are never followed. The Alerts page's ntfy access token is sent only to that page's own server.
- Only a paired phone can register an address, and only for itself. Unpairing the phone forgets it. An address the push server says is gone is dropped (`notify_push_address_gone` in the audit log) and that phone goes back to the 15-minute check.

### Under the hood
- New `mobilewake.py`. `mobileevents.py`: the `unifiedpush` provider, `endpoint` and `push_seq` columns, `pref_where()` shared with the background check's filter, and the event check every 30 seconds (was 60) while any phone uses instant alerts.
- `features.instant_alerts` in the capabilities answer. Contract: `docs/mobile-api-v1.md`, section 9.
- No new package: the panel calls the push server over HTTPS itself, as it already does for ntfy alerts.
- Tests: `tests/test_wake.py`.

---

## v6.47.1: File manager downloads work with download managers (2026-11-25)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.47.1_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Fixed: File manager downloads failed with a download manager installed
A download manager's browser extension (Neat Download Manager, IDM and others) takes over every browser download and fetches it again by itself. It does that without your panel sign-in, so the panel answered "Not logged in", and it usually doesn't trust the panel's own certificate either ("SSL HandShake Error"). In the browser this showed as "File wasn't available on site".

The File manager now fetches the file itself, so the download manager isn't involved:

| Browser | How the file is saved | Size |
|---|---|---|
| Chrome, Edge, Brave and other Chromium browsers on a computer | You choose where to save it, and the file goes straight to disk, with progress at the bottom of the page | Any size |
| Other browsers | The page holds the file, then hands it to the browser | Up to 200 MB |
| Other browsers, bigger files | A one-time download link | Any size |

### Added: Copy download link
Right-click a file and choose **Copy download link** to paste it into a download manager. The link needs no sign-in, so it is kept tight:
- it works **once**, within **60 seconds**, for that one file;
- only from the same address that made it;
- only while your panel sign-in and the File manager's connection to that account are still open;
- only while you are still an administrator.

A used, expired or refused link says why. Make a new one from the File manager.

### Audit log
Every download is still recorded as `fs_download`; one through a link also has `"via": "link"`. Making a link is `fs_download_link`, and a link tried from another address is `fs_download_link_refused`.

### Under the hood
- `fs.py`: the download is split into `_open_file` and `_stream` (now with `Cache-Control: no-store`). New: `POST /api/fs/link` and `GET /api/fs/get/{token}/{name}`. Links are kept in memory only, so restarting the panel cancels any that are waiting.
- `static/page/files.js`: `download()` picks the way (save picker, page, link); new `copyLink()` and the menu item; 409 opens "Connect again".
- `tests/test_fs_links.py`.

---

## v6.47.0: Install and remove software from the phone (2026-11-25)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.47.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: install and remove software from the phone
The phone app (0.37.0 and newer) gets **More, Software**:
1. Search for a package.
2. See exactly what an install or removal would add and take away (apt's own dry run).
3. Confirm, then follow the job live.

Installing software runs as root, so this is the most guarded phone feature:
- **Off until you switch it on.** On the web panel's **Packages** page, tick *Let administrators install and remove software from the phone app*. The phone can never reach that switch.
- **Administrators only, on a full phone.** A read-only phone, an operator or a viewer can search but not change anything. The server enforces this, not only the app.
- **Off while updates need approval.** If installing updates from a phone needs a second administrator's approval, software changes from the phone are off too. A package can do as much as an update.
- **The same checks as the web page.** The change goes through the same root helper. An install that would remove anything is refused, and so is removing something the machine needs (adminpanel, sudo, SSH, nginx, systemd, apt, the kernel and the like).
- **No double installs.** Each change carries an Idempotency-Key, so a dropped connection and a retry never start it twice. Only one job runs at a time, shared with Updates.
- **Audited.** Every change, refusal and switch flip goes into the audit log.

### Under the hood
- **Phone routes:** new `mobilepackages.py` adds `GET /api/mobile/v1/packages`, `/packages/plan` and `POST /packages/run` (contract section 26). It reuses the web page's own search, plan and start code from `packages.py`. Progress is the existing `GET /api/updates/job`.
- **Web switch:** `GET`/`PUT /api/packages/phone` holds the switch. It is administrator-only and never reachable from a phone (`roles.py`: `ADMIN_ONLY`). An unreadable switch reads as off.
- **Capabilities:** they gain `packages_change`, and the features gain `packages`.
- **Tests:** new `tests/test_packages_v1.py` uses real phone tokens and roles over a stand-in for apt. It covers:
  - searching for every role, and the switch;
  - the read-only phone and the operator;
  - the plan and apt's own refusals;
  - the Idempotency-Key, replay and conflict;
  - the helper's refusals, one job at a time, the approval rule, the audit and the unreadable switch.

  It writes the answers the app's tests read.

---

## v6.46.1: The Lightsail browser SSH warning keeps its link (2026-11-25)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.46.1_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Fixed: the Lightsail browser SSH warning had no link
The Security check page only keeps links from a fixed list, so a bad helper reply can never put an arbitrary link on the page. 6.46.0's new warning, "Lightsail browser SSH", points to the SSH server page (`/sshd.html`), which wasn't on that list. The warning appeared, but without its link. It is on the list now. Nothing else changed.

### Under the hood
- `seccheck.py`: `/sshd.html` added to `LINKS`.
- `tests/test_cloud_ssh.py` checks that the link is kept.

---

## v6.46.0: A warning before Lightsail browser SSH stops working (2026-11-25)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.46.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: a warning before Lightsail's browser SSH stops working
On a Lightsail server, **Connect using SSH** in the Lightsail console doesn't use your key pair. It signs in with a short-lived certificate. The SSH server only accepts that certificate if its settings contain
```
TrustedUserCAKeys /etc/ssh/lightsail_instance_ca.pub
```
Lightsail adds that line when it creates the instance. An Ubuntu or Debian upgrade that replaces `/etc/ssh/sshd_config` with the package's own copy removes it. From then on the console only says **CLIENT_UNAUTHORIZED**, often just when you need it because the VPN or your own key is not working.

The **Security check** page and `sudo adminpanel-selfcheck` now warn when a server has Lightsail's certificate-authority file but the SSH server does not trust it. The warning gives the one-line fix, which puts the setting in its own file so a future upgrade cannot remove it again:
```bash
echo 'TrustedUserCAKeys /etc/ssh/lightsail_instance_ca.pub' | sudo tee /etc/ssh/sshd_config.d/50-lightsail.conf && sudo sshd -t && sudo systemctl reload ssh
```
On servers that are not on Lightsail, the check doesn't appear at all.

### Under the hood
- **Security check:** `adminpanel-audit` gets `check_cloud_ssh`, which reads `TrustedUserCAKeys` from `sshd -T`. Checks that do not apply to a server are now left out of the list instead of shown.
- **Self-check:** `adminpanel-selfcheck` does the same check with `sshd -T`.
- **Tests:** new `tests/test_cloud_ssh.py` covers trusted, not trusted, another CA, unreadable settings and a non-Lightsail server, for both checks. Accepting any CA, or any `trustedusercakeys` line, makes it fail.

---

## v6.45.0: Block an address straight from the left-over connections (2026-11-25)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.45.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: block an address straight from the left-over connections
In the Firewall page's **Still open, though no longer allowed** box, each row now has a **Block** button. It does two things in one go:
1. **Blocks the address,** exactly like the **Blocked addresses** page. The same safety checks apply: your own address, this server's addresses and loopback are refused.
2. **Ends that address's open connections,** and only those. Other rows are left as they are.

Use it for an address you don't recognise. To let it in again, unblock it on the Blocked addresses page. The row for your own browser has no Block button.

### Under the hood
- `adminpanel-ufw end-stale KEEP [ONLY]` can end the connections of one address only. It still never ends the asking browser's connections or port 22, even when that address is named.
- `POST /api/firewall/stale/end` takes an optional `{"address": ...}`. Bad addresses are refused before the helper runs, and the audit log records which address was ended.
- `static/page/firewall.js` adds the button.
- `tests/test_stale_conns.py` covers ending one address, refusing to end this browser by name, and the route's checks. A browser test checked that the button blocks first and then ends only that address.

---

## v6.44.0: Panel access on the phone, and an alert when the panel opens up again (2026-11-25)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.44.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: Panel access on the phone, and an alert when the panel opens up again
- **On the phone (app 0.36.0):** the VPN screen shows **Panel access**: *Only through the VPN*, *Open to everyone* (with the port), or a change waiting to be kept. It is read only, like the rest of the screen. The firewall rules themselves never leave the server.
- **A new alert, "The panel is open to everyone again":** once **Allow only the VPN** was kept on a server, the panel remembers that this is what you want. If the panel's port is then open outside the VPN for 3 minutes, a warning is raised on the Alerts page, by email, chat and push, and in the phone's alert list. That happens, for example, after `sudo adminpanel-setup vpnonly off` on the console, or a rule added by hand or by another program. Tapping it opens the VPN screen. When the port is closed again, a calm "The panel is reachable only through the VPN again" follows.
- **Opened on purpose:** **Open to everyone again** on the web page makes the open port the wanted state, so it raises no alert. If the port was reopened some other way, the web page says so, and offers **Open to everyone** to make it official.

### Under the hood
- `network.py` remembers the choice (`vpn_only` in the panel database). It is set when the change is kept and cleared when the panel is opened from the page. The VPN status reports it as `vpn_only.wanted`.
- `vpnhealth.py` adds the alert `vpn-panel-open`. `mobileevents.py` maps it to `vpn_panel_open`.
- `mobilevpn.py` adds `panel_access` to `GET /api/mobile/v1/vpn` (contract section 25).
- Tests cover the alert and when it must not appear, the remembered choice, and the phone's answer, which never includes the rule text. The app's fixtures were regenerated.

---

## v6.43.0: See and end connections the firewall no longer allows (2026-11-24)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.43.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: see and end connections the firewall no longer allows
A firewall only judges **new** connections. ufw lets the packets of a connection that is already open through. So after you remove a rule, or block an address, anything that connected before keeps working until it closes. A browser tab that stays open on the panel, for example, refreshes every few seconds and never closes. (This is why the panel still answered on a server's public address after its port had been closed.)

The **Firewall** page now has a **Still open, though no longer allowed** box. It lists such connections by address and port, and **End them** closes them. It appears when the page loads and again after you remove a rule. The **Blocked addresses** page points to it.

**Safe by design:**
- **Your own connection is never ended.** The box marks it "this browser (kept open)" and warns that this address cannot connect again while the rules stay as they are.
- **SSH (port 22) is never listed or ended.**
- **Judged the way ufw judges.** The first matching rule decides, so a block at the top wins over an allow below it, and a deny below an allow does not. Port ranges, application profiles such as `Nginx Full` and IPv4-in-IPv6 addresses are understood. An IPv4 rule does not let an IPv6 address in.
- **Any doubt counts as allowed.** For a rule that only applies to one network card, an application profile ufw cannot describe, or a source port, a connection it might allow is never listed or ended, and the box says some rules could not be read with certainty.
- **Only when the firewall is on.** Nothing is listed when ufw is off or lets everything in by default.
- **Administrators only.** Ending connections needs an administrator, never a phone, and is written to the audit log (`firewall_end_stale`). Everyone can see the list.

### Under the hood
- `adminpanel-ufw` gets `stale` and `end-stale KEEP`.
  - **Finding them:** it reads the listening ports and the established connections with `ss`, leaves out loopback and this machine's own addresses, and checks each against the rules from `ufw show added` and the default incoming policy.
  - **Ending them:** `ss -K`, one address and port at a time, skipping KEEP (the address of the browser asking) and port 22.
- `firewall.py`: `GET /api/firewall/stale` and `POST /api/firewall/stale/end`.
- `static/page/firewall.js` and `static/firewall.html` hold the box; `static/blocked.html` has the pointer.
- New `tests/test_stale_conns.py`. It runs the helper against stand-ins for ufw and ss and covers the cases above, ending and the routes. Breaking the "doubt counts as allowed" rule, the first-match order or the SSH exclusion makes it fail. The connection reading was also checked against the real `ss` output.

---

## v6.42.0: Make the panel reachable only through the VPN (2026-11-24)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.42.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: make the panel reachable only through the VPN
The Quick VPN card (on the hub and on a joined server) has a new **Panel access** part. **Allow only the VPN** closes the panel's port (8443) in this server's firewall to everyone outside the VPN. From then on, its sign-in page can only be reached from your own devices and servers on the VPN.

**How it keeps you from locking yourself out:**
1. **Only through the VPN.** The button only works on a page opened through the VPN. That proves the VPN already gets you in.
2. **Password and 2FA.** It asks for your password and 2FA code again.
3. **Undo first.** Before any rule changes, a timer is set to put everything back after **2 minutes**. The page then keeps the change itself, through the VPN. If it cannot reach the panel, nothing keeps the change and the port reopens by itself.
4. **Only the panel's port.** It only removes the rules that let others reach the panel's own port. SSH, the VPN's UDP port, port 80 and every other rule are left alone. Port 22 is never touched.
5. **Refused when pointless.** It does nothing if the firewall is off or lets everything in by default (`ufw default incoming allow`), because closing one port would change nothing then.
6. **Old connections are cut.** When the change is kept, connections to the panel that were opened from outside the VPN before it closed are ended (`ss -K`). Otherwise an open browser tab would keep working.
7. **A way back from the console:** if you ever lose the VPN, sign in to the server's console (Lightsail: **Connect using SSH**) and run
   ```bash
   sudo adminpanel-setup vpnonly off
   ```
   That opens the port to everyone again. **Open to everyone again** on the page does the same, at once.

This changes this server's own firewall only. If your cloud provider has its own firewall (Lightsail: Networking, IPv4 firewall), remove the panel's port there too. The page reminds you.

Every step is in the audit log: `vpn_only_on`, `vpn_only_keep`, `vpn_only_off`.

### Under the hood
- **Helper:** `adminpanel-ufw` gets `vpnonly-status`, `vpnonly-on`, `vpnonly-keep`, `vpnonly-off`, and `vpnonly-undo` (run only by its root timer `adminpanel-vpnonly-undo`; sudo does not allow the panel to call it).
  - It reads the panel's port from `/var/lib/adminpanel/port`, never from the request.
  - What it removed is kept in `/var/lib/adminpanel/vpnonly-undo.json` (mode 600) until the change is kept or undone.
- **Routes:** `network.py` has `POST /api/network/vpn/easy/vpnonly` and `/vpnonly/keep` (administrators only, never from a phone), and the status shows `vpn_only`.
- **Console:** `adminpanel-setup vpnonly [show|off]`.
- **Tests:** `tests/test_vpn_only.py` runs the helper against a stand-in for ufw. It checks:
  - what is removed and what is left alone;
  - the undo puts back every rule, comments included;
  - a timer that cannot be set changes nothing;
  - a failed removal puts everything back;
  - the refusals and the console way back.
  `tests/test_vpn_easy.py` checks the routes: outside the VPN, wrong password, operator and phone are all refused, and only a browser on the VPN can keep the change.

---

## v6.41.0: Alerts when the VPN has a problem (2026-11-24)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.41.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: alerts when the VPN has a problem
The Quick VPN now raises alerts. They appear on the **Alerts** page, in email, Telegram, WhatsApp and ntfy push when those are on, and in the phone app's alert list, where tapping one opens the VPN screen (app 0.35.0).

| Alert | Severity | When |
|---|---|---|
| The VPN is not running | critical | The tunnel is set up but not running, for 2 minutes |
| The VPN's protection rules are not active | critical | Devices might reach each other or what lies beyond the VPN, for 2 minutes |
| Server *name* lost its VPN link | warning | On the hub: a joined server has not been in contact for 10 minutes |
| This server lost its link to the VPN | warning | On a joined server: no contact with the hub for 10 minutes |
| This server has never reached the VPN | warning | On a joined server: joined but not connected, for 5 minutes |
| VPN forwarding is off / the firewall rule for the VPN's servers is missing | warning | Devices cannot reach the servers, for 3 minutes |
| The firewall blocks the VPN's port | warning | ufw does not allow the VPN's UDP port, for 3 minutes |

When a problem clears, the phone gets a calm "ok" entry: "Server debian is back on the VPN", "The VPN is running again". Email and chat list it under "No longer a problem", as for other alerts.

**No false alarms:**
- Phones and laptops going offline is normal, so it never raises an alert.
- A server that has a join code but never joined isn't reported.
- A problem has to last 2 to 5 minutes, so applying a change (which briefly removes the tunnel's rules) never sends one.
- Nothing is reported while a network change waits to be kept.
- If the status cannot be read, no alert is invented, and the other alerts carry on.

### Under the hood
- New `vpnhealth.py`. It reads the VPN page's own status (`network.easy_view`) at most once a minute, applies the waiting times and returns alerts of kind `vpn`.
- `alerts.py` adds them to `scan()`, so every channel gets them.
- `mobileevents.py` turns them into the event types `vpn_down`, `vpn_unprotected`, `vpn_server_lost`, `vpn_link_lost`, `vpn_relay_broken`, `vpn_port_closed` and `vpn_recovered`, with the deep link `vpn` (contract section 7).
- New `tests/test_vpn_alerts.py`: every alert and non-alert, the waiting times, pending changes, an unreadable status, the phone's events and recoveries. `tests/test_vpn_easy.py` checks the alerts against the real status code. Removing the waiting time, the pending check or the "devices are not alerts" rule makes a test fail.

---

## v6.40.1: A VPN change from a page left open no longer fails with a misleading message (2026-11-24)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.40.1_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Fixed: a VPN change from a page left open could fail with a misleading message
While a window such as **Add a server** or **Add a device** is open, the VPN card stops refreshing so it does not redraw under your typing. Left open for a long time, the browser could end up holding a dead connection to the panel, for example after the panel was upgraded or the laptop's VPN went quiet. Pressing **Create join code** then failed with "The connection dropped. If the change went through, it undoes itself in two minutes unless you press Keep changes". The request had never left the browser, so that message was wrong.

Now every Quick VPN change first checks, within 8 seconds, that the panel can be reached from the page; the check also opens a fresh connection. When it cannot reach the panel, nothing is sent and the page says so: "The panel can't be reached from this page right now (is your VPN connected?). Nothing was changed. Reload the page and try again." If you were signed out in the meantime, it takes you to the sign-in page. The old message about Keep changes now appears only when the change was really sent and the connection broke afterwards.

This covers turning the VPN on or off, adding a device or a server, joining, removing and Repair.

### Under the hood
- `static/page/vpneasy.js`: `reachable()` is called at the start of `change()`.
- `tests/test_vpn_easy.py` checks that every change asks first. A browser test with a dead connection showed nothing is sent and the right message appears; one with a change cut off after sending still gets the Keep-changes message. Removing the check makes both fail.

---

## v6.40.0: Join a VPN with the WireGuard config file (2026-11-24)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.40.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: join a VPN with the WireGuard config file
**Add a server** on the hub has always offered **Download as a WireGuard config** next to the join code. A server can now join with that file too. Under **Or join another server's VPN**, either paste the config's text into the box or press **Choose a .conf file…**, then enter that server's password and 2FA code and press **Join**. The result is exactly the same as with the join code.

The file is checked by the same rules as a join code, plus a few of its own. It is refused, with the reason, when it:
- runs commands (`PreUp`, `PostUp`, `PreDown`, `PostDown`). The panel never runs anything from it, and a config made by Add a server has none.
- has more or fewer than one `[Peer]`, or a section other than `[Interface]` and `[Peer]`.
- is missing the private key, the hub's public key, the preshared key or the Endpoint.
- sends all traffic through the VPN (`AllowedIPs = 0.0.0.0/0`), or its AllowedIPs leave out the VPN's /24.
- has no IPv4 Address, or an address that is the hub's, the network's or the broadcast address.

Lines such as `DNS`, `MTU` and `PersistentKeepalive` are ignored; a joined server always keeps the link open every 25 seconds. The page reads a chosen file in the browser and refuses anything without an `[Interface]` section or larger than 4,000 characters. Like the join code, the config holds the new server's private key: it goes only to this server's join call, and the audit log notes only that a config was used (`source: config`), never its contents.

### Also
- A join code or config whose hub address is inside the VPN itself (such as `10.77.0.1`) is now refused with a clear reason. The joining server could never reach it. This matches the 6.38.3 rule for devices.

### Under the hood
- `network.py`: `read_conf` turns a config into the same fields as a join code and passes them through `read_join`, so both paths share every check. The `join` field now takes up to 4,000 characters.
- `static/page/vpneasy.js`, `static/vpn.html`: the file chooser and the wording.
- `tests/test_vpn_easy.py`: joining with a config gives the same server as joining with the code; 14 kinds of bad config are refused before any key is stored. Removing the command check or the VPN-address check makes a test fail.

---

## v6.39.0: Quick VPN status in the phone app (2026-11-24)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.39.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: Quick VPN status in the phone app
The phone app (0.34.0 and newer) can now show the server's Quick VPN: whether it is on, which devices and servers are connected right now and when each was last seen, and anything that is wrong with it (a closed UDP port, forwarding switched off, missing protection rules, a joined server that never connected), with the web page that fixes it. The device you are holding is marked **This phone** when it is connected through the VPN.

It is **read only**. Turning the VPN on, adding a device or a server and making a join code stay on the web panel, because each one asks for your password and 2FA code again and hands out keys.

Every role can see it, as on the web page. The answer never holds keys (not even public ones), the sign-in address list or firewall rule text.

### Under the hood
- New route `GET /api/mobile/v1/vpn` (`mobilevpn.py`), built from the same status code the web VPN page uses (`network.easy_view`), so the phone and the page always agree. Contract: `docs/mobile-api-v1.md`, section 25. The capabilities answer has `features.vpn`.
- `tests/test_vpn_v1.py` checks the hub, member, off and unavailable answers, every warning in the web page's order, odd values, the 250-entry limit, a failing status read, and that no key or administrator-only setting leaves the server. It also writes the answers the app's tests read.

---

## v6.38.5: The release check passes the VPN test as a normal user (2026-11-24)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.38.5_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Fixed: the release check failed the VPN test when run as a normal user
`tools/release-check.sh` runs the tests as your own account. The VPN test runs the network helper, which makes its key folder and keys owned by root (so that only root and systemd-networkd can read them). A normal account may not hand a file to root, so the test stopped with "Operation not permitted" on the key folder. It only passed when run as root.

The test now lets the helper set the group as usual, keeps the owner as it is, and checks that the helper asked for root as the owner every time. The panel itself is unchanged: on the server the helper runs as root and keys are owned by root, group systemd-network, mode 0640, as in 6.38.2.

This release also carries 6.38.4 (adding or removing a VPN device no longer drops the others).

---

## v6.38.4: Adding or removing a VPN device no longer drops the others (2026-11-24)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.38.4_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### No more drop for everyone when a device is added or removed
Adding, removing or changing a VPN device or server used to recreate the whole WireGuard interface. Every other connected device, including yours, lost its session and took about 15 seconds to reconnect by itself.

Now, when only the list of devices and servers changes, the interface stays up and gets its new peers in place (`wg syncconf`). Everyone else keeps their connection. A removed device is still cut off at once, because its peer and keys are gone from the running interface in the same step. The interface is only recreated when its own settings change (its private key or its port). The automatic undo works the same way.

Tested with real WireGuard tunnels: while one device kept sending, another was removed and a third added. Before, the busy device lost the hub for 15.3 seconds. Now it never lost it, the removed device was locked out immediately, and the new one connected straight away.

This applies to the advanced editor's interfaces too.

---

## v6.38.3: New devices get the public server address, never a VPN one (2026-11-24)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.38.3_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Fixed: devices made while viewing the panel through the VPN could never connect
**Add a device** and **Add a server** fill in the server address from the address the panel was opened on. When you were looking at the hub through the VPN itself (for example at `https://10.77.0.1:8443/`), that put the hub's *VPN* address into the new config (`Endpoint = 10.77.0.1:…`). A device can never reach that address to connect, so the tunnel stayed at "0 B received".

- The windows no longer fill in an address inside the VPN. They use the public address you entered last time, or leave the field empty.
- Both the panel and the network helper refuse a VPN address as the server address, with a message saying to use the public IP or a domain name. No keys are made for such a request.

**If a device was made this way:** in the WireGuard app, choose **Edit** and change its `Endpoint` line to the hub's public address and port, for example `Endpoint = 203.0.113.10:51820`.

---

## v6.38.2: VPNs start again: WireGuard keys readable by networkd (2026-11-24)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.38.2_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Fixed: VPNs could not start ("these interfaces were not created")
Turning on Quick VPN, or applying any WireGuard interface, failed with "these interfaces were not created: adminvpn (is the WireGuard kernel module available?)", and the change was rolled back. The real cause was in the system log: `Failed to read private key from '/var/lib/adminpanel/wg/…key' … Permission denied`.

The panel's service runs with `UMask=0077`. That made the stored WireGuard keys `0600` instead of `0640`, so systemd-networkd, which reads them through the `systemd-network` group, could not open them. Keys are now always stored as `0640`. Every network change also repairs keys stored with the wrong mode by older versions before networkd reads them, so nothing needs to be done by hand. The bug dates from the first WireGuard version and also affected interfaces made in the advanced editor.

---

## v6.38.1: Quick VPN: typing kept during refreshes, no false WireGuard warning (2026-11-24)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.38.1_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Fixed: typing in the Quick VPN card was wiped
The Quick VPN card refreshes every 10 seconds, and each refresh redrew it, which emptied the password, 2FA code and join code fields while you were filling them in. The card now waits while you are typing, or while any of those fields has something in it. The status still updates in the background.

### Fixed: a false "kernel may not support WireGuard" warning
The panel's service runs sandboxed (`ProtectKernelModules=yes`), so it cannot look at the kernel's module folder. Ubuntu's kernels have WireGuard as a module that loads only when the first WireGuard interface is made, so the check said "may not support" on servers that support it fine. The card no longer guesses. If WireGuard really is missing, turning the VPN on says so. To load the module ahead of time anyway: `sudo modprobe wireguard`.

---

## v6.38.0: Quick VPN: other servers join with a code (2026-11-24)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.38.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: your other servers join the VPN with a code
Quick VPN now connects servers as well as phones and laptops, in the style of Tailscale. One server runs the VPN (the hub: the one your devices can reach from the internet), and your other servers join it with a one-time code. A server that joins needs no open port and no public address. It connects out to the hub, so it works behind a home or office router too. Your devices can then open its panel at its VPN address.

1. **On the hub**, in **Networking, Configuration, VPN**, choose **Add a server**. Give it a name, enter your password and 2FA code, and copy the join code. Like a device's QR code, the join code is shown once and is not kept: it holds the new server's keys.
2. **On the other server**, same page, under **Or join another server's VPN**: paste the code, enter that server's password and 2FA code, and press **Join**.
3. It shows as connected on the hub within a few seconds. From your phone or laptop on the VPN, its panel is at an address such as `https://10.77.0.129:8443/` (the Servers list links to it).

**What can reach what:**
- Devices reach the hub and every joined server.
- Servers reach the whole VPN.
- **Devices never reach each other**, so one lost phone cannot attack another person's laptop.
- **Nothing in the VPN reaches anything beyond it**: not the hub's local network, not the internet through the hub.
- **Nothing outside reaches into the VPN.** A machine on the hub's local network cannot push packets into it, even by faking a VPN address.

These rules hold whatever the server's IP forwarding switch and firewall say. They were checked with real tunnels: a hub, two devices, a joined server, and a private network behind the hub.

**How it works.** The hub passes traffic on for its VPN interface only. IP forwarding is switched on for `adminvpn` and not for the server's other network cards. That is set at boot too, through `/etc/sysctl.d/60-adminpanel-vpn.conf`. A ufw rule (`ufw route allow in on adminvpn out on adminvpn`, marked "adminpanel vpn relay") lets the relayed traffic through ufw's default "drop forwarded traffic". Four routing rules (priorities 74, 76, 77 and 78) decide what may go where. When the last server is removed, forwarding and the firewall rule go away again.

**Also:**
- Room for **120 devices and 120 servers**. Devices get addresses .2 to .127, servers .129 to .254.
- The card **warns and offers Repair** when something switched forwarding off for the whole server, when the firewall rule is missing, or when the routing rules are not active.
- **Upgrading from 6.37:** the VPN's files get the two new rules (74 and 78) with your next change. Until then the card shows **Repair**; press it once.
- **A server without AdminPanel** can join too. The join window offers **Download as a WireGuard config** for `wg-quick`.
- **Joining is fully undoable.** Press **Leave the VPN** on the server, or **Remove** it on the hub. To come back it needs a new join code.
- **Containers on the hub** (for example Docker) cannot reach the VPN. That is part of "nothing from outside the VPN gets into it".
- **Only paste join codes you made on your own hub.** A join code links your server into that VPN.

### Fixed
- If the VPN card ever failed to draw, the page hid the error and stayed on "Loading…". Errors now show (the panel's own tests found this).

### Under the hood
- `packaging/live/sbin/adminpanel-net`:
  - A VPN interface can have a Quick VPN role (`hub` or `member`) and a `relay` (the servers' /25).
  - The routing rules are written by `render_isolation`.
  - `sync_relay` sets per-interface forwarding, the sysctl file and the ufw rule after every change and every rollback.
  - Up to 250 peers per interface.
- `network.py`: new routes `POST /api/network/vpn/easy/server` (makes a join code) and `POST /api/network/vpn/easy/join` (uses one). Both ask for the password and 2FA code again, and the browser keeps each change. The status separates devices and servers and reports the role, the link to the hub, forwarding, the firewall rule and the routing rules.
- `static/page/vpneasy.js`, `static/vpn.html`: the join form, the Servers list, the **Add a server** window, the joined-server view and the Repair warnings.
- `tests/test_vpn_easy.py` covers the new rules, the join code from both ends, the joined-server role and its limits, the relay switching on and off, and Repair. Undoing any of these safety pieces makes a test fail.

**After upgrading, on the hub, once a server has joined:**
- `ip rule show` lists priorities 74, 76, 77 and 78.
- `sysctl net.ipv4.conf.adminvpn.forwarding` prints `1`.
- `ufw status` shows an `ALLOW FWD` line on `adminvpn`.

---

## v6.37.1: Quick VPN safety fixes (2026-11-24)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.37.1_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Quick VPN: safety fixes
Quick VPN (6.37.0) was put through a safety test: real WireGuard tunnels between isolated test networks, built from the configs the panel itself produces, plus hostile input against the server's network helper and the API. The VPN itself held up. Strangers get no answer at all. Wrong keys and wrong preshared keys get nowhere. A device cannot pretend to be another device. A removed device, and a stolen copy of its config, are locked out at once. The test also found the problems below, and this release fixes all of them.

- **Devices reach this server and nothing else.** On a server where IP forwarding is switched on and the firewall does not drop forwarded traffic (LXD, libvirt, a router setup, or ufw turned off can leave it like that), a VPN device could reach your other devices and the private network behind the server. The VPN now carries a routing rule that refuses anything arriving on it that is not for this server itself, whatever the forwarding switch and the firewall say. The panel and the server's own addresses stay reachable.
- **Your password and 2FA code are asked again** to turn the VPN on and to add a device, as pairing a phone already did. A new device is a new way into the server, so a stolen session alone can no longer create one.
- **Your browser keeps each change.** Quick VPN used to confirm its own changes. Now, like every other network change in the panel, a change undoes itself after two minutes unless your browser confirms it can still reach the panel. The page confirms on its own as soon as the answer arrives, and a device's QR code is only shown once it has been kept.
- **60 devices really fit.** Every device's preshared key counted towards a limit of 40 stored keys meant for unused drafts, so only 39 devices could be added. Keys in use no longer count. When a change is kept, the keys it stopped using are deleted straight away (for example a removed device's preshared key), instead of a week later.
- **The advanced editor leaves Quick VPN alone.** The advanced editor saves the whole VPN list from its draft, so a draft opened before you removed a device in Quick VPN could bring that device back. The server now ignores what any draft says about Quick VPN's interface. The editor shows it as "Managed by Quick VPN", and the name `adminvpn` is reserved.
- **Operators and viewers** could see, through the VPN status, whether the administrator-only sign-in address list is on. Now only administrators see that.
- **The downloaded config** (it holds the device's private key) is released from the browser tab's memory right after the download.
- **A port typed with an unusual digit** (for example ²) made the network helper fail with a Python error. Ports now accept only 0 to 9 and get a clear message otherwise. This also affects the advanced editor.

**If you turned Quick VPN on with 6.37.0:** the card shows **Add the protection**. Press it once. The protection is also added with your next device change.

**After upgrading, on the server:** `ip rule show` should list `from all iif adminvpn lookup 7077`, and `ip route show table 7077` should show `unreachable default`.

### Under the hood
- `packaging/live/sbin/adminpanel-net`: an `isolate` setting for one VPN interface, written to its `.network` file as a `[RoutingPolicyRule]` (incoming interface, table 7077, priority 77) and a `[Route]` of type `unreachable` in that table. The key limit counts only keys no applied setting uses. `confirm` deletes the keys the kept change stopped using. Endpoint ports must be ASCII digits.
- `network.py`: Quick VPN changes are applied with a 120-second rollback timer and kept by the page (`POST /api/network/confirm`). Turning on and adding a device use the same password-and-code check as phone pairing. There is a new `POST /api/network/vpn/easy/protect`. `POST /api/network/apply` keeps Quick VPN's interface as it is on the server.
- `static/page/vpneasy.js`, `static/vpn.html`, `static/page/vpn.js`: password and code fields, keeping each change, the protection button, the read-only `adminvpn` row, and releasing downloaded configs.
- `tests/test_vpn_easy.py` covers every fix, and undoing any one of them makes it fail.

---

## v6.37.0: Quick VPN, a WireGuard VPN you set up with one button (2026-11-24)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.37.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: Quick VPN, a WireGuard VPN you set up with one button
At the top of **Networking → Configuration → VPN** there is now a **Quick VPN** card. It is the simple way to reach this server (and its panel) from your phone or laptop without leaving the panel open to the whole internet.

1. **Turn on the VPN.** The panel makes a private network that only your own devices can join (it picks a free `10.x.0.0/24`, starting at `10.77.0.0/24`, and never one that overlaps a network the server already uses), creates the server's key, starts the tunnel and opens its UDP port in the firewall. You never type a `wg` command.
2. **Add a device.** Give it a name and confirm the server's public address. The panel makes the device's keys and shows a **QR code** for the free WireGuard app on a phone, and a `.conf` file to import on a computer. The device's private key is shown once and is **never stored** on the server; closing the window wipes it from the page.
3. **See who is connected.** The list shows each device's address, whether it is connected right now, when it was last seen and its traffic. **Remove** takes a device off the VPN at once.
4. **Turn it off** again whenever you like. Doing so also removes the firewall rules it added.

Things it does for you, so you don't get caught out:

- It refuses to remove the device you are using, or to turn the VPN off, while you are connected through it. Both would cut you off.
- Every change goes through the same checks and the same automatic rollback as the advanced network editor.
- It tells you when the firewall is missing a rule, and when **Where people may sign in from** is on and does not include the VPN network (the panel would refuse VPN devices until you add it).
- It reminds you that cloud servers (AWS, Lightsail, Azure, DigitalOcean…) have a second firewall in the provider's own website, and the VPN's UDP port must be opened there too.
- Operators can look at the card. Only administrators can change anything. Every change is in the audit log (never the keys or configs).

**What it does not do yet:** it is a hub for your devices to reach **this** server. It does not yet let devices reach each other or other servers through it (that needs forwarding, planned for a later version), and it does not close the panel to the public for you. Once the VPN works, restrict the public port yourself.

### Fixed: "Generate a peer config" did nothing
The advanced editor's **Generate a peer config…** button asked the server's network helper for a command (`wg-peer`) that the helper never had, so it always failed. The command now exists. It makes the device's key pair and, optionally, a preshared key, builds the config file, and stores only the preshared key. The device's own private key is printed once and not kept.

### Fixed: options that looked available but did nothing
The advanced editor offers **Gateway** (forwarding and NAT) and **full tunnel**, and the peer generator offered "Everything". None of them was connected to anything in the helper, so ticking them silently changed nothing. They now say **not available yet** and are refused with a clear message instead of being ignored, and the generator no longer offers "Everything". The README no longer lists them as features.

### Under the hood
- `packaging/live/sbin/adminpanel-net`: new `wg-peer` command; key storing moved into one function shared by `wg-key` and `wg-peer`; clear errors for the gateway and full-tunnel options.
- `network.py`: new routes under `/api/network/vpn/easy` (`GET`, and `POST` for `enable`, `device`, `revoke`, `disable`).
- New `static/page/vpneasy.js`; `static/vpn.html` carries the card and the device window.
- `tests/test_vpn_easy.py` covers the helper (against a fake `wg`), the routes (against a stand-in helper) and the page wiring.
- No new package is needed: `wireguard-tools` is already recommended by the `.deb` and checked by `adminpanel-selfcheck`, and the QR code is drawn by the `qrcode` library the panel already ships.

---

## v6.36.1: The editor window stays over the page (2026-11-24)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.36.1_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Fix: the editor opened at the bottom of the page and dragged the file list down with it
In 6.36.0 the editor's window was given a `display` of its own, which also applied while it was **closed**. A closed `<dialog>` is supposed to disappear; this one stayed in the page, below the file list, which made the page taller, and the browser then did not always treat the next open as a window over the page. Opening a file could scroll the file list to the bottom and show the editor there, half off the screen and with the page behind it still live.

- The editor's layout now applies only while it is open (`#editor[open]`), so a closed editor is gone from the page again.
- Both file manager windows are pinned to the middle of the browser window, so even if a browser or an extension ever takes one out of its top layer, it cannot fall to the bottom of the page.
- Opening a file no longer moves the page: the editor asks for the keyboard without scrolling, puts the scroll position back, and opens the window again as a proper one if it finds that it is not.
- `tests/test_editor.py` now checks all of this, so it cannot come back.

---

## v6.36.0: A code editor in the file manager (2026-11-24)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.36.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: a code editor in the file manager
Opening a text file in the file manager now opens a proper editor instead of a plain box. It is written for this panel, needs no internet and adds no packages: nothing is fetched from a CDN, so it also works on a server with no way out to the internet.

- **Line numbers**, the line you are on, and a status line with *Ln, Col*, the language, the indent and a **Wrap** switch.
- **Colours** for 26 languages, picked from the file's name or its `#!` line: Python, JavaScript, TypeScript, JSON, HTML (the `<script>` and `<style>` parts get their own colours), XML, CSS, Sass, shell, Java, C and C++, Go, Rust, PHP, Ruby, Perl, Lua, SQL, YAML, config and unit files, nginx, Dockerfile, Makefile, Markdown and diffs. The language can also be chosen by hand at the bottom right.
- **Indenting that behaves:** Tab and Shift+Tab indent the lines you selected, Enter keeps the indent (and adds one after `{` or a Python `:`), Backspace takes a whole indent away, brackets and quotes close themselves, and the editor keeps the file's own style (tabs, or 2, 4 or 8 spaces).
- **Keys:** Ctrl+S save, Ctrl+F find, Ctrl+H find and replace, Ctrl+G go to line, Ctrl+/ comment or uncomment, Ctrl+D duplicate the line, Alt+Up / Alt+Down move lines. Undo and redo are the browser's own, so they cover everything above.
- **Find and replace** with a match count, next and previous, replace one and replace all.
- **Expand** fills the window, and a dot next to the name shows when there is something not saved; closing with changes asks first.
- Colours go off by themselves above 160 KB so a very large file still opens quickly, and the 256 KB edit limit is unchanged.
- An **Edit** entry in the right-click menu opens any file in the editor, even one that would otherwise be downloaded.

Nothing changed on the server: the same `GET /api/fs/read` and `PUT /api/fs/write` are used, and a save still refuses when the file changed since it was opened. No new package is needed, so the `.deb` dependencies are unchanged.

- New files `static/page/editor.js` and `static/editor.css`; `static/files.html` and `static/page/files.js` use them.
- New test `tests/test_editor.py` (it runs the colouring under `node` when node is installed).

---

## v6.35.1: A copy you delete on purpose is not reported as missing (2026-11-23)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.35.1_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Fix: deleting a backup copy on purpose no longer raises "A backup is missing"
The check for vanished copies compared the recorded backups with the files on disk, so a copy you deleted yourself, from the web page or from the phone (6.35.0), was reported as missing and raised a critical alert. The helper now remembers which copies were removed on purpose and leaves them out. A copy that disappears by itself is still reported.
- Copies you already deleted before this update keep the old count until they drop out of the "keep N" window.
- Test extended: `tests/test_backup_missing_alert.py`.

---

## v6.35.0: Delete a backup copy from the phone (2026-11-23)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.35.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: delete a backup copy from the phone
The phone app (0.31.0) can delete one backup copy, for example a damaged one. Because a deleted copy is gone for good, this is **off by default**.
- New switch in the web panel (Backups, Phone): **Let administrators delete backup copies from the phone app**. It is separate from the restore switch. Only an administrator on a full phone gets the new capability `backup_delete`; an unreadable switch means off.
- New call `POST /api/mobile/v1/backups/{name}/delete`: the body repeats the copy's name, it needs an Idempotency-Key, and the panel refuses (409) when it is the only copy, when a backup or a check is running, or when the destination is not connected.
- Audit: **Backup copy deleted** (`backup_delete`) with the phone and request ID, and **Phone backup deletion switched** (`backup_phone_delete`). Feature flag `backup_delete`; see section 24 of the phone API contract.
- New test `tests/test_backup_delete_v1.py`.

---

## v6.34.0: Check a backup copy from the phone (2026-11-22)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.34.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: check a backup copy from the phone
Since 6.33.0 the panel tests one copy a day. Now the phone app (0.29.0) can test a copy on demand and shows what the checks found.
- New call `POST /api/mobile/v1/backups/{name}/check`: reads one copy right through (nothing is extracted or sent to the phone) and answers `{ok, entries}` or, for a damaged copy, `{ok: false, error}`. It needs the same right as starting a backup (operators and administrators on a full phone), an Idempotency-Key, and only one check runs at a time. It is recorded the same way as the web page's Check button, so a good result clears the "backup copy is damaged" alert.
- Every copy in the phone API now says when it was last checked and whether it was fine (`checked`: `{t, ok}`, or none).
- Audit: **Backup copy checked** (`backup_check`), with the phone and request ID. Feature flag `backup_check`; see section 23 of the phone API contract.
- New test `tests/test_backup_check_v1.py`.

---

## v6.33.0: Backup copies are checked on a schedule (2026-11-22)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.33.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: backup copies are checked on a schedule
Having a copy is not the same as being able to restore from it. A copy can be cut short or damaged on the disk or share and you would only find out on the day you need it.
- When scheduled backups are on, the hourly run now **reads one copy right through** (`tar -tz`; nothing is written or extracted) at most once every 20 hours. A copy never checked goes first, newest first, then the one checked longest ago, so every kept copy is tested in turn. It runs at idle priority, never while a backup is running, and never connects a destination that is not already connected.
- A failed read is tried once more before the copy is called damaged, and a slow check or a copy that was deleted while it was read records nothing.
- The Alerts list (and email, chat and phone alerts) shows **"A backup copy is damaged"** (critical). It clears when the copy is deleted, pushed out by newer ones, or checked again and found fine.
- The Backups page shows, under each copy, when it was last checked and whether it was fine. The **Check** button records its result the same way.
- The phone gets its own event type, `backup_damaged`, opening the Backups screen (app 0.28.2 gives it the backup icon).
- The root helper's `brief` report carries a new `verify` field ({copies, checked, bad, last_t, bad_t}); results are kept in `/var/lib/adminpanel/backup-verify.json`. The rule lives in `backupcheck.damaged_alert()`.
- New test `tests/test_backup_verify.py` (includes the real helper).

---

## v6.32.1: Backup alerts open the Backups page (2026-11-22)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.32.1_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Fix: the "Open" button on backup alerts
The **Open** link on every backup alert (backup failed, overdue, grew, and the new "A backup is missing") pointed at `/backup.html`, which does not exist, so it showed "Not Found". It now opens the Backups page (`/backups.html`). Found while testing the missing-backups alert.
- Tests for the backup alerts now check the correct link.

---

## v6.32.0: Alert when backups that should still be kept are missing (2026-11-22)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.32.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: a warning when backups you should still have are gone
"Keep the newest 7 copies" only means something if the copies are really there. Someone deleting copies by hand, a cleaned backup folder or a swapped disk used to go unnoticed until the day you needed a restore.
- The Alerts list (and email, chat and phone alerts) now shows **"A backup is missing"** or **"Some backups are missing"** when copies that the keep rule should still hold can no longer be found in the backup folder. It is a warning, and critical when all or all but one of the recent copies are gone.
- Normal pruning never triggers it: old copies are only removed once newer ones push them out of the newest N. Only copies recorded for the current destination count, and it needs two recorded copies before it can judge. It clears by itself once newer copies replace the missing ones.
- It does not look when the destination is not connected (a network share that is down says so in its own way), and it never connects one.
- The phone gets its own event type, `backup_missing`, opening the Backups screen (app 0.28.1 gives it the backup icon).
- The root helper's `brief` report carries a new `kept` field ({keep, expected, missing}). The rule lives in `backupcheck.missing_alert()`.
- New test `tests/test_backup_missing_alert.py` (includes the real helper).

---

## v6.31.2: Fix: release check finds bandit in the virtualenv (2026-11-22)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.31.2_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Fix: the release check finds bandit in the panel's virtualenv
- `tools/release-check.sh` only looked for `bandit` on the PATH, so it said "bandit is not installed" even when it was installed in the panel's virtualenv (`./.venv`). It now tries the virtualenv's Python first (`python -m bandit`), then the PATH, and skips the `.venv` folder when scanning.
- Nothing in the panel itself changes. A scan of the current source reports no medium or high findings.

---

## v6.31.1: Tidy: unused imports removed (2026-11-22)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.31.1_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Tidy: unused imports removed
- Removed the 16 imports that nothing used (in `aging.py`, `audit.py`, `auth.py`, `autoupdates.py`, `create_user.py`, `diskusage.py`, `enroll_2fa.py`, `fs.py`, `images.py`, `ipallow.py`, `logins.py`, `packages.py`, `paneladmin.py`, `storage.py`, `volumes.py` and the `adminpanel-aging` helper). Nothing changes for users.
- `tools/release-check.sh` now reports no unused-import warning. The imports in `app.py` stay on purpose: each one registers a router.

---

## v6.31.0: Browse and restore backups from the phone, off by default (2026-11-22)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.31.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: browse and restore backups from the phone (off by default)
- On the Backups page there is a new tick box, **Let administrators browse and restore copies from the phone app**. It is **off** until you turn it on. Only administrators on a full phone get it; phones with read-only access and operators never do.
- With it on, the phone app (0.28.0) can look inside a copy, search it, restore chosen files or a whole copy, and delete restored folders.
- A restore only copies files into the protected restored-folders area, exactly like the web page. It never touches live files, and the phone cannot download what it restored: putting a file back is still done on the server's console.
- Every restore and delete from a phone is written to the audit log with the phone and request ID; changing the tick box is audited too. The phone API contract has a new section 22.
- New phone calls: `GET /backups/{name}/files`, `POST /backups/{name}/restore`, `GET /restores`, `POST /restores/{folder}/delete`; new module `mobilerestore.py` and switch module `backupphone.py`.
- New test `tests/test_restore_v1.py`.

---

## v6.30.0: Alert when a backup is much bigger than usual (2026-11-21)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.30.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: a warning when a backup is much bigger than usual
A hidden editor folder once took a backup from 110 MB to 600 MB and nothing said so until the disk was full.
- The Alerts list (and email, chat and phone alerts, like every other alert) now shows the warning **"The newest backup is much bigger than usual"** when the latest successful backup is at least twice the usual size (the median of the seven before it) and at least 50 MB bigger. It says how big it is and where to look: Backups, "What makes a backup big".
- It needs three backups before it can say what is usual, and it works for scheduled and manual backups. It clears by itself after the next normal-sized backup. A failed latest run still shows only "The last backup failed".
- The phone gets its own event type, `backup_grew` (it was never mislabelled as a failure), opening the Backups screen.
- The root helper's `brief` report now carries the sizes of the last successful runs. The one rule for "bigger than usual" lives in `backupcheck.growth()` and is shared with the phone's Backups screen.
- New test `tests/test_backup_jump_alert.py` (includes the real helper).

---

## v6.29.0: Phone backups, left out and size trend (2026-11-21)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.29.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: what a backup leaves out and how its size changes, for the phone app
For the phone app 0.27.0 (Backups screen).
- `GET /api/mobile/v1/backups` now also says which folders backups leave out (the standard tool and cache folders, and the ones you chose in the web panel) and gives the sizes of the last ten successful copies.
- It says when the newest copy is much bigger than usual (at least twice the median of the earlier ones and at least 50 MB more), the kind of jump that a hidden editor folder caused on the test server.
- Read only. Older phone apps ignore the new fields; an older panel simply lacks them.
- The root helper's `status` now reports its built-in skip list, so the phone and the panel never disagree about it. New test `tests/test_mobile_backup_trend.py`; contract section 12 updated.

---

## v6.28.0: Backup folders to leave out and sizes (2026-11-21)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.28.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: see what makes a backup big, and choose folders to leave out (Backups page)
Prompted by a backup that grew from 110 MB to 600 MB because of a hidden editor folder.
- **Folders to leave out:** a new box in the settings. Each line is a full path inside a folder you save (for example `/home/you/Downloads`). Backups skip it and everything below it. The helper checks every line again: it must be a plain full path (no `..`, no `*`, `?` or `[`), it must exist and lie inside a saved folder, at most 30. A refused save changes nothing.
- **What makes a backup big:** a new Measure button lists the biggest folders one and two levels inside the folders you save, with their sizes (before compression), and a **Leave out** button on each that adds it to the box. The total, and how much of it is already left out, is shown. Measuring stops after 100 seconds.
- Editor servers and caches (`.vscode-server`, `.cursor-server`, `.cache`) stay left out as in 6.26.1.
- The audit record of a settings change now says how many folders are left out. Old settings files without the new field keep working.
- New root-helper command `adminpanel-backup sizes` (read only), new route `GET /api/backup/sizes`; new tests `tests/test_backup_exclude.py` (runs the real `tar` and `du`) and `tests/test_backup_route_exclude.py`.

---

## v6.27.0: Free-space overview for the phone (2026-11-21)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.27.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: free-space overview for the phone app
For the phone app 0.26.0, which shows a "Free up space" screen. It opens from a disk alert and from More.
- New read-only call `GET /api/mobile/v1/freespace` (contract section 21): how full the root disk is, and what could give space back (package cache, unused packages and old kernels, the system journal, growing the root volume), the largest first.
- Any role can read it. Nothing can be changed from the phone; cleaning up stays on the web panel (Storage, Free up space), where only administrators can do it.
- The answer holds sizes and at most eight package names, never paths or commands, and is kept for 30 seconds.
- New `features.freespace` flag in the phone capabilities; new test `tests/test_freespace_v1.py`.

---

## v6.26.2: Failed backups are always reported (2026-11-21)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.26.2_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Fix: a failed backup is reported even when scheduled backups are off
Found on the test server: a backup started by hand was refused because the disk was nearly full, and nothing warned about it, because the backup alerts only watched scheduled backups.
- With scheduled backups off, a backup that failed (for example "less than 500 MB free") now raises the critical alert "The last backup failed". It shows on the Alerts page, in email and chat alerts, and on the phone, and it goes away when a backup succeeds or after seven days.
- The phone's Backups screen shows the same problem instead of only "Scheduled backups are off".
- Scheduled backups behave as before.
- New test `tests/test_backupcheck.py`.

---

## v6.26.1: Backups skip editor servers (2026-11-21)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.26.1_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Fix: backups no longer swallow editor servers and caches
Found on the test server: after a few days the backup grew from about 110 MB to 600 MB, because the home folder held a VS Code remote server (`.vscode-server`). With the disk nearly full, the next runs were then refused by the 500 MB free-space guard.
- Folders named `.vscode-server`, `.vscode-server-insiders`, `.cursor-server` and `.cache` are now left out of backups. They are downloaded again when needed; your own files are unchanged.
- New test `tests/test_backup_skip.py` runs the real `tar` and checks what is in the archive.

---

## v6.26.0: Free up space page (2026-11-21)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.26.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: Free up space (Storage > Free up space)
A page for when the disk is nearly full. It shows how much room is left and what can safely be given back:
- **Package cache**: empties the downloaded `.deb` files (`apt-get clean`).
- **Unused packages and old kernels**: shows the exact list first, then removes them (`apt-get autoremove --purge`). The list is refused if it holds the running kernel, the panel, nginx, ssh, sudo, Python or the boot loader.
- **Grow the root volume**: on LVM systems with free room in the volume group, extends the root volume and its file system in one step.
- Only administrators can change anything; every action is written to the audit log with the space freed. One cleanup runs at a time.
- A root helper (`adminpanel-freespace`) does the work; the panel never runs apt itself. The self-check tests it.
- New test `tests/test_freespace.py` (verified with stubbed commands; try it on a real machine first).

---

## v6.25.1: Setup fixes for Debian (2026-11-21)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.25.1_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Fix: first-time setup on a fresh Debian
Found while setting the panel up on a plain Debian 13 machine.
- `adminpanel-setup` and `adminpanel-selfcheck` now set their own PATH. After `su` (without the dash) root's PATH lacks `/usr/sbin`, so setup claimed "nginx is not installed" although it was.
- When nginx will not start during setup, the message now says why in plain words. The common case on Debian is another web server (Apache) already using port 80 while nginx's own `default` site wants it; setup shows the exact command that switches the default site off (it only removes a shortcut) and tells you to run setup again. Before, it stopped with only systemd's "see journalctl".
- New test `tests/test_setup_nginx_fail.py`.

---

## v6.25.0: Security scan clean-up (2026-11-21)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.25.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Security scan clean-up (no change in what the panel does)
- The bandit scan now reports **no medium or high findings**. Each of the 15 was read, and none was a real hole:
  - 10 SQL notices (approvals, maintenance windows, alert centre, performance history) build their text only from fixed module constants or a number checked to a range; every value from a request is bound as a parameter. Each is marked `# nosec B608` with that reason.
  - 2 SSH command notices (file manager and remote servers): one runs only shell-quoted, base64-wrapped arguments, the other a fixed command with the request sent as JSON on stdin. Marked `# nosec B601`.
  - 1 temp-folder notice (the Terminal's key goes to the RAM folder `/dev/shm` so it never reaches a disk). Marked `# nosec B108`.
  - 1 weak-hash notice: the audit record id is a short SHA-1 of the record. It is not a security hash, so it is now marked `usedforsecurity=False` (the ids do not change).
  - 1 URL notice: alerts now refuse any address that is not `http://` or `https://` before opening it (a small hardening; the built-in services already use https).
- `tools/release-check.sh` now treats a new medium or high bandit finding as a failure.
- New test `tests/test_bandit_fixes.py`.

---

## v6.24.0: Command presets from the phone (2026-11-21)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.24.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: edit command presets from the phone app (with app 0.24.0)
- Administrators on a full phone can add, edit, reorder and delete command presets in the app. The phone calls `GET` and `PUT /api/mobile/v1/presets/manage` (contract section 20); the panel saves through the same root helper as the web editor, which checks every entry again (full program path, no shells or interpreters, limits).
- **It is off by default.** Presets are commands that run as root, so you turn it on yourself: web panel, Command presets, tick "Let administrators edit these presets from the phone app". That switch can only be changed from the web panel, never from a phone. Operators, viewers and read-only phones never get the editor, and untick the box to close it again.
- Every save from a phone is in the audit log with the phone and request ID (`presets_save`, `presets_save_refused`); switching the option is logged as `presets_phone_edit`.
- New module `presetsphone.py` (included in the package); new capability `presets_edit` and feature flag `presets_edit`.

---

## v6.23.2: Test fixes (2026-11-21)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.23.2_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Fix: two tests failed on a normal (non-root) server
- `tests/test_maint_v1.py` ended a maintenance window in the same second it began, which the panel (correctly) records as cancelled. The test now waits a second first.
- `tests/test_presets_temp_v1.py` runs the root helper, which only trusts files owned by root. As a normal user it now reports "skipped" instead of failing; run it with `sudo ./.venv/bin/python tests/test_presets_temp_v1.py` to include it.
- The release checklist's missing-module hint now says `./.venv/bin/pip install <name>`.

---

## v6.23.1: Release checklist fixes (2026-11-21)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.23.1_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Fix: the release checklist on a normal server
- The commit-author check compares the e-mail address only, so `kofi` and `Kofi` both pass.
- The panel tests run with the panel's own virtualenv when one is found (`$VIRTUAL_ENV`, `./.venv`, `~/.venv`), so they no longer skip for a missing `pyotp` or `fastapi`.
- `tests/test_presets_save.py` needs root; run as a normal user it now reports "skipped" instead of failing. Run it with `sudo` to include it.

---

## v6.23.0: Release checklist script (2026-11-21)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.23.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: a release checklist script for maintainers
- `bash tools/release-check.sh` runs every check before you tag a release: git state (clean tree, tag not already used, commit author, no co-author trailers), version numbers agree across `packaging/VERSION`, the release notes, the install guide and the README, every Python file compiles, pyflakes finds no undefined names, shell scripts and page scripts parse, the sudoers files pass `visudo`, all panel tests pass, bandit scan, and the .deb builds with every module, page and the self-check inside it.
- It prints PASS, WARN or FAIL for each check, saves the same text to `release-check-report.txt`, and ends with the tag and release commands. It never changes files, commits, tags or pushes.
- `--no-build` skips the package build; `--selfcheck` also runs `adminpanel-selfcheck` when the package is installed on that machine.
- The panel tests now live in the repository under `tests/` (run one with `PYTHONPATH=. python3 tests/test_panel.py`). Nothing changes for people running the panel.

---

## v6.22.0: Logo fix for the phone app (2026-11-21)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.22.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Fix: the logo showed as a black square in the phone app
- Some distribution logos (the Ubuntu one is an example) colour their shapes with a CSS `<style>` block. Browsers handle that, but the phone app's SVG drawer ignores it, so every shape came out black.
- The phone call `GET /api/mobile/v1/distro` now copies simple class rules onto each shape before sending the logo. A logo that uses CSS it cannot translate is not sent at all, so the app shows no logo instead of a black square. The web pages are unchanged.
- Works with phone app 0.23.1, which also refuses to draw an SVG that still contains a `<style>` block.

---

## v6.21.0: Browser-tab icon is the distribution logo (2026-11-21)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.21.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Browser-tab icon is the distribution logo
- The icon on the browser tab (and in bookmarks) is now the logo of the Linux distribution the server runs, on every page including the sign-in page. It is the same logo the sign-in page and top bar show, including a file you put in `/etc/adminpanel/logos/`.
- If the system has no logo, the browser keeps its default icon. Browsers keep tab icons for a while, so after updating you may need to reload the page once or twice (or close and reopen the tab) to see the new icon.
- No new package, no setting changes, no API changes.

---

## v6.20.0: Distribution logo for the phone app (2026-11-21)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.20.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Distribution logo for the phone app
- New read-only phone call `GET /api/mobile/v1/distro` (contract section 19, `features.distro`). It returns the short distribution name and, when the system has a logo, the image as base64 over the same pinned connection (SVG or PNG, at most 120 KB). With no logo it returns `null` and the app shows its own icon.
- It uses the same logo as the sign-in page and top bar (`distrologo.py`), including a file you put in `/etc/adminpanel/logos/`.
- The panel ships no distribution artwork. Needs phone app 0.23.0 to be displayed; older apps ignore it. No new package, no setting changes.

---

## v6.19.0: Command presets editor (2026-11-21)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.19.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Create command presets in the web panel
- New page **Tools, Command presets**: add, edit, reorder and delete the fixed commands the phone app can run, with no JSON editing. Type the command as one line; the page shows how it is split into parts (no shell, so `|`, `&&`, `>` and `$VAR` are plain text). Examples can be filled in with one click. Each save checks every entry and keeps the previous list as `presets.json.bak`.
- **Safety:** administrators only, in the browser only (the phone is refused, as for every administrators-only page). The panel account still cannot write the file; the root helper `adminpanel-presets` has new `dump` and `save` commands that re-check each entry (full program path, root-owned and not writable by others, 1 to 25 seconds, at most 20 presets) and replace `/etc/adminpanel/presets.json` atomically, owned by root. Every save is in the audit log.
- Presets made in the editor cannot start a shell or interpreter (`sh`, `bash`, `python`, `env`, `sudo` and similar); use a root-owned script instead. Presets you wrote by hand keep working exactly as before, and hand-editing the file is still supported.
- New module `presetsadmin.py`; the sudoers entry for the helper gains `dump` and `save`. The phone app is unchanged (it still only lists and runs presets).

---

## v6.18.0: Distribution logo in the top bar (2026-11-21)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.18.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Distribution logo in the top bar
- The logo of the Linux distribution (the same one the sign-in page shows since 6.17.0) now also sits at the left of the top bar, next to your user name and the server name, on every page.
- If the system has no logo, the top bar looks exactly as before. Put `<id>.svg` or `<id>.png` in `/etc/adminpanel/logos/` to choose the image yourself.
- Long server names are now shortened with an ellipsis instead of pushing the layout. No new package, no setting changes, no API changes.

---

## v6.17.0: Distribution logo on the sign-in page (2026-11-21)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.17.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Sign-in page shows the logo of the system it runs on
- The sign-in page now shows the logo of the Linux distribution installed on the server (Ubuntu, Debian, Linux Mint and so on) inside the dial mark, and says "Sign in to manage this Ubuntu server". Only the short distribution name is shown before sign-in, never the version.
- The panel ships **no** distribution artwork. It uses the logo files the system already has (icon themes, `desktop-base`, the `LOGO=` entry of `/etc/os-release`). To use a particular image, put `<id>.svg` or `<id>.png` (for example `ubuntu.svg`) in `/etc/adminpanel/logos/`; that file wins. With no logo found, the panel's own dial mark is shown, as before.
- New module `distrologo.py` with two read-only routes, `/api/distro` and `/api/distro-logo`. Only `.svg` and `.png` files up to 300 KB are served, with a sandboxing content-security policy.
- Package: `desktop-base` is now suggested (it carries the Debian logo), and `adminpanel-selfcheck` reports whether a logo was found (a note, never a failure).

---

## v6.16.0: Sign-in page in the new look (2026-11-21)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.16.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Sign-in page in the new look
- A small gradient dial mark above the title, a gradient line along the top of the card, and centred heading text, in both the dark and light themes.
- Sign-in itself is unchanged: same fields, same two-factor step. No new package, no setting changes, no API changes.

---

## v6.15.0: More pages in the new look (2026-11-21)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.15.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### More pages in the new look
- **Disk usage** and **Startup** bars use the same cyan-to-green gradient as the dials and meters.
- **Alerts** cards and the "all clear" box sit on the card colour, so they match the rest of the charcoal theme.
- No new package, no setting changes, no API changes.

---

## v6.14.0: Gradient style on History and Storage (2026-11-21)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.14.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Gradient style on the History charts and Storage meters
- **History charts** (Overview) use the same cyan, green and yellow as the dials, with a soft fade under each line.
- **Storage usage meters** are rounded gradient bars. They turn warm from 75 % full and pink-orange from 95 %.
- The live sparklines on the Overview cards use the same colours. Both themes are supported.
- No new package, no setting changes, no API changes.

---

## v6.13.0: Web look matches the phone app (2026-11-21)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.13.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Web look matches the phone app
- **Charcoal dark theme.** The dark theme now uses neutral charcoal greys (page `#202020` fading to `#191919`, cards `#262626`, edges `#343434`) in place of the earlier blue-grey. The light theme keeps its colours.
- **Gradient dials on the Overview.** CPU, Memory and Disk are shown as 270-degree gradient dials with the percentage in the middle, a soft glow in the dark theme, and warmer colours from 75 %. They follow the Dark / Light button.
- No new package, no setting changes, no API changes. Nothing to do on the phone.

---

## v6.12.1: Housekeeping (2026-11-21)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.12.1_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Housekeeping
- Removed five unused imports and one unused variable in the phone-app modules (`mobile.py`, `mobiletemp.py`, `mobileapprovals.py`, `chatalerts.py`). Nothing changes for you; the code is just tidier and a source check (`pyflakes`) is now clean for them.
- No new package, no setting changes, and the phone app needs no update.

---

## v6.12.0: Push alerts to the phone through ntfy (2026-11-21)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.12.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: push alerts to the phone (ntfy)
A new section on the *Alerts* page, **Push to the phone (ntfy)**. Alerts are sent to a topic on an ntfy server (the free ntfy.sh by default, or your own), and the free **ntfy** Android app shows them the moment they arrive, even when the AdminPanel app is closed. It works beside email, Telegram and WhatsApp and sends the same messages, including sign-in notices.
- **Make a topic** creates a random topic. Anyone who knows the topic can read the alerts, so keep it private. A private server can be used with an access token, which is kept in its own file readable only by the panel account and never sent back.
- The panel never follows a redirect from the push server, so the token only goes where you set it.
- The phone app (0.21.0) has a **Push alerts** screen for administrators: it shows the topic, opens the ntfy app already subscribed, and sends a test.

Details: [docs/mobile-api-v1.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/mobile-api-v1.md), section 18. The capabilities answer has the `push` feature and the `push_info` capability.

### Good to know
- No new package is needed: the panel calls the ntfy server over HTTPS itself.
- Older app versions keep working and simply do not show the new screen.

---

## v6.11.0: Command presets and temporary read-only access for the phone app (2026-11-20)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.11.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: command presets for the phone app
You decide which quick commands the phone may run. Write them in `/etc/adminpanel/presets.json` (root-owned); the phone lists them and runs one **by name**. It can never type a command.
- A new root helper, `adminpanel-presets`, re-reads the file each time and runs the stored command directly: no shell, 25 seconds at most, output cut at 4 KB.
- A file that is not owned by root, or a program others can write to, is refused.
- Operators and admins can run presets; `"admin_only": true` limits one to admins. Read-only phones can only look.
- One preset at a time. Every run is in the audit log with the phone and request ID.
- A first preset, `check-disk`, is installed only if you have no presets file yet.

### New: temporary read-only access
An admin on a full phone can make a QR that gives another phone **read-only** access for 15 minutes, 1 hour or 24 hours. It ends by itself and can be revoked at once. The QR works once for 10 minutes; at most 3 temporary accesses exist at a time; every step is audited.

Details: [docs/mobile-api-v1.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/mobile-api-v1.md), sections 16 and 17. The capabilities answer now has `presets` and `temp_access` features and `presets_run` and `temp_access` capabilities.

### Good to know
- No new package is needed. `adminpanel-selfcheck` now checks the presets helper and its sudo rule.
- Older app versions keep working and simply do not show the new screens.

---

## v6.10.0: Two-person approval for the phone app (2026-11-20)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.10.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: two-person approval for the phone app
A risky action can now need two people. An operator or admin **requests** it from the app; a **different administrator approves** it, and only then does the panel run it, under the approver's name.
- Actions are a fixed list: reboot, install updates, run a backup. No free text, no commands.
- Nobody can approve their own request, a request expires after 10 minutes, and each approved request runs at most once.
- A phone can reboot the machine **only** through an approval.
- An administrator can make "install updates" and "run a backup" approval-only for phones (the policy, off by default). The web panel is not affected by the policy.
- Every step is in the audit log with the phone and request ID.

Details: [docs/mobile-api-v1.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/mobile-api-v1.md), section 15. The capabilities answer now says `"approvals": true` and has `approval_request`, `approval_decide`, `approval_needed_updates` and `approval_needed_backup`.

### Good to know
- No new package is needed. Older app versions keep working and simply do not show the new screen.
- With the policy on, an older app that still shows a Backup or Install button gets a clear "needs a second administrator's approval" refusal instead of the action.

---

## v6.9.0: Audit log, incident timeline and incidents for the phone app (2026-11-20)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.9.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: records for the phone app (admins)
An admin's phone can now read three things, all redacted by the panel before they leave it:
- **Audit log** (`/api/mobile/v1/audit`): who did what, from which device, with what result. Filter by person, action, result and time (1 hour to 30 days or an exact window) and search; pages never shift when new lines are written meanwhile.
- **Incident timeline** (`/api/mobile/v1/timeline`): alerts (held ones marked) and notable actions merged into one chronology for up to 7 days. If one source cannot be read, the answer says so instead of silently leaving it out.
- **Incidents** (`/api/mobile/v1/incidents`): bursts of warning or critical alerts from the last 30 days, so you can pick "what happened Tuesday night".

Only a short list of harmless fields is ever passed on (never paths, commands, passwords, keys, codes or file contents), and every address comes with a masked twin so an export can leave the last part out. The web audit page is unchanged and still admin-only; operators, viewers and read-only phones get 403 from the new calls.

Details: [docs/mobile-api-v1.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/mobile-api-v1.md), section 14. The capabilities answer now says `"audit": true`, `"timeline": true` and `audit_view` is true for an admin's phone.

### Good to know
- Nothing is stored or changed: these calls only read the existing audit log and alert history.
- No new package is needed. Older app versions keep working and simply do not show the new screens.

---

## v6.8.0: Maintenance windows and service dependents for the phone app (2026-11-20)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.8.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: maintenance windows for the phone app
Admins can announce planned work from the phone: `POST /api/mobile/v1/maintenance` starts a window now or at a chosen time (5 minutes to 24 hours, up to 30 days ahead, with an optional reason). While a window with muting is active, new alerts are **held**: they are still recorded and still listed (marked `muted`), but they do not raise the unread count and are not delivered to a phone's background check. Nothing is hidden or deleted. The start and the end of a window are announced as alerts of their own, and the end says how many alerts were held. An alert that appeared during the window and is still active afterwards is announced again when the window ends.

Only admins can start, plan or end a window (a read-only phone cannot). Every change needs an `Idempotency-Key` (a retry never creates two windows), windows never overlap, and each change is written to the audit log (`maintenance_start`, `maintenance_schedule`, `maintenance_end`) with the phone and request ID. Everyone who can view can see the current and planned windows.

### New: what depends on a service
`GET /api/mobile/v1/units/dependents?name=...` lists the units that depend on a service, with their state, so the phone can warn "3 running services depend on this" before you stop or restart something. It is read-only.

Details: [docs/mobile-api-v1.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/mobile-api-v1.md), section 13. The capabilities answer now says `"maintenance": true` and `"service_dependents": true`.

### Good to know
- The alert log gains a `muted` column; it is added automatically on first start and old events count as not held.
- The web panel's own alert page is unchanged. Older app versions keep working; they do not know about held alerts and will list them like any other.
- No new package is needed.

---

## v6.7.0: Backup management for the phone app (2026-11-20)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.7.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: backup management for the phone app
The phone app can now see and manage backups: `GET /api/mobile/v1/backups` says whether a backup is idle, starting or running (with elapsed time and the size written so far), the last result, the last good copy, the destination, the schedule, how many copies exist and how much disk is free, and whether the next run will remove the oldest copy. There is also a history of runs (successes, failures and cancellations, newest first) and the list of copies on the destination.

**Back up now** and **Cancel** are available from the phone for roles that may run backups. Both need an `Idempotency-Key`, so a bad connection and a retry can never start two backups. Only one backup runs at a time; asking for a second gets a clear 409. Both actions are written to the audit log with the phone and the request ID (`backup_start`, `backup_cancel`).

Cancelling stops the running backup safely: the unfinished file is removed, finished copies and the last result stay untouched, so cancelling never raises a false "backup failed" alert. Only backups started from the panel or the timer can be cancelled; one started by hand in a terminal is refused with an explanation.

The backup helper now keeps a bounded history of the last 30 runs (`/var/lib/adminpanel/backup-history.json`) with start time, duration and how many old copies were removed. It also reports progress while a backup runs.

The phone never sees host paths, share passwords or the contents of a copy. Details: [docs/mobile-api-v1.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/mobile-api-v1.md), section 12. The capabilities answer now says `"backups": true`.

### Good to know
- The package adds two permitted helper commands (`history`, `cancel`) to the backup sudoers file. Nothing else about privileges changes.
- The web Backups page works as before. Older app versions keep working; they do not show the backups screen.
- No new package is needed.

---

## v6.6.0: Performance history for the phone app (2026-11-19)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.6.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: performance history for the phone app
The panel already recorded CPU, memory, disk and network once a minute for seven days (the Overview graphs). The phone app can now read that history: `GET /api/mobile/v1/metrics/history?range=1h|6h|24h|7d` returns up to about 240 chart points, exact minimum / average / maximum for the range, the latest reading, how much of the range was actually recorded, and the panel's own warning levels for display.

The sampler now also records the one-minute **load average** and the **temperature** of the hottest sensor, and notes when a reading could not be taken. A machine without a temperature sensor (most virtual machines) shows temperature as unavailable, never as 0. Gaps stay gaps: while the panel was stopped nothing was recorded and nothing is invented. Every timestamp is the panel's own clock, and the reply says whether the sampler looks stuck, so the phone can label old data as old.

Every role and a read-only phone may read it (it shows what the web Overview already shows); nothing can be changed through it. The calls are in [docs/mobile-api-v1.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/mobile-api-v1.md), section 11. The capabilities answer now says `"metrics_history": true`.

### Good to know
- Existing data is kept. The history table gets three new columns when the panel starts; older rows simply have no load or temperature.
- Nothing changes in the web panel. Older app versions keep working; they do not show the performance screen.
- No new package, no root helper and no new audit lines (reading history is not an action).

---

## v6.5.0: Alert center for the phone app (2026-11-19)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.5.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: an alert center for the phone app
The panel now keeps a log of what went wrong and when, so the phone app can show an alert history, an unread count and links to the right screen, and can check in the background for anything new while the app is closed. It watches the same alert engine as the Alerts page and writes one event when something new goes wrong (a failed service, a failed or overdue backup, a disk or memory problem, a failing disk, an expiring certificate), a calm "ok" event when a service recovers or a backup problem clears, and events for newly available security updates and for a restart becoming necessary. The same problem is reported once, not on every check.

Each phone has its own read marks, filters and notification registration. They are deleted when a phone is unpaired or revoked, and a revoked phone receives nothing. The log keeps the newest 2000 events for up to 30 days. Events never contain passwords, tokens or certificate fingerprints.

The calls are in [docs/mobile-api-v1.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/mobile-api-v1.md), section 9. Delivery is by the phone checking in (polling); the registration already names a provider, so push delivery can be added later without changing the app's other calls.

### Good to know
- Nothing changes in the web panel. Older app versions keep working; they simply do not show the alert center.
- Two new audit lines: `notify_device_registered` / `notify_device_removed` and `notify_prefs`.
- No new package and no root helper.

---

## v6.4.0: Mobile API v1 foundation (2026-11-19)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.4.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: Mobile API v1 (the foundation for the next phone app)
The phone app now has a stable, versioned contract with the panel, written down in [docs/mobile-api-v1.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/mobile-api-v1.md). The first endpoint is `GET /api/mobile/v1/capabilities`, which tells the app which panel version it is talking to, who the phone is signed in as, and exactly what that phone may do (look, restart a service, run updates, schedule a restart, start a backup). The answers are worked out by the same permission function the panel already uses to allow or refuse requests, so the list cannot say yes where the panel would say no.

All v1 replies use one envelope with a request ID and the server's time, and every v1 error uses one error format. The request ID is also sent back as an `X-Request-ID` header so a problem seen on the phone can be found on the server.

The document also fixes, for everything the app will add later: one event shape shared by alerts, push messages and the audit log, paging rules, safe retries for actions that start work, which actions need which right and which audit record, and the rules the app follows for storing server details and upgrading them.

### Good to know
- Nothing changes in the web panel and nothing about existing phones: current endpoints and tokens work as before.
- No new package and no root helper.

---

## v6.3.1: Panel access fix and phone address (2026-11-18)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.3.1_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Fixed: the Panel access page reloaded itself behind nginx
Three forms on **Accounts, Panel access** (the "Confirm it is you" box, the sign-in address list and the new Phones form) blocked their own page reload with an inline `onsubmit` attribute. The panel's Content-Security-Policy forbids inline scripts, so behind nginx the browser ignored that attribute and reloaded the page whenever you pressed a button. The change itself still went through, but the page reset, so the pairing square vanished and the result message of an address-list save was lost. The forms are now handled by the page's script, and a new test fails if any page ever gets an inline event handler again.

### New: Phone address (Phones)
If the address you use in your browser is not one the phone can reach (an SSH tunnel to `localhost`, for example), type the address the phone should use in **Phone address** (such as `192.168.1.5:8443` or `panel.example.com`) before pressing **Add phone**. The square then carries that address instead of the browser's.

### New: no useless squares over plain http
The phone app only talks over https and checks the certificate, so a square made from a page opened over plain `http://` (for example the panel's internal port 8000 through a tunnel) can never work. The panel now says so and asks you to open the `https://` address or type the Phone address.

### Good to know
- No new package and no root helper.

---

## v6.3.0: Phone pairing (2026-11-17)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.3.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Nothing changes until you pair a phone. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: pair phones with the panel (Accounts, Panel access, Phones)
This is the groundwork for the Admin Panel mobile app. It adds safe, separate phone access without ever putting your password on a phone.
- **Pair with a square.** Type your password and a current code, name the phone and press **Add phone**. The panel shows a QR code (and a typed code) that works **once** and expires after 10 minutes. The square carries the panel's address and its certificate fingerprint, so the app can check it is talking to your server and not an impostor.
- **A token, not a password.** The phone receives a long random token. The panel stores only a hash of it (`phones.json`, mode 600), so a copy of the file cannot be used to sign in. Tokens are never written to the audit log.
- **Narrower than a browser.** A phone can read the dashboard, alerts, services, backups and updates, and do the everyday actions: restart or stop a service, start a backup, run updates, set or cancel the reboot schedule. It can **never** open the Terminal or File manager, change people, roles, passwords or two-step settings, edit the allow-list, power off, or pair more phones. Denied tries are logged as `role_denied`.
- **Look-only phones.** Tick *Look only* and the phone behaves as a viewer: it can see everything it is allowed to and change nothing.
- **Still bound by the person's role.** A phone belongs to the person who paired it. Demote them and their phones lose rights at once; remove them and their phones are deleted.
- **Control.** Each person can pair up to 5 phones and see and revoke their own; administrators see all. A revoked phone stops working immediately. A phone unused for 90 days expires by itself.
- **Same walls as the browser.** The sign-in address list applies to phones too, wrong pairing codes are rate limited per address, and the audit log records `phone_pair_started`, `phone_paired`, `phone_pair_failed`, `phone_revoked` and `phones_removed`.
- **One call for the app's home screen:** `GET /api/mobile/summary` returns the host, load, memory, disk, network, alert counts, backup state and whether a reboot is pending.

### Good to know
- The fingerprint shown is that of the certificate in `/etc/ssl/certs/adminpanel.crt`. If you replace the certificate, pair phones again.
- No new package and no root helper.

---

## v6.2.0: Sign-in address list (2026-11-17)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.2.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. The new list starts **off**, so nothing changes until you turn it on. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: sign-in address allow-list (Accounts, Panel access)
Limit the panel to chosen addresses or networks, for example only the school network or your VPN. Anyone else gets a plain `403` before they even see the sign-in page, so a stolen password (or a stolen session cookie) used from elsewhere is useless.
- **One address or network per line**, IPv4 or IPv6, for example `203.0.113.7`, `198.51.100.0/24`, `2001:db8::/32`. Up to 50 entries.
- **Covers everything**: pages, the API, the Terminal and live-log connections, in front of the login and the roles check.
- **It will not lock you out by mistake.** The panel refuses to save a list that does not include the address you are using right now (there is an **Add my address** button), and refuses an empty list.
- **This machine is always allowed.** Connections from `127.0.0.1` and `::1` (an SSH tunnel, or a person at the console) always pass, so the server's own administrator can never be shut out.
- **Recovery from the server:** `sudo adminpanel-setup ipallow show` prints the list, and `sudo adminpanel-setup ipallow off` switches it off at once (no restart needed).
- **Safe changes.** Saving needs your password and a current code, only administrators can see or change the list, and each change is written to the audit log as `ipallow_changed`. Blocked requests are logged as `ip_denied`, at most one line per address every five minutes so a scanner cannot fill the log.
- A damaged settings file never takes the panel down: it is treated as off.

### Good to know
- The address used is the real client address as nginx sees it. If you put another proxy or a load balancer in front of the panel, every request will look like it comes from that proxy, so list its address instead (or leave the list off).
- No new package and no root helper.

---

## v6.1.0: Audit log (2026-11-17)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.1.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: Audit log (Accounts, then Audit log)
Every change made through the panel has always been written to `audit.log`, but the only way to read it was `tail` on the server. This page shows it in the browser:
- **Search and filter** by time (last hour, 24 hours, 7 days, 30 days, everything kept), by person, by event type, and by free text (an address, a path, a unit name).
- **Plain names** for the common events ("Sign-in failed", "Refused by role", "Role changed", "Person added"), with the raw event name always available. Failures and refusals are shown in red.
- **Older weeks.** The log is rotated weekly and twelve copies are kept. Tick **Include older weeks** to search them too (compressed copies are read automatically).
- **Download CSV** of exactly what the filters show (up to 50,000 rows). Cells that start with `=`, `+`, `-` or `@` are defused so a spreadsheet cannot run them as formulas.
- **Safe on big logs:** only the newest 12 MB of each file is read, at most 200,000 lines per search, and the page says when that limit was hit.

### Safety
- **Administrators only.** Operators and viewers cannot open the page or the export (the log holds everyone's addresses and what they changed).
- Read only: nothing on this page can edit or delete a log line. The file stays append-only, and a copy of each line still goes to the system journal.
- No new package and no root helper.

---

## v6.0.0: Roles (2026-11-17)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_6.0.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. **Every existing account stays an administrator**, so nothing changes until you give someone else a smaller role. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Major change: roles
Until now everyone who could sign in to the panel could do everything, including opening a shell. 6.0.0 adds three roles, set per person on **Accounts, Panel access**:

| Role | What it can do |
|---|---|
| **Administrator** | Everything, as before. |
| **Operator** | Runs the machine: services, storage, backups, updates, reboots, containers, certificates, logs, cron. Can look at every page but cannot change accounts, SSH keys or the SSH server, sudo, the firewall, blocked addresses, the network, kernel settings, alert channels, sign-in notices, other servers or the hosts file, and cannot use the Terminal or the File manager. |
| **Viewer** | Read only. Can open every page and change nothing. Can still browse a backup, run ping and DNS lookups and read web logs, because those only read. |

- **One gate for the whole panel.** The rule is checked in one place in front of every request, including the live log and Terminal connections. Anything not explicitly allowed for a role is refused with a plain sentence ("You have read-only access (viewer)…"), so a page that forgets to check cannot leak a permission. Refusals are written to the audit log as `role_denied`.
- **Takes effect at once.** The role is read on every request, so promoting, demoting or removing someone applies to their open sessions immediately.
- **Safe defaults.** Accounts made before 6.0.0, or with no role, stay administrators. A new person defaults to Viewer in the form. An unknown role value gets the least power, never the most.
- **No lock-out.** You cannot change your own role, and the panel refuses to demote or remove the last administrator who can sign in.
- **Self-service for everyone.** Every role can change its own password, redo its own two-step setup, make new recovery codes and sign out its own sessions on the Panel access page.
- The top bar shows `name (role)` for operators and viewers, and hides the Terminal and File manager links for them.
- New audit events: `role_denied`, `panel_role_changed`; `panel_admin_added` now records the role.

### Compatibility
- `adminpanel-setup user` still creates administrators; make someone an operator or viewer from the Panel access page.
- No new package and no root helper.

---

## v5.17.0: Panel access (2026-11-17)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_5.17.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New: Panel access (Accounts, then Panel access)
Until now the panel's own administrators could only be managed from the server with `adminpanel-setup`. This page does it in the browser:
- **Administrators**: every panel administrator, whether two-step verification is on, how many recovery codes are left and how many sessions are signed in.
- **Add an administrator**: a name and a password. The new person cannot sign in until you press **Set up**, scan the QR code with an authenticator app and type the first code. The page then shows their ten recovery codes once.
- **Reset two-step** for anyone who lost their phone: a new QR code and new recovery codes; the old ones stop working.
- **Remove** an administrator: they are signed out at once. You cannot remove yourself, and the panel refuses to remove the last administrator who can sign in.
- **Change my password**: your other sessions are signed out afterwards.
- **My recovery codes** and **My sessions**: make a new set of recovery codes, see where you are signed in, and sign out one session or all the others (these used to exist only as hidden API calls).

### Safety
- Every change needs your password and a current six-digit code. A code works once, and wrong tries share the existing sign-in lock-out (429 after five).
- Password rules are the same as the setup command: at least 8 characters and one symbol.
- Nothing secret is written to the audit log. New events: `panel_admin_added`, `panel_admin_removed`, `panel_password_changed`, `panel_2fa_started`, `panel_2fa_enrolled`, `panel_stepup_failed`.
- No root helper and no new package: this only edits the panel's own `users.json`.

---

## v5.16.1: Firewall message when ufw is missing, self-check fix (2026-11-16)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_5.16.1_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Fixed
- **Firewall and Blocked addresses with ufw removed.** When the `ufw` program was not installed, these pages showed a raw Python error. They now say plainly: "The firewall program (ufw) is not installed. Install it with: sudo apt install ufw". Adding, removing and enabling rules, and blocking or unblocking an address, give the same message. A `ufw` command that takes too long now reports that instead of hanging.
- **False FAIL in the self-check.** `sudo adminpanel-selfcheck` could print "FAIL programs the panel needs are missing. Run: sudo apt install" with an empty list even though nothing was missing. It now reports the programs as installed, and names only real missing ones.
- The fail2ban helper also says "fail2ban is not installed" if the program disappears between two calls.

### Notes
- No new package is needed. `ufw` and `fail2ban` stay in Depends, so a normal install always has them; this only matters if someone removes them later.

---

## v5.16.0: Backup and inode alerts (2026-11-15)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_5.16.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Backup alerts.** The Alerts page, the top-bar count and every channel you have set up (email, Telegram, WhatsApp) now cover backups, as long as backups are switched on:
  - **The last backup failed** (critical), with the reason and how long ago.
  - **No backup for too long** (warning): the last good backup is older than the schedule allows (36 hours for daily, 8 days for weekly).
  - **Backups are on but none has run** (warning), after the schedule has had time to run once.
  Nothing is said while a backup is running or while backups are switched off. The alert clears by itself after the next good backup.
- **Out of file slots (inodes).** A disk can stop accepting new files while it still has free space, when it holds millions of tiny files. The Alerts page now warns at 90% of inodes used and goes critical at 97%, with a hint about where to look. Filesystems that do not report inodes (such as Btrfs) are skipped.

### Notes
- No new package is needed.
- The backup report is read through a new, cheap command of the existing backup helper (`brief`), which does not connect a share or list the copies, and is kept for two minutes because the Alerts list is requested often. If the helper cannot be reached the last good reading is used.

### Security note
- One command was added to the existing sudo rule for `adminpanel-backup`: `brief`, which takes no arguments and only reads the schedule and the last result. No new helper was added.

---

## v5.15.0: Sign-in notices (2026-11-15)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_5.15.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Sign-in notices.** A new section on the *Alerts* page. When switched on, the panel sends a message on every channel you have turned on (email, Telegram, WhatsApp) when:
  - someone signs in to an account from an address that account has not used before,
  - a recovery code is used to sign in,
  - sign-in is locked after too many wrong attempts (optional).
  You can choose **new addresses only** (the default) or **every sign-in**. There is a **Send test message** button and a **Forget my known addresses** button.
- The message says who, from which address, when, with which browser, and why you are being told, and what to do if it was not you.

### Notes
- The panel learns an account's addresses on every successful sign-in, even while the notices are off, so switching them on does not make your ordinary sign-in look new. The first address an account ever uses is learned without a message. Up to 50 addresses are remembered per account.
- Messages are sent from a background thread, so a slow mail server or a Telegram outage never delays or blocks a sign-in. A failed notice is recorded once in the audit log (`signin_notice_failed`).
- At most one lock-out message is sent per account and address every ten minutes, so someone attacking the panel cannot flood you.
- No new package is needed. It uses the email, Telegram and WhatsApp settings from the Alerts page.

### Security note
- Nothing sent contains a password, code or token. The browser text is stripped of control characters and shortened before it goes into a message. No root helper or sudo rule was added. Changing the settings, the test and clearing the known addresses are written to the audit log.

---

## v5.14.0: Scheduled reboot (2026-11-15)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_5.14.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Scheduled reboot.** A new **Scheduled reboot** tab in the Software updates group. Choose a date and time (or use *In 1 hour* or *Tonight or tomorrow at 03:00*), confirm, and the reboot is booked. The page shows the booked time and how long is left, lets you change the time or cancel it, and says when a reboot is waiting for installed updates. Users who are logged in are warned by the system. The system itself keeps the booking, so it still happens if the panel is restarted.
- The time is worked out in your browser's time zone and rounded up to the next whole minute. It must be between two minutes and thirty days from now.

### Notes
- A booked reboot does not check whether a software update is running when the time comes. Avoid booking it at the time your automatic updates run.
- **Packages:** the programs needed are installed with the package. `systemd-sysv` (which provides `shutdown`) is added to Depends, and the self-check now looks for `shutdown`.

### Security note
- New root helper `adminpanel-schedule` with `status`, `set MINUTES`, `cancel` and `check`. It can only book a **reboot** (never a power-off), only between 2 minutes and 30 days ahead, and the message users see is fixed in the code. It will not replace or cancel a shutdown that is a power-off or something else, and it never reboots right now (the Overview page keeps its own stricter path with the machine name typed). The sudo rule uses a single trailing `*`. Every booking and cancellation, including a refused one, is recorded in the audit log.

---

## v5.13.0: Storage fixes (2026-11-15)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_5.13.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Fixed (storage)
- **A stuck disk could freeze the panel.** Asking a filesystem for its size can wait forever when the disk behind it has disappeared (a lost iSCSI disk, for example). The Storage page, the Alerts page and the alert checker all asked, so one stuck mount could tie up every request. Each question now gets five seconds. A mount that does not answer is shown as **Not answering**, raises a critical alert, and is left alone for a minute before the next try.
- **Network shares were missing from the Filesystems table.** Mounted NFS and SMB shares now show with their size and usage, marked *(network share)*.
- **The same disk was listed several times** when it is mounted in more than one place (bind mounts, Btrfs subvolumes). It now has one row with *also mounted at ...* under it, and the Alerts page reports it once.
- **Disk usage silently left folders out** when the measurement ran out of time: the folders it had not reached simply were not listed. They are now listed and marked *(not measured)*, and the notice says how many.
- **Disk usage could not look inside a folder on another filesystem** (for example /home when it is a separate disk). Those entries are now links.
- **Disk and share actions that timed out were not written to the audit log**, although the change may have partly happened. They are now recorded as failed, with a message to check the device state before retrying.
- **Swap on Btrfs, ZFS, tmpfs, overlay or a network share** failed with a confusing error. The Swap page now says why a swap file cannot go there and disables the button; where a filesystem makes a sparse file that cannot be used as swap, the file is written out in full and tried again.
- **Disk health**: several requests arriving while a reading was in progress each started their own slow reading; they now share one. A failing background reading is recorded once in the audit log (`disk_health_failed`) instead of being ignored.
- The Storage page now shows the error when it cannot load, instead of staying empty. A damaged answer from the disk helper gives a clear message instead of a crash.

### Notes
- No new package is needed, and no new root helper or sudo rule was added.
- Not covered by this audit: the partition, LVM, RAID, LUKS and iSCSI operations inside the large `adminpanel-disk` helper. Those need a real test disk.

---

## v5.12.0: Telegram and WhatsApp alerts (2026-11-15)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_5.12.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Telegram alerts.** The *Alerts* page has a new **Telegram** section. Create a bot with @BotFather, paste its token, send the bot a message, press **Find my chat ID**, pick your chat and save. A **Send test message** button checks the whole path.
- **WhatsApp alerts.** A new **WhatsApp** section uses Meta's WhatsApp Business Cloud API (access token, phone number ID and the number to send to, with country code). A free-text message is delivered only to someone who has written to your business number in the last 24 hours; for anything else, enter the name of an approved message template with one variable and the alert text is put into it. The test button reports the 24-hour case in plain words.
- The messages are the same ones email already sends: new problems, and a note when they clear. Email, Telegram and WhatsApp can be on together. **Each channel keeps its own record**, so if one is down the others are not repeated; the failed one is retried at the next check (every two minutes).

### Notes
- No new package is needed. The panel calls `api.telegram.org` and `graph.facebook.com` over HTTPS itself, using Python's standard library, so nothing is added to Depends, Recommends or Suggests, and the machine needs outgoing HTTPS to those two addresses.
- The failure line in the audit log is now named `alert_notify_failed` (it was `alert_email_failed`) because it covers all three channels.

### Security note
- The Telegram token and the WhatsApp access token are saved in their own files in the data folder (mode 600, readable only by the panel account), are never sent back to the browser, and are never written to the audit log or to error messages (they are removed from anything the services answer). Settings are checked against strict patterns before saving. No root helper or sudo rule was added. Saving, tests and chat lookups are recorded in the audit log without the tokens.
- Anyone who can read the panel's data folder can read the tokens, as with the email password. Use a bot that is only for this purpose.

---

## v5.11.0: Docker networks (2026-11-15)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_5.11.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Docker networks.** A new **Docker networks** tab in the Services group, beside Compose, Images and Volumes. It lists every network Docker has, with its driver, its address range (subnet and gateway) and the containers attached to it. Networks made by Compose show their project name. A network that no container uses has a **Remove…** button that asks for confirmation first.
- **Protected against mistakes.** The built-in networks (`bridge`, `host`, `none`) and any network that still has a container attached cannot be removed, and the button is not shown for them. Nothing is forced and nothing is pruned. If two networks share a name, the panel refuses to guess which one you mean.
- If Docker is not installed or its service is not running, the page says so instead of showing an error.

### Notes
- No new package is needed: Docker stays under `Suggests` as before, and the page simply reports that Docker is missing until you install `docker.io`.
- A network made by Docker Compose is created again by `docker compose up`, so removing an unused one is safe.

### Security note
- New root helper `adminpanel-dnetworks` with three commands: `list`, `remove NAME` and `check`. The name must match a strict pattern and be one that Docker itself lists exactly once; removal is a plain `docker network rm` by full network ID. It cannot create, connect, disconnect or prune anything, and cannot touch containers, images or volumes. The sudo rules use a single trailing `*` (required by sudo-rs). Every removal, including a refused one, is recorded in the audit log.

---

## v5.10.0: Block and unblock addresses (2026-11-15)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_5.10.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Block and unblock an address.** The *Blocked addresses* page (Firewall group) now has a **Blocked by you** section. Type an IP address (`203.0.113.5`) or a network (`203.0.113.0/24`, an IPv6 address or prefix also works) and press **Block**; every block you made is listed with an **Unblock** button. A block is a firewall (UFW) rule that refuses all traffic from that address, placed at the top of the rule list so that it wins over any allow rule. If the firewall is switched off the page says the blocks are saved but do nothing until it is turned on. The fail2ban part of the page is unchanged and now sits under its own heading.
- **Protected against mistakes.** The panel refuses to block the address you are using right now (also when it is inside a network you typed), any address of this machine, loopback and multicast addresses, and networks larger than IPv4 `/8` or IPv6 `/16`. It will not add the same block twice, and **Unblock** removes only the blocks this page made (their rules carry the comment `adminpanel block`), so your other firewall rules cannot be removed from here.

### Security note
- The existing root helper `adminpanel-ufw` gained three commands: `blocks`, `block ADDRESS` and `unblock ADDRESS`. The address is parsed with Python's `ipaddress` module and rewritten in canonical form before it reaches `ufw`, so nothing else can be passed through. Up to 200 blocks are allowed. The sudo rules still use a single trailing `*` per command. Every block and unblock, including a refused one, is recorded in the audit log.
- A UFW rule does not cover ports that Docker publishes to the world (Docker adds its own firewall rules ahead of UFW's). Blocking an address does not stop it from reaching such a container port.

---

## v5.9.0: Package installs what the panel needs (2026-11-15)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_5.9.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Changed
- **The package now installs the programs its pages need.** `apt install ./adminpanel_5.9.0_all.deb` also installs everything the panel calls, so no page fails with "not installed" on a fresh server. New required packages: `openssh-server`, `passwd`, `procps`, `kmod`, `apt`, `dpkg`, `tar`, `e2fsprogs`, `iputils-ping`, `iputils-tracepath`, `bind9-dnsutils` (or `dnsutils`), `cron`, `ufw`, `fail2ban`, `smartmontools` and `unattended-upgrades`. Programs for optional pages are **recommended** (`certbot`, `python3-certbot-nginx`, `cifs-utils`, `nfs-common`, `parted`, `lvm2`, `xfsprogs`, `mdadm`, `cryptsetup`, `open-iscsi`, `wireguard-tools`, `multipath-tools`, `targetcli-fb`, `dmidecode`), so `apt` installs them too unless you use `--no-install-recommends`. Large or invasive extras are only **suggested**: `docker.io` with `docker-compose-v2`, `mariadb-client`, `postgresql-client`, `squid` and `msmtp-mta`.
- **`adminpanel-selfcheck` checks for the programs the panel needs.** If any is missing it fails with the exact `sudo apt install ...` command, and it lists the optional ones that are not installed.

### Notes
- Installing `ufw`, `fail2ban` and `openssh-server` does not change your firewall rules: UFW stays off until you enable it, and `fail2ban` starts with the distribution's default settings (an SSH jail). Review them on the *Firewall* and *Fail2ban* pages.
- On upgrade, `apt` installs the new required packages from your normal package sources, so the server needs access to them.

---

## v5.8.0: SSH server tab (2026-11-15)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_5.8.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **SSH server** (a tab in the *Accounts* group, after *SSH keys*). The effective settings of the SSH server, read with `sshd -T`, for the options that matter most: root login, password sign-in, key sign-in, empty passwords, X11 and TCP forwarding, user environment, sign-in attempts, login grace time, idle checks and sessions per connection. Each row shows the current value (green when it matches the recommended one, amber when it differs), the value saved by the panel and the recommended value. The port and PAM are shown for information. **Set** writes the value to the panel's own file, `/etc/ssh/sshd_config.d/00-adminpanel.conf`, which is read before the other files in that folder, and **Forget** removes it.
- **Safe by design.** Every change is checked with `sshd -t`, the effective value is read back with `sshd -T`, and only then is the service reloaded (not restarted, so open sessions stay connected). If the check fails, if another line in `sshd_config` overrides the value, or if the reload fails, the old file is put back and the message says why. The panel refuses changes that could lock everyone out: passwords off while no account has an SSH key (or key sign-in is off), key sign-in off while passwords are off, and root login off when no ordinary account exists. *Forget* is refused if it would leave no sign-in method.

### Fixed
- `adminpanel-selfcheck` now also checks that the Kernel settings helper (added in 5.7.0) is installed with the right owner and permissions.

### Security note
- A new root helper, `adminpanel-sshd`, accepts only `list`, `set`, `forget` and `check`. It can read and write only the twelve listed keys with their own allowed words or ranges, and it changes nothing outside its one drop-in file (replaced atomically). The sudo rules use a single trailing `*` per command, which both classic sudo and sudo-rs accept. Every change is recorded in the audit log. The remote-management account (Servers page) does **not** get these rules.

---

## v5.7.1: Kernel settings page layout fix (2026-11-15)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_5.7.1_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Fixed
- **Kernel settings page layout.** The table was wider than the window on normal screens, so the *Change* column (the Set and Forget buttons) was cut off and needed sideways scrolling. The setting names now wrap only when they have to, the description column gets more room, and the table fits a normal window.

---

## v5.7.0: Kernel settings tab (2026-11-15)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_5.7.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Kernel settings** (a tab in the *Hardware* group, after *Kernel*). A short list of 24 kernel (sysctl) settings that matter for security and for server tuning: IP forwarding, SYN cookies, reverse-path filtering, ICMP redirects, source routing, martian logging, `dmesg` and kernel-pointer restrictions, ASLR, `ptrace` scope, protected links, core dumps, open-file and inotify limits, connection backlog, memory map count and memory overcommit. Each row shows what the setting does, the value now (green when it matches the recommended value, amber when it differs), the value saved by the panel and the recommended value. **Set** applies a value at once and saves it in `/etc/sysctl.d/90-adminpanel.conf` so it survives a reboot; **Forget** removes the saved value. A setting the running kernel does not have is shown as not available.

### Security note
- A new root helper, `adminpanel-sysctl`, accepts only `list`, `set`, `forget` and `check`. It can read and write only the 24 listed keys, each with its own allowed values (a fixed set or a numeric range), so it cannot write anywhere else under `/proc/sys`. It changes nothing outside the file `/etc/sysctl.d/90-adminpanel.conf`, which it replaces atomically. The sudo rules use a single trailing `*` per command, which both classic sudo and sudo-rs accept. Every change is recorded in the audit log. The remote-management account (Servers page) does **not** get these rules.

---

## v5.6.0: Password aging tab (2026-11-14)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_5.6.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Password aging** (a tab in the *Accounts* group, between *SSH keys* and *Security check*). Shows, for every ordinary login account, when its password was last changed, the date it must be changed by (and how many days are left, in amber under 8 days and red when overdue), the warning period and the date the account expires. **Change rules** lets you set how many days a password may be used before it must be changed (or never), how many days before that the user is warned, and an optional date when the whole account stops working. The rules take effect the next time the user signs in. Useful on shared machines such as school or institution servers.

### Security note
- A new root helper, `adminpanel-aging`, accepts only `list`, `set` and `check`, with exact sudo rules. It never prints a password hash (only whether the password is locked). It touches ordinary login accounts only: user ids from 1000 up, never `root` and never system accounts. The values are checked before `chage` is called with fixed options: days must be numbers in range, and an expiry must be a future date (to lock an account now use the Users page), so this page cannot lock someone out by accident. Every change is recorded in the audit log. The remote-management account (Servers page) does **not** get these rules.

---

## v5.5.0: Volumes tab (2026-11-14)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_5.5.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Volumes** (a tab in the *Services* group, after *Images*). Lists the Docker volumes on this machine, which hold the data of containers such as a database's files, with their size and whether a container uses them. A volume that no container uses can be **removed**, but removing a volume deletes its data for good, so the page asks you to **type the volume's name** to confirm. A volume a container still uses cannot be removed here, and nothing is ever forced. Removals are recorded in the audit log.

### Security note
- Access to Docker is the same as root, so the new root helper, `adminpanel-volumes`, is narrow. It accepts only `list`, `remove` and `check`, with exact sudo rules. A volume is named by its Docker name, which must be one Docker itself lists. Removal is plain `docker volume rm`, never `--force`, so Docker itself refuses a volume a container still uses. It cannot prune, create volumes, read what is inside a volume, or touch containers or images. The panel also checks the typed name before it calls the helper. The remote-management account (Servers page) does **not** get these rules.

---

## v5.4.0: Network tools tab (2026-11-14)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_5.4.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Network tools** (a tab in the *Networking* group, after *Hosts file*). Checks connectivity from this machine: **Ping** a host, **DNS lookup** (A, AAAA, MX, NS, TXT, CNAME, SOA, or PTR for an IP address), **Port check** (does a TCP port answer: open, closed or filtered, with the time it took) and **Trace route**. They run on the server, so they can reach networks your own computer cannot. If a program is missing the page says which package to install (`iputils-ping`, `bind9-dnsutils`, `iputils-tracepath`); without `dig` the A and AAAA lookups still work.

### Security note
- These tools need no root rights and no new sudo rules: they run as the panel's own account. A host must be a plain host name or IP address (nothing that could be read as a command option), the commands are started without a shell, each run has a time limit, only one runs at a time, and every use is recorded in the audit log, because the panel can reach networks a browser cannot. Like the rest of the panel it is for signed-in administrators only.

---

## v5.3.1: Compose hardening (2026-11-14)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_5.3.1_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Security
- **Compose page hardened further.** The compose files of a project come from labels on its containers, and anyone who can create containers can set those labels. The helper already required the file and every folder above it to be owned by root or a docker-group member and not writable by others. It now also ignores a recorded file unless, after links are resolved, it is a regular `.yml` or `.yaml` file of at most 1 MB, and it opens the file without following links. Before this, a forged label naming a root-owned file such as `/etc/shadow` could make the *Compose file* view read it as root. The helper's other limits are unchanged: only projects Docker lists, a fixed set of verbs, no `down`, no volumes, no `exec`.
- **The page now shows who owns a compose file**, and the *Apply* confirmation warns when the owner is not root, because applying runs that file with root's rights and its owner can change what it does.

---

## v5.3.0: Backup restore (2026-11-14)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_5.3.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Restore from a backup, on the Backups page.** Until now the page could only list, check and delete copies and told you to restore on the console. Each copy now has a **Browse and restore** button. It shows what is inside the copy (search by part of a name), and you can restore everything or tick up to 50 files and folders.
- Restored files go into a **protected staging folder** on this machine (`/var/lib/adminpanel/restore/<copy>`, openable only by root). **Your live files are never overwritten.** A new *Restored folders* list shows each restore with its file count, size and path, and a Delete button. To put a file back you copy it from that folder on the console, for example `sudo cp -a /var/lib/adminpanel/restore/<folder>/etc/hostname /etc/hostname`, so you stay in control of what replaces what.
- Works for copies on this machine, on a network share and on another disk.

### Security note
- The Backups helper, `adminpanel-backup`, gained four commands: `contents`, `restore`, `restores` and `restore-delete` (exact sudo rules). A copy is named by its file name and must be one the helper lists. Extraction uses Python's standard `data` filter, which refuses names that leave the folder (`../`), links that point outside it, devices and other special files, and removes set-uid bits and world-writable permissions; anything refused is skipped and counted. The helper checks free space first, allows at most 3 restored folders at a time, and only ever writes inside its own staging folder. Restores and deletions of restored folders are recorded in the audit log. The remote-management account (Servers page) does **not** get these rules.

---

## v5.2.0: Images tab (2026-11-14)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_5.2.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Images** (a tab in the *Services* group, after *Compose*). Lists the Docker images on this machine with their size, age and whether a container uses them. Old images pile up and use a lot of disk space, so you can **Remove** an image that no container uses, or **Prune dangling images** (untagged leftovers, usually from updates) in one step; the page shows how much space was freed. An image a container still uses cannot be removed here, and nothing is ever forced.

### Security note
- Access to Docker is the same as root, so the new root helper, `adminpanel-images`, is narrow. It accepts only `list`, `remove`, `prune` and `check`, with exact sudo rules. An image is named by its 64-letter id, which must be one Docker itself lists. Removal never uses `--force`, so Docker itself refuses an image a container still uses, and `prune` removes only dangling images, never tagged images, containers or volumes. Removals and prunes are recorded in the audit log. The remote-management account (Servers page) does **not** get these rules.

---

## v5.1.0: Databases tab (2026-11-14)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_5.1.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Databases** (a tab in the *Services* group, after *Compose*). A read-only overview of the database servers on this machine, MariaDB/MySQL and PostgreSQL. For each one it shows whether it is installed and running, the version, how long it has been up, how many connections are open and the size of every database (and the number of tables for MariaDB/MySQL). If a server is installed but not answering the page says so and points to the Services page. Nothing can be changed from this page.

### Security note
- A new root helper, `adminpanel-databases`, takes **no input** from the caller: it accepts only `list` and `check` and runs a few fixed queries (version, uptime, connection count, database sizes). It never reads table contents, user accounts or passwords, and never changes anything. MariaDB is reached as root through its local socket and PostgreSQL as the `postgres` user, both without reading any saved credentials. The remote-management account (Servers page) does **not** get these rules.

---

## v5.0.0: Compose tab (2026-11-13)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_5.0.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Compose** (a tab in the *Services* group, next to *Containers*). Manages Docker Compose projects, the stacks of containers that belong together. Each project shows its services (container, image, state, ports) and has buttons to **Start**, **Stop**, **Restart**, **Pull images** (download newer images) and **Apply (up -d)**, which recreates only the containers whose image or settings changed. It can also show the project's log and its compose file, with the values of keys that look like passwords, secrets or tokens hidden. The output of each action is shown on the page. If Docker or the Compose plugin is missing the page says so and which package to install.
- Only projects Docker already knows about are listed (a project appears after it has been started once with `docker compose` on the command line). Creating and removing projects stays on the command line on purpose.

### Security note
- Access to Docker is the same as root, so the new root helper, `adminpanel-compose`, is deliberately narrow. It accepts only `list`, `start`, `stop`, `restart`, `pull`, `up`, `logs`, `file` and `check`, with exact sudo rules. A project is named by its Compose project name, which must be one Docker itself lists, and the helper uses the compose files Docker recorded for it. It cannot create a project, run `down`, remove volumes or images, or run a command inside a container. Every action is recorded in the audit log. The remote-management account (Servers page) does **not** get these rules.

---

## v4.9.0: Hosts file tab (2026-11-13)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_4.9.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Hosts file** (a tab in the *Networking* group, after *Proxy*). Shows the lines of `/etc/hosts` and lets you add and remove name-to-address entries. The machine checks this file before DNS, so it is handy for pointing a name at a test server, or for blocking a name by sending it to `0.0.0.0`. Entries added here live in one marked block of the file; the system's own lines are shown but never changed. The page refuses a name that is already defined elsewhere in the file and the reserved `localhost` names. The first change saves the original as `/etc/hosts.adminpanel-backup`.

### Security note
- A new root helper, `adminpanel-hosts`, accepts only `list`, `add`, `remove` and `check`, with exact sudo rules. The address is validated as an IP address and the name against a strict host-name pattern; nothing else is accepted. It edits only its own block, writes the file atomically and takes a lock. Every change is recorded in the audit log. The remote-management account (Servers page) does **not** get these rules.

---

## v4.8.0: Web logs tab (2026-11-13)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_4.8.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Web logs** (a tab in the *Services* group, next to *Websites*). Shows the end of the nginx log files (access, error and rotated `.log.1` files) with a choice of 50, 100, 300 or 1000 lines and an optional "only lines containing" filter. **Summarise** reads the last 5000 requests of an access log and shows how many were answered with 2xx, 3xx, 4xx and 5xx, the busiest addresses and the most requested paths. Access logs contain visitors' addresses, so the page says to treat them as private. If nginx has no logs the page says so.

### Security note
- A new root helper, `adminpanel-weblogs`, only reads. It accepts `list`, `tail`, `summary` and `check`, with exact sudo rules, and only opens regular files from its own listing in `/var/log/nginx` (no links, no directories, no paths). The filter is sent on standard input and matched as plain text. The remote-management account (Servers page) does **not** get these rules.

---

## v4.7.0: Certificate renewal tab (2026-11-12)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_4.7.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Certificate renewal** (a tab on the *Certificates* page, next to *Certificates*). Lists the Let's Encrypt certificates certbot manages (name, the domains, expiry and days left), says whether the renewal timer is on, and has two buttons: **Test renewal (dry run)**, which changes nothing and shows whether renewal would work, and **Renew now**, which renews only the certificates certbot considers due (within 30 days of expiry), so pressing it early is harmless. The output of certbot is shown on the page. After a renewal, reload nginx on the Websites page. If certbot is not installed the page says so and how to install it.

### Security note
- A new root helper, `adminpanel-certbot`, accepts only `status`, `test`, `renew` and `check`, with exact sudo rules, and runs fixed certbot command lines: no domain, path or option from the caller reaches certbot. It never reads a private key. The remote-management account (Servers page) does **not** get these rules.

---

## v4.6.0: Websites tab (2026-11-12)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_4.6.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Websites** (a tab beside *Services*, *Cron jobs*, *Containers* and *Startup*). Lists every site nginx is set up to serve, read from `/etc/nginx/sites-enabled` and `/etc/nginx/conf.d`: the names, the ports it listens on (with an HTTPS tag), what it serves (a folder, another program it passes requests to, PHP or a redirect), its certificate file and which file it comes from. **Test configuration** runs nginx's own check and **Reload nginx** applies a change. The reload is refused when the test fails, so a mistake in a site file cannot take the web server, and this panel, down.

### Security note
- A new root helper, `adminpanel-nginx`, accepts only `list`, `test`, `reload` and `check`, with exact sudo rules. It reads site files and never edits one, and never reloads without a passing `nginx -t`. The panel's own site appears in the list like any other. The remote-management account (Servers page) does **not** get these rules.

---

## v4.5.0: Log cleanup tab (2026-11-12)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_4.5.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Log cleanup** (a tab on the *Logs* page, next to *Journal*). Shows how much disk the system journal and the rest of `/var/log` use, how much disk is free, and the 15 biggest log files with their last-changed time. You can **trim the journal** to keep at most 100 MB, 500 MB, 1 GB or 2 GB, or only the last 7, 14, 30 or 90 days (it asks first). Full logs are a common reason a small server runs out of disk.

### Security note
- A new root helper, `adminpanel-logclean`, accepts only `status`, `vacuum-size MB` (50 to 102400) and `vacuum-time DAYS` (1 to 3650), with exact sudo rules, and runs journalctl's own vacuum with that number. It reads only file names, sizes and times, never contents, skips links, and never deletes a plain log file. The remote-management account (Servers page) does **not** get these rules.

---

## v4.4.0: SSH keys tab (2026-11-12)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_4.4.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **SSH keys** (a tab in the *Accounts* group). Pick an account, see the public keys that let it sign in over SSH (type, SHA256 fingerprint, comment), **add** a key by pasting its public half, or **remove** one. This is the step before turning off SSH password sign-in, which the Security check recommends; its *SSH password sign-in* line now links here.

### Security note
- A new root helper, `adminpanel-sshkeys`, works on `~/.ssh/authorized_keys` **as that user**: it drops to the account's own user and group id first, so a link planted in the home folder cannot reach anything the user could not already reach (tested against a linked `.ssh` folder, a linked `authorized_keys` and a linked home folder). It accepts only accounts with a user id of 1000 or more and a real login shell, only plain one-line public keys of a known type with a valid key body (so no `command=` or other options can be added), and removes a key only by its fingerprint. Keys with options that are already in a file are never shown or changed. The remote-management account (Servers page) does **not** get these rules.

---

## v4.3.0: Security check tab (2026-11-12)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_4.3.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Security check** (a tab beside *Users*, *Login history*, *Groups* and *Sudo activity*). Runs nine common safety checks and lists each as **OK**, **Warning** or **Fix**, with a sentence on what is wrong and a link to the page where you can fix it: SSH sign-in as root, SSH password sign-in, the firewall, automatic security updates, a pending restart, fail2ban, accounts with an empty password, other accounts with root power, and clock synchronisation. Problems are listed first, and **Check again** reruns it.

### Security note
- Read only. A new root helper, `adminpanel-audit`, takes no input, changes nothing and returns only a yes or no and a sentence for each check; it never returns a password hash or file contents. It needs root only to read the SSH server settings and the password file. The remote-management account (Servers page) does **not** get this rule.

---

## v4.2.0: Swap tab (2026-11-12)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_4.2.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Swap** (a tab beside *Storage*, *Disk usage* and *Network shares*). Shows memory, swap total and free, free disk space and the swap that is active. Small cloud machines often have no swap, and then run out of memory and start killing programs. You can **create a swap file** of a chosen size (it is turned on at once and added to `/etc/fstab` so it returns after a restart), **remove** it (asks first), and set **swappiness**, which is saved for the next boot too. The page offers only sizes that leave at least 1 GB of the disk free.

### Security note
- A new root helper, `adminpanel-swap`, touches only one file, `/swapfile`, and accepts only a size in megabytes (128 to 65536), a swappiness number (0 to 100), `status` and `remove`, with exact sudo rules. No path, device or command line from the caller reaches a program. It refuses to replace an existing file, refuses a size that would leave less than 1 GB free, and cleans up if any step fails. `/etc/fstab` is rewritten atomically. The remote-management account (Servers page) does **not** get these rules.

---

## v4.1.0: Automatic updates tab (2026-11-12)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_4.1.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Automatic updates** (a tab beside *Updates* and *Packages*). Shows whether the machine installs security updates by itself, with a **Turn on / Turn off** button (turning off asks first), the state of the daily timer, and the end of the last run's log. If the `unattended-upgrades` package is not installed, the page says so and points to the Packages page. Automatic updates never restart the machine; the Overview page still tells you when a restart is needed.

### Security note
- A new root helper, `adminpanel-autoupd`, accepts only `status`, `set on` and `set off`, with exact sudo rules. It writes one file, `/etc/apt/apt.conf.d/20auto-upgrades`, with fixed content (nothing from the caller goes into it), replacing it atomically. The remote-management account (Servers page) does **not** get these rules.

---

## v4.0.0: Startup tab (2026-11-12)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_4.0.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Startup** (a tab beside *Services*, *Cron jobs* and *Containers*). Shows how long the last boot took (total, kernel, initrd and services), the 30 services that were slowest to start with a bar for each, and any services that have **failed**. Use it to find out why a machine is slow to boot or which service did not come up.

### Security note
- Read only, and no new root helper or sudo rule: `systemd-analyze` and `systemctl --failed` are readable by any account. Unit names and descriptions are checked and drawn as plain text.

---

## v3.9.0: Listening ports tab (2026-11-12)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_3.9.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Listening ports** (a tab beside *Firewall* and *Blocked addresses*). Lists every TCP and UDP port that is waiting for connections, the program that owns it, and whether it is reachable from the **network** or from **this machine only**. A checkbox narrows the list to network-reachable ports, which is the quick way to see what the machine exposes. It is read only: to close a port, stop its service or add a firewall rule.

### Security note
- A new root helper, `adminpanel-ports`, only runs `ss` to list sockets (root is needed to see which program owns each one). It takes no address, port or name from anyone and changes nothing. The remote-management account (Servers page) does **not** get this rule.

---

## v3.8.0: Blocked addresses tab (2026-11-12)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_3.8.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Blocked addresses** (a tab beside *Firewall*). Shows the fail2ban jails on the machine, how many failures and blocks each has seen, its settings (failures allowed, time window, block length) and the addresses it is blocking right now. **Lift** removes one block, which helps if you locked yourself out with wrong passwords. If fail2ban is not installed, or its service is stopped, the page says so and what to do (install `fail2ban` on the Packages page, or start the `fail2ban` service).

### Security note
- A new root helper, `adminpanel-f2b`, allows only `list` and `unban`, with exact sudo rules. It cannot block an address, change a jail or edit any fail2ban setting. The jail must be one fail2ban itself lists and the address must be a valid IPv4 or IPv6 address.
- Lifting a block is written to the audit log. The remote-management account (Servers page) does **not** get these rules.

---

## v3.7.0: Containers tab (2026-11-11)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_3.7.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Containers** (a tab beside *Services* and *Cron jobs*). Lists the Docker containers on the machine with their image, state, status and ports. You can **start, stop and restart** a container (stop and restart ask first) and read the **last 300 lines of its log**. If Docker is not installed, or its service is stopped, the page says so and what to do (install `docker.io` on the Packages page, or start the `docker` service).

### Security note
- Access to Docker is the same as root, so a new root helper, `adminpanel-docker`, allows only `list`, `start`, `stop`, `restart` and `logs`, with exact sudo rules. It cannot run, create, remove or copy into a container, or run commands inside one: that stays on the command line on purpose.
- A container is named by its full 64-letter id, and the helper only acts on an id that Docker itself lists. Names, images and logs are shown as plain text (control and colour codes removed).
- The remote-management account (Servers page) does **not** get these rules.

---

## v3.6.0: NFS shares (2026-11-11)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_3.6.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **NFS shares** on the *Network shares* page, next to SMB. Pick the type, enter the server and the export folder on it (for example `/srv/backups`) and choose NFS 4.2, 4.1, 4.0 or 3. Test, Connect, Disconnect and Remove work the same way, and a share is again either for **Backups** (root only) or for the **File manager** (read only for everyone).
- Backups can store copies on an NFS share exactly like an SMB one, with the same safety: nothing is written unless the share is really mounted.
- The package now also recommends `nfs-common` (needed for NFS). If it is missing the page says so and links to the Packages page.

### Notes
- NFS has no password in this panel. The server decides who may mount an export, usually by this machine's address, so allow this machine in the server's exports. If the server squashes root, writing a backup may be refused; use `no_root_squash` on the backup export.
- No new root helper and no new sudo rules: the existing `adminpanel-share` helper checks the export path again as root (a full path with no `..`, no trailing `/` and only letters, digits and `. _ - /`), so nothing can add a mount option.

---

## v3.5.0: Backups to any mounted disk (2026-11-11)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_3.5.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Backups can be stored on any disk mounted under `/mnt`**, including an iSCSI disk. Connect the iSCSI target, then format and mount the disk on the *Storage* page as before (it appears under `/mnt/NAME`); it is then listed in the new *Store copies on* choice on the Backups page, with its file system and free space.
- Only a whole disk with a file system that keeps Unix permissions (ext2/3/4, XFS, Btrfs, F2fs) is offered, so copies stay readable by root only. Bind mounts, network shares and FAT/NTFS disks are not offered.
- A backup only writes when the disk really is mounted. If the disk is missing (for example the iSCSI session is down after a reboot), the backup fails with a clear message instead of filling this machine's own disk, and the Backups page says to mount it on the Storage page.

### Notes
- iSCSI itself (discovery, login, reconnect, start-up login) was already on the Storage page; this release connects it to Backups.
- No new root helper and no new sudo rules: the existing backup helper reads `/proc/self/mountinfo` and re-checks the choice as root.

---

## v3.4.0: Network shares tab (2026-11-11)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_3.4.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Network shares** (a tab beside *Storage*). Connect Windows (SMB) file shares, such as a NAS or another computer's shared folder: add a share with its server, share name, user and password, then **Test**, **Connect**, **Disconnect** or **Remove** it. Shares are mounted under `/mnt/adminpanel/NAME`.
- Each share is used either for **Backups** (only root can see inside it) or for the **File manager** (everyone with an account can read it, nobody can change it from here). It cannot be both, because a world-readable mount would let any local user read the backup copies.
- **Backups can now be stored on a network share.** A new *Store copies on* choice on the Backups page lists the shares set up for backups. The share is connected automatically when a backup starts, copies are kept and pruned the same way as before, and the page shows free space on the share and the right restore path.
- Safety: a backup never writes unless the share is really mounted, so a missing mount cannot fill this machine's own disk. A share that is the backup destination cannot be removed until you pick another destination.
- The package now recommends `cifs-utils` (needed for SMB). If it is missing, the page says so and links to the Packages page.

### Security note
- A new root helper, `adminpanel-share`, with seven exact sudo rules (`list`, `add`, `check`, and `mount`, `unmount`, `test`, `remove` with a name). It checks every value again as root: names, server (a host name or IPv4 address), share, user and domain are matched against strict patterns, so nothing can add mount options.
- Passwords are sent on standard input (never on a command line), kept in a root-only file per share, and never sent back to the browser. Shares are mounted `nosuid,nodev,noexec`; File manager shares are also read-only.
- The remote-management account (Servers page) does **not** get these rules.

---

## v3.3.1: Terminal remembers last username (2026-11-11)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_3.3.1_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Fixed
- **Terminal: the "Log in as" box no longer starts with a fixed name.** It used to be pre-filled with one built-in user name on every machine. It now starts with the account you connected with last time in this browser, and is empty (with a "username" hint) on a first visit. Pressing Enter in the box connects.

---

## v3.3.0: Disk usage tab (2026-11-11)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_3.3.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Disk usage** (a tab beside *Storage*). Shows what is taking the space inside any folder: each item directly inside it with its size, a share bar and file count, biggest first. Click a folder to look inside it; breadcrumbs and an *Up* button move around, and the header shows how full the filesystem is.
- Sizes are the disk space actually used, hard-linked files are counted once, and only the filesystem the folder is on is counted (other mounted filesystems are marked, not added in).
- Very large folders stop after about 25 seconds and say the sizes are a lower bound, so the page never hangs.

### Security note
- A new read-only root helper, `adminpanel-du`, with two exact sudo rules (`scan *` and `check`), because ordinary accounts cannot read most system folders. It reads **metadata only**: it never opens a file and never follows a symlink. It refuses a path that is relative or goes through a symlink, and only lists a folder's items; nothing is changed, deleted or downloaded.
- The remote-management account (Servers page) does **not** get these rules.

---

## v3.2.0: Packages page (2026-11-11)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_3.2.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Packages** (a tab beside *Updates*). Search for software, install it, and remove installed packages, with a filter over everything already installed.
- **Look before you change.** Before an install or a removal the page shows apt's own dry run: what will be installed or upgraded, what will be removed, and the disk space involved. Nothing happens until you confirm.
- Changes run in the same background job as updates (they survive a panel restart), with the same live log. Only one job runs at a time. Every change is written to the audit log with the package name.

### Safety
- `adminpanel-apt` (the existing root helper) gains `install NAME` and `remove NAME`. The name is checked again as root: lower-case letters, digits and `+ . -` only, and it must be a real installable package.
- **Removal is refused** if apt's dry run shows it would take out anything the machine needs: the panel itself, `sudo`, SSH, nginx, systemd, apt, dpkg, the C library, Python, networking, boot loader or kernel packages, and any essential or required package. The check is on everything the removal would take with it, not just the name you asked for.
- **An install is refused** if it would remove other packages.
- Packages the system needs show as *Needed by the system* and have no Remove button.
- The sudo rule allows `install *` and `remove *` for this one helper only; the helper rejects anything else. The remote-management account does **not** get these rules.

---

## v3.1.0: Sudo activity tab (2026-11-10)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_3.1.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Sudo activity** (a tab under *Accounts*, beside *Login history*). Shows who used `sudo` in the last 24 hours, 7 days or 30 days, what they ran, in which directory, and as which user. A summary by person shows how many commands each ran and how many were refused.
- Refusals are marked: *Not allowed* (the user may not use sudo, or not that command) and *Wrong password* with the number of attempts.
- A filter box for the recent list.
- The panel's own use of `sudo` (its fixed root helpers, many times a day) is hidden by default, with a count of how many were hidden; a checkbox shows them.

### Notes
- Read only, from the system journal, which the panel already reads for logs and failed logins. No new root helper and no sudo rule.
- Commands are shown exactly as sudo logged them, as plain text.

---

## v3.0.0: Kernel tab (2026-11-10)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_3.0.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Kernel** (a tab beside *Hardware*). Shows the running kernel, whether it is *tainted* (with each reason in words, such as an out-of-tree or proprietary module), and every loaded module with its size and what uses it, with a filter box.
- **Security settings.** A short table of kernel settings that matter on a server (address-space randomisation, kernel pointer and log restrictions, symlink and hard-link protection, SYN cookies, reverse-path filtering, redirects and others), each marked *As recommended*, *Different* (with the suggested value) or *Info* where the right value depends on the machine's job, such as IP forwarding.

### Notes
- Read only, with no new root helper and no sudo rule: everything comes from `/proc`, which any account can read. Nothing here changes a setting.
- A setting marked *Different* is a prompt to check, not proof of a problem.

---

## v2.9.0: Restart status (2026-11-10)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_2.9.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Restart status** on the *Software updates* page. It says whether a reboot is needed, how long it has been waiting, which packages asked for it, the running kernel compared with the newest one installed, and how long the machine has been up.
- **Alerts.** A reboot that has been waiting for 7 days or more raises a warning, because the updates are not fully in effect until the machine restarts.

### Notes
- Read only, and no new root helper or sudo rule: everything comes from files any account can read (`/run/reboot-required`, `/run/reboot-required.pkgs`, `/boot`).
- Only kernels of the same flavour as the running one (for example `-generic` or `-aws`) are compared.

---

## v2.8.0: Certificates page (2026-11-10)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_2.8.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Certificates** (new sidebar entry). A read-only list of the TLS certificates this machine serves: the panel's own, Let's Encrypt, and any that nginx points to. Each shows its names, who issued it (or *Self-signed*), when it expires, how many days are left, and where the file is.
- **Alerts.** A certificate that expires within 21 days raises a warning, within 7 days (or already expired) a critical alert, on the Alerts page and by email if you set that up. The reading is refreshed about once an hour; *Check again* reads it now.
- This page changes nothing and does not renew certificates.

### Security note
- A new read-only root helper, `adminpanel-certs`, with two exact sudo rules (`report` and `check`). It finds the certificate files itself and takes no path from the caller. It only uses the first certificate block of a file and never reads or outputs a private key, and it only follows paths that end up inside `/etc/letsencrypt`, `/etc/ssl`, `/etc/nginx` or `/etc/pki`.
- The remote-management account (Servers page) does **not** get these rules.

---

## v2.7.0: Date & time page (2026-11-10)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_2.7.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Date & time** (new sidebar entry). Shows the live clock in the machine's time zone, whether network time (NTP) is on and synchronised, and the hostname.
- **Change the time zone** from the list the system knows (with a filter box), **turn network time on or off**, and **change the hostname**. Every change is written to the audit log.
- The time itself cannot be typed in: with network time on the machine keeps it right, and a hand-set clock is a common cause of certificate and login problems.
- Changing the hostname also updates the machine's own `127.0.1.1` line in `/etc/hosts`, so `sudo` does not start complaining that it cannot resolve the new name.

### Security note
- A new root helper, `adminpanel-time`, with exact sudo rules (`timezone *`, `ntp on`, `ntp off`, `hostname *`, `check`). The helper checks every value itself as root: a time zone must be one that `timedatectl` lists, a hostname must be a valid name, and nothing goes through a shell.
- The remote-management account (Servers page) does **not** get these rules.

---

## v2.6.0: Cron jobs view under Services (2026-11-10)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_2.6.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Cron jobs** (*Services* → *Cron jobs*). A read-only list of everything scheduled through cron: `/etc/crontab`, the files in `/etc/cron.d`, and the personal crontab of every account. Each job shows its schedule in plain English (for example "At 03:17 on Monday and Friday"), the raw schedule, the next time it will run, who it runs as, the command and where it came from.
- A filter box, the daily/weekly/hourly/monthly scripts in `/etc/cron.*` (with a note if a script is not executable and so is skipped), and the anacron jobs that catch up after downtime.
- A warning when the cron service is not running.
- This page changes nothing. Systemd timers stay on the *Timers* tab of Services.

### Security note
- A new read-only root helper, `adminpanel-cron`, with two exact sudo rules (`list` and `check`). It takes no names from the caller: it lists the crontab directory itself, accepts only plain file names, refuses symlinks and other non-regular files, and caps how much it reads.
- The remote-management account (Servers page) does **not** get these rules.

---

## v2.5.1: Clearer remote connection errors (2026-11-10)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_2.5.1_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept.

### Improved
- **Clearer errors when a remote server can't be reached** (Servers → Remote services, remote reboot, logs). The panel used to say "Could not sign in to that server" for many different problems. It now says what happened: the server refused the panel's key, accepted the connection but didn't answer in time, refused the connection (SSH not running or wrong port), reset or closed the connection, or didn't answer at all (busy, starting up, or a firewall dropping it). Nothing about how the panel connects or what it is allowed to do has changed.

---

## v2.5.0: Disk health (2026-11-09)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_2.5.0_all.deb
sudo apt install smartmontools      # needed to read disk health; the package only recommends it
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Disk health** (*Storage* → *Health* tab). One row per physical disk with a Good, Warning, Failing, Asleep or Not available badge, the model, type (hard disk, SSD, NVMe), size, temperature, time powered on and, for NVMe, wear. The reasons are shown in plain words, for example "24 reallocated sectors" or "The drive is 93% worn".
- **Alerts.** A failing disk raises a critical alert and a disk with warning signs raises a warning on the Alerts page (and by email if you set that up). The reading is refreshed in the background about once an hour; *Check again* reads it now.
- Disks that are asleep are not woken just to read their health. Virtual and cloud disks usually don't report SMART and show *Not available*.

### Security note
- A new read-only root helper, `adminpanel-smart`, with two exact sudo rules (`report` and `check`). It takes no disk names from the caller: it lists the disks itself and runs `smartctl` with fixed options.
- The remote-management account (Servers page) does **not** get these rules.
- Package: `smartmontools` is now a *recommended* package (not required).

---

## v2.4.0: Processes (2026-11-09)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_2.4.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Processes** (new sidebar entry, under *Services*). A live list of every process: number, name, user, CPU share, memory, state, start time and command line. Sort by any column, filter by name, user, number or command, hide root and system accounts, and refresh every 3 seconds (stops when the tab is hidden). The top shows totals and the load average.
- **End** and **Force quit** for ordinary programs: *End* asks the program to stop (TERM), *Force quit* stops it at once (KILL). Each asks for confirmation and is written to the audit log with the process, user and signal.

### Security note
- A new root helper, `adminpanel-proc`, with exact sudo rules (`signal *` and a self-check). It refuses processes owned by root or by the panel, core system processes (`systemd`, `sshd`, `dbus-daemon` and similar), the helper itself and process 1. Services are stopped from the Services page, not here.
- The panel sends the process number **and its start time**. The helper opens a handle on the process, checks that it is still the same process, and sends the signal through that handle, so if a program ended and another reused its number, nothing is signalled.
- The remote-management account (Servers page) does **not** get this rule.

---

## v2.3.1: Login history works when the last command is missing (2026-11-09)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_2.3.1_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept.

### Fixed
- **Login history** showed "The 'last' command is not installed" as an error and left the whole Sign-ins tab empty. Now the panel looks for `last` on the normal system paths, and when it is missing the *Signed in now* list still works and a note under *History* says how to install it (`sudo apt install util-linux-extra`, or `util-linux` on older Ubuntu). The *Failed attempts* tab never depended on it.

---

## v2.3.0: Backups (2026-11-09)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_2.3.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Backups** (new sidebar entry, under *Storage*). Choose the folders to save, a schedule (off, every day or every week, from an hour you pick) and how many copies to keep. *Back up now* starts a copy at once; each copy can be checked (the archive is read back to make sure it is not damaged) or deleted.
- Copies are `.tar.gz` files in `/var/backups/adminpanel`, readable only by root. The panel can list, check and delete them but cannot read what is inside, and the page shows the console command to restore.
- The schedule runs from a systemd timer that checks every hour whether a copy is due, so a machine that was off at the chosen hour makes its copy when it is next running. If a backup fails, the existing *failed service* alert on the Alerts page reports it, and the Backups page shows the reason.

### Security note
- A new root helper, `adminpanel-backup`, with exact sudo rules (`status`, `set`, `start`, `verify NAME`, `delete NAME`). The helper checks everything again as root: full paths only, no `..`, the folder must exist, `/proc`, `/sys`, `/dev`, `/run` and the backup folder itself are refused, and file names must match the backup pattern exactly. Settings are saved only by the helper, in a root-only file.
- The remote-management account (Servers page) does **not** get these rules.
- A copy on the same disk does not protect against losing the disk: copy `/var/backups/adminpanel` somewhere else as well.

---

## v2.2.0: Groups (2026-11-09)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_2.2.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Groups** (under *Accounts*, next to *Users* and *Login history*). See every group with its members, create a group, add an ordinary user to it, remove a user from it, and delete an empty group.
- **Locked on purpose.** Groups that give control of the machine (`sudo`, `adm`, `docker`, `shadow` and similar), system groups (group number below 1000) and administrator accounts cannot be changed from the panel; they show as *manage from console*. A user's main group cannot be removed.
- Every change is written to the audit log (user, group, who did it).

### Security note
- The accounts helper gets four new commands (`mkgroup`, `rmgroup`, `addgroup`, `delgroup`) and a list command (`groups`), each with its own exact sudo rule. The helper checks every name again as root, so a forged request cannot touch a privileged group or an administrator.

---

## v2.1.0: Login history (2026-11-09)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_2.1.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Login history** (under *Accounts*, next to *Users*). A read-only page with two tabs:
  - *Sign-ins*: who is signed in on a terminal now, and a filterable history of past logins (user, terminal, address, time, duration, and whether a session ended in a crash or shutdown).
  - *Failed attempts*: failed SSH password and key attempts over the last 24 hours, 7 days or 30 days, grouped by source address with the user names tried, plus the latest individual attempts.
- No new permissions: it reads the system login record and the journal that the panel already reads. Nothing is changed by this page.

---

## v2.0.1: Smoother network graphs (2026-11-09)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_2.0.1_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Changed
- **Smoother network graphs.** The Network card on Overview and the Network chart under *History* now draw smooth curves with a soft fade under the *Down* line, instead of jagged straight segments. The curve never dips below zero or overshoots a spike, and gaps in the history still show as breaks.
- The Network card now uses the same colours as the History chart: blue for *Down*, green for *Up*.

---

## v2.0.0: Hardware information (2026-11-09)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_2.0.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Hardware page** (System, after Storage): what the machine is made of, all in one place.
  - **System:** vendor, model, board, firmware version and date, and whether it is a physical machine or a virtual one.
  - **Processor:** model, sockets, cores, threads, speed range and caches.
  - **Memory:** total, available and swap, and (on real hardware) each **memory module** with its slot, size, type, speed and maker.
  - **Disks:** every disk and its partitions as a tree, with size, model, bus (NVMe, SATA, USB), file system and where it is mounted; SSD/flash and hard disks are told apart.
  - **Temperatures and sensors:** every temperature with its warning and critical limits (a value above its warning limit turns amber, above critical red), fans and battery. Refreshes by itself every five seconds.
  - **PCI devices** (with a filter box, so you can find "ethernet" or "nvidia" quickly) and **USB devices**.
- Where a machine has no such hardware, or a tool is missing, the section says so and how to install it, instead of staying blank. Virtual machines and cloud servers usually show no temperatures and no memory modules; that is normal.

### Security notes
- The page only **reads**. The one thing that needs root, listing the memory modules, goes through a new sudo rule that allows exactly `dmidecode -t memory` and nothing else. The rule is not given to the remote-management user created by `adminpanel-setup remote-enable`.
- Needs the standard tools `pciutils` and `usbutils` (installed by default on Ubuntu Server); `dmidecode` for the memory modules.

---

## v1.9.0: History graphs (2026-11-08)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_1.9.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **History graphs on the Overview page.** Under the four cards there are now four charts: **CPU**, **Memory**, **Disk (/)** and **Network** (down and up). Choose the last hour, 6 hours, 24 hours or 7 days. Hover a chart to read the exact value and time; the latest value is shown at the top right of each chart.
- The panel records **one sample a minute** and keeps **seven days** (about 10,000 small rows in the panel database, well under 1 MB). Longer ranges show averages, so a short spike can look lower on the 7-day view.
- **Gaps are real.** While the panel or the machine is not running nothing is recorded, and the chart shows a break instead of a made-up line. After an install or a reboot the charts start filling within a couple of minutes.

### Notes
- Nothing leaves the machine; the history lives in the panel's own database, and the new `/api/metrics` endpoint needs a signed-in session like every other one.
- The CPU history is calculated separately from the live CPU card, so the two do not disturb each other.

---

## v1.8.1: Email notifications for alerts (2026-11-08)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_1.8.1_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Email notifications for alerts.** On the Alerts page, under *Email*, enter your mail server, port, user name, password, a *From* address and up to five *To* addresses, tick **Send alert emails**, and press **Send test email** to check that it works.
- While it is on, the panel checks every two minutes and sends **one message** when new problems appear and one when they clear. It does not repeat itself while a problem stays. Muted services are not mailed.
- Works with any mail server that offers STARTTLS (port 587) or SSL (port 465); for Gmail and similar, use an app password.

### Security notes
- The connection **must be encrypted** and the server's certificate is checked; unencrypted mail is refused, so the password never crosses the network in the clear.
- The password is stored in its own file in the data folder (readable only by the panel account), is never sent back to the browser, and is never written to the audit log. Leave the field empty to keep the saved password.
- Addresses, server name and port are validated, so a crafted value cannot add extra mail headers or recipients.
- Saving the settings, test emails and failed sends are written to the audit log.

---

## v1.8.0: Alerts (2026-11-08)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_1.8.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Alerts.** A new page (System, after Logs) lists problems found on the machine right now:
  - a **disk** that is filling up (warning at 85 %, critical at 95 % by default; each real disk is checked once),
  - **memory** running out (warning at 90 % used),
  - **failed services** (a failed `.service` is critical).
- **An alert count in the top bar** on every page (for example "3 alerts", red when anything is critical). It refreshes once a minute and links to the Alerts page.
- **Settings on the page:** change the three thresholds, and **mute** a service you know is failing and have decided to ignore. Muted services are not counted. Saving settings is written to the audit log.

### Notes
- Alerts only read the machine; nothing is changed or restarted by this page. There is no separate alert history, so the list is always the current state.
- Email notifications are not part of this release. They need mail-server settings and a stored password, so they will come separately.

---

## v1.7.0: A proper Logs page (2026-11-08)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_1.7.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Logs is now in the sidebar** (System, after Accounts). The journal viewer already existed but had no menu entry, so it could only be reached by typing `/logs.html`.

### Changed
- **The Logs page is rebuilt** to read like a log browser:
  - Newest entries first, grouped under a heading for each day, with a *Reboot* marker where the machine restarted.
  - **Priority** works as "X and above" (Only emergency … Debug and above), so choosing *Error and above* shows errors, critical, alert and emergency together. The default is *Info and above*.
  - **Identifier** drop-down lists every source that has written to the journal (`sshd-session`, `kernel`, `systemd`, …), so you no longer type unit names.
  - Search as you type, and a **Pause** / **Resume** button instead of the Follow checkbox. New entries arrive automatically unless paused.
  - Identical lines that follow each other are folded into one row with a count.
  - Warnings and errors have a warning icon; Download still saves what is shown.
- The journal API gains `ident` (filter by identifier) and `/api/journal/identifiers`. All input is validated as before.

---

## v1.6.1: Remote services under Servers (2026-11-08)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_1.6.1_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Changed
- **Remote services now lives under Servers.** The sidebar has one *Servers* entry with two tabs at the top of the page: **AdminPanel servers** (the list of other AdminPanel servers, as before) and **Remote services** (services, boot state and power for machines you manage over SSH). Both pages work exactly as before; only where you reach them changed.
- *Servers* stays highlighted on both pages, and the sidebar search finds it for `remote`, `ssh`, `bridge`, `reboot` and `shut down`.
- Old bookmarks to `/remote.html` keep working.

---

## v1.6.0: VPN and Proxy under Networking (2026-11-08)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_1.6.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Changed
- **VPN and Proxy now live under Networking → Configuration.** The sidebar has one *Networking* entry. Its *Configuration* tab has three sub-tabs: **Interfaces**, **VPN** and **Proxy**. The VPN and Proxy pages work exactly as before; only where you reach them changed.
- The *Networking* entry stays highlighted while you are on VPN or Proxy, and the sidebar search still finds them (typing `vpn`, `proxy` or `wireguard` shows *Networking*).
- Old bookmarks to `/vpn.html` and `/proxy.html` keep working.

---

## v1.5.1: Fix false update-running refusal (2026-11-08)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_1.5.1_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Fixed
- **Reboot and Shut down said "A software update is running" when none was.** On Ubuntu a background program, `unattended-upgrade-shutdown`, runs all the time, waiting for the machine to shut down. It has the same short process name as a real unattended upgrade, so the check mistook it for one. The check now tells them apart by their command line. This affected the buttons on the Overview page, the *Reboot required* chip, and rebooting other machines; the other machines need the new package too, because the check runs there.
- The refusal now names the process that is running (for example `dpkg`), so you can see what it is waiting for.

### Still protected
A real update (`apt`, `apt-get`, `dpkg` or an unattended upgrade in progress) still blocks Reboot and Shut down until it has finished.

---

## v1.5.0: Reboot and shut down other machines (2026-11-08)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_1.5.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New
- **Reboot and Shut down for other machines.** On the Remote services page, a new *Power* row under the machine's services. Each button asks you to type the machine's name from the list before it does anything. The panel writes `remote_power` (and `remote_power_failed` if it did not work) to the audit log with who, from where and which machine.
- The machine refuses while a software update (`apt` or `dpkg`) is running there, and says so.
- A machine that is shut down must be started again from outside (power button, or your hosting provider's console).

### To use it on a managed machine
The other machine needs the new package and a refreshed sudo rule:
```bash
sudo apt install ./adminpanel_1.5.0_all.deb
sudo adminpanel-setup remote-enable 'ssh-ed25519 AAAA... adminpanel-central'
```
(the same `remote-enable` line as before; run `sudo adminpanel-setup remote-key` on the central panel to print it again). If you skip this, the button explains what is missing instead of failing silently.

### Under the hood
- The bridge has one new operation, `power.act`, which accepts only `reboot` or `poweroff`. It checks everything first (update running, sudo rule present), sends its answer, and only then starts the shutdown, so the central panel always gets a clear reply.
- The sudo rules are the two added in 1.4.0 (`systemctl --no-block reboot` and `poweroff`, exact arguments); `remote-enable` copies them for the bridge's account.
- The update check and the command now live in `actions.py` and are shared by the local Power buttons and the bridge.

---

## v1.4.1: Reboot from the Reboot required chip (2026-11-08)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_1.4.1_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Changed
- **The "Reboot required" chip in the top bar now reboots.** After updates that need a restart, click it on any page, type the machine's name and confirm. Before, it only linked to the software updates page. It uses the same confirmation, update check and audit entry as the Reboot button on the Overview page.

---

## v1.4.0: Reboot and Shut down buttons (2026-11-08)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_1.4.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### New
- **Reboot and Shut down buttons** in a new *Power* section at the bottom of the Overview page. Each asks you to type the machine's own name before it does anything, so a stray click cannot restart a server. A machine that is shut down has to be started again from outside (power button, or your hosting provider's console).
- The buttons refuse while a software update (`apt` or `dpkg`) is running, because stopping one half way can leave packages broken.
- Every attempt is written to the audit log first (`power_action`, `power_refused`, `power_failed`), with who, from where and which machine.

### Under the hood
- New module `power.py` with `POST /api/power/reboot` and `POST /api/power/poweroff`. The command runs after the answer has been sent.
- Two new sudo rules: `systemctl --no-block reboot` and `systemctl --no-block poweroff`, with those exact arguments.
- This works on the machine the panel runs on. Other machines on the Remote services page are not affected.

---

## v1.3.1: Append-only audit log (2026-11-08)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_1.3.1_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Security
- **The audit log is append-only.** `/opt/adminpanel/data/audit.log` is marked append-only (`chattr +a`), so the panel account can add lines but cannot erase, rewrite, rename or delete them, even if the panel is taken over. Only root can lift the mark (`sudo chattr -a /opt/adminpanel/data/audit.log`). The copy in the system journal stays as a second safeguard.
- Weekly log rotation lifts the mark for a moment and sets it again afterwards. Removing the package does the same before it deletes the folder.
- `adminpanel-selfcheck` reports whether the audit log is append-only. On a file system that does not support the mark (rare) it shows a warning and the journal copy remains the safeguard.

---

## v1.3.0: Root-owned program files (2026-11-08)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_1.3.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Security
- **The panel can no longer rewrite its own program.** Until now the service account owned `/opt/adminpanel`, so anyone who found a flaw in the panel could change the panel's code and make the change survive a restart. The program files (and the Python environment) are now owned by root. The panel account can write only in `/opt/adminpanel/data`.
- **Everything the panel saves lives in `/opt/adminpanel/data`:** `users.json`, `panel.db` and `audit.log`. The upgrade moves your existing files there by itself (the panel is stopped for a moment while it does), so your administrators, 2FA, sessions and audit history stay as they were.
- `adminpanel-selfcheck` now checks that the panel account cannot change its own program files, and reports data files left in the old place.
- Log rotation of `audit.log` follows the new location.

### For developers
`deploy.sh` keeps the program files root-owned and leaves `data/` alone. `ADMINPANEL_DATA` points the panel at another data folder.

---

## v1.2.2: Require 2FA and tighten sign-in (2026-11-08)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_1.2.2_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

**Before you upgrade:** every panel administrator now needs two-step verification. Check with `sudo adminpanel-selfcheck` after upgrading; if it lists an account, run `sudo adminpanel-setup 2fa` on the server (SSH still works, so you cannot be locked out of the machine).

### Security
- **Two-step verification is required to sign in.** An account without it is refused with a message that says what to run. A wrong password still counts as a failed attempt; a right password on an account without 2FA does not.
- **Admin passwords must contain at least one symbol** (for example `!`, `@`, `#`, `-`, `_`). The minimum length stays at 8. This applies when you create an administrator or reset a password; existing passwords keep working.
- **Per-account sign-in limit.** Besides the existing 5 failures per address and user in 5 minutes, an account is now paused after 20 wrong attempts from all addresses together, so guessing from many addresses at once no longer gets unlimited tries.
- **Stricter service settings.** The panel's systemd unit now also blocks kernel module loading, kernel log access, cgroup and clock changes, hostname changes, new namespaces and non-native system calls, and creates files private to the panel by default.
- `adminpanel-selfcheck` reports any administrator without two-step verification.

### Emergency switch
If you ever lose the authenticator and the recovery codes, run `sudo adminpanel-setup 2fa` on the server. As a last resort, set `Environment=ADMINPANEL_ALLOW_NO_2FA=1` in a drop-in for `adminpanel.service`; remove it again afterwards.

---

## v1.2.1: Hide the boot state of ssh (2026-11-07)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_1.2.1_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Changed
- **No boot state for `ssh`.** On Ubuntu 24.04 SSH starts through `ssh.socket`, so the `ssh` service itself reads "disabled" even though SSH comes up at boot. The Services tables no longer show a boot state for `ssh`, because it only looked like a problem.
- **Remote services page text** now says that services can also be set to start at boot.

Nothing needs to be done on the other machines: only the panel machine changes.

---

## v1.2.0: Enable and disable services at boot (2026-11-07)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_1.2.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Enable and disable at boot.** The Services table on the Overview page and the Remote services page now show whether each service starts at boot ("active/running · boot: enabled") and offer one button to change it: "disable at boot" for an enabled service, "enable at boot" for a disabled one. These only change what happens at the next boot. They never start or stop the service now.
- Works for `nginx` and `cron`, on this machine and on other machines through the bridge. `ssh` is deliberately left out, so a mistake cannot stop you signing in after a reboot.
- Every change is written to the audit log like the other service actions (`service_action`, with `host` and `host_name` for other machines).

### Upgrade notes
- **This machine:** nothing to do. The package installs the new sudo rule.
- **Other machines you manage:** install 1.2.0 there, then run `sudo adminpanel-setup remote-enable 'ssh-ed25519 AAAA... adminpanel-central'` once more. Without it the new buttons answer "This machine's sudo rule is older. Run 'sudo adminpanel-setup remote-enable' there again"; everything else keeps working. The key is the line already in `/var/lib/adminpanel-remote/.ssh/authorized_keys` (its last two fields).

---

## v1.1.1: Audit log names the remote machine (2026-11-06)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_1.1.1_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Changed
- **Audit log shows the machine's name.** Entries for actions on another machine (`service_action`, `remote_logs_read`) now carry `host_name` (for example `"host_name": "ubuntu"`) next to the short `host` id, so the log can be read without looking the id up. Entries for this machine are unchanged.

Nothing needs to be done on the other machines: only the panel machine changes.

---

## v1.1.0: Run the remote bridge from a root-owned folder (2026-11-06)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_1.1.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Fixed
- **Remote machines answered "No usable answer from that server".** On a machine set up with `remote-enable`, the bridge could not start, because it was run from `/opt/adminpanel`, a folder only the panel's own account may enter. The bridge now has its own root-owned folder, `/usr/lib/adminpanel-bridge/`, and `remote-enable` points the key there. The panel's account can no longer change the code the bridge runs either.

### Changed
- `remote-enable` needs the 1.1.0 package on the machine (it checks for the new folder) and removes the `adminpanel-remote` user from the `adminpanel` group if an earlier workaround added it.
- **For every machine you set up before:** install 1.1.0 on it and run the same `sudo adminpanel-setup remote-enable '...'` line again. See [docs/REMOTE.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/REMOTE.md).

---

## v1.0.9: Fix button labels (2026-11-06)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_1.0.9_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Fixed
- **Button labels showing codes.** In the File manager the buttons showed the text `…`, `←`, `→`, `↑` and `⟳` instead of "Connect another…" and the back, forward, up and refresh arrows. The same happened to "Unlock…" and "Create volume group…" on the Storage page and "Import a client config…" on the VPN page. The labels now show the right characters.

---

## v1.0.8: Remote server facts and service logs (2026-11-06)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_1.0.8_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Machine facts on the Remote services page.** Choosing a machine now shows its name, system, kernel, uptime, load, memory and disk, read through the same restricted bridge.
- **Service logs.** Each service has a **log** button that shows the last 50, 100, 200 or 500 journal lines of that service on the other machine, with Reload and Close. Only nginx, cron and ssh can be read, nothing else from the journal. Every read is written to the audit log (`remote_logs_read`).
- New bridge operations `system.info` and `logs.tail`; new endpoints `GET /api/remote/info` and `GET /api/remote/logs` (panel login needed).

### Changed
- `adminpanel-setup remote-enable` adds the bridge user to the `systemd-journal` group so logs can be read. **For a machine you already set up, run the same `remote-enable` command once more.**

### Known limitations
- Still read-only apart from the start, stop and restart of the three allowed services. The Terminal, File manager and other pages work on this machine only.

---

## v1.0.7: Remote services page (2026-11-06)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_1.0.7_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Remote services page.** Pick a machine you listed with `adminpanel-setup add-host` and see its allowed services (nginx, cron, ssh), with start, stop and restart buttons. Every action asks first ("restart nginx on web1?"), runs on that machine through its bridge, and is written to the audit log with the machine's name. If a machine cannot be reached, or its host key has changed, the page says so in plain words. If no machine is listed yet, the page shows the three setup steps. See [docs/REMOTE.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/REMOTE.md).
- `GET /api/remote/hosts` returns the listed machines (id, name, address, port only; never the key or user name). It needs a panel login.

### Known limitations
- Only the Services actions work on other machines so far. The other pages, including the Terminal and File manager, still work on this machine only.

---

## v1.0.6: Remote setup commands (2026-11-06)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_1.0.6_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Set up other machines with `adminpanel-setup`.** Three steps: `sudo adminpanel-setup remote-key` on the central panel prints a command; run it on the other machine (`remote-enable`) to let the panel's key run the bridge and nothing else; then `sudo adminpanel-setup add-host NAME ADDRESS` on the central panel shows the other machine's SSH host key fingerprint, asks you to confirm it, pins it and tests the connection. Also `list-hosts`, `remove-host NAME` and `remote-disable`. The Servers and Services pages do not use this yet; a host selector comes next. See [docs/REMOTE.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/REMOTE.md).

### Security
- The panel's key for other machines and the pinned host keys are root-owned: the panel can read them but cannot change them.
- `remote-enable` accepts only a plain `ssh-ed25519` key line, creates a user with no password, and gives the key a forced command with `restrict`. `add-host` changes nothing unless the fingerprint is confirmed.

---

## v1.0.5: Bridge foundation (2026-11-06)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_1.0.5_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Foundation for managing other machines from one panel (not visible yet).** A small program, `bridge.py`, can run on another machine over SSH and do only a fixed list of operations (`ping`, `services.list`, `services.act`). The panel has a client for it (`remote.py`) and the Services routes accept `?host=<id>`. There is no host selector and no add-host command yet; they come in the next releases. See [docs/REMOTE.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/REMOTE.md).

### Changed
- The service list and the start/stop/restart logic moved from `services.py` into `actions.py` so the panel and the bridge share one copy. On this machine the commands, the checks and the audit entries are unchanged.

### Security
- The bridge refuses unknown operations, extra arguments, malformed requests and requests over 64 KB, and re-checks the service name and action itself. A remote host's SSH key is checked against a root-owned list of pinned host keys that the panel cannot change.

---

## v1.0.4: Servers page (2026-11-06)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_1.0.4_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Servers page (System > Servers).** List the other AdminPanel servers you manage, see at a glance whether each one is up and which version it runs, and open its panel in a new tab. Each server keeps its own administrators, 2FA and audit log; nothing is shared or proxied. Add a server by its address, then confirm its certificate fingerprint against the other machine; if that certificate ever changes the row turns red and has to be accepted again by hand. See [docs/FLEET.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/FLEET.md).
- **`GET /api/health`.** Needs no login and returns only `{"app": "adminpanel", "version": "..."}`. It is what the Servers page asks the other servers.

### Security
- The page only makes `https://` requests, refuses link-local addresses, gives up after 4 seconds, reads at most 4 KB, never follows redirects, and writes every change to the audit log.

### Known limitations
- Panels older than 1.0.4 show as "Not AdminPanel" until they are upgraded.

---

## v1.0.3: File manager review fixes (2026-11-05)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_1.0.3_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Security
- **The File manager no longer shows whether a Linux account exists.** A name that did not exist was turned away at once, while a real account took a moment longer to check, so the difference in time gave the name away. Both now go to the SSH server the same way and answer with the same message.

### Fixed
- **The File manager works when the account's login shell is not bash.** Commands such as copy, move, delete, folder size and free space were sent through the account's login shell with bash-style quoting. In `tcsh` a name containing `!` made them fail, and other shells can treat other characters differently. The commands are now sent as plain letters and digits and run by `/bin/sh`, so every login shell handles them the same way.
- **A file whose name contains a line break can be downloaded.** Before, the download failed because the line break ended up in the response header.
- **Opening a folder with a very large number of files no longer loads the whole folder at once.** The panel reads the listing as it arrives and stops after 100,000 entries (it still shows at most 5,000 and says the list is cut short).

---

## v1.0.2: Terminal SSH key sign-in fix (2026-11-05)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_1.0.2_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Fixed
- **Signing in to the Terminal with an SSH key now works.** The Terminal showed `no such identity: /dev/fd/16` and `Permission denied`. The key was handed to `ssh` as an open file, but `ssh` closes every file it did not open itself when it starts, so it never saw the key. The key is now written to a private file (mode 600, in its own mode 700 folder, in RAM under `/dev/shm`) just before `ssh` starts, and removed after 30 seconds or when the session ends, whichever comes first. The File manager's key sign-in was not affected.

### Changed
- The key is no longer described as "held in memory only": for up to 30 seconds it exists as a RAM-backed file readable only by the panel's own account. It is still never logged, and never written to a disk.

---

## v1.0.1: File manager sign-in wait (2026-11-05)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_1.0.1_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Fixed
- **A wrong password in the File manager no longer sends you back to the main panel login.** The server answered "wrong password" with the same code it uses for "your panel session has ended", so the browser logged you out of the page. A wrong Linux password now stays on the File manager sign-in card and shows an error. The main panel login only appears when your panel session really ended.

### Changed
- **Three tries, then a 30-second wait.** After 3 wrong passwords in a row the File manager sign-in form pauses for 30 seconds. The Connect button counts the seconds down and nothing is sent to the SSH server while you wait (not even a correct password). Each wrong password shows how many tries are left. A correct password resets the count, and the same wait applies to the SSH-key form.
- The existing limit still applies on top: 5 failed sign-ins in 5 minutes (per browser address and panel user), and 10 in 5 minutes per Linux account, lock sign-in for a few minutes. So after the first 3 wrong passwords and the wait, 2 more wrong ones reach that lock.

---

## v1.0.0: File manager security fixes (2026-11-04)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_1.0.0_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Security
- **A successful File manager sign-in no longer resets the failed-sign-in counter.** The counter is shared with the Terminal, so someone with a panel session and one account they knew the password for could wipe it between guesses at another account. Failures now stay counted until their 5-minute window ends.
- **A burst of simultaneous guesses can no longer get past the limit.** The File manager now counts an attempt before it tries the password (and gives it back if the password turns out to be right, or the SSH server could not be reached), so 30 requests sent at once get at most 5 guesses, not 30.
- **The File manager now uses the per-account limit too.** 10 failures in 5 minutes against one Linux account lock it for the File manager as well as the Terminal, from any browser address.
- **Simultaneous File manager sign-ins can no longer exceed the connection limits** (3 accounts per browser session, 8 in total). Sign-ins still in progress now count towards the limits.
- **Free disk space in a folder is now read as the signed-in account**, not by the panel itself, so it can no longer reveal the free space of folders that account cannot open.

### Fixed
- **File manager sign-in accepts account names with capital letters and dots** (for example `john.doe`). Release 0.9.9 said it did, but the sign-in form still used the old lowercase-only rule. The Terminal was not affected.
- **Saving a file you opened through a symbolic link no longer replaces the link with a regular file.** The editor now writes to the file the link points to and leaves the link alone.
- **Saving a file keeps its owner.** When saving through a temporary file would give the file a different owner, the editor writes the file in place instead.

### Known limitations
- Saving through a temporary file (used when the folder is writable and the owner stays the same) does not carry over extended attributes or ACLs.
- A file whose name contains a line break cannot be downloaded: the server refuses the header and the download fails. It is not a security problem.

---

## v0.9.9: optional SSH group limit, more account names (2026-11-03)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_0.9.9_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Limit password sign-in over SSH to one group (optional).** `adminpanel-setup` allows password sign-in over SSH from this machine only, so the Terminal and File manager can work. By default that applies to every account. You can now limit it to the members of one group:

  ```bash
  sudo adminpanel-setup ssh-restrict adminpanel-ssh     # creates the group if it does not exist
  sudo usermod -aG adminpanel-ssh YOURNAME              # add each account that needs the Terminal / File manager
  ```

  Accounts that are not in the group can then no longer sign in to the Terminal or File manager. To go back to "every account", run `sudo adminpanel-setup ssh-restrict off`. The change is checked with `sshd -t` before it is applied and is undone automatically if the SSH server rejects it. Nothing changes unless you run this command, and running `adminpanel-setup` again does not undo it.

### Changed
- **Terminal and File manager accept more Linux account names.** Names with capital letters and dots (for example `john.doe`) now work. A name still has to start with a letter or `_`, so it can never be read as an SSH option.

### Known limitations
- Any panel administrator can still try any non-root account in the Terminal; the account's password is the only gate. With the group limit above, only group members can sign in.

---

## v0.9.8: Terminal security fixes (2026-11-03)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_0.9.8_all.deb
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Security
- **The pinned SSH host key can no longer be changed by the panel.** The Terminal and File manager check that they are talking to this machine's own SSH server by comparing its host key with a saved copy. That copy was kept in the panel's own folder, so anything that took over the panel could swap it and read passwords typed into the Terminal. It now lives in `/var/lib/adminpanel/ssh_known_hosts`, owned by root, which the panel can read but not change. Upgrading moves it automatically and re-reads the key from the machine's real host key; `adminpanel-selfcheck` fails if the old location is still in use.
- **The Terminal session limit now holds when connections arrive at the same moment.** Before, several simultaneous connections could all pass the limit check, so more than 2 per user (3 in total) could open. The slot is now reserved before the connection is accepted.
- **A failed Terminal sign-in now also counts against the Linux account being tried**, from any browser address: 10 failures in 5 minutes locks that account in the Terminal. The existing limit (5 per browser address and panel user) stays.
- **The Terminal now gives up after 10 seconds** if it cannot reach the SSH server (`ConnectTimeout`).

### Fixed
- A malformed message from the browser (for example a window size of `Infinity`) no longer ends the Terminal session. It is ignored.
- The audit log entry `terminal_close` now includes `auth_failures`, the number of failed sign-ins in that session. The authoritative record of a successful sign-in remains the SSH server's own log (`/var/log/auth.log` or `journalctl -u ssh`).

### Known limitations
- Password sign-in over SSH is still allowed from this machine for every account (the `Match Address 127.0.0.1,::1` rule written by `adminpanel-setup`). Restricting it to a group needs a setup step that adds users to that group, so it is planned for a later release.
- Linux account names with capital letters or dots are not accepted by the Terminal.

---

## v0.9.7: web console address at login (2026-11-03)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_0.9.7_all.deb
sudo adminpanel-setup          # first install only
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Login message with the web console address.** After you sign in to the server (SSH or console) on Ubuntu, it shows, for example: `AdminPanel Web console: https://testserver1:8443/ or https://192.168.109.133:8443/`. It reads the current port and addresses each time, so it stays correct if you change them. It is installed as `/etc/update-motd.d/90-adminpanel`; edit or delete that file to change or hide the message (your edit is kept on upgrade). On Debian, which does not run `update-motd.d`, the message does not appear.

---

## v0.9.6: security follow-ups (2026-11-03)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_0.9.6_all.deb
sudo adminpanel-setup          # first install only
sudo adminpanel-setup tls      # existing installs: turns on the new security header (keeps your certificate)
sudo adminpanel-selfcheck
```

Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Security
- **Terminal sign-in lockout.** Wrong passwords typed into the Terminal now count against the same budget as the File manager: 5 failures in 5 minutes per browser address and panel user, kept across restarts. When the limit is reached the session is closed and new ones are refused until the window passes. Each failure is written to the audit log (`terminal_auth_failed`).
- **Software updates survive a panel restart.** `apt update` and `apt upgrade` now run as their own systemd unit (`adminpanel-apt-job`), so restarting or crashing the panel can no longer kill apt halfway through a package change. A restarted panel re-attaches to the running job and shows its log.
- **Content-Security-Policy.** The panel's pages now run only scripts served by the panel itself (inline scripts were moved to `static/page/*.js`). An existing install gets the header after `sudo adminpanel-setup tls`; `adminpanel-selfcheck` warns until then.

### Changed
- `adminpanel-selfcheck` also checks for `systemd-run` and the CSP header.
- HSTS is not enabled (browsers ignore it for IP addresses, and it would block the self-signed-certificate warning bypass). A commented example is in the nginx site file for use with a real certificate.

---

## v0.9.5: live traffic graph (2026-11-02)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_0.9.5_all.deb
sudo adminpanel-setup          # first install only
sudo adminpanel-selfcheck
```

Upgrading from any earlier version: the same `apt install` line, then `sudo adminpanel-selfcheck`. Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Live traffic graph on the Networking tab.** A large graph of the last 3 minutes with a labelled rate axis, smooth download (green) and upload (blue) curves with a soft fill, an interface picker (it starts on the interface that carries the default route) and a hover read-out showing the exact rates. It follows the Dark and Light themes. The small per-interface graphs in the table stay.

---

## v0.9.4: Dark and Light themes (2026-11-02)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_0.9.4_all.deb
sudo adminpanel-setup          # first install only
sudo adminpanel-selfcheck
```

Upgrading from any earlier version: the same `apt install` line, then `sudo adminpanel-selfcheck`. Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Added
- **Dark and Light themes.** Press the **Light** / **Dark** button in the top bar (or in the corner of the sign-in page). Your choice is remembered in that browser; Dark stays the default. The Terminal, the overview and network charts, the log viewer and the file manager follow the theme too, and a change in one browser tab updates the others.
- The package build now checks that `theme.js` is present.

---

## v0.9.3: Systemd units start/stop fixed (2026-11-02)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_0.9.3_all.deb
sudo adminpanel-setup          # first install only
sudo adminpanel-selfcheck
```

Upgrading from 0.9.0, 0.9.1 or 0.9.2: the same `apt install` line, then `sudo adminpanel-selfcheck`. Your accounts, certificate, port and settings are kept. Full guide: [docs/INSTALL.md](https://github.com/kofas3690/AdminPanel/blob/main/docs/INSTALL.md).

### Fixed
- **Starting and stopping system units from the Systemd units page now works.** The page called a root helper, `adminpanel-units`, that was missing from the package, so every action failed. The helper, its sudo rule, and its entries in the build, self-check and uninstall steps are now included.

### Safety rules of the new helper
- It accepts only two requests: `policy NAME` and `act ACTION NAME`. Names and actions are checked again as root, and actions are serialised with a lock.
- Protected units cannot be controlled from the web: the panel itself (`adminpanel*`), D-Bus, the journal, login, udev, networkd and resolved. Targets are view-only.
- `ssh` and `nginx` can be started, restarted or reloaded, but not stopped or disabled, so a click cannot lock you out.
- Every action is written to the system journal (`journalctl -t adminpanel-units`) and to the panel's audit log.
- `adminpanel-selfcheck` now checks that the helper is present and answers.

---

## v0.9.2: security and setup fixes (2026-11-01)

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_0.9.2_all.deb
sudo adminpanel-setup          # first install only
sudo adminpanel-selfcheck
```

Upgrading from 0.9.0 or 0.9.1: the same `apt install` line, then `sudo adminpanel-selfcheck`. Your accounts, certificate, port and settings are kept. Then open `https://SERVER-IP:8443` (or tunnel with `ssh -L 8443:127.0.0.1:8443 USER@SERVER-IP` and use `https://localhost:8443`). Full guide: [docs/INSTALL.md](docs/INSTALL.md).

### Security
- **The Terminal now refuses `root`** (and any account with UID 0), like the File manager. Opening terminals is limited to 10 per panel user per 5 minutes, which slows password guessing.
- The interactive API docs (`/docs`, `/redoc`, `/openapi.json`) are switched off.
- The audit log is also written to the system journal (`journalctl -t adminpanel-audit`), which the panel account cannot edit, and is rotated weekly (`/etc/logrotate.d/adminpanel`).
- A one-time 2FA code can no longer be used twice by two simultaneous sign-ins.

### Changed
- The panel administrator password needs at least 8 characters (was 12). Setup states the rule before asking, and asks again (up to 3 tries) instead of stopping.
- Removed the unused legacy `/api/files` module, which exposed `/var/log` read-only and pointed at a folder nothing creates.
- `adminpanel-setup` uses private temporary files.
- The package build now fails if the network-manager guard cannot be added.
- `deploy.sh` no longer copies docs, packaging files or machine-specific files into `/opt/adminpanel`.

### Known issues
- The Systemd units page can list units, but starting and stopping them needs a root helper that is not yet packaged. Use the Services page or the command line for now.

---

## v0.9.1: SSH key sign-in

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_0.9.1_all.deb
sudo adminpanel-setup          # first install only
sudo adminpanel-selfcheck
```

Then open `https://SERVER-IP:8443` (or tunnel with `ssh -L 8443:127.0.0.1:8443 USER@SERVER-IP` and use `https://localhost:8443`). Full guide: [docs/INSTALL.md](docs/INSTALL.md).

### Added
- **SSH key sign-in for the Terminal and File manager.** Both pages now offer **Sign in with: Password / SSH key**. Needed on VPS images that allow only key login.
- **Key pair generator** in the page: Ed25519, optional passphrase, shows the private key once, and gives a ready command that authorizes a restricted public key (`from="127.0.0.1,::1"`, no forwarding), so a stolen copy is useless from any other machine.
- Support for Ed25519, RSA and ECDSA keys in OpenSSH or PEM format, with passphrases. Clear messages for common mistakes: public key pasted by accident, PuTTY `.ppk` file, damaged or oversized key.
- Audit entries record the sign-in method (`key` or `password`), never the key.

### Security
- The key is used once: it is never stored or logged. In the Terminal it is held in an anonymous in-memory file (never written to disk) and passed to a single `ssh` process; a passphrase is typed into the terminal and never passes through the panel.
- Same protections as password sign-in: pinned SSH host key, no `root`, failed-attempt lockout, idle timeout, limits on concurrent terminals. A key that cannot be read does not count toward the lockout.
- The panel does not install keys into accounts on its own. You authorize the key as that account.

### Packaging
- New module `sshkeys` is included in the package (`MODULES` list in `packaging/build.sh`).

### Not included
- FIDO (`sk-`) and DSA keys, ssh-agent forwarding, and remembering keys between sessions.

---

## v0.9.0: first public release

**Install**

```bash
sudo apt update
sudo apt install ./adminpanel_0.9.0_all.deb
sudo adminpanel-setup
sudo adminpanel-selfcheck
```

### Highlights
- **Sign-in:** argon2 passwords, TOTP two-step verification with replay protection, one-time recovery codes, persistent sessions with a session list, lockout counters, HttpOnly / SameSite=Strict / Secure cookies.
- **Dashboard, Services** (system and per-user systemd units with System / User switch), **Logs** (live viewer and journal), **Updates** (APT), **Firewall** (UFW), **Users**.
- **Terminal** (xterm.js over SSH to this machine) and **File manager** (explorer-style SFTP, as a chosen non-root account).
- **Storage administration:** partitions, LVM, RAID (mdadm), LUKS encryption, iSCSI initiator and target, background secure-erase jobs. Destructive actions need password + authenticator unlock, typed confirmations and a preview of the exact commands; one rule protects the system disk.
- **Network manager:** activity, IP configuration, bridges, VLANs, bonds, WireGuard VPN (full tunnel, peer config generator), gateway/NAT, proxies, with automatic rollback.
- **Audit trail** of administrative actions.
- **Modern UI** with a sidebar layout shared by every page.

### Architecture and security
- The API runs as the unprivileged `adminpanel` user on `127.0.0.1:8000`; nginx provides HTTPS (self-signed certificate, login rate limit).
- Privileged work happens in small root-owned helpers in `/usr/local/sbin`, allowed through narrow sudoers rules, each re-validating its input. `adminpanel-selfcheck` verifies that the panel account cannot run arbitrary root commands.

### Packaging
- Debian package for Ubuntu and Debian-based systems (Python 3.10+, systemd), with `adminpanel-setup` (first-run setup) and `adminpanel-selfcheck` (installation check).
- `remove` keeps your data; `purge` deletes the panel's files and account but leaves settings it made for the machine (network files, `/etc/fstab` and `/etc/crypttab` lines marked `adminpanel`, RAID and VPN data).

### Known limitations
- Self-signed certificate (browser warning on first visit).
- The application code under `/opt/adminpanel` is owned by the service account, not root.
- Needs internet during install to download Python packages.
