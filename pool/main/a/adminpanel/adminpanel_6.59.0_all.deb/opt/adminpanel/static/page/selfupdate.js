/* Is a newer AdminPanel out? (6.51.0)  On the Overview: one line when there is. On Software updates: the details,
   how to update, Check now and the GitHub switch (administrators). It only tells; nothing is installed from here. */
(function () {
  const $ = (id) => document.getElementById(id);
  async function errText(r) {
    try { const j = await r.json(); if (typeof j.detail === "string") return j.detail; } catch (e) {}
    return "Request failed (" + r.status + ")";
  }
  const when = (t) => t ? new Date(t * 1000).toLocaleString() : "not yet";

  function banner(d) {
    const p = $("panelupd");
    if (!p) return;
    if (!d.newer) { p.hidden = true; return; }
    p.replaceChildren(document.createTextNode("AdminPanel " + d.latest + " is available (this server has " + d.current + "). "));
    const a = document.createElement("a"); a.href = "/updates.html#panel"; a.textContent = "How to update";
    p.appendChild(a);
    p.hidden = false;
  }

  function details(d) {
    const box = $("selfupd");
    if (!box) return;
    let t;
    if (d.newer) t = "AdminPanel " + d.latest + " is available. This server has " + d.current + ".";
    else if (d.checked) t = "AdminPanel " + d.current + " is the newest version found.";
    else t = "AdminPanel " + d.current + ". Not checked yet.";
    t += " Last checked: " + when(d.checked) + ".";
    if (d.github_off) t += " GitHub is not asked (switched off below); only apt is.";
    else if (d.github_error) t += " GitHub: " + d.github_error + ".";
    if (!d.apt_repository) t += " This server does not have the AdminPanel APT repository added, so apt cannot update it.";
    box.textContent = t;
    box.className = d.newer ? "warn" : "muted";
    const how = $("selfhow"), link = $("selfnotes");
    how.textContent = d.how || "";
    how.hidden = !d.how;
    if (link) { link.href = d.url; link.hidden = !d.newer; }
    $("selfgh").checked = d.enabled;
  }

  // 6.59.0: release notes. What is new since this version (from GitHub, at the last check) or this version's own notes.
  // Shown as plain text (textContent), never as HTML.
  function note(title, sub, text, url, open) {
    const d = document.createElement("details");
    d.className = "relnote";
    d.open = !!open;
    const s = document.createElement("summary");
    const b = document.createElement("b"); b.textContent = title;
    s.appendChild(b);
    if (sub) { const m = document.createElement("span"); m.className = "muted"; m.textContent = " " + sub; s.appendChild(m); }
    d.appendChild(s);
    const body = document.createElement("div");
    body.className = "reltext";
    body.textContent = text || "No notes here for this version yet.";
    d.appendChild(body);
    if (url) {
      const a = document.createElement("a");
      a.href = url; a.target = "_blank"; a.rel = "noopener"; a.textContent = "Open the release page";
      d.appendChild(a);
    }
    return d;
  }

  function releases(d) {
    const box = $("relbox"), list = $("rellist"), sum = $("relsum");
    if (!box || !list) return;
    list.replaceChildren();
    const newer = d.newer || [];
    if (newer.length) {
      sum.textContent = "What is new since " + d.current + " (" + newer.length + (newer.length === 1 ? " version)" : " versions)");
      newer.forEach((r, i) => list.appendChild(note(r.version, r.published || (r.source === "apt" ? "in apt; notes on GitHub" : ""),
        r.notes || (r.source === "apt" ? "apt offers this version. Its notes are on the release page." : ""), r.url, i === 0)));
      if (d.github_off) list.appendChild(Object.assign(document.createElement("p"), { className: "muted", textContent: "GitHub is not asked, so only apt's version is known." }));
    } else if (d.this && d.this.notes) {
      sum.textContent = "What is in " + d.current;
      list.appendChild(note(d.current + (d.this.title ? ": " + d.this.title : ""), d.this.date || "", d.this.notes, "", true));
    } else {
      box.hidden = true;
      return;
    }
    if (d.github_error) list.appendChild(Object.assign(document.createElement("p"), { className: "muted", textContent: "GitHub: " + d.github_error + "." }));
    box.hidden = false;
  }

  async function loadReleases() {
    try {
      const r = await fetch("/api/selfupdate/releases");
      if (r.ok) releases(await r.json());
    } catch (e) {}
  }

  async function load() {
    try {
      const r = await fetch("/api/selfupdate");
      if (!r.ok) return;
      const d = await r.json();
      banner(d); details(d);
    } catch (e) {}
    if ($("relbox")) loadReleases();
  }

  const say = (t) => { const m = $("selfmsg"); if (m) m.textContent = t; };
  if ($("selfcheck")) {
    $("selfcheck").onclick = async () => {
      $("selfcheck").disabled = true; say("Checking…");
      try {
        const r = await fetch("/api/selfupdate/check", { method: "POST" });
        if (!r.ok) { say(await errText(r)); return; }
        say(""); details(await r.json()); loadReleases();
      } catch (e) { say("Could not reach the panel."); }
      finally { $("selfcheck").disabled = false; }
    };
    $("selfgh").onchange = async () => {
      const on = $("selfgh").checked;
      const r = await fetch("/api/selfupdate/settings", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ enabled: on }) });
      if (!r.ok) { $("selfgh").checked = !on; say(await errText(r)); return; }
      say(on ? "GitHub will be asked again." : "GitHub will not be asked. apt is still read on this server."); details(await r.json());
    };
  }
  load();
})();
