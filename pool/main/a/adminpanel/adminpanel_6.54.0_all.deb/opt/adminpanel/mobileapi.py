"""Mobile API v1: the stable, versioned contract the AdminPanel Mobile app builds on.

Everything under /api/mobile/v1 follows the same rules (full text in docs/mobile-api-v1.md):
  * every reply is an envelope: {"ok": true, "data": ..., "request_id": ..., "server_time": {...}}
    or {"ok": false, "error": {"code": ..., "message": ...}, "request_id": ..., "server_time": {...}}
  * every reply carries an X-Request-ID header (the caller's own if it sent a sane one) that also goes in the audit log
  * the app asks GET /api/mobile/v1/capabilities first and shows only what that says the phone may do
  * capabilities are worked out by asking roles.decide(), the same function that enforces permissions, so the
    list can never say "yes" where the panel would say "no"
Later features (notifications, history, backups, audit) add endpoints here and turn their "features" flag on."""
import hashlib, json, re, threading, time, uuid
from pathlib import Path
from fastapi import APIRouter, Depends, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi.routing import APIRoute
from fastapi import HTTPException
import auth, roles, store
from auth import current_user

API_VERSION = 1
MIN_API_VERSION = 1
MIN_APP_VERSION = "0.6.0"
RID_RE = re.compile(r"^[A-Za-z0-9._-]{8,64}$")
CODES = {400: "bad_request", 401: "unauthorized", 403: "forbidden", 404: "not_found", 405: "method_not_allowed", 409: "conflict",
         413: "too_large", 422: "invalid_request", 429: "rate_limited"}


def server_version():
    try:
        return (Path(__file__).parent / "VERSION").read_text().strip()[:40] or "unknown"
    except OSError:
        return "unknown"


def server_time():
    now = time.time()
    return {"epoch": int(now), "iso": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(now))}


def new_request_id(supplied=None):
    return supplied if supplied and RID_RE.fullmatch(supplied) else uuid.uuid4().hex


def error_body(status, message, rid):
    return {"ok": False, "error": {"code": CODES.get(status, "server_error" if status >= 500 else "error"), "message": str(message)[:500]},
            "request_id": rid, "server_time": server_time()}


def reply(request, data):
    return {"ok": True, "data": data, "request_id": request.state.request_id, "server_time": server_time()}


# ---- Idempotency (docs/mobile-api-v1.md, section 4): one Idempotency-Key = one action, however often the phone retries
with store._lock:
    store._conn.execute("CREATE TABLE IF NOT EXISTS idem (user TEXT NOT NULL, key TEXT NOT NULL, action TEXT NOT NULL, body TEXT NOT NULL, "
                        "status INTEGER NOT NULL, resp TEXT NOT NULL, ts INTEGER NOT NULL, PRIMARY KEY (user, key))")
    store._conn.commit()
IDEM_MAX_ROWS = 500
_idem_lock = threading.Lock()


def idempotent(request, user, action, body, make):
    """Runs make() at most once per (user, Idempotency-Key) for 24 hours.
    make() returns (http_status, data). The same key with the same action and body replays the first result (header
    Idempotent-Replay: true) without running make() again; the same key for something else is 409. Failures (make()
    raising) are not remembered, so a retry after an error really retries. The key is required (8 to 64 characters)."""
    key = request.headers.get("idempotency-key", "")
    if not RID_RE.fullmatch(key):
        raise HTTPException(400, "Send an Idempotency-Key header (8 to 64 letters, digits, dots, dashes or underscores) with this request.")
    body_hash = hashlib.sha256(json.dumps(body, sort_keys=True).encode()).hexdigest()
    now = int(time.time())
    with _idem_lock:
        with store._lock:
            store._conn.execute("DELETE FROM idem WHERE ts < ?", (now - LIMITS["idempotency_ttl_seconds"],))
            row = store._conn.execute("SELECT action, body, status, resp FROM idem WHERE user=? AND key=?", (user, key)).fetchone()
        if row:
            if row[0] != action or row[1] != body_hash:
                raise HTTPException(409, "This Idempotency-Key was already used for a different request. Use a new key for a new action.")
            return JSONResponse(reply(request, json.loads(row[3])), status_code=row[2], headers={"Idempotent-Replay": "true"})
        status, data = make()
        with store._lock:
            store._conn.execute("INSERT OR REPLACE INTO idem (user, key, action, body, status, resp, ts) VALUES (?,?,?,?,?,?,?)",
                                (user, key, action, body_hash, status, json.dumps(data), now))
            store._conn.execute("DELETE FROM idem WHERE rowid IN (SELECT rowid FROM idem ORDER BY ts DESC LIMIT -1 OFFSET ?)", (IDEM_MAX_ROWS,))
            store._conn.commit()
    return JSONResponse(reply(request, data), status_code=status)


class V1Route(APIRoute):
    """Gives every v1 endpoint the request ID, the no-store header and the error envelope."""

    def get_route_handler(self):
        inner = super().get_route_handler()

        async def handler(request):
            rid = new_request_id(request.headers.get("x-request-id"))
            request.state.request_id = rid
            try:
                resp = await inner(request)
            except HTTPException as e:
                resp = JSONResponse(error_body(e.status_code, e.detail, rid), status_code=e.status_code, headers=e.headers)
            except RequestValidationError as e:
                first = (e.errors() or [{}])[0]
                resp = JSONResponse(error_body(422, f'{".".join(str(x) for x in first.get("loc", [])[1:])}: {first.get("msg", "invalid")}', rid), status_code=422)
            resp.headers["X-Request-ID"] = rid
            resp.headers["Cache-Control"] = "no-store"
            return resp
        return handler


router = APIRouter(prefix="/api/mobile/v1", route_class=V1Route)

# What each capability means, as a request the roles module can judge. Never hand-written yes/no.
PROBES = {
    "service_actions": ("POST", "/api/units/action"),
    "updates_run": ("POST", "/api/updates/run/upgrade"),
    "restart_schedule": ("POST", "/api/schedule/set"),
    "backup_run": ("POST", "/api/backup/start"),
    "reboot_now": ("POST", "/api/power/reboot"),
    "audit_view": ("GET", "/api/auditlog"),
}
# Features the server can serve. Each later release flips its own flag when its endpoints exist.
FEATURES = {"notifications": True, "metrics_history": True, "backups": True, "audit": True, "timeline": True, "maintenance": True, "service_dependents": True, "approvals": True, "presets": True, "temp_access": True, "push": True, "distro": True, "presets_edit": True, "freespace": True, "restore": True, "backup_check": True, "backup_delete": True, "vpn": True, "packages": True, "panel_update": True, "snippets": True, "instant_alerts": True, "server_status": False}
LIMITS = {"page_default": 50, "page_max": 100, "idempotency_ttl_seconds": 86400}


def capabilities_for(role, phone):
    out = {"view": role in roles.ROLES}
    for name, (method, path) in PROBES.items():
        out[name] = role in roles.ROLES and roles.decide(role, method, path, phone=phone) is None
    out["notifications"] = out["view"]
    out["audit_view"] = role == "admin"           # the web audit page is admin-only; the phone reads the redacted /audit, /timeline and /incidents instead
    out["approval_request"] = role in ("operator", "admin")      # a read-only phone arrives here as "viewer"
    out["approval_decide"] = role == "admin"
    out["presets_run"] = role in ("operator", "admin")            # a read-only phone arrives as "viewer"
    try:
        import presetsphone
        out["presets_edit"] = role == "admin" and presetsphone.enabled()     # admin on a full phone, and only when switched on in the web panel
    except Exception:
        out["presets_edit"] = False
    try:
        import backupphone
        out["restore"] = role == "admin" and backupphone.enabled()         # admin on a full phone, and only when switched on in the web panel
    except Exception:
        out["restore"] = False
    try:
        import backupphone
        out["backup_delete"] = role == "admin" and backupphone.delete_enabled()   # admin on a full phone, and only when switched on in the web panel
    except Exception:
        out["backup_delete"] = False
    try:
        import mobilepackages
        out["packages_change"] = role == "admin" and mobilepackages.why_not() is None     # admin on a full phone, switched on, no approval rule
    except Exception:
        out["packages_change"] = False
    out["temp_access"] = role == "admin"                          # handing out read-only access is an admin decision, from a full phone only
    out["push_info"] = role == "admin"                            # the topic works like a password for reading alerts: admin on a full phone only
    out["snippets"] = role == "admin"                             # 6.54.0: your own Terminal snippets, to look at and copy; admin on a full phone only
    try:
        import mobileapprovals
        pol = mobileapprovals.policy()
    except Exception:
        pol = {"updates_install": True, "backup_run": True}          # unreadable policy: say "approval needed", never the reverse
    out["approval_needed_updates"] = bool(pol.get("updates_install"))
    out["approval_needed_backup"] = bool(pol.get("backup_run"))
    out["maintenance"] = role == "admin"          # planning a quiet period is an admin decision; a read-only phone is a viewer here
    return out


def require(request, user, capability):
    """For later endpoints: refuse unless the caller has this capability. Server-side, so hiding buttons is never the only guard."""
    from fastapi import HTTPException
    ph = getattr(request.state, "phone", None)
    role = roles.role_of(auth.load_users().get(user))
    if ph and ph["ro"] and role:
        role = "viewer"
    if not capabilities_for(role, bool(ph)).get(capability):
        raise HTTPException(403, "Your role cannot do this from the phone app.")
    return role


@router.get("/capabilities")
def capabilities(request: Request, user: str = Depends(current_user)):
    ph = getattr(request.state, "phone", None)
    declared = roles.role_of(auth.load_users().get(user))
    effective = "viewer" if (ph and ph["ro"] and declared) else declared
    return reply(request, {
        "api_version": API_VERSION, "min_api_version": MIN_API_VERSION, "server_version": server_version(), "min_app_version": MIN_APP_VERSION,
        "identity": {"user": user, "role": declared, "effective_role": effective, "via": "phone" if ph else "browser",
                     "phone": {"id": ph["id"], "read_only": ph["ro"]} if ph else None},
        "capabilities": capabilities_for(effective, bool(ph)),
        "features": FEATURES, "limits": LIMITS,
    })
